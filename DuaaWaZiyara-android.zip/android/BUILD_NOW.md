# BUILD INSTRUCTIONS — READ FIRST, FOLLOW EXACTLY

## THE ONLY PERMITTED WORKFLOW
1. Extract this zip FRESH into an EMPTY directory. Never merge over a previous copy.
2. Run exactly:
   chmod +x gradlew && ./gradlew assembleDebug --stacktrace
3. DO NOT open, read, edit, "fix", reformat, or delete ANY file. Not one.
   The source is verified correct: SHA-256 manifest, brace/paren balance,
   lexer, and a 9-point integration check — all green on all 65 Kotlin files.

## WHY THIS RULE EXISTS
This project contains large UTF-8 Arabic data files (now capped at ~165KB per file, lines under 7KB).
Tools that load files into limited context windows TRUNCATE them on read.
Every previous "corruption" report (62,000 / 294 / 861 errors) was produced
AFTER an automated tool edited files based on its own truncated reads.
The genuine tree has compiled successfully before (v18.1.3, vCode 156).

## THE INTEGRITY GATE
`verifySources` runs automatically before compilation. It SHA-256-checks
every source file against tools/CHECKSUMS.txt:
- If it prints "65 files intact" then any error after it is genuine — report the `e:` lines verbatim.
- If it FAILS naming a file: that file was modified after extraction. Re-extract and retry WITHOUT editing.
- If tools/CHECKSUMS.txt is missing, the build fails by design. Re-extract.
- Deleting or editing the manifest or build.gradle.kts to bypass the gate is prohibited.

## PROJECT FACTS
- Kotlin files: 76 | Items: 549 | version 18.3.1 (versionCode 162)
- Gradle 8.11.1 (wrapper properties included; jar regenerates via `gradle wrapper --gradle-version 8.11.1` ONLY if gradle/wrapper/gradle-wrapper.jar is absent)
- JDK 17, compileSdk 36, minSdk 24
- Output: app/build/outputs/apk/debug/app-debug.apk

## REPORTING FAILURES
Report ONLY raw compiler `e:` lines plus the verifySources output above them.
Do not attempt repairs. Do not summarize. Paste verbatim.

## JDK REQUIREMENT (added v18.6.2)
The build must run on a FULL JDK 17+ (with javac), not a JRE.
If the build fails with "does not provide the required capabilities: [JAVA_COMPILER]":
  1. Install a full JDK 17:  apt-get install -y openjdk-17-jdk
  2. export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
  3. export PATH=$JAVA_HOME/bin:$PATH
  4. Verify BOTH print a version:  java -version   &&   javac -version
  5. Re-run: bash build-verify.sh
Toolchain auto-detection is disabled in gradle.properties, so Gradle uses the JVM it runs on.
