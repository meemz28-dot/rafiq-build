#!/usr/bin/env bash
# ============================================================
#  رفيق المؤمن — provenance-recording build
#  Run:  bash build-verify.sh
#  Return the ENTIRE console output plus build-transcript.txt
#  unedited. This transcript is the only accepted build report.
# ============================================================
set -uo pipefail
{
echo "==================== PROVENANCE TRANSCRIPT ===================="
echo "UTC: $(date -u '+%Y-%m-%d %H:%M:%S')"
echo "PWD: $(pwd)"
echo
echo "---- [1/4] Source fingerprints (compare against developer's manifest) ----"
sha256sum tools/CHECKSUMS.txt app/build.gradle.kts settings.gradle.kts
echo
echo "---- [2/4] Tree integrity gate ----"
bash tools/verify.sh
echo
echo "---- [3/4] Gradle environment ----"
chmod +x gradlew 2>/dev/null
(./gradlew --version 2>&1 || gradle --version 2>&1) | head -8
echo
echo "---- [4/4] Build (verifySources runs automatically before compile) ----"
( ./gradlew assembleDebug --stacktrace 2>&1 || gradle assembleDebug --stacktrace 2>&1 )
BUILD_EXIT=$?
echo
echo "---- Result ----"
echo "build exit code: $BUILD_EXIT"
ls -la app/build/outputs/apk/debug/ 2>/dev/null || echo "no APK directory produced"
echo "=================== END TRANSCRIPT ==================="
} 2>&1 | tee build-transcript.txt
