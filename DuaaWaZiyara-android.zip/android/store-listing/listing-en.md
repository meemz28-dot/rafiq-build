# Google Play listing (EN), Release 1.0

## Title (26/30)
Rafiq al-Mu'min: Shia Duas

## Short description (80/80)
Authentic Shia duas & ziyarat, prayer times, and a Hijri calendar of daily amaal

## Full description (2180/4000)
Rafiq al-Mu'min is your daily companion to your Lord: no ads, and it works entirely offline.

■ Authentic texts, with their sources
More than 560 texts transcribed word for word from established Shia sources, above all Shaykh Abbas al-Qummi's Mafatih al-Jinan, together with the complete al-Sahifa al-Sajjadiyya (all 54 supplications), Nahj al-Balagha, Risalat al-Huquq, and the complete Holy Quran (114 surahs). Every text shows its source.
• Famous duas: Kumayl, Tawassul, Nudba, Iftitah, Ahd, Abu Hamza al-Thumali, Jawshan and more
• Ziyarat: Ashura, Warith, Amin Allah, Arba'een, al-Jami'a al-Kabira, Aal Yasin, and the ziyarat of the Infallibles (as)
• The salawat on each of the Infallibles (as), from Shaykh al-Tusi's Misbah
• The fifteen munajat, post-prayer ta'qibat, morning and evening duas, and the duas of each weekday

■ A calendar that knows what today asks of you
137 day and night observances drawn from the months chapter of Mafatih al-Jinan: the Nights of Qadr, mid-Sha'ban, Arafa, Ghadir, Mab'ath and more. The "Today's amaal" card surfaces them automatically, and a reminder arrives at maghrib on nights that carry special acts.

■ Prayer times and qibla
Astronomically computed prayer times for your location (Ja'fari method and others), with the shar'i midnight, times of virtue, daily nawafil, prayer-time reminders, and the qibla direction.

■ Hajj and Umrah
Station duas in the order of the rites, and the ziyarat of Medina following the manasik of Sayyid Sadiq al-Hussaini al-Shirazi.

■ Tools for worship
Quran completion plans (30, 40 or 90 days), Tasbih of Lady Fatima (as), a step-by-step Salat al-Layl guide, self-accounting, missed-prayer tracking, Quran istikhara, a khums calculator, and a date converter.

■ Comfortable reading
Amiri typeface for sacred text, size and spacing control, diacritics on or off, an interactive reading mode, dark theme, and estimated reading time. Share any dua as a designed card.

■ Your privacy
No accounts, no ads, no tracking, no internet connection. Your data stays on your device.

Note: prayer times and month beginnings are approximate; take precaution in worship. For rulings, consult your marja's risala.

## Category
Books & Reference

## Contains ads: No. In-app purchases: No.
