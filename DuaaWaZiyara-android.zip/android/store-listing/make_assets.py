#!/usr/bin/env python3
# توليد أصول متجر Play بلغة التصميم نفسها: تدرّج تيل + شبكة گيري ثمانية + وهج ضوء
import math
from PIL import Image, ImageDraw, ImageFont, ImageFilter

FONT_DIR = "/home/claude/android/app/src/main/res/font"
OUT = "/home/claude/android/store-listing/assets"

TEAL_LIGHT = (95, 196, 208)
TEAL_MID   = (62, 148, 166)
TEAL_DEEP  = (43, 110, 132)
TEAL_NIGHT = (12, 40, 48)
GOLD       = (212, 168, 96)
WHITE      = (255, 255, 255)


def vgrad(size, stops):
    """تدرّج رأسي/قطري ناعم عبر عدّة محطّات لونية."""
    w, h = size
    img = Image.new("RGB", (1, h))
    px = img.load()
    n = len(stops) - 1
    for y in range(h):
        t = y / max(h - 1, 1)
        seg = min(int(t * n), n - 1)
        lt = (t * n) - seg
        a, b = stops[seg], stops[seg + 1]
        px[0, y] = tuple(int(a[i] + (b[i] - a[i]) * lt) for i in range(3))
    return img.resize((w, h), Image.BILINEAR)


def star8(d, cx, cy, rO, rI, fill=None, outline=None, width=2):
    pts = []
    for i in range(16):
        a = -math.pi / 2 + i * math.pi / 8
        r = rO if i % 2 == 0 else rI
        pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    d.polygon(pts, fill=fill, outline=outline, width=width)


def octagon(d, cx, cy, r, outline, width=2):
    pts = []
    for i in range(8):
        a = math.pi / 8 + i * math.pi / 4
        pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    d.polygon(pts, outline=outline, width=width)


def girih_layer(size, cell, alpha_main, alpha_soft, bloom):
    """شبكة الگيري ثلاثية الطبقات مع تلاشٍ قطريّ من منبع الضوء — كما في التطبيق."""
    w, h = size
    layer = Image.new("RGBA", size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    y = -cell
    while y < h + cell:
        x = -cell
        while x < w + cell:
            cx, cy = x + cell / 2, y + cell / 2
            star8(d, cx, cy, cell * 0.46, cell * 0.20, outline=(255, 255, 255, alpha_main), width=2)
            octagon(d, cx, cy, cell * 0.135, outline=(255, 255, 255, alpha_soft), width=2)
            d.line([(cx, cy - cell * 0.46), (cx, cy - cell / 2)], fill=(255, 255, 255, alpha_main), width=2)
            d.line([(cx + cell * 0.46, cy), (cx + cell / 2, cy)], fill=(255, 255, 255, alpha_main), width=2)
            x += cell
        y += cell
    # الشبكة المتشابكة المُزاحة بنصف خليّة
    y = -cell / 2
    while y < h + cell:
        x = -cell / 2
        while x < w + cell:
            cx, cy = x + cell / 2, y + cell / 2
            star8(d, cx, cy, cell * 0.26, cell * 0.115, outline=(255, 255, 255, alpha_soft), width=2)
            x += cell
        y += cell

    # قناع تلاشٍ قطريّ: كثافة عند منبع الضوء، خفوت عند الأطراف
    mask = Image.new("L", size, 0)
    md = ImageDraw.Draw(mask)
    bx, by = bloom
    maxr = max(w, h) * 1.05
    steps = 60
    for i in range(steps, 0, -1):
        r = maxr * i / steps
        v = int(255 * (1 - (i / steps) ** 1.5) * 0.85 + 30)
        md.ellipse([bx - r, by - r, bx + r, by + r], fill=min(v, 255))
    layer.putalpha(Image.composite(layer.getchannel("A"), Image.new("L", size, 0), mask))
    return layer


def sheen(size, bloom, strength=70):
    """وهج ضوء ناعم + ترسيخ سفليّ — نظير HeroSheen في التطبيق."""
    w, h = size
    lay = Image.new("RGBA", size, (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    bx, by = bloom
    maxr = max(w, h) * 0.62
    steps = 48
    for i in range(steps, 0, -1):
        r = maxr * i / steps
        a = int(strength * (1 - i / steps) ** 1.8)
        d.ellipse([bx - r, by - r, bx + r, by + r], fill=(255, 255, 255, a))
    lay = lay.filter(ImageFilter.GaussianBlur(18))
    # ظلّ سفليّ
    sh = Image.new("RGBA", size, (0, 0, 0, 0))
    sd = ImageDraw.Draw(sh)
    for y in range(int(h * 0.55), h):
        t = (y - h * 0.55) / (h * 0.45)
        sd.line([(0, y), (w, y)], fill=(0, 0, 0, int(58 * t)))
    return Image.alpha_composite(lay, sh)


def dome_layer(size, cx, base_y, width_, color):
    """قبة ومئذنتان وهلال — تُرسم على طبقة مستقلّة ليُقتطع الهلال اقتطاعاً صحيحاً."""
    lay = Image.new("RGBA", size, (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    r = width_ / 2
    # مئذنتان خلف القبة
    mw = r * 0.16
    for sx in (cx - r * 1.34, cx + r * 1.34):
        d.rectangle([sx - mw / 2, base_y - r * 1.05, sx + mw / 2, base_y], fill=color)
        d.pieslice([sx - mw * 0.95, base_y - r * 1.05 - mw * 0.95,
                    sx + mw * 0.95, base_y - r * 1.05 + mw * 0.95], 180, 360, fill=color)
        d.rectangle([sx - mw * 0.95, base_y - r * 0.62, sx + mw * 0.95, base_y - r * 0.56], fill=color)
    # القبة
    d.pieslice([cx - r, base_y - r * 1.30, cx + r, base_y + r * 0.70], 180, 360, fill=color)
    d.rectangle([cx - r, base_y - r * 0.06, cx + r, base_y], fill=color)
    # قاعدة
    d.rectangle([cx - r * 1.12, base_y, cx + r * 1.12, base_y + r * 0.10], fill=color)
    # الهلال: دائرة ثم اقتطاع دائرة مُزاحة على الطبقة نفسها
    top = base_y - r * 1.30
    cr = r * 0.21
    ccx, ccy = cx, top - cr * 1.15
    d.ellipse([ccx - cr, ccy - cr, ccx + cr, ccy + cr], fill=color)
    d.ellipse([ccx - cr * 0.30, ccy - cr * 1.05, ccx + cr * 1.45, ccy + cr * 0.95], fill=(0, 0, 0, 0))
    return lay


def ar(draw, xy, text, font, fill, anchor="ra"):
    draw.text(xy, text, font=font, fill=fill, anchor=anchor,
              language="ar", direction="rtl", features=["liga", "calt"])


def feature_graphic():
    W, H = 1024, 500
    base = vgrad((W, H), [TEAL_LIGHT, TEAL_MID, TEAL_DEEP]).convert("RGBA")
    base.alpha_composite(girih_layer((W, H), 96, 46, 26, (W * 0.22, H * 0.16)))
    base.alpha_composite(sheen((W, H), (W * 0.24, H * 0.10), strength=76))
    base.alpha_composite(dome_layer((W, H), 238, 356, 200, WHITE))
    d = ImageDraw.Draw(base)

    f_title = ImageFont.truetype(f"{FONT_DIR}/cairo_extrabold.ttf", 86)
    f_sub = ImageFont.truetype(f"{FONT_DIR}/cairo_semibold.ttf", 32)
    f_feat = ImageFont.truetype(f"{FONT_DIR}/cairo_medium.ttf", 25)

    ar(d, (W - 74, 138), "رفيق المؤمن", f_title, WHITE)
    ar(d, (W - 76, 252), "رفيقك إلى ربّك كلَّ يوم", f_sub, (255, 255, 255, 228))
    d.line([(W - 78, 318), (W - 430, 318)], fill=GOLD + (215,), width=3)
    ar(d, (W - 78, 340), "٥٥٠+ نصّاً موثّقاً", f_feat, (255, 255, 255, 215))
    ar(d, (W - 78, 380), "مواقيت · تقويم · ختمة · محاسبة", f_feat, (255, 255, 255, 215))
    base.convert("RGB").save(f"{OUT}/feature-graphic-1024x500.png", quality=96)
    print("feature-graphic-1024x500.png")


def promo_tile(name, title, sub, cell, size=(1080, 1080)):
    W, H = size
    base = vgrad(size, [TEAL_LIGHT, TEAL_MID, TEAL_DEEP]).convert("RGBA")
    base.alpha_composite(girih_layer(size, cell, 44, 24, (W * 0.24, H * 0.14)))
    base.alpha_composite(sheen(size, (W * 0.26, H * 0.10), strength=72))
    base.alpha_composite(dome_layer(size, W / 2, H * 0.50, 320, WHITE))
    d = ImageDraw.Draw(base)
    f_t = ImageFont.truetype(f"{FONT_DIR}/cairo_extrabold.ttf", 92)
    f_s = ImageFont.truetype(f"{FONT_DIR}/cairo_medium.ttf", 38)
    ar(d, (W - 90, H * 0.66), title, f_t, WHITE)
    ar(d, (W - 92, H * 0.785), sub, f_s, (255, 255, 255, 222))
    base.convert("RGB").save(f"{OUT}/{name}", quality=96)
    print(name)


if __name__ == "__main__":
    import os
    os.makedirs(OUT, exist_ok=True)
    feature_graphic()
    promo_tile("promo-square-1080.png", "رفيق المؤمن", "أدعية وزيارات ومواقيت", 120)
