# رفيق المؤمن: Release 1.0.0 Checklist

The codebase is release-ready. Remaining steps need your accounts or keys.

## 0. Blocker: a green build
Paste the `===== ERRORS =====` section from GitHub Actions. Nothing below can be tested until debug builds pass.

## 1. Two placeholders only you can fill
- [ ] Support email: replace `[SUPPORT EMAIL]` in `privacy-policy-en.md`, `privacy-policy-ar.md`, and `privacy-site/index.html`
- [ ] In-app feedback address: `app/src/main/java/com/shirazi/duaa/ui/Screens.kt`, the one line containing `feedback@rafiqalmumin.app`

## 2. Signing key (once; keep it forever, losing it means you can never update the app)
```
keytool -genkeypair -v -keystore keystore.jks -keyalg RSA -keysize 4096 -validity 10000 -alias duaa
```
Alias **must be `duaa`** (the build's default), or set `DUAA_KEY_ALIAS`. Back up `keystore.jks` and both passwords offline.

## 3. Build the signed AAB (GitHub Actions)
1. Encode the key: `base64 -w0 keystore.jks > keystore.b64`
2. Repo → Settings → Secrets → Actions, add: `KEYSTORE_BASE64` (file contents), `DUAA_STORE_PASSWORD`, `DUAA_KEY_PASSWORD`
3. Copy `github-release-workflow.yml` to `.github/workflows/release.yml`, run it manually (Actions → Release AAB → Run)
4. Download artifact `rafiq-release-aab` → `app-release.aab`

## 4. Host the privacy policy
Enable GitHub Pages on the repo, publish `store-listing/privacy-site/index.html`, and use its URL in Play Console.

## 5. Play Console: App content answers
| Form | Answer |
| --- | --- |
| Privacy policy | Your GitHub Pages URL |
| Ads | No ads |
| App access | All functionality available without login |
| Data safety: data collected | **None** (location is processed on-device only and never transmitted; Play does not count on-device-only processing as collection) |
| Data safety: data shared | **None** |
| Data safety: encryption in transit | Not applicable (no network) |
| Data deletion | Uninstalling deletes all data |
| Target audience | 13+ recommended |
| Content rating | Reference / religious text; no violence, sexual content, gambling or user interaction |
| Government / financial / health app | No |

## 6. Store listing
Upload from `listing-ar.md` (primary, Arabic) and `listing-en.md`; feature graphic `assets/feature-graphic-1024x500.png`; icon `assets/app-icon-512.png`; screenshots `assets/screenshots/` (see the Play Submission Kit); the 8 phone screenshots.

## 7. Launch sequence
Internal testing (you + 2 to 5 testers, 3 to 7 days) → check the pre-launch report → production. Recommended: scholar sign-off on the review pack before production.

## What changed for 1.0 (for the record)
- Version 1.0.0 (versionCode 192)
- Removed `USE_EXACT_ALARM` (restricted by Google Play to alarm-clock and calendar apps) and `INTERNET` (no code uses the network); added an in-app request for the "Alarms & reminders" permission so prayer reminders stay on time on Android 14+
- Rewrote listing and privacy policy against the verified current app; every listed feature confirmed in code
- Fixed signing instructions (alias and environment variable names now match `app/build.gradle.kts`)
