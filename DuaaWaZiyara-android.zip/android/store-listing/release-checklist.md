# Play Store Release Checklist — رفيق المؤمن v18.6

## 1) Signing (once)
keytool -genkeypair -v -keystore keystore.jks -keyalg RSA -keysize 4096 -validity 10000 -alias rafiq
Place keystore.jks at repo root (or set DUAA_KEYSTORE / DUAA_KS_PASS / DUAA_KEY_PASS env vars).
Build: ./gradlew bundleRelease  →  app/build/outputs/bundle/release/app-release.aab

## 2) Play Console — App content
- Privacy policy URL: host store-listing/privacy-policy-*.md (GitHub Pages works)
- Data safety: "No data collected, no data shared" (truthful — fully offline)
- Ads: No ads. Target audience: 13+. Content rating questionnaire: reference/religious text app.

## 3) Store listing
- Title: رفيق المؤمن — أدعية وزيارات ومواقيت
- Short (AR): رفيقك اليومي: مواقيت دقيقة، أدعية وزيارات موثّقة، تقويم هجري، ومحاسبة النفس.
- Short (EN): Shia daily companion: prayer times, authentic duas & ziyarat, Hijri calendar, self-accounting.
- Full description: see listing-full-ar.md
- Screenshots: 6–8 phone shots (portrait, 1080×2400+): الرئيسية، التقويم بيوم مفتوح، القارئ، الأوقات، المزيد، رحلتي
- Feature graphic 1024×500: dome/crescent monogram on teal #0F6273, gold accent, «رفيقك إلى ربّك كل يوم»

## 4) Pre-launch
- Internal testing track first → review pre-launch report → production.
