# Privacy Policy — Rafiq Al-Mumin (رفيق المؤمن)

Last updated: 2026

Rafiq Al-Mumin is designed to run entirely on your device.

- **We collect no data.** The app transmits no personal or non-personal information to any server.
- **Location** (if granted) is used locally only to compute prayer times and Qibla direction; it never leaves your device. You may instead pick a city manually.
- **Storage:** your preferences (favorites, streaks, font size, theme) are saved locally on your device only.
- **No ads, no trackers, no accounts.**
- **Permissions:** Location (optional) for times/Qibla; Notifications (optional) for prayer reminders.

Contact: feedback@rafiqalmumin.app
