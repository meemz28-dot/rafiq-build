# Privacy Policy: Rafiq al-Mu'min (رفيق المؤمن)

Last updated: September 27, 2026

Rafiq al-Mu'min runs entirely on your device. **The app has no internet permission and cannot send data anywhere.**

## What we collect
**Nothing.** We collect, store on servers, sell, or share no personal or non-personal data. There are no accounts, no ads, no analytics, and no third-party SDKs.

## Permissions and why
| Permission | Purpose | Required? |
| --- | --- | --- |
| Location (approximate or precise) | Computes prayer times and qibla direction on your device. It is never stored off the device or transmitted. You can choose a city manually instead. | Optional |
| Notifications | Prayer-time reminders and reminders for nights and days with special observances. | Optional |
| Alarms & reminders (exact alarms) | Delivers prayer reminders at the correct minute. | Optional; reminders still work without it but may be delayed |
| Run at startup | Restores your reminders after the phone restarts. | Automatic |
| Vibration | Gentle feedback in counters such as the tasbih. | Automatic |

## Data on your device
Your settings, favorites, reading progress, and self-accounting entries are saved only in the app's private storage on your device. Uninstalling the app deletes them.

## Sharing
When you choose to share a text, the app hands an image or text to the app you pick (e.g. WhatsApp). Nothing else is shared.

## Children
The app contains religious reference texts suitable for all ages and collects no data from anyone.

## Contact
[SUPPORT EMAIL — replace before publishing]
