plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.shirazi.duaa"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.shirazi.duaa"
        minSdk = 24
        targetSdk = 36
        versionCode = 162
        versionName = "18.3.1"
        vectorDrawables { useSupportLibrary = true }
    }

    signingConfigs {
        create("release") {
            val ksPath = System.getenv("DUAA_KEYSTORE") ?: "keystore.jks"
            val ksFile = file(ksPath)
            if (ksFile.exists()) {
                storeFile = ksFile
                storePassword = System.getenv("DUAA_STORE_PASSWORD") ?: ""
                keyAlias = System.getenv("DUAA_KEY_ALIAS") ?: "duaa"
                keyPassword = System.getenv("DUAA_KEY_PASSWORD") ?: ""
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (file(System.getenv("DUAA_KEYSTORE") ?: "keystore.jks").exists()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
        debug { applicationIdSuffix = ".debug" }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.01.00")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("androidx.compose.ui:ui-tooling-preview")
}

// ============================================================================
// بوّابة سلامة المصادر: تفشل البناء برسالةٍ واضحة إذا تلفت الملفات أثناء النقل
// (بدل آلاف أخطاء الصياغة الغامضة). للتجاوز عمداً: -PskipVerify
// ============================================================================
val verifySources = tasks.register("verifySources") {
    doFirst {
        if (project.hasProperty("skipVerify")) {
            println("verifySources: SKIPPED by -PskipVerify")
            return@doFirst
        }
        val checksums = rootProject.file("tools/CHECKSUMS.txt")
        if (!checksums.exists()) throw GradleException(
            "INTEGRITY MANIFEST MISSING: tools/CHECKSUMS.txt\n" +
            ">>> This file ships with the project and must not be deleted or edited.\n" +
            ">>> FIX: delete the project folder and re-extract the original zip fresh, then build WITHOUT modifying any file.")
        val md = java.security.MessageDigest.getInstance("SHA-256")
        var checked = 0
        checksums.readLines().forEach { line ->
            val parts = line.trim().split(Regex("\\s+"), limit = 2)
            if (parts.size == 2) {
                val want = parts[0]
                val path = parts[1].removePrefix("*")
                val f = rootProject.file(path)
                if (!f.exists()) throw GradleException(
                    "SOURCE FILE MISSING: $path\n>>> The extraction is incomplete. Delete the project folder and re-extract the zip fresh.")
                md.reset()
                val got = md.digest(f.readBytes()).joinToString("") { "%02x".format(it) }
                if (got != want) throw GradleException(
                    "SOURCE FILE CORRUPTED OR MODIFIED: $path\n" +
                    ">>> A tool edited or truncated this file after extraction (common with large UTF-8 Arabic files).\n" +
                    ">>> FIX: delete the project folder, re-extract the zip fresh, build WITHOUT editing any file.\n" +
                    ">>> (intentional local changes: build with -PskipVerify)")
                checked++
            }
        }
        println("verifySources: $checked files intact ✓")
    }
}
tasks.named("preBuild") { dependsOn(verifySources) }
