package com.shirazi.duaa.logic

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * كاشف حركات الصلاة (تجريبي) — يعتمد على مُستشعِر التسارع لتقدير وضعية الجذع.
 *
 * الفكرة: عند وضع الهاتف في جيب الصدر أو جيب أمامي، يكشف متّجهُ الجاذبية
 * ميلَ الجذع. نُصنّف الوضعية إلى: قيام، ركوع، سجود/جلوس، ثم نَعُدّ الركعات
 * بآلة حالات (state machine):  قيام → ركوع → قيام → سجدتان (بينهما جلوس) = ركعة.
 *
 * ملاحظة شرعية مهمة: هذا عدّادٌ مُعِين تقريبي وليس مرجعاً. لا يُعتمد عليه في صحّة
 * الصلاة؛ فقد يُخطئ بحسب وضع الهاتف وسرعة المصلّي. الغرض منه التذكير لا الإفتاء.
 *
 * كل الحساب داخل الجهاز، بلا إنترنت وبلا كاميرا.
 */
class PrayerMotionDetector(
    context: Context,
    private val onState: (Posture) -> Unit,
    private val onRakahCompleted: (Int) -> Unit,
    private val onSajdaCounted: (Int) -> Unit,
) : SensorEventListener {

    enum class Posture { STANDING, BOWING, PROSTRATING, SITTING, UNKNOWN }

    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accel: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    // مرشّح منخفض التمرير لعزل الجاذبية
    private val gravity = FloatArray(3)
    private var hasGravity = false
    private val alpha = 0.85f

    var rakahCount = 0; private set
    var sajdaCount = 0; private set
    private var posture = Posture.UNKNOWN
    private var lastStable = Posture.UNKNOWN
    private var stableSince = 0L

    // تتبّع تسلسل الركعة
    private var sawBowing = false
    private var sawStandingAfterBow = false
    private var prostrationsInThisCycle = 0
    private var lastPostureChangeT = 0L

    fun start() {
        accel?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        reset()
    }

    fun stop() { sm.unregisterListener(this) }

    fun reset() {
        rakahCount = 0; sajdaCount = 0
        posture = Posture.UNKNOWN; lastStable = Posture.UNKNOWN
        sawBowing = false; sawStandingAfterBow = false; prostrationsInThisCycle = 0
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        // عزل الجاذبية بمرشّح
        if (!hasGravity) {
            gravity[0] = e.values[0]; gravity[1] = e.values[1]; gravity[2] = e.values[2]; hasGravity = true
        } else {
            for (i in 0..2) gravity[i] = alpha * gravity[i] + (1 - alpha) * e.values[i]
        }
        val gx = gravity[0]; val gy = gravity[1]; val gz = gravity[2]
        val norm = sqrt(gx * gx + gy * gy + gz * gz).coerceAtLeast(0.0001f)

        // زاوية ميل المحور الطولي للهاتف عن الرأسي.
        // الهاتف عمودي في الجيب (قيام): gy ≈ +9.8 (محور y لأعلى).
        // الركوع ~90°: يميل الجذع للأمام، يكبر gz.
        // السجود: الهاتف شبه أفقي مقلوب، gz سالب كبير أو gy سالب.
        val gyN = gy / norm   // 1 = عمودي قائم
        val gzN = gz / norm

        val detected = when {
            gyN > 0.72f -> Posture.STANDING                 // الجذع رأسي
            gyN in 0.20f..0.72f && gzN > 0.45f -> Posture.BOWING  // مائل ~45-80°
            gzN > 0.78f || gyN < -0.35f -> Posture.PROSTRATING    // شبه أفقي / منكبّ
            gyN in 0.20f..0.72f -> Posture.SITTING          // جلوس بين السجدتين/تشهد
            else -> posture
        }

        val now = System.currentTimeMillis()
        if (detected != posture) {
            posture = detected
            stableSince = now
        }
        // نثبت الوضعية فقط إذا استقرّت ~400ms (لتجنّب الضجيج)
        if (posture != lastStable && now - stableSince > 400) {
            lastStable = posture
            onState(posture)
            handleTransition(posture)
        }
    }

    private fun handleTransition(p: Posture) {
        when (p) {
            Posture.BOWING -> { sawBowing = true; sawStandingAfterBow = false }
            Posture.STANDING -> { if (sawBowing) sawStandingAfterBow = true }
            Posture.PROSTRATING -> {
                sajdaCount++; onSajdaCounted(sajdaCount)
                prostrationsInThisCycle++
                // ركعة كاملة = ركوع ثم سجدتان
                if (sawBowing && prostrationsInThisCycle >= 2) {
                    rakahCount++; onRakahCompleted(rakahCount)
                    sawBowing = false; sawStandingAfterBow = false; prostrationsInThisCycle = 0
                }
            }
            else -> {}
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    companion object {
        fun isSupported(context: Context): Boolean {
            val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            return sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
        }
    }
}
