package com.shirazi.duaa.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.shirazi.duaa.data.Settings
import com.shirazi.duaa.logic.PrayerTimes
import java.util.Calendar

/**
 * جدولة تذكيرات الروتين اليومي المرتبطة بأوقات الصلاة الفعلية:
 *  - التعقيبات: تذكير بعد كل صلاة بدقائق قليلة (تسبيح الزهراء والتعقيب).
 *  - صلاة الليل: تذكير قبل الفجر بعدد الدقائق المختارة.
 * تُحسب الأوقات من مواقيت الصلاة لموقع المستخدم وطريقته، ليومين (اليوم والغد) لتغطية الانتقال.
 */
object RoutineScheduler {

    private const val TAQIB_BASE = 700   // معرّفات مستقلة عن الصلاة (0..) والأذكار (500..)
    private const val LAYL_BASE = 760
    private const val OCC_BASE = 780     // تنبيهات المناسبات: 780..783
    private const val TAQIB_DELAY_MIN = 6 // دقائق بعد دخول الوقت ليُتمّ المصلّي فريضته

    private val prayerSlots = listOf("fajr", "dhuhr", "asr", "maghrib", "isha")
    private val prayerNames = mapOf(
        "fajr" to "الفجر", "dhuhr" to "الظهر", "asr" to "العصر",
        "maghrib" to "المغرب", "isha" to "العشاء"
    )

    fun reschedule(context: Context) {
        val settings = Settings(context)
        cancelAll(context)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val loc = settings.location()
        val now = Calendar.getInstance()

        for (dayOffset in 0..1) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, dayOffset) }
            val t = PrayerTimes.compute(cal, loc.lat, loc.lng, loc.tz, settings.method.value)

            // ===== تذكير التعقيبات بعد كل صلاة =====
            if (settings.taqibatEnabled.value) {
                prayerSlots.forEachIndexed { i, slot ->
                    val hours = PrayerTimes.norm(PrayerTimes.value(t, slot))
                    val total = (hours * 60).toInt() + TAQIB_DELAY_MIN
                    val fire = atMinute(cal, total)
                    if (fire.timeInMillis > now.timeInMillis) {
                        val reqId = TAQIB_BASE + dayOffset * 10 + i
                        schedule(am, context, reqId, fire.timeInMillis,
                            "تعقيب صلاة ${prayerNames[slot]}",
                            "لا تنسَ تسبيح الزهراء (ع) والتعقيب بعد صلاتك")
                    }
                }
            }

            // ===== تنبيهات المناسبات من التقويم =====
            if (settings.occasionEnabled.value) {
                val jd = com.shirazi.duaa.logic.HijriCalendar.gToJd(
                    cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
                val h = com.shirazi.duaa.logic.HijriCalendar.jdToHijri(jd, settings.hijriAdj.value)
                val hNext = com.shirazi.duaa.logic.HijriCalendar.jdToHijri(jd + 1, settings.hijriAdj.value)
                val months = com.shirazi.duaa.logic.HijriCalendar.months

                // عشيّة الليلة: أعمال «الليلة» التابعة لليوم الهجري التالي، عند المغرب
                val nights = com.shirazi.duaa.data.Amaal.forDay(hNext.m, hNext.d)
                    .filter { it.d == hNext.d && it.title.startsWith("الليلة") }
                if (nights.isNotEmpty()) {
                    val mg = PrayerTimes.norm(PrayerTimes.value(t, "maghrib"))
                    val fire = atMinute(cal, (mg * 60).toInt() + 10)
                    if (fire.timeInMillis > now.timeInMillis) {
                        schedule(am, context, OCC_BASE + dayOffset * 2, fire.timeInMillis,
                            "الليلة ليلة ${hNext.d} ${months[hNext.m - 1]}",
                            "لها أعمالٌ مأثورة: " + nights.first().title.substringBefore(" · ") + " — افتح التقويم")
                    }
                }

                // صباح اليوم: الأيّام التي لها أعمال (عرفة، الغدير، المبعث...)، بعد الشروق بساعة
                val days = com.shirazi.duaa.data.Amaal.forDay(h.m, h.d)
                    .filter { it.d == h.d && !it.title.startsWith("الليلة") }
                if (days.isNotEmpty()) {
                    val sr = PrayerTimes.norm(PrayerTimes.value(t, "sunrise"))
                    val fire = atMinute(cal, (sr * 60).toInt() + 60)
                    if (fire.timeInMillis > now.timeInMillis) {
                        schedule(am, context, OCC_BASE + dayOffset * 2 + 1, fire.timeInMillis,
                            "اليوم ${h.d} ${months[h.m - 1]}",
                            days.first().title.substringBefore(" · ") + (if (days.size > 1) " وأعمالٌ أخرى" else ""))
                    }
                }
            }

            // ===== تذكير صلاة الليل قبل الفجر =====
            if (settings.laylEnabled.value) {
                val fajr = PrayerTimes.norm(PrayerTimes.value(t, "fajr"))
                val total = (fajr * 60).toInt() - settings.laylBeforeFajr.value
                if (total >= 0) {
                    val fire = atMinute(cal, total)
                    if (fire.timeInMillis > now.timeInMillis) {
                        val reqId = LAYL_BASE + dayOffset
                        schedule(am, context, reqId, fire.timeInMillis,
                            "وقت صلاة الليل",
                            "اقترب الفجر — أحيِ ليلك بصلاة الليل ولو ركعة الوتر")
                    }
                }
            }
        }
    }

    private fun atMinute(day: Calendar, totalMin: Int): Calendar {
        val h = (totalMin / 60).coerceIn(0, 23)
        val m = (totalMin % 60).coerceIn(0, 59)
        return (day.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
    }

    private fun schedule(am: AlarmManager, context: Context, reqId: Int, fireAt: Long, title: String, body: String) {
        val pi = pendingIntent(context, reqId, title, body)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setWindow(AlarmManager.RTC_WAKEUP, fireAt, 120_000L, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pi)
            }
        } catch (e: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, fireAt, pi)
        }
    }

    fun cancelAll(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (dayOffset in 0..1) {
            for (i in prayerSlots.indices) am.cancel(pendingIntent(context, TAQIB_BASE + dayOffset * 10 + i, "", ""))
            am.cancel(pendingIntent(context, LAYL_BASE + dayOffset, "", ""))
            for (k in 0..1) am.cancel(pendingIntent(context, OCC_BASE + dayOffset * 2 + k, "", ""))
        }
    }

    private fun pendingIntent(context: Context, reqId: Int, title: String, body: String): PendingIntent {
        val intent = Intent(context, DhikrReceiver::class.java).apply {
            action = "com.shirazi.duaa.ROUTINE_$reqId"
            putExtra("routineTitle", title)
            putExtra("routineBody", body)
        }
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags = flags or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, reqId, intent, flags)
    }
}
