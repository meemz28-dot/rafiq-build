package com.shirazi.duaa.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.shirazi.duaa.MainActivity
import com.shirazi.duaa.R

/** يستقبل منبّه الذِّكر أو الروتين فيُظهر الإشعار ثمّ يعيد الجدولة. */
class DhikrReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val routineTitle = intent.getStringExtra("routineTitle")
        if (routineTitle != null) {
            // تذكير روتين (تعقيبات / صلاة الليل / صدقة)
            val body = intent.getStringExtra("routineBody") ?: ""
            showNotification(context, routineTitle, body, routineTitle.hashCode() and 0xFFFF)
            if (intent.action == "com.shirazi.duaa.SADAQA") SadaqaScheduler.reschedule(context)
            else if (intent.action == "com.shirazi.duaa.KHUMS") KhumsScheduler.reschedule(context)
            else RoutineScheduler.reschedule(context)
            return
        }
        val idx = intent.getIntExtra("dhikrIdx", 0)
            .coerceIn(0, DhikrScheduler.ADHKAR.size - 1)
        val (title, body) = DhikrScheduler.ADHKAR[idx]
        showNotification(context, title, body, idx)
        // أعد الجدولة لضمان استمرار التذكيرات في الأيام التالية
        DhikrScheduler.reschedule(context)
    }

    private fun showNotification(context: Context, title: String, body: String, idx: Int) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "تذكير بالذِّكر", NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "تذكير لطيف بالصلوات والاستغفار والذكر خلال اليوم" }
            nm.createNotificationChannel(channel)
        }
        var flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            flags = flags or android.app.PendingIntent.FLAG_IMMUTABLE
        val openIntent = android.app.PendingIntent.getActivity(
            context, 1, Intent(context, MainActivity::class.java), flags
        )
        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(openIntent)
            .build()
        nm.notify(CHANNEL_ID.hashCode() + idx, notif)
    }

    companion object { const val CHANNEL_ID = "dhikr_reminders" }
}
