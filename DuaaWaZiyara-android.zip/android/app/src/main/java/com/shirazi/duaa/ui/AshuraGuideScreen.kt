package com.shirazi.duaa.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * دليل زيارة عاشوراء التفاعلي — يمشي بك خطوة بخطوة:
 * النيّة ← متن الزيارة ← اللعن ١٠٠ مرّة بعدّاد ← السلام ١٠٠ مرّة بعدّاد ← دعاء الختام ← السجدة.
 */
private const val ASHURA_LAN = """اللّهُمَّ العَنْ أَوَّلَ ظالِمٍ ظَلَمَ حَقَّ مُحَمَّدٍ وَآلِ مُحَمَّدٍ وَآخِرَ تابِعٍ لَهُ عَلى ذلِكَ، اللّهُمَّ العَنْ العِصابَةَ الَّتِي جاهَدَتِ الحُسَيْنَ وَشايَعَتْ وَبايَعَتْ وَتابَعَتْ عَلى قَتْلِهِ اللّهُمَّ العَنْهُمْ جَميعاً."""
private const val ASHURA_SALAM = """السَّلامُ عَلَيْكَ يا أَبا عَبْدِ الله وَعَلى الأَرواحِ الَّتِي حَلَّتْ بِفِنائِكَ، عَلَيْكَ مِنِّي سَلامُ اللهِ أَبَداً مابَقِيتُ وَبَقِيَ اللَيْلُ وَالنَّهارُ وَلا جَعَلَهُ الله آخِرَ العَهْدِ مِنِّي لِزِيارَتِكُمْ . السَّلامُ عَلى الحُسَيْنِ وَعَلى عَلِيِّ بْنِ الحُسَيْنِ وَعَلى أَوْلادِ الحُسَيْنِ وَعَلى أَصْحابِ الحُسَيْنِ."""
private const val ASHURA_CLOSING = """اللّهُمَّ خُصَّ أَنْتَ أَوَّلَ ظالِمٍ بِاللَّعْنِ مِنِّي وَأَبْدأْ بِهِ أَوَّلاً ثُمَّ الثَّانِي وَالثَّالِثَ وَالرَّابِعَ، اللّهُمَّ الْعَنْ يَزِيدَ خامِساً وَالعَنْ عُبَيْدَ الله بْنَ زِيادٍ وَابْنَ مَرْجانَةَ وَعُمَرَ بْنَ سَعْدٍ وَشِمْراً وَآلَ أَبِي سُفْيانَ وَآلَ زِيادٍ وَآلَ مَرْوانَ إلى يَوْمِ القِيامَةِ.

اللّهُمَّ لَكَ الحَمْدُ حَمْدَ الشَّاكِرِينَ لَكَ عَلى مُصابِهِمْ، الحَمْدُ للهِ عَلى عَظِيمِ رَزِيَّتِي، اللّهُمَّ ارْزُقْنِي شَفاعَةَ الحُسَيْنِ يَوْمَ الوُرُودِ وَثَبِّتْ لِي قَدَمَ صِدْقٍ عِنْدَكَ مَعَ الحُسَيْنِ وَأَصْحابِ الحُسَيْنِ الَّذِينَ بَذَلُوا مُهَجَهُمْ دُونَ الحُسَيْنِ عَلَيهِ السَّلامُ."""

private data class AshuraStep(
    val phase: String,
    val title: String,
    val how: String,
    val say: String? = null,
    val repeat: Int = 0   // إن كان >0 فهذه خطوة بعدّاد تكرار
)

private val ashuraSteps = listOf(
    AshuraStep("تمهيد", "زيارة عاشوراء",
        "زيارة عاشوراء من أجلّ الزيارات وأعظمها ثواباً، تُقرأ يوم عاشوراء وفي كل يوم. لها كيفية مخصوصة: تقرأ متن الزيارة، ثم تلعن الظالمين مئة مرّة، ثم تسلّم على الحسين (ع) مئة مرّة، ثم تدعو بدعاء الختام، ثم تسجد. سنمشي معك خطوة بخطوة."),
    AshuraStep("النيّة", "النيّة والاستقبال",
        "استقبل القبلة (أو حرم الإمام الحسين عليه السلام إن كنت هناك)، واخطر بقلبك نيّة زيارة الإمام الحسين (ع) قربةً إلى الله."),
    AshuraStep("المتن", "قراءة متن الزيارة",
        "اقرأ متن زيارة عاشوراء كاملاً (تجده في باب الزيارات). ابدأ بـ«السلام عليك يا أبا عبد الله» إلى آخر المتن. يمكنك فتحه في القارئ التفاعلي ثم العودة لإكمال الأعمال.",
        "اَلسَّلامُ عَلَيْكَ يا اَبا عَبْدِ اللهِ، اَلسَّلامُ عَلَيْكَ يَا بْنَ رَسُولِ اللهِ..."),
    AshuraStep("اللعن", "اللعن مئة مرّة",
        "بعد المتن، العن الظالمين مئة مرّة. اضغط الدائرة في كل مرّة تقولها. يجوز الاقتصار على مرّة واحدة بنيّة المئة عند الضرورة.",
        ASHURA_LAN, repeat = 100),
    AshuraStep("السلام", "السلام مئة مرّة",
        "ثم سلّم على الإمام الحسين (ع) مئة مرّة. اضغط الدائرة في كل مرّة.",
        ASHURA_SALAM, repeat = 100),
    AshuraStep("الختام", "دعاء الختام",
        "ثم اقرأ دعاء الختام (دعاء علقمة يأتي بعده إن أردت).",
        ASHURA_CLOSING),
    AshuraStep("السجدة", "سجدة الختام",
        "اسجد، وقل في سجودك:",
        "اَللّهُمَّ لَكَ الْحَمْدُ حَمْدَ الشّاكِرينَ لَكَ عَلى مُصابِهِمْ، اَلْحَمْدُ للهِ عَلى عَظيمِ رَزِيَّتي، اَللّهُمَّ ارْزُقْني شَفاعَةَ الْحُسَيْنِ يَوْمَ الْوُرُودِ، وَثَبِّتْ لي قَدَمَ صِدْقٍ عِنْدَكَ مَعَ الْحُسَيْنِ وَاَصْحابِ الْحُسَيْنِ الَّذينَ بَذَلُوا مُهَجَهُمْ دُونَ الْحُسَيْنِ عَلَيْهِ السَّلامُ."),
    AshuraStep("تمّ", "تقبّل الله",
        "بهذا تمّت زيارة عاشوراء. يُستحب بعدها قراءة دعاء علقمة (صفوان) — تجده في باب الزيارات. تقبّل الله أعمالك وحشرك مع الحسين وأصحابه.")
)

@Composable
fun AshuraGuideScreen(settings: com.shirazi.duaa.data.Settings, pal: DuaaPalette, onClose: () -> Unit, openReader: (String, String) -> Unit) {
    var i by remember { mutableStateOf(0) }
    val fontScale = settings.fontSize.value / 21f   // موحّد مع تفضيل القارئ المحفوظ
    // عدّادات التكرار لكل خطوة
    val counts = remember { mutableStateMapOf<Int, Int>() }
    val step = ashuraSteps[i]
    val isLast = i == ashuraSteps.lastIndex
    val count = counts[i] ?: 0

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
            Column(Modifier.fillMaxSize()) {
                // شريط علوي
                Box(Modifier.fillMaxWidth().background(pal.heroBrush)) {
                    IslamicPattern(Color.White.copy(alpha = .05f), Modifier.matchParentSize(), cell = 80f)
                    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = .14f))
                            .clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                            LineIcon(AppIcon.ChevronStart, Color.White, 17.dp)
                        }
                        Text("دليل زيارة عاشوراء", color = Color.White, fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp, modifier = Modifier.padding(start = 12.dp).weight(1f))
                        Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Color.White.copy(alpha = .14f))
                            .clickable { settings.fontSize.value = (settings.fontSize.value - 2).coerceAtLeast(15f); settings.save() }, contentAlignment = Alignment.Center) {
                            Text("أ-", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(6.dp))
                        Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Color.White.copy(alpha = .14f))
                            .clickable { settings.fontSize.value = (settings.fontSize.value + 2).coerceAtMost(40f); settings.save() }, contentAlignment = Alignment.Center) {
                            Text("أ+", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                // شريط التقدّم
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    ashuraSteps.indices.forEach { idx ->
                        Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp))
                            .background(if (idx <= i) pal.gold else pal.line))
                    }
                }

                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
                    AnimatedContent(targetState = i, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "s") { idx ->
                        val s = ashuraSteps[idx]
                        val c = counts[idx] ?: 0
                        Column {
                            Box(Modifier.clip(RoundedCornerShape(99.dp)).background(pal.emerald.copy(alpha = .12f))
                                .padding(horizontal = 12.dp, vertical = 6.dp)) {
                                Text(s.phase, color = pal.emerald, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            Spacer(Modifier.height(16.dp))
                            Text(s.title, fontSize = (24 * fontScale).sp, fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onBackground, lineHeight = (32 * fontScale).sp)
                            Spacer(Modifier.height(14.dp))
                            Text(s.how, fontSize = (16 * fontScale).sp, lineHeight = (30 * fontScale).sp,
                                color = MaterialTheme.colorScheme.onSurface)

                            // زرّ فتح المتن في القارئ
                            if (idx == 2) {
                                Spacer(Modifier.height(14.dp))
                                Box(Modifier.clip(RoundedCornerShape(14.dp)).background(pal.pillBrush)
                                    .clickable { openReader("ziyarat", "z-ashura") }.padding(horizontal = 16.dp, vertical = 12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        LineIcon(AppIcon.Book, Color.White, 16.dp); Spacer(Modifier.width(8.dp))
                                        Text("افتح المتن الكامل", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                                    }
                                }
                            }

                            // نصّ يُقال
                            if (s.say != null) {
                                Spacer(Modifier.height(18.dp))
                                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                                    .background(pal.emerald.copy(alpha = if (pal.dark) .14f else .10f)).padding(20.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(8.dp).clip(CircleShape).background(pal.gold))
                                        Spacer(Modifier.width(8.dp))
                                        Text(if (s.repeat > 0) "تقول (${s.repeat} مرّة):" else "تقول:",
                                            color = pal.gold, fontSize = (14 * fontScale).sp, fontWeight = FontWeight.ExtraBold)
                                    }
                                    Spacer(Modifier.height(12.dp))
                                    Text(s.say, fontSize = (22 * fontScale).sp, lineHeight = (42 * fontScale).sp,
                                        fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.fillMaxWidth())
                                }
                            }

                            // عدّاد التكرار
                            if (s.repeat > 0) {
                                Spacer(Modifier.height(20.dp))
                                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("$c / ${s.repeat}", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = pal.emerald)
                                    Spacer(Modifier.height(4.dp))
                                    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(pal.line)) {
                                        Box(Modifier.fillMaxWidth((c.toFloat() / s.repeat).coerceIn(0f, 1f)).height(8.dp)
                                            .clip(RoundedCornerShape(4.dp)).background(pal.gold))
                                    }
                                    Spacer(Modifier.height(16.dp))
                                    Box(Modifier.size(120.dp).clip(CircleShape).background(pal.heroBrush)
                                        .clickable { counts[idx] = (c + 1).coerceAtMost(s.repeat) },
                                        contentAlignment = Alignment.Center) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            LineIcon(AppIcon.Beads, Color.White, 28.dp)
                                            Text(if (c >= s.repeat) "تمّ" else "اضغط", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                                        }
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    Box(Modifier.clip(RoundedCornerShape(10.dp)).background(pal.surface2)
                                        .clickable { counts[idx] = 0 }.padding(horizontal = 16.dp, vertical = 8.dp)) {
                                        Text("تصفير", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(Modifier.height(20.dp))
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                }

                // التنقّل
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp).navigationBarsPadding(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (i > 0) {
                        Box(Modifier.weight(1f).heightIn(min = 64.dp).clip(RoundedCornerShape(20.dp)).background(pal.surface2)
                            .clickable { i-- }, contentAlignment = Alignment.Center) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                LineIcon(AppIcon.ChevronStart, pal.emerald, 22.dp); Spacer(Modifier.width(8.dp))
                                Text("السابق", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                            }
                        }
                    }
                    Box(Modifier.weight(if (i > 0) 1.6f else 1f).heightIn(min = 64.dp).clip(RoundedCornerShape(20.dp)).background(pal.pillBrush)
                        .clickable { if (isLast) onClose() else i++ }, contentAlignment = Alignment.Center) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (isLast) "تمّ - إغلاق" else "التالي",
                                color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            if (!isLast) { Spacer(Modifier.width(8.dp)); LineIcon(AppIcon.ChevronEnd, Color.White, 22.dp) }
                        }
                    }
                }
            }
        }
    }
}
