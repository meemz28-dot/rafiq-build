package com.shirazi.duaa.ui

import androidx.compose.ui.draw.clip
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Settings
import com.shirazi.duaa.logic.Khums

/** حاسبة الخُمس — تطبيق native بالكامل، بلا WebView وبلا HTML. */
@Composable
fun KhumsScreen(settings: Settings, pal: DuaaPalette, onClose: () -> Unit) {
    BackHandler { onClose() }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scroll = rememberScrollState()
    val cur = settings.khumsCurrency.value
    val marja = Khums.maraji.firstOrNull { it.key == settings.khumsMarja.value } ?: Khums.maraji.first()

    // حقول الإدخال كحالة محلية محفوظة
    @Composable fun field(id: String) = remember { mutableStateOf(settings.khumsField(id)) }
    val cash = field("cash"); val goods = field("goods"); val trade = field("trade")
    val metals = field("metals"); val receivables = field("receivables"); val other = field("other")
    val khumsed = field("khumsed"); val loans = field("loans"); val debts = field("debts")
    val mixed = field("mixed")
    var mixedSeparate by remember { mutableStateOf(true) }
    var showRulings by remember { mutableStateOf(false) }
    var marjaMenu by remember { mutableStateOf(false) }
    var curMenu by remember { mutableStateOf(false) }

    fun d(s: String): Double = s.replace("٠","0").replace("١","1").replace("٢","2").replace("٣","3")
        .replace("٤","4").replace("٥","5").replace("٦","6").replace("٧","7").replace("٨","8").replace("٩","9")
        .replace(",", "").trim().toDoubleOrNull() ?: 0.0

    val result = Khums.calc(
        Khums.Inputs(
            cash = d(cash.value), goods = d(goods.value), trade = d(trade.value), metals = d(metals.value),
            receivables = d(receivables.value), other = d(other.value),
            khumsed = d(khumsed.value), loans = d(loans.value), debts = d(debts.value),
            mixed = d(mixed.value), mixedSeparate = mixedSeparate
        ), marja
    )
    // مبالغ مقروءة بفواصل الآلاف، وبلا صيغةٍ علمية (مثل 1.55E7) في المبالغ الكبيرة كالدينار العراقيّ والتومان
    fun money(n: Double): String {
        val r = Math.round(n * 100.0) / 100.0
        val s = if (r == Math.floor(r)) String.format(java.util.Locale.US, "%,d", r.toLong())
                else String.format(java.util.Locale.US, "%,.2f", r)
        return "$s $cur"
    }

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Column(Modifier.fillMaxSize().background(pal.bgBrush)) {
            ScreenTopBar("حاسبة الخُمس", pal, onClose)
            Column(Modifier.weight(1f).verticalScroll(scroll).padding(16.dp)) {

                // البسملة + العنوان
                Text("بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيمِ", color = pal.emerald, fontSize = 14.sp,
                    fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                Spacer(Modifier.height(14.dp))

                // ===== السنة الخمسية: التذكير السنويّ =====
                run {
                    val today = com.shirazi.duaa.logic.HijriCalendar.today(settings.hijriAdj.value)
                    val months = com.shirazi.duaa.logic.HijriCalendar.months
                    var datePicker by remember { mutableStateOf(false) }
                    KhCard(pal) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(pal.gold.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                                LineIcon(AppIcon.Crescent, pal.gold, 21.dp)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("سنتك الخمسية", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                                if (settings.khumsDateSet.value) {
                                    val m = settings.khumsHMonth.value; val d = settings.khumsHDay.value
                                    // أيّام حتى الموعد القادم: بالتقويم الهجريّ الفعليّ (أشهرٌ من ٢٩ و٣٠ يوماً)
                                    val daysUntil = remember(m, d, today) { Khums.daysUntilKhumsDay(m, d, settings.hijriAdj.value) }
                                    Text(
                                        if (daysUntil == 0) "اليوم موعد خمسك — حاسب أموالك"
                                        else "بعد ${arabicCount(daysUntil, "يومٍ واحد", "يومين", "أيّام", "يوماً")} (${d} ${months.getOrElse(m - 1) { "" }})، ونذكّرك قبله بأسبوعٍ ويومَه",
                                        color = if (daysUntil <= 7) pal.gold else pal.ink2, fontSize = 12.sp, fontWeight = if (daysUntil <= 7) FontWeight.Bold else FontWeight.Normal
                                    )
                                } else {
                                    Text("حدّد يوماً ثابتاً سنوياً لحساب خمس أرباحك", color = pal.ink2, fontSize = 12.sp, lineHeight = 17.sp)
                                }
                            }
                            Text(if (settings.khumsDateSet.value) "تغيير" else "تحديد", color = pal.emerald, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clip(RoundedCornerShape(99.dp)).clickable { datePicker = !datePicker }.padding(horizontal = 12.dp, vertical = 6.dp))
                        }
                        if (datePicker) {
                            Spacer(Modifier.height(14.dp))
                            Text("اختر الشهر الهجريّ:", color = pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            // شبكة الأشهر
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                months.chunked(4).forEachIndexed { rowIdx, row ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        row.forEachIndexed { colIdx, mname ->
                                            val mNum = rowIdx * 4 + colIdx + 1
                                            val sel = settings.khumsDateSet.value && settings.khumsHMonth.value == mNum
                                            Box(
                                                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                                                    .background(if (sel) pal.emerald else pal.surface2)
                                                    .clickable { settings.saveKhumsDate(mNum, today.d.coerceIn(1, 29)); com.shirazi.duaa.notify.KhumsScheduler.reschedule(ctx) }
                                                    .padding(vertical = 9.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(mname, color = if (sel) Color.White else MaterialTheme.colorScheme.onSurface, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                            }
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("يُضبط اليوم على ${today.d} تلقائياً (يمكنك تغيير الشهر). الخمس يجب على فاضل مؤونة السنة.", color = pal.ink2, fontSize = 11.sp, lineHeight = 15.sp)
                            if (settings.khumsDateSet.value) {
                                Spacer(Modifier.height(8.dp))
                                Text("إلغاء التذكير", color = pal.danger, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable { settings.clearKhumsDate(); datePicker = false })
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                }

                // اختيار المرجع
                KhCard(pal) {
                    Text("مرجع التقليد", color = pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Box {
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.background)
                                .border(1.5.dp, pal.line, RoundedCornerShape(12.dp)).clickable { marjaMenu = !marjaMenu }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(marja.name, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            LineIcon(if (marjaMenu) AppIcon.ChevronStart else AppIcon.ChevronEnd, pal.ink2, 14.dp)
                        }
                    }
                    if (marjaMenu) {
                        Spacer(Modifier.height(6.dp))
                        Khums.maraji.forEach { m ->
                            val on = m.key == marja.key
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                    .background(if (on) pal.emerald.copy(alpha = .1f) else Color.Transparent)
                                    .clickable { settings.saveKhumsMarja(m.key); marjaMenu = false }
                                    .padding(horizontal = 12.dp, vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(8.dp).clip(RoundedCornerShape(99.dp)).background(if (on) pal.emerald else pal.line))
                                Spacer(Modifier.width(10.dp))
                                Text(m.name, color = if (on) pal.emerald else MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(pal.emerald.copy(alpha = .07f)).padding(12.dp)) {
                        Text(marja.note, color = pal.ink2, fontSize = 12.sp, lineHeight = 20.sp)
                    }
                }

                // العملة
                KhCard(pal) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("العملة", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Box(Modifier.clip(RoundedCornerShape(10.dp)).background(pal.emerald.copy(alpha = .1f))
                            .clickable { curMenu = !curMenu }.padding(horizontal = 14.dp, vertical = 8.dp)) {
                            Text(cur, color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        }
                    }
                    if (curMenu) {
                        Spacer(Modifier.height(8.dp))
                        Khums.currencies.chunked(3).forEach { row ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                row.forEach { (sym, name) ->
                                    val on = sym == cur
                                    Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                                        .background(if (on) pal.emerald else MaterialTheme.colorScheme.background)
                                        .border(1.dp, pal.line, RoundedCornerShape(10.dp))
                                        .clickable { settings.saveKhumsCurrency(sym); curMenu = false }
                                        .padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                        Text(name, color = if (on) Color.White else pal.ink2, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    }
                                }
                                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }

                // الموجودات
                SectionLabel("الموجودات عند رأس السنة الخمسية", "كلّ ما فضل عن مؤونة سنتك من الأرباح والفوائد، بقيمته الفعلية يوم حلول رأس السنة.", pal)
                MoneyField("النقد", "ما لديك من نقد في اليد وأرصدة الحسابات البنكية والمحافظ الإلكترونية.", cash, cur, pal) { settings.saveKhumsField("cash", it) }
                MoneyField("المؤن والأغراض العينية غير المستعملة", "ما اشتُري من الأرباح ولم يُستهلك حتى رأس السنة، بقيمته الفعلية.", goods, cur, pal) { settings.saveKhumsField("goods", it) }
                MoneyField("البضائع ورأس المال التجاري غير المخمّس", "بضاعة المتجر وأدوات الكسب ورأس المال بالقيمة الحالية، إن لم تُخمَّس.", trade, cur, pal) { settings.saveKhumsField("trade", it) }
                MoneyField("الذهب والفضة والمجوهرات الزائدة عن المؤونة", "ما زاد عن حدّ الاستعمال المتعارف. وحُليّ المرأة المستعمَل اللائق بشأنها من المؤونة ولا خمس فيه.", metals, cur, pal) { settings.saveKhumsField("metals", it) }
                if (marja.receivablesCounted) {
                    MoneyField("الديون المستحقّة لك", "ما لك في ذمم الآخرين من ديونٍ حالّة يمكن تحصيلها. (غير القابل للتحصيل يُخمَّس عند قبضه.)", receivables, cur, pal) { settings.saveKhumsField("receivables", it) }
                } else {
                    Box(Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(14.dp)).background(pal.surface2).padding(14.dp)) {
                        Text("الديون المستحقّة لك لا تُحتسب على رأي هذا المرجع، وتُخمَّس عند قبضها.", color = pal.ink2, fontSize = 12.sp, lineHeight = 20.sp)
                    }
                }
                MoneyField("أرباح وفوائد أخرى", "الهدايا والجوائز الفائضة عن المؤونة، أسهم واستثمارات غير مخمّسة بقيمتها الفعلية.", other, cur, pal) { settings.saveKhumsField("other", it) }

                // المستثنيات
                SectionLabel("المستثنيات (تُحسم من المجموع)", "ما لا يتعلّق به الخمس فيُطرح قبل الحساب.", pal)
                MoneyField("الأموال المخمّسة سابقاً", "المال المخمَّس لا يُخمَّس مرّة أخرى. أدخل ما بقي عندك ممّا سبق إخراج خمسه.", khumsed, cur, pal) { settings.saveKhumsField("khumsed", it) }
                MoneyField("المال المقترَض الموجود بعينه", "القرض الذي لم تسدّده وعينُ ماله ما تزال ضمن موجوداتك، مقابَلٌ بالدين ولا خمس فيه عليك.", loans, cur, pal) { settings.saveKhumsField("loans", it) }
                MoneyField("ديون المؤونة الحالّة", "الديون التي حلّ وقت سدادها وكانت لمؤونة هذه السنة. ديون السنوات السابقة أو غير الحالّة لا تُحسم، وفي موارد الشكّ يُرجع إلى وكيل المرجع.", debts, cur, pal) { settings.saveKhumsField("debts", it) }

                // المال المختلط بالحرام
                SectionLabel("المال المختلط بالحرام", "إن كان فيك مالٌ اختلط حلاله بحرامه ولا تعرف مقداره ولا صاحبه، ففيه الخمس لتطهيره.", pal)
                MoneyField("مقدار المال المختلط", "يُخرَج خمسه لتطهيره. يُحسب مستقلّاً عند تفعيل الخيار أدناه.", mixed, cur, pal) { settings.saveKhumsField("mixed", it) }
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(12.dp)).background(pal.surface2)
                        .clickable { mixedSeparate = !mixedSeparate }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(22.dp).clip(RoundedCornerShape(4.dp)).background(if (mixedSeparate) pal.emerald else Color.Transparent).border(1.5.dp, if (mixedSeparate) pal.emerald else pal.ink2, RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) {
                        if (mixedSeparate) Text("✓", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text("احسب خمس المال المختلط مستقلّاً (لتطهيره)", color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, modifier = Modifier.weight(1f))
                }

                // ===== النتيجة =====
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(pal.heroBrush).padding(20.dp)) {
                    Column(Modifier.fillMaxWidth()) {
                        Text("الوعاء الخاضع للخمس", color = Color.White.copy(alpha = .8f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(money(result.base), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(14.dp))
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .14f)).padding(16.dp)) {
                            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("مقدار الخمس الواجب", color = Color(0xFFEFF7F8), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(4.dp))
                                Text(money(result.khums), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ResultMini("سهم الإمام (عج)", money(result.imam), Modifier.weight(1f))
                            ResultMini("سهم السادة", money(result.sada), Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("يبقى لك بعد الخمس: ${money(result.keep)}", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))

                // أزرار
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) { BigButton("الأحكام والفتاوى", pal, false) { showRulings = !showRulings } }
                    Box(Modifier.weight(1f)) {
                        BigButton("تصفير", pal, false) {
                            settings.clearKhumsFields()
                            cash.value=""; goods.value=""; trade.value=""; metals.value=""; receivables.value=""
                            other.value=""; khumsed.value=""; loans.value=""; debts.value=""; mixed.value=""
                        }
                    }
                }

                if (showRulings) {
                    Spacer(Modifier.height(14.dp))
                    marja.rulings.forEach { (h, body) ->
                        KhCard(pal) {
                            Text(h, color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(body, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, lineHeight = 22.sp)
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).border(1.dp, pal.line, RoundedCornerShape(14.dp)).padding(14.dp)) {
                    Text("حاسبة استرشادية مبنية على فتاوى ${marja.name}. في موارد الشكّ والحالات الخاصّة والمصالحة يُرجع إلى المرجع أو وكيله المجاز.",
                        color = pal.ink2, fontSize = 12.sp, lineHeight = 21.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun KhCard(pal: DuaaPalette, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).paper(pal, 20).padding(16.dp), content = content)
}

@Composable
private fun SectionLabel(title: String, sub: String, pal: DuaaPalette) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(width = 3.dp, height = 16.dp).clip(RoundedCornerShape(2.dp)).background(pal.emerald))
            Spacer(Modifier.width(8.dp))
            Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onBackground)
        }
        Spacer(Modifier.height(4.dp))
        Text(sub, color = pal.ink2, fontSize = 12.sp, lineHeight = 19.sp, modifier = Modifier.padding(start = 11.dp))
    }
}

@Composable
private fun MoneyField(label: String, hint: String, state: androidx.compose.runtime.MutableState<String>, cur: String, pal: DuaaPalette, onSave: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Text(label, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(3.dp))
        Text(hint, color = pal.ink2, fontSize = 11.sp, lineHeight = 17.sp)
        Spacer(Modifier.height(7.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.background)
                .border(1.5.dp, pal.line, RoundedCornerShape(12.dp)).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = state.value,
                onValueChange = { state.value = it; onSave(it) },
                modifier = Modifier.weight(1f),
                placeholder = { Text("٠", color = pal.ink2) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                textStyle = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontSize = 17.sp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
                )
            )
            Text(cur, color = pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ResultMini(label: String, value: String, modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .1f)).padding(14.dp)) {
        Column {
            Text(label, color = Color.White.copy(alpha = .8f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(3.dp))
            Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}
