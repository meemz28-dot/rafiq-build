package com.shirazi.duaa.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Settings

/**
 * رحلتي — لوحة التقدّم الروحيّ. تجمع مؤشّرات التطوّر (السلسلة، القراءة، القضاء،
 * المحاسبة) في مكانٍ واحدٍ يبعث على الاستمرار. كلّ بطاقةٍ تنقل لأداتها.
 */
@Composable
fun JourneyScreen(
    settings: Settings,
    pal: DuaaPalette,
    onClose: () -> Unit,
    openScreen: (String) -> Unit,
    openReader: (String, String) -> Unit
) {
    BackHandler { onClose() }

    val streak = settings.streak.value
    val best = settings.bestStreak.value
    val points = settings.quranPoints.value
    val (levelName, levelNum) = settings.readerLevel()
    val surahsDone = settings.quranDoneCount.value
    val khatmaPct = (surahsDone * 100 / 114).coerceIn(0, 100)
    val activeDays = settings.activeDaysLast30()

    // إجمالي القضاء المتبقّي
    val qadaRemaining = settings.qadaState("fajr").value + settings.qadaState("dhuhr").value +
        settings.qadaState("asr").value + settings.qadaState("maghrib").value +
        settings.qadaState("isha").value + settings.qadaState("fast").value

    // محاسبة اليوم
    val muhMask = settings.muhasabaMask.value
    val muhCount = (0 until 8).count { muhMask and (1 shl it) != 0 }

    Column(Modifier.fillMaxSize().background(pal.bgBrush)) {
        ScreenTopBar("رحلتي", pal, onClose)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {

            // ===== بطاقة البطل: السلسلة =====
            Box(
                Modifier.fillMaxWidth()
                    .heroCard(pal.emerald)
                    .background(pal.heroBrush)
            ) {
                IslamicPattern(Color.White.copy(alpha = .07f), Modifier.matchParentSize(), cell = 64f)
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("سلسلة المواظبة", color = Color.White.copy(alpha = .85f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("$streak", color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.width(8.dp))
                        Text(if (streak == 1) "يوم" else "يوماً", color = Color.White.copy(alpha = .9f), fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
                    }
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.clip(RoundedCornerShape(99.dp)).background(Color.White.copy(alpha = .18f)).padding(horizontal = 14.dp, vertical = 6.dp)) {
                        Text("أطول سلسلة: $best يوماً", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // ===== صفّ بطاقتي إحصاءٍ متجاورتين =====
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(Modifier.weight(1f), pal, "$activeDays", "يوماً نشطاً", "آخر ٣٠ يوماً", AppIcon.StarFill, pal.emerald)
                StatTile(Modifier.weight(1f), pal, "$best", "أطول سلسلة", "رقمك القياسيّ", AppIcon.Sparkle, pal.gold)
            }

            Spacer(Modifier.height(12.dp))

            // ===== بطاقة خريطة الأسبoع =====
            Box(
                Modifier.fillMaxWidth()
                    .paper(pal, 20).padding(18.dp)
            ) {
                Column {
                    Text("نشاطك هذا الأسبوع", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        val labels = listOf("اليوم", "أمس", "٣", "٤", "٥", "٦", "٧")
                        for (offset in 0..6) {
                            val score = settings.activityForDayOffset(offset)
                            val frac = score / 4f
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                Box(
                                    Modifier.size(34.dp).clip(RoundedCornerShape(11.dp))
                                        .background(if (score == 0) pal.line.copy(alpha = .4f) else pal.emerald.copy(alpha = 0.25f + frac * 0.6f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (score > 0) Text("$score", color = if (frac > 0.5f) Color.White else pal.emerald, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(labels[offset], color = pal.ink2, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("كلّ يومٍ تُتمّ فيه وِردك أو محاسبتك يُضيء هنا (الدرجة من ٤).", color = pal.ink2, fontSize = 11.sp, lineHeight = 17.sp)
                }
            }

            Spacer(Modifier.height(20.dp))

            // ===== شبكة بطاقات الأدوات (عمودان) =====
            Text("أدوات رحلتك", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))

            // القرآن — بطاقةٌ عريضة بمؤشّر تقدّم الختمة
            WideToolCard(
                pal, AppIcon.Book, "نقاط القراءة", "$points نقطة · المستوى $levelNum: $levelName",
                progress = khatmaPct / 100f, progressLabel = "الختمة: $surahsDone من ١١٤ ($khatmaPct٪)", accent = pal.emerald
            ) { openScreen("qpoints") }

            Spacer(Modifier.height(12.dp))

            // المحاسبة والقضاء — عمودان
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GridToolCard(Modifier.weight(1f), pal, AppIcon.StarFill, "محاسبة النفس",
                    if (muhCount > 0) "$muhCount من ٨ اليوم" else "لم تبدأ اليوم", pal.emerald, muhCount / 8f) { openScreen("muhasaba") }
                GridToolCard(Modifier.weight(1f), pal, AppIcon.Clock, "قضاء الفوائت",
                    if (qadaRemaining > 0) "$qadaRemaining متبقّية" else "لا فوائت", pal.gold, null) { openScreen("qada") }
            }

            Spacer(Modifier.height(12.dp))

            // الخيرة والخمس — عمودان
            // صفة الشهر — حالة رحلة التهذيب
            run {
                val trActive = settings.traitActive.value
                val trName = com.shirazi.duaa.data.traits.firstOrNull { it.id == settings.traitId.value }?.vice
                GridToolCard(Modifier.fillMaxWidth(), pal, AppIcon.Star8, "صفة الشهر",
                    if (trActive && trName != null) "تخلية «$trName» — ${settings.traitDoneCount()} من ${settings.traitTarget.value} يوماً"
                    else "ابدأ رحلة تهذيب صفة",
                    pal.gold,
                    if (trActive) (settings.traitDoneCount().toFloat() / settings.traitTarget.value).coerceIn(0f, 1f) else null
                ) { openScreen("trait") }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GridToolCard(Modifier.weight(1f), pal, AppIcon.Sparkle, "خِيرة القرآن", "استشِر عند الحيرة", pal.gold, null) { openScreen("khira") }
                GridToolCard(Modifier.weight(1f), pal, AppIcon.Hands, "حاسبة الخمس", "احسب خمسك", pal.emerald, null) { openScreen("khums") }
            }

            Spacer(Modifier.height(20.dp))

            // ===== تذييل تحفيزيّ =====
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(pal.emerald.copy(alpha = if (pal.dark) .12f else .08f)).padding(20.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text("«أَحَبُّ الأَعْمَالِ إِلَى اللهِ أَدْوَمُهَا وَإِنْ قَلَّ»", color = pal.emerald, fontSize = 14.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, lineHeight = 22.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("المداومة على القليل خيرٌ من الكثير المنقطع", color = pal.ink2, fontSize = 11.sp, textAlign = TextAlign.Center)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

// بطاقة إحصاءٍ مربّعة صغيرة
@Composable
private fun StatTile(modifier: Modifier, pal: DuaaPalette, value: String, label: String, sub: String, icon: AppIcon, accent: Color) {
    Column(
        modifier
            .paper(pal, 20).padding(16.dp)
    ) {
        Box(Modifier.size(36.dp).clip(RoundedCornerShape(11.dp)).background(accent.copy(alpha = if (pal.dark) .18f else .12f)), contentAlignment = Alignment.Center) {
            LineIcon(icon, accent, 18.dp)
        }
        Spacer(Modifier.height(12.dp))
        Text(value, color = accent, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text(sub, color = pal.ink2, fontSize = 10.sp)
    }
}

// بطاقة أداةٍ مربّعة في الشبكة
@Composable
private fun GridToolCard(modifier: Modifier, pal: DuaaPalette, icon: AppIcon, title: String, stat: String, accent: Color, progress: Float?, onClick: () -> Unit) {
    Column(
        modifier
            .paper(pal, 18)
            .clickable(onClick = onClick).padding(16.dp)
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(accent.copy(alpha = if (pal.dark) .18f else .12f)), contentAlignment = Alignment.Center) {
            LineIcon(icon, accent, 21.dp)
        }
        Spacer(Modifier.height(12.dp))
        Text(title, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(2.dp))
        Text(stat, color = pal.ink2, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (progress != null) {
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(99.dp)).background(pal.line.copy(alpha = .5f))) {
                Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).height(6.dp).clip(RoundedCornerShape(99.dp)).background(accent))
            }
        }
    }
}

// بطاقة أداةٍ عريضة بمؤشّر تقدّم
@Composable
private fun WideToolCard(pal: DuaaPalette, icon: AppIcon, title: String, subtitle: String, progress: Float, progressLabel: String, accent: Color, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .paper(pal, 20)
            .clickable(onClick = onClick).padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(accent.copy(alpha = if (pal.dark) .18f else .12f)), contentAlignment = Alignment.Center) {
                LineIcon(icon, accent, 23.dp)
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, color = pal.ink2, fontSize = 12.sp)
            }
            LineIcon(AppIcon.ChevronStart, pal.ink2.copy(alpha = .6f), 18.dp)
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(99.dp)).background(pal.line.copy(alpha = .5f))) {
            Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).height(8.dp).clip(RoundedCornerShape(99.dp)).background(accent))
        }
        Spacer(Modifier.height(6.dp))
        Text(progressLabel, color = pal.ink2, fontSize = 11.sp)
    }
}
