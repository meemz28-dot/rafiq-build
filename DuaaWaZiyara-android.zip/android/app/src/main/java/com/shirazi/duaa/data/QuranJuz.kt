package com.shirazi.duaa.data

// بدايات الأجزاء الثلاثين (سورة، آية) — عن بيانات مشروع تنزيل (tanzil.net، رخصة CC BY 3.0).
internal object QuranJuz {
    val SURA: IntArray = intArrayOf(1,2,2,3,4,4,5,6,7,8,9,11,12,15,17,18,21,23,25,27,29,33,36,39,41,46,51,58,67,78)
    val AYA: IntArray = intArrayOf(1,142,253,93,24,148,82,111,88,41,93,6,53,1,1,75,1,1,21,56,46,31,28,32,47,1,31,1,1,1)
}
