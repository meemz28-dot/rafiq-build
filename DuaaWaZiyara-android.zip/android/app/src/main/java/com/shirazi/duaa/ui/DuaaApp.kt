package com.shirazi.duaa.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Settings

private data class Tab(val key: String, val label: String, val icon: AppIcon)
private val TABS = listOf(
    Tab("home", "الرئيسية", AppIcon.Dome), Tab("lib", "الفهرس", AppIcon.Book),
    Tab("prayer", "الأوقات", AppIcon.Clock), Tab("cal", "التقويم", AppIcon.Crescent), Tab("more", "المزيد", AppIcon.Sparkle)
)

@Composable
fun DuaaApp(
    settings: Settings, onRequestNotifyPermission: () -> Unit,
    startTab: String? = null, startScreen: String? = null, startSheet: String? = null, startReader: Pair<String, String>? = null
) {
    val dark = settings.theme.value == "dark"
    // بناء فهرس البحث في الخلفية مرّةً واحدة، فلا تتأخّر أوّل ضغطة مفتاح
    LaunchedEffect(Unit) { kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { com.shirazi.duaa.logic.ArabicSearch.warmUp() } }
    DuaaTheme(dark) {
        val pal = palette(dark)
        // أوّل تشغيل: اعرض تدفّق الترحيب قبل التطبيق
        if (!settings.onboardingDone.value) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                OnboardingScreen(settings, pal, onRequestNotifyPermission) { /* تُحدّث الحالة داخلياً */ }
            }
            return@DuaaTheme
        }
        var tab by remember { mutableStateOf(startTab ?: "home") }
        var reader by remember { mutableStateOf(startReader) }
        var screen by remember { mutableStateOf(startScreen) }   // khira / khums
        var sheet by remember { mutableStateOf(startSheet) }    // tasbih/fav/settings/about/loc/method
        // نحتفظ بآخر قيمةٍ معروضة كي يبقى المحتوى ظاهراً أثناء حركة الخروج
        var lastScreen by remember { mutableStateOf("") }
        var lastReader by remember { mutableStateOf<Pair<String, String>?>(null) }

        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            // زر الرجوع: قارئ ← شاشة ← تبويب ← خروج
            BackHandler(enabled = reader != null || screen != null || sheet != null || tab != "home") {
                when {
                    sheet != null -> sheet = null
                    reader != null -> reader = null
                    screen != null -> screen = null
                    tab != "home" -> tab = "home"
                }
            }

            Box(Modifier.fillMaxSize().background(pal.bgBrush), contentAlignment = Alignment.TopCenter) {
                // على الشاشات الكبيرة (لوحيّ/قابل للطيّ) نُبقي المحتوى بعرضٍ مقروء ومتوسّط — توافقاً مع أندرويد ١٧
                Column(Modifier.fillMaxSize().widthIn(max = 640.dp)) {
                    if (tab != "home") Header(pal, TABS.firstOrNull { it.key == tab }?.label ?: "",
                        onTheme = { settings.theme.value = if (dark) "light" else "dark"; settings.save() },
                        onSettings = { sheet = "settings" })
                    Box(Modifier.weight(1f)) {
                        Crossfade(targetState = tab, animationSpec = tween(260), label = "tab") { current ->
                        when (current) {
                            "home" -> HomeScreen(settings, pal,
                                openReader = { c, i -> reader = c to i },
                                openSheet = { sheet = it },
                                openScreen = { screen = it },
                                goTab = { tab = it })
                            "lib" -> LibraryScreen(settings, pal) { c, i -> reader = c to i }
                            "prayer" -> PrayerScreen(settings, pal, openSheet = { sheet = it }, openTab = { tab = it })
                            "cal" -> CalendarScreen(settings, pal, openReader = { c, i -> reader = c to i }, openScreen = { screen = it })
                            "more" -> MoreScreen(pal, openSheet = { sheet = it }, openScreen = { screen = it })
                        }
                        }
                    }
                    NavBar(tab, pal) { tab = it; reader = null; screen = null }
                }

                // شاشات كاملة فوق التبويبات — تدخل بانزلاقٍ لطيف من الأسفل
                AnimatedVisibility(
                    visible = screen != null,
                    enter = slideInVertically(animationSpec = tween(280)) { it / 6 } + fadeIn(tween(220)),
                    exit = slideOutVertically(animationSpec = tween(240)) { it / 6 } + fadeOut(tween(180))
                ) {
                    // نُبقي آخر شاشةٍ معروضة أثناء الخروج لتنعم الحركة
                    val shown = remember(screen) { screen ?: lastScreen }
                    LaunchedEffect(screen) { if (screen != null) lastScreen = screen!! }
                    when (shown) {
                        "khira" -> KhiraScreen(pal, openReader = { c, i -> reader = c to i }) { screen = null }
                        "weekly" -> WeeklyScreen(pal, openReader = { c, i -> reader = c to i }) { screen = null }
                        "asma" -> AsmaScreen(settings, pal) { screen = null }
                        "masoom" -> MasoomeenScreen(pal,
                            openReader = { c, i -> screen = null; reader = c to i }) { screen = null }
                        "khums" -> KhumsScreen(settings, pal) { screen = null }
                        "tracker" -> PrayerTrackerScreen(pal) { screen = null }
                        "layl" -> LaylGuideScreen(settings, pal) { screen = null }
                        "hajj" -> HajjScreen(settings, pal, openReader = { c, i -> reader = c to i }) { screen = null }
                        "ashura" -> AshuraGuideScreen(settings, pal, onClose = { screen = null },
                            openReader = { c, i -> screen = null; reader = c to i })
                        "qibla" -> QiblaScreen(settings, pal) { screen = null }
                        "muhasaba" -> MuhasabaScreen(settings, pal) { screen = null }
                        "journey" -> JourneyScreen(settings, pal,
                            onClose = { screen = null },
                            openScreen = { s -> screen = s },
                            openReader = { c, i -> screen = null; reader = c to i })
                        "trait" -> TraitJourneyScreen(settings, pal,
                            onClose = { screen = null },
                            openScreen = { s -> screen = s },
                            openReader = { c, i -> screen = null; reader = c to i })
                        "amaal" -> AmaalScreen(settings, pal) { screen = null }
                        "qada" -> QadaScreen(settings, pal) { screen = null }
                        "khatma" -> KhatmaScreen(settings, pal, openReader = { c, i -> reader = c to i }) { screen = null }
                        "converter" -> DateConverterScreen(settings, pal) { screen = null }
                        "ptable" -> PrayerTableScreen(settings, pal) { screen = null }
                        "qpoints" -> QuranPointsScreen(settings, pal, onClose = { screen = null },
                            openReader = { c, i -> screen = null; reader = c to i })
                    }
                }
                // القارئ — يدخل بانزلاقٍ لطيف من الأسفل (إحساس «صفحةٌ أتت للأمام»)
                AnimatedVisibility(
                    visible = reader != null,
                    enter = slideInVertically(animationSpec = tween(300)) { it / 5 } + fadeIn(tween(240)),
                    exit = slideOutVertically(animationSpec = tween(250)) { it / 5 } + fadeOut(tween(180))
                ) {
                    val shownReader = remember(reader) { reader ?: lastReader }
                    LaunchedEffect(reader) { if (reader != null) lastReader = reader }
                    shownReader?.let { (c, i) ->
                        ReaderScreen(settings, pal, c, i,
                            onClose = { reader = null },
                            onNavigate = { nc, ni -> reader = nc to ni },
                            onHome = { reader = null; screen = null; tab = "home" })
                    }
                }
            }

            when (sheet) {
                "tasbih" -> TasbihSheet(settings, pal) { sheet = null }
                "fav" -> FavSheet(settings, pal, onClose = { sheet = null },
                    openReader = { c, i -> sheet = null; reader = c to i })
                "bookmarks" -> BookmarksSheet(settings, pal, onClose = { sheet = null },
                    openReader = { c, i -> sheet = null; reader = c to i })
                "settings" -> SettingsSheet(settings, pal, onClose = { sheet = null },
                    openSheet = { sheet = it }, onRequestNotifyPermission = onRequestNotifyPermission)
                "about" -> AboutSheet(pal) { sheet = null }
                "loc" -> LocationSheet(settings, pal) { sheet = null }
                "method" -> MethodSheet(settings, pal) { sheet = null }
            }
        }
    }
}

@Composable
private fun Header(pal: DuaaPalette, title: String, onTheme: () -> Unit, onSettings: () -> Unit) {
    // عنوان صفحةٍ كبير على خلفية الورق، بدل الشريط الملوّن المتكرّر: مساحةٌ أوسع للمحتوى وهدوءٌ بصري
    Row(
        Modifier.fillMaxWidth().statusBarsPadding()
            .padding(start = 20.dp, end = 14.dp, top = 10.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
            Box(Modifier.padding(top = 2.dp).size(width = 28.dp, height = 3.dp).clip(RoundedCornerShape(2.dp)).background(pal.gold))
        }
        HeaderBtn(AppIcon.Theme, pal, onTheme); Spacer(Modifier.width(6.dp)); HeaderBtn(AppIcon.Gear, pal, onSettings)
    }
}

@Composable
private fun HeaderBtn(icon: AppIcon, pal: DuaaPalette, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, pal.line, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { LineIcon(icon, MaterialTheme.colorScheme.onSurface, 19.dp) }
}

@Composable
private fun NavBar(current: String, pal: DuaaPalette, onSelect: (String) -> Unit) {
    val haptics = rememberHaptics()
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 12.dp).navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth()
                .shadow(16.dp, RoundedCornerShape(28.dp), spotColor = pal.emerald.copy(alpha = .22f), ambientColor = Color.Black.copy(alpha = .12f))
                .clip(RoundedCornerShape(28.dp)).background(MaterialTheme.colorScheme.surface)
                .border(1.dp, pal.line, RoundedCornerShape(28.dp)).padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TABS.forEach { t ->
                val on = current == t.key
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                        .then(if (on) Modifier.background(pal.pillBrush) else Modifier)
                        .semantics { role = Role.Tab; selected = on; contentDescription = t.label }
                        .clickable { if (!on) haptics.tick(); onSelect(t.key) }.padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LineIcon(t.icon, if (on) Color.White else pal.ink2, 21.dp)
                    Spacer(Modifier.height(4.dp))
                    Text(t.label, fontSize = 11.sp, letterSpacing = 0.2.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium,
                        color = if (on) Color.White else pal.ink2)
                }
            }
        }
    }
}

// ===== مكوّنات مشتركة بالأسلوب الجديد =====
@Composable
fun ArchCard(pal: DuaaPalette, content: @Composable ColumnScope.() -> Unit) {
    Box(
        Modifier.fillMaxWidth().padding(bottom = 16.dp)
            .clip(RoundedCornerShape(28.dp)).background(pal.heroBrush)
    ) {
        // زخرفة النجمة الثمانية في الزاوية
        Box(Modifier.align(Alignment.TopEnd).padding(8.dp)) {
            StarTile(Color.White.copy(alpha = .07f), 92.dp)
        }
        Box(Modifier.align(Alignment.BottomStart).padding(6.dp)) {
            StarTile(Color.White.copy(alpha = .05f), 64.dp)
        }
        Column(
            Modifier.fillMaxWidth().padding(vertical = 26.dp, horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally, content = content
        )
    }
}

@Composable
fun PlainCard(pal: DuaaPalette, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 14.dp).paper(pal, 20).padding(16.dp), content = content)
}
