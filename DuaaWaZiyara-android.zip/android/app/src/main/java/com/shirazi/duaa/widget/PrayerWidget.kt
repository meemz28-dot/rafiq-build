package com.shirazi.duaa.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.shirazi.duaa.MainActivity
import com.shirazi.duaa.R
import com.shirazi.duaa.data.Data
import com.shirazi.duaa.logic.HijriCalendar
import com.shirazi.duaa.logic.PrayerTimes
import java.util.Calendar

/**
 * ودجت الشاشة الرئيسية: يعرض التاريخ الهجري، الموقع، والصلاة القادمة مع وقتها،
 * إضافةً لصفّ المواقيت الخمسة. يقرأ التفضيلات مباشرةً ويحسب المواقيت كالتطبيق.
 */
class PrayerWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) updateWidget(context, mgr, id)
    }

    companion object {
        fun updateAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(android.content.ComponentName(context, PrayerWidget::class.java))
            for (id in ids) updateWidget(context, mgr, id)
        }

        private fun updateWidget(context: Context, mgr: AppWidgetManager, id: Int) {
            val sp = context.getSharedPreferences("duaa_prefs", Context.MODE_PRIVATE)

            // الموقع: مخصّص أو من قائمة المدن
            val hasCustom = sp.contains("lat")
            val lat: Double; val lng: Double; val tz: Double; val locName: String
            if (hasCustom) {
                lat = sp.getFloat("lat", 0f).toDouble()
                lng = sp.getFloat("lng", 0f).toDouble()
                tz = sp.getFloat("tz", 0f).toDouble()
                locName = sp.getString("cityName", "موقع مخصّص") ?: "موقع مخصّص"
            } else {
                val idx = sp.getInt("cityIdx", 0).coerceIn(0, Data.cities.size - 1)
                val c = Data.cities[idx]
                lat = c.lat; lng = c.lng; tz = c.tz; locName = c.n
            }
            val method = sp.getString("method", "jafari") ?: "jafari"
            val hijriAdj = sp.getInt("hijriAdj", 0)

            val now = Calendar.getInstance()
            val times = PrayerTimes.compute(now, lat, lng, tz, method)
            val nowH = now.get(Calendar.HOUR_OF_DAY) + now.get(Calendar.MINUTE) / 60.0
            val (nextKey, dt) = PrayerTimes.next(times, nowH)
            val nextName = PrayerTimes.slots.firstOrNull { it.key == nextKey }?.name ?: ""
            val hh = dt.toInt(); val mm = Math.round((dt - hh) * 60).toInt()
            val countdown = if (hh > 0) "بعد ${hh}س ${mm}د" else "بعد ${mm}د"

            val hd = HijriCalendar.today(hijriAdj)
            val hijri = "${hd.d} ${HijriCalendar.months.getOrElse(hd.m - 1) { "" }} ${hd.y} هـ"

            val views = RemoteViews(context.packageName, R.layout.widget_prayer)
            views.setTextViewText(R.id.w_hijri, hijri)
            views.setTextViewText(R.id.w_location, locName)
            views.setTextViewText(R.id.w_countdown, "$nextName · $countdown")

            views.setTextViewText(R.id.w_fajr, PrayerTimes.fmt(times.fajr))
            views.setTextViewText(R.id.w_dhuhr, PrayerTimes.fmt(times.dhuhr))
            views.setTextViewText(R.id.w_asr, PrayerTimes.fmt(times.asr))
            views.setTextViewText(R.id.w_maghrib, PrayerTimes.fmt(times.maghrib))
            views.setTextViewText(R.id.w_isha, PrayerTimes.fmt(times.isha))

            // إبراز الصلاة القادمة بخلفيةٍ تيل ونصٍّ أبيض — كما في بطاقة الرئيسية
            val cols = mapOf(
                "fajr" to Triple(R.id.w_col_fajr, R.id.w_lbl_fajr, R.id.w_fajr),
                "dhuhr" to Triple(R.id.w_col_dhuhr, R.id.w_lbl_dhuhr, R.id.w_dhuhr),
                "asr" to Triple(R.id.w_col_asr, R.id.w_lbl_asr, R.id.w_asr),
                "maghrib" to Triple(R.id.w_col_maghrib, R.id.w_lbl_maghrib, R.id.w_maghrib),
                "isha" to Triple(R.id.w_col_isha, R.id.w_lbl_isha, R.id.w_isha)
            )
            for ((key, ids) in cols) {
                val (colId, lblId, timeId) = ids
                if (key == nextKey) {
                    views.setInt(colId, "setBackgroundResource", R.drawable.widget_next_pill)
                    views.setTextColor(lblId, android.graphics.Color.WHITE)
                    views.setTextColor(timeId, android.graphics.Color.WHITE)
                } else {
                    views.setInt(colId, "setBackgroundResource", 0)
                    views.setTextColor(lblId, android.graphics.Color.parseColor("#FF6A7C82"))
                    views.setTextColor(timeId, android.graphics.Color.parseColor("#FF15333B"))
                }
            }

            // النقر يفتح التطبيق
            val intent = Intent(context, MainActivity::class.java)
            var flags = PendingIntent.FLAG_UPDATE_CURRENT
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) flags = flags or PendingIntent.FLAG_IMMUTABLE
            val pi = PendingIntent.getActivity(context, 0, intent, flags)
            views.setOnClickPendingIntent(R.id.w_root, pi)

            mgr.updateAppWidget(id, views)
        }
    }
}
