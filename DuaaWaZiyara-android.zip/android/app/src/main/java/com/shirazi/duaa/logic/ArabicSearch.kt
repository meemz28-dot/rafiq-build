package com.shirazi.duaa.logic

import com.shirazi.duaa.data.Category
import com.shirazi.duaa.data.Data
import com.shirazi.duaa.data.DuaaItem

/** تطبيع النص العربي للبحث: حذف التشكيل وتوحيد الهمزات والحروف. */
object ArabicSearch {

    private val tashkeel = Regex("[\u064B-\u0652\u0670\u0640\u0653-\u065F]")

    fun stripTashkeel(s: String): String = tashkeel.replace(s, "")

    private val hamza = Regex("[أإآ]")
    private val spaces = Regex("\\s+")

    fun normalize(s: String): String =
        stripTashkeel(s)
            .replace(hamza, "ا")
            .replace('ى', 'ي')
            .replace('ة', 'ه')
            .replace('ؤ', 'و')
            .replace('ئ', 'ي')
            .replace(spaces, " ")
            .trim()

    /** فهرسٌ مطبَّع يُبنى مرّةً واحدة؛ كان كلّ ضغطة مفتاحٍ تعيد تطبيع المكتبة كلّها (٥٨٠ نصّاً) بسبعة تمريرات regex لكلّ نصّ. */
    private class Entry(val cat: Category, val item: DuaaItem, val nTitle: String, val nSrc: String, val nIntro: String, val nText: String)
    private val index: List<Entry> by lazy {
        Data.categories.flatMap { c ->
            c.items.map { Entry(c, it, normalize(it.title), normalize(it.src ?: ""), normalize(it.intro ?: ""), normalize(it.text.replace('\n', ' '))) }
        }
    }
    /** يُستدعى في الخلفية عند بدء التطبيق كي لا يتأخّر أوّل بحث. */
    fun warmUp() { index.size }

    data class Hit(val cat: Category, val item: DuaaItem, val snippet: String, val score: Int)

    /**
     * بحث مُرتَّب حسب الصِّلة، يدعم تعدّد الكلمات (يجب أن تَرِد كلّها):
     *  - مطابقة العنوان كاملاً/بدايةً = أعلى الدرجات
     *  - مطابقة في المصدر/المقدّمة = متوسطة
     *  - مطابقة في المتن = أدنى
     */
    fun search(query: String): List<Hit> {
        val nq = normalize(query)
        if (nq.isEmpty()) return emptyList()
        val terms = nq.split(" ").filter { it.isNotBlank() }
        val hits = ArrayList<Hit>()

        for (e in index) {
            val nTitle = e.nTitle; val nSrc = e.nSrc; val nIntro = e.nIntro; val nText = e.nText
            if (!terms.all { nTitle.contains(it) || nSrc.contains(it) || nIntro.contains(it) || nText.contains(it) }) continue
            val it = e.item; val c = e.cat

            var score = 0
            when {
                nTitle == nq -> score += 1000
                nTitle.startsWith(nq) -> score += 600
                nTitle.contains(nq) -> score += 400
                terms.all { nTitle.contains(it) } -> score += 250
            }
            if (nSrc.contains(nq)) score += 80
            if (nIntro.contains(nq)) score += 60
            if (nText.contains(nq)) score += 40

            var snippet = ""
            val ix = nText.indexOf(terms.first())
            if (ix >= 0) {
                val plain = stripTashkeel(it.text.replace('\n', ' '))
                val st = (ix - 20).coerceAtLeast(0)
                val end = (st + 80).coerceAtMost(plain.length)
                if (end > st) snippet = (if (st > 0) "…" else "") + plain.substring(st, end).trim() + "…"
            }
            hits.add(Hit(c, it, snippet, score))
        }
        return hits.sortedWith(compareByDescending<Hit> { it.score }.thenBy { it.item.title })
    }
}
