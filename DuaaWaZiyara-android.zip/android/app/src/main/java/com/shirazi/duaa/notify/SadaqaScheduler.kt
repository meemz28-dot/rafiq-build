package com.shirazi.duaa.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.shirazi.duaa.data.Settings
import java.util.Calendar

/**
 * تذكير الصدقة اليومي: يُذكّر المستخدم بساعةٍ مختارة بأداء صدقةٍ ولو يسيرة،
 * مع بيان فضلها من الروايات. الصدقة تدفع البلاء وتزيد في الرزق.
 */
object SadaqaScheduler {

    private const val REQ = 820

    // رسائل الفضل تتناوب لتبقى التذكِرة حيّة
    val FADL = listOf(
        "تصدّق ولو بشِقّ تمرة" to "الصدقة تدفع البلاء وتُطفئ غضب الرب، وتزيد في العمر والرزق.",
        "صدقة اليوم" to "قال الصادق (ع): الصدقة باليد تقي مِيتة السوء وتدفع سبعين نوعاً من البلاء.",
        "باكِر بالصدقة" to "بكّروا بالصدقة فإنّ البلاء لا يتخطّاها — داوِم ولو على القليل.",
        "صدقة تُظلّك" to "كلّ امرئٍ في ظلّ صدقته يوم القيامة — لا تَدَع يومك بلا صدقة.",
        "الصدقة دواء" to "داووا مرضاكم بالصدقة، وادفعوا البلاء بالدعاء والصدقة."
    )

    fun reschedule(context: Context) {
        val settings = Settings(context)
        cancel(context)
        if (!settings.sadaqaEnabled.value) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = Calendar.getInstance()
        val fire = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, settings.sadaqaHour.value)
            set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
        }
        // اختر رسالةً بحسب اليوم لتتناوب
        val idx = (fire.get(Calendar.DAY_OF_YEAR)) % FADL.size
        val (title, body) = FADL[idx]
        val pi = pendingIntent(context, title, body)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setWindow(AlarmManager.RTC_WAKEUP, fire.timeInMillis, 300_000L, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fire.timeInMillis, pi)
            }
        } catch (e: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, fire.timeInMillis, pi)
        }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context, "", ""))
    }

    private fun pendingIntent(context: Context, title: String, body: String): PendingIntent {
        val intent = Intent(context, DhikrReceiver::class.java).apply {
            action = "com.shirazi.duaa.SADAQA"
            putExtra("routineTitle", title)
            putExtra("routineBody", body)
        }
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags = flags or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, REQ, intent, flags)
    }
}
