package com.shirazi.duaa.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Amaal
import com.shirazi.duaa.data.Settings
import com.shirazi.duaa.logic.HijriCalendar
import java.util.Calendar

@Composable
fun AmaalScreen(settings: Settings, pal: DuaaPalette, onClose: () -> Unit) {
    val today = HijriCalendar.today(settings.hijriAdj.value)
    var selM by remember { mutableStateOf(today.m) }
    val now = Calendar.getInstance()
    val weekday = now.get(Calendar.DAY_OF_WEEK) - 1
    val fast = Amaal.fastingRec(today.m, today.d, weekday)
    val monthWorks = Amaal.works.filter { it.m == selM }
    var expanded by remember { mutableStateOf<String?>(null) }

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                ScreenTopBar("الأعمال والمستحبّات", pal, onClose)
                Column(Modifier.padding(18.dp)) {

                    // توصية صيام اليوم
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (fast.recommended) pal.good.copy(alpha = .12f) else pal.surface2.copy(alpha = .6f))
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                            .background(if (fast.recommended) pal.good.copy(alpha = .2f) else pal.line.copy(alpha = .5f)),
                            contentAlignment = Alignment.Center) {
                            LineIcon(AppIcon.Crescent, if (fast.recommended) pal.good else pal.ink2, 22.dp)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (fast.recommended) "صيام اليوم مستحبّ" else "صيام اليوم",
                                fontWeight = FontWeight.ExtraBold, fontSize = 15.sp,
                                color = if (fast.recommended) pal.good else MaterialTheme.colorScheme.onSurface)
                            Text(fast.reason, color = pal.ink2, fontSize = 12.sp, lineHeight = 19.sp)
                        }
                    }

                    // أعمال اليوم
                    val todayWorks = Amaal.forDay(today.m, today.d)
                    if (todayWorks.isNotEmpty()) {
                        SectionTitle("أعمال اليوم — ${today.d} ${HijriCalendar.months[today.m - 1]}")
                        todayWorks.forEach { w -> WorkCard(w.title, w.body, pal, true) }
                        Spacer(Modifier.height(6.dp))
                    }

                    // تصفّح حسب الشهر
                    SectionTitle("تصفّح حسب الشهر")
                    androidx.compose.foundation.lazy.LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
                    ) {
                        items(12) { idx ->
                            val m = idx + 1; val on = m == selM
                            Box(
                                Modifier.clip(RoundedCornerShape(99.dp))
                                    .background(if (on) pal.pillBrush else androidx.compose.ui.graphics.SolidColor(pal.surface2))
                                    .clickable { selM = m; expanded = null }.padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text(HijriCalendar.months[idx], color = if (on) Color.White else MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                    if (monthWorks.isEmpty()) {
                        Text("لا توجد أعمال مخصوصة مسجّلة في هذا الشهر.", color = pal.ink2, fontSize = 13.sp)
                    } else {
                        monthWorks.forEach { w ->
                            val key = "${w.m}-${w.d}-${w.title}"
                            WorkCard(
                                if (w.d == 0) w.title else "${w.title} (${w.d} ${HijriCalendar.months[w.m - 1]})",
                                w.body, pal, expanded == key
                            ) { expanded = if (expanded == key) null else key }
                        }
                    }
                    Spacer(Modifier.height(90.dp))
                }
            }
        }
    }
}

@Composable
fun WorkCard(title: String, body: String, pal: DuaaPalette, expandedInit: Boolean, onToggle: (() -> Unit)? = null) {
    var expanded by remember { mutableStateOf(expandedInit) }
    val open = if (onToggle != null) expandedInit else expanded
    Column(
        Modifier.fillMaxWidth().padding(bottom = 10.dp).animateContentSize(animationSpec = tween(220)).paper(pal, 20)
            .clickable { if (onToggle != null) onToggle() else expanded = !expanded }.padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(pal.gold))
            Spacer(Modifier.width(10.dp))
            Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
            LineIcon(if (open) AppIcon.ChevronStart else AppIcon.ChevronEnd, pal.ink2, 13.dp)
        }
        if (open) {
            Spacer(Modifier.height(10.dp))
            Text(body, fontSize = 14.sp, lineHeight = 26.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
