package com.shirazi.duaa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.logic.PrayerMotionDetector

/** عدّاد الركعات: يدويّ موثوق (افتراضي) + وضعٌ تلقائيّ تجريبيّ بالمستشعر. */
@Composable
fun PrayerTrackerScreen(pal: DuaaPalette, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val haptics = rememberHaptics()
    var mode by remember { mutableStateOf("manual") } // manual | motion

    Column(Modifier.fillMaxSize().background(pal.bgBrush)) {
        ScreenTopBar("عدّاد الركعات", pal, onClose)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {

            // مبدّل الوضع
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.surface2).padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ModeTab("يدويّ", mode == "manual", Modifier.weight(1f), pal) { mode = "manual" }
                ModeTab("تلقائيّ · تجريبيّ", mode == "motion", Modifier.weight(1f), pal) { mode = "motion" }
            }
            Spacer(Modifier.height(16.dp))

            if (mode == "manual") ManualCounter(pal, haptics)
            else MotionCounter(ctx, pal)

            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
private fun ModeTab(label: String, on: Boolean, modifier: Modifier, pal: DuaaPalette, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(10.dp))
            .background(if (on) MaterialTheme.colorScheme.surface else Color.Transparent)
            .clickable(onClick = onClick).padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (on) pal.emerald else pal.ink2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

// ============ الوضع اليدويّ الموثوق ============
@Composable
private fun ManualCounter(pal: DuaaPalette, haptics: Haptics) {
    val prayers = listOf("الفجر" to 2, "الظهر" to 4, "العصر" to 4, "المغرب" to 3, "العشاء" to 4, "نافلة" to 2)
    var prayerIdx by remember { mutableStateOf(1) }
    val target = prayers[prayerIdx].second
    var rakah by remember(prayerIdx) { mutableStateOf(0) }
    val done = rakah >= target

    Text("الصلاة", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        prayers.forEachIndexed { i, pair ->
            val sel = i == prayerIdx
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                    .background(if (sel) pal.emerald else pal.surface2)
                    .clickable { prayerIdx = i; rakah = 0 }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(pair.first, color = if (sel) Color.White else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                    Text("${pair.second}", color = if (sel) Color.White.copy(alpha = .8f) else pal.ink2, fontSize = 11.sp)
                }
            }
        }
    }
    Spacer(Modifier.height(20.dp))

    Column(
        Modifier.fillMaxWidth()
            .heroCard(pal.emerald)
            .background(pal.heroBrush)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { if (rakah < target) { rakah++; if (rakah == target) haptics.celebrate() else haptics.tick() } }
            .padding(vertical = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(if (done) "أتممت صلاتك ✓" else "الركعة", color = Color.White.copy(alpha = .85f), fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("$rakah", color = Color.White, fontSize = 88.sp, fontWeight = FontWeight.ExtraBold)
        Text("من $target ركعات", color = Color.White.copy(alpha = .8f), fontSize = 14.sp)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(target) { i ->
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (i < rakah) Color.White else Color.White.copy(alpha = .3f)))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(if (done) "اضغط «تصفير» لصلاةٍ جديدة" else "انقر لإتمام كلّ ركعة", color = Color.White.copy(alpha = .7f), fontSize = 12.sp)
    }
    Spacer(Modifier.height(14.dp))

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.weight(1f)) { BigButton("− ركعة", pal, false) { if (rakah > 0) { rakah--; haptics.tick() } } }
        Box(Modifier.weight(1f)) { BigButton("تصفير", pal, false) { rakah = 0; haptics.tick() } }
    }
    Spacer(Modifier.height(16.dp))

    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(pal.gold.copy(alpha = if (pal.dark) .12f else .08f)).padding(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        LineIcon(AppIcon.Sparkle, pal.gold, 18.dp)
        Spacer(Modifier.width(10.dp))
        Text("يعينك على تتبّع ركعاتك إن خشيت السهو. إن شككت في عددها بعد الانتهاء فالعمل على ما تيقّنت، وراجع أحكام سجود السهو.", color = pal.ink2, fontSize = 12.sp, lineHeight = 19.sp)
    }
}

// ============ الوضع التلقائيّ التجريبيّ ============
@Composable
private fun MotionCounter(ctx: android.content.Context, pal: DuaaPalette) {
    val supported = remember { PrayerMotionDetector.isSupported(ctx) }
    var running by remember { mutableStateOf(false) }
    var posture by remember { mutableStateOf(PrayerMotionDetector.Posture.UNKNOWN) }
    var rakah by remember { mutableStateOf(0) }
    var sajda by remember { mutableStateOf(0) }

    val detector = remember {
        PrayerMotionDetector(ctx,
            onState = { posture = it },
            onRakahCompleted = { rakah = it },
            onSajdaCounted = { sajda = it })
    }
    DisposableEffect(Unit) { onDispose { detector.stop() } }
    LaunchedEffect(running) { if (running) detector.start() else detector.stop() }

    val postureLabel = when (posture) {
        PrayerMotionDetector.Posture.STANDING -> "قيام"
        PrayerMotionDetector.Posture.BOWING -> "ركوع"
        PrayerMotionDetector.Posture.PROSTRATING -> "سجود"
        PrayerMotionDetector.Posture.SITTING -> "جلوس"
        else -> "—"
    }

    Row(
        Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(RoundedCornerShape(16.dp)).background(pal.mid.copy(alpha = .12f)).padding(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        LineIcon(AppIcon.Sparkle, pal.mid, 18.dp)
        Spacer(Modifier.width(10.dp))
        Text(
            "وضعٌ تجريبيّ: ضع الهاتف في جيب الصدر أو الجيب الأمامي ليقدّر حركاتك. قد يُخطئ بحسب وضع الهاتف وسرعتك — والوضع اليدويّ أدقّ. ليس مرجعاً لصحّة الصلاة.",
            color = pal.mid, fontSize = 12.sp, lineHeight = 20.sp
        )
    }

    if (!supported) {
        Box(Modifier.fillMaxWidth().paper(pal, 20).padding(20.dp), contentAlignment = Alignment.Center) {
            Text("جهازك لا يحتوي مُستشعِر التسارع اللازم لهذا الوضع. استخدم العدّاد اليدويّ.",
                color = pal.ink2, textAlign = TextAlign.Center, lineHeight = 20.sp)
        }
        return
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        CounterCard("الركعات", rakah, pal, Modifier.weight(1f))
        CounterCard("السجدات", sajda, pal, Modifier.weight(1f))
    }
    Spacer(Modifier.height(16.dp))

    Column(
        Modifier.fillMaxWidth().paper(pal, 28).padding(vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(110.dp).clip(CircleShape).background(if (running) pal.heroBrush else androidx.compose.ui.graphics.SolidColor(pal.surface2)),
            contentAlignment = Alignment.Center
        ) {
            Text(postureLabel, color = if (running) Color.White else pal.ink2, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        }
        Spacer(Modifier.height(14.dp))
        Text(if (running) "يرصد الآن…" else "متوقّف", color = if (running) pal.good else pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
    Spacer(Modifier.height(18.dp))

    BigButton(if (running) "إيقاف" else "ابدأ الرصد", pal, !running) { running = !running }
    Spacer(Modifier.height(10.dp))
    BigButton("تصفير العدّاد", pal, false) {
        detector.reset(); rakah = 0; sajda = 0; posture = PrayerMotionDetector.Posture.UNKNOWN
    }
}

@Composable
private fun CounterCard(label: String, value: Int, pal: DuaaPalette, modifier: Modifier = Modifier) {
    Column(
        modifier.paper(pal, 20).padding(vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("$value", color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 38.sp)
        Spacer(Modifier.height(2.dp))
        Text(label, color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}
