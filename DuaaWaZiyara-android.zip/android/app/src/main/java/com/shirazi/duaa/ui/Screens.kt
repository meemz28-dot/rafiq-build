package com.shirazi.duaa.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.tween
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Data
import com.shirazi.duaa.data.DailyContent
import com.shirazi.duaa.data.Settings
import com.shirazi.duaa.logic.ArabicSearch
import com.shirazi.duaa.logic.HijriCalendar
import com.shirazi.duaa.logic.PrayerTimes
import java.util.Calendar

private val WEEKDAY_DUA = listOf("d-sun", "d-mon", "d-tue", "d-wed", "d-thu", "d-fri", "d-sat")
// بريد استقبال بلاغات أخطاء النصوص — على المطوّر تغييره لبريده الفعليّ قبل النشر
const val SUPPORT_EMAIL = "feedback@rafiqalmumin.app"

@Composable
fun HomeScreen(
    settings: Settings, pal: DuaaPalette,
    openReader: (String, String) -> Unit, openSheet: (String) -> Unit,
    openScreen: (String) -> Unit, goTab: (String) -> Unit
) {
    val haptics = rememberHaptics()
    // ساعة حيّة: تتجدّد كل ٣٠ ثانية — يبقى العدّاد صحيحاً وتُعاد المواقيت والتاريخ الهجري بعد منتصف الليل
    var clockTick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(30_000); clockTick++ } }
    val now = remember(clockTick) { Calendar.getInstance() }
    val t = remember(settings.hijriAdj.value, now.get(Calendar.DAY_OF_YEAR)) { HijriCalendar.today(settings.hijriAdj.value) }
    val loc = settings.location()
    val times = remember(loc.lat, loc.lng, loc.tz, settings.method.value, now.get(Calendar.DAY_OF_YEAR)) {
        PrayerTimes.compute(now, loc.lat, loc.lng, loc.tz, settings.method.value)
    }
    val nowH = now.get(Calendar.HOUR_OF_DAY) + now.get(Calendar.MINUTE) / 60.0
    val (nextKey, dt) = PrayerTimes.next(times, nowH)
    val nextName = PrayerTimes.slots.firstOrNull { it.key == nextKey }?.name ?: ""
    val hh = dt.toInt(); val mm = Math.round((dt - hh) * 60).toInt()
    val wd = now.get(Calendar.DAY_OF_WEEK) - 1
    val occ = Data.occasions.filter { it.m == t.m && it.d == t.d }
    val duaId = WEEKDAY_DUA[wd]
    val dua = Data.categories.firstOrNull { it.id == "osboo" }?.items?.firstOrNull { it.id == duaId }

    LaunchedEffect(Unit) { settings.touchStreak(); settings.refreshTodayActivity() }
    val dhikr = DailyContent.ofDay(settings.dayOfYearIndex())
    val hikma = DailyContent.hikmaOfDay(settings.dayOfYearIndex())
    val wird = settings.wirdMask.value
    val wirdDone = wird and 0b1111 == 0b1111

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        // ===== الرأس: ترحيب مضغوط + التاريخ الهجري =====
        Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background)) {
            Column(Modifier.fillMaxWidth().statusBarsPadding().padding(start = 18.dp, end = 14.dp, top = 10.dp, bottom = 8.dp)) {
                // ترويسة خفيفة: العنوان وسط، أيقونات جانبية
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(pal.emerald.copy(alpha = .1f))
                            .clickable { settings.theme.value = if (pal.dark) "light" else "dark"; settings.save() },
                        contentAlignment = Alignment.Center
                    ) { LineIcon(AppIcon.Theme, pal.emerald, 18.dp) }
                    Spacer(Modifier.weight(1f))
                    Text("الرئيسية", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    Spacer(Modifier.weight(1f))
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(pal.emerald.copy(alpha = .1f))
                            .clickable { goTab("lib") },
                        contentAlignment = Alignment.Center
                    ) { LineIcon(AppIcon.Search, pal.emerald, 18.dp) }
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(pal.emerald.copy(alpha = .1f))
                            .clickable { openSheet("settings") },
                        contentAlignment = Alignment.Center
                    ) { LineIcon(AppIcon.Gear, pal.emerald, 18.dp) }
                }
                // ===== شريط «اليوم»: مناسبات اليوم فقط (التاريخ يظهر في بطاقة المواقيت) =====
                if (occ.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    occ.forEachIndexed { idx, o ->
                        if (idx > 0) Spacer(Modifier.height(6.dp))
                        // اللون بحسب نوع المناسبة: الحزن رايةٌ سوداء مهيبة، والولادة والعيد ذهبٌ احتفاليّ
                        val mourning = o.k == "death"
                        val bannerBrush = when (o.k) {
                            "death" -> Brush.linearGradient(listOf(Color(0xFF2B2F35), Color(0xFF15171B)))
                            "birth", "eid" -> Brush.linearGradient(listOf(Color(0xFFC9A86A), Color(0xFFA9834A)))
                            else -> Brush.linearGradient(listOf(pal.emerald, pal.emerald.copy(alpha = .82f)))
                        }
                        val label = when (o.k) { "death" -> "ذكرى حزن"; "birth" -> "ذكرى ولادة"; "eid" -> "عيد ومناسبة"; else -> "مناسبة اليوم" }
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(bannerBrush)
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(Color.White.copy(alpha = .14f)),
                                contentAlignment = Alignment.Center
                            ) { LineIcon(if (mourning) AppIcon.Crescent else AppIcon.Sparkle, if (mourning) pal.gold else Color.White, 17.dp) }
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f)) {
                                Text(label, color = if (mourning) pal.gold else Color.White.copy(alpha = .9f),
                                    fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                                Text(o.t, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, lineHeight = 20.sp)
                            }
                        }
                    }
                }
            }
        }

        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            // ===== بطاقة المواقيت بأسلوب التصميم: مشهد غروب + صفّ الصلوات =====
            run {
                val slots = listOf(
                    Triple("fajr", "الفجر", PrayerGlyph.Dawn),
                    Triple("dhuhr", "الظهر", PrayerGlyph.Sun),
                    Triple("asr", "العصر", PrayerGlyph.Cloud),
                    Triple("maghrib", "المغرب", PrayerGlyph.Dusk),
                    Triple("isha", "العشاء", PrayerGlyph.Night)
                )
                val countdown = if (hh > 0) "${hh}س ${mm}د" else "${mm}د"
                Column(
                    Modifier.fillMaxWidth()
                        .shadow(16.dp, RoundedCornerShape(30.dp), spotColor = pal.emerald.copy(alpha = .30f), ambientColor = Color.Black.copy(alpha = .10f))
                        .clip(RoundedCornerShape(30.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .clickable { goTab("prayer") }
                ) {
                    // مشهد السماء + الصلاة القادمة في القلب (البطل)
                    Box(Modifier.fillMaxWidth().height(220.dp)) {
                        DuskScene(Modifier.matchParentSize().clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp)))
                        Box(
                            Modifier.matchParentSize().clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
                                .background(
                                    Brush.verticalGradient(
                                        0f to Color(0xFF0E3A44).copy(alpha = .55f),
                                        0.42f to Color(0xFF0E3A44).copy(alpha = .34f),
                                        1f to Color(0xFF0E3A44).copy(alpha = .60f)
                                    )
                                )
                        )
                        // الصفّ العلويّ: التاريخ الهجري + الموقع
                        Row(
                            Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(horizontal = 18.dp, vertical = 15.dp),
                            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clip(RoundedCornerShape(99.dp)).clickable { goTab("cal") }.padding(horizontal = 4.dp, vertical = 2.dp)) {
                                Text("${t.d} ${HijriCalendar.months[t.m - 1]} ${t.y} هـ", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(4.dp))
                                LineIcon(AppIcon.ChevronStart, Color.White.copy(alpha = .75f), 12.dp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                LineIcon(AppIcon.Pin, Color.White.copy(alpha = .9f), 13.dp)
                                Spacer(Modifier.width(4.dp))
                                Text(loc.n, color = Color.White.copy(alpha = .9f), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                        // القلب: الصلاة القادمة بارزة
                        Column(Modifier.align(Alignment.Center).padding(top = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("الصلاة القادمة", color = Color.White.copy(alpha = .85f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(nextName, color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "${PrayerTimes.fmt(PrayerTimes.value(times, nextKey))}  ·  بعد $countdown",
                                color = Color.White.copy(alpha = .92f), fontSize = 14.sp, fontWeight = FontWeight.Medium
                            )
                        }
                    }
                    // صفّ الصلوات الخمس
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        slots.forEach { (key, name, glyph) ->
                            val isNext = key == nextKey
                            Column(
                                Modifier.weight(1f).padding(horizontal = 3.dp).clip(RoundedCornerShape(16.dp))
                                    .background(if (isNext) pal.emerald else Color.Transparent)
                                    .padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(name, color = if (isNext) Color.White else pal.ink2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                PrayerIcon(glyph, if (isNext) Color.White else pal.emerald, 22.dp)
                                Spacer(Modifier.height(8.dp))
                                Text(PrayerTimes.fmt(PrayerTimes.value(times, key)),
                                    color = if (isNext) Color.White else MaterialTheme.colorScheme.onSurface,
                                    fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))

            // ===== وضع رمضان: يظهر تلقائياً في الشهر الكريم — عدّ الإفطار والإمساك وليالي القدر =====
            if (t.m == 9) {
                val maghribH = PrayerTimes.value(times, "maghrib")
                val fajrH = PrayerTimes.value(times, "fajr")
                val qadrNight = t.d in listOf(19, 21, 23)
                val beforeIftar = nowH < maghribH
                val target = if (beforeIftar) maghribH else fajrH + 24.0
                val remH = ((target - nowH) % 24.0 + 24.0) % 24.0
                val rh = remH.toInt(); val rm = ((remH - rh) * 60).toInt()
                Column(
                    Modifier.fillMaxWidth().padding(bottom = 14.dp)
                        .heroCard(if (qadrNight) pal.gold else pal.emerald)
                        .background(Brush.linearGradient(
                            if (qadrNight) listOf(Color(0xFF6D5518), Color(0xFF3E3110))
                            else listOf(Color(0xFF1F5A4E), Color(0xFF123C34))))
                        .pressable { openReader("ramadan", if (qadrNight) "r-new5092" else "r-abuhamza") }
                        .padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LineIcon(AppIcon.Crescent, pal.gold, 20.dp)
                        Spacer(Modifier.width(9.dp))
                        Text(if (qadrNight) "ليلة القدر — أحيِها" else "رمضان المبارك",
                            color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Spacer(Modifier.weight(1f))
                        Text("اليوم ${t.d}", color = Color.White.copy(alpha = .85f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (beforeIftar) "الإفطار بعد ${rh}س ${rm}د — ${PrayerTimes.fmt(maghribH)}"
                        else "الإمساك بعد ${rh}س ${rm}د — ${PrayerTimes.fmt(fajrH)}",
                        color = Color.White.copy(alpha = .92f), fontSize = 13.sp, fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(if (qadrNight) "أعمال الليلة المباركة — انقر للبدء" else "دعاء أبي حمزة الثمالي — انقر للقراءة",
                        color = pal.gold.copy(alpha = .95f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // شارة المواظبة — شريط أفقي أنيق
            Row(
                Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(16.dp))
                    .background(pal.gold.copy(alpha = if (pal.dark) .12f else .14f)).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LineIcon(AppIcon.Flame, pal.saffron, 20.dp)
                Spacer(Modifier.width(10.dp))
                Text("مواظبة ${settings.streak.value} ${if (settings.streak.value == 1) "يوم" else "أيام"}",
                    color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Spacer(Modifier.weight(1f))
                if (settings.bestStreak.value > 0)
                    Text("الأفضل ${settings.bestStreak.value}", color = pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            // ===== شارة نقاط القرآن (تظهر بعد كسب أوّل نقطة) =====
            if (settings.quranPoints.value > 0) {
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(16.dp))
                        .background(pal.emerald.copy(alpha = if (pal.dark) .16f else .12f))
                        .clickable { openScreen("qpoints") }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LineIcon(AppIcon.Star8, pal.gold, 20.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("نقاط القرآن ${settings.quranPoints.value}",
                        color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${settings.quranDoneCount.value}/114 سورة", color = pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    LineIcon(AppIcon.ChevronStart, pal.ink2, 18.dp)
                }
            }

            // ===== ماذا أقرأ الآن؟ — يظهر فقط لمن لا «متابعة» لديه (تجنّب التكرار) =====
            run {
                val hasResume = settings.lastReadCat.value != null &&
                    Data.categories.firstOrNull { it.id == settings.lastReadCat.value }?.items?.any { it.id == settings.lastReadId.value } == true
                val sg = com.shirazi.duaa.logic.Recommend.now(t.m, t.d, wd, now.get(Calendar.HOUR_OF_DAY))
                val sgItem = Data.categories.firstOrNull { it.id == sg.catId }?.items?.firstOrNull { it.id == sg.itemId }
                if (!hasResume && sgItem != null) {
                    Box(
                        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(18.dp))
                            .background(Brush.linearGradient(listOf(pal.emerald, pal.emeraldDeep)))
                            .clickable { openReader(sg.catId, sg.itemId) }
                    ) {
                        IslamicPattern(Color.White.copy(alpha = .07f), Modifier.matchParentSize(), cell = 60f)
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(50.dp).clip(RoundedCornerShape(16.dp))
                                    .background(Color.White.copy(alpha = .18f)), contentAlignment = Alignment.Center
                            ) { LineIcon(categoryIcon(sg.catId), Color.White, 26.dp) }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("ماذا أقرأ الآن؟ · ${sg.reason}", color = Color.White.copy(alpha = .82f), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                                Spacer(Modifier.height(3.dp))
                                Text(sgItem.title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 1)
                                Text(sg.label, color = Color.White.copy(alpha = .7f), fontSize = 11.sp)
                            }
                            LineIcon(AppIcon.ChevronStart, Color.White, 18.dp)
                        }
                    }
                }
            }

            // ===== المتابعة: آخر نص مقروء =====
            run {
                val lrc = settings.lastReadCat.value
                val lri = settings.lastReadId.value
                val lastCat = Data.categories.firstOrNull { it.id == lrc }
                val lastItem = lastCat?.items?.firstOrNull { it.id == lri }
                if (lastCat != null && lastItem != null) {
                    Box(
                        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(18.dp))
                            .background(Brush.linearGradient(categoryGradient(lastCat.id)))
                            .clickable { openReader(lastCat.id, lastItem.id) }
                    ) {
                        IslamicPattern(Color.White.copy(alpha = .06f), Modifier.matchParentSize(), cell = 64f)
                        Box(Modifier.align(Alignment.CenterStart).padding(start = 6.dp)) {
                            StarTile(Color.White.copy(alpha = .07f), 92.dp)
                        }
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(48.dp).clip(RoundedCornerShape(14.dp))
                                    .background(Color.White.copy(alpha = .16f))
                                    .border(1.dp, Color.White.copy(alpha = .25f), RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center
                            ) { LineIcon(AppIcon.Book, Color.White, 24.dp) }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("متابعة القراءة", color = Color.White.copy(alpha = .82f), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                                Spacer(Modifier.height(3.dp))
                                Text(lastItem.title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, maxLines = 1)
                                Text(lastCat.name, color = Color.White.copy(alpha = .7f), fontSize = 11.sp, maxLines = 1)
                            }
                            Spacer(Modifier.width(8.dp))
                            LineIcon(AppIcon.ChevronStart, Color.White, 18.dp)
                        }
                    }
                }
            }

            // ===== المقروء حديثاً — شريط أفقي =====
            run {
                val recent = settings.recentReads()
                    .mapNotNull { (c, i) ->
                        val cc = Data.categories.firstOrNull { it.id == c }
                        val ii = cc?.items?.firstOrNull { it.id == i }
                        if (cc != null && ii != null) Triple(cc.id, ii.id, ii.title) else null
                    }
                    .drop(1).take(8)   // أول عنصر هو نفسه "المتابعة"
                if (recent.isNotEmpty()) {
                    SectionTitle("المقروء حديثاً")
                    androidx.compose.foundation.lazy.LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(end = 4.dp)
                    ) {
                        items(recent) { triple ->
                            val (cId, iId, title) = triple
                            Box(
                                Modifier.width(150.dp).height(74.dp).clip(RoundedCornerShape(16.dp))
                                    .background(Brush.linearGradient(categoryGradient(cId)))
                                    .clickable { openReader(cId, iId) }
                            ) {
                                IslamicPattern(Color.White.copy(alpha = .06f), Modifier.matchParentSize(), cell = 44f)
                                Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                    LineIcon(categoryIcon(cId), Color.White.copy(alpha = .9f), 18.dp)
                                    Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 2, lineHeight = 17.sp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                }
            }

            // ===== مكتبتي — وصولٌ سريع للمفضّلة والعلامات =====
            run {
                val favCount = settings.favorites.size
                val bmCount = settings.bookmarks().size
                if (favCount > 0 || bmCount > 0) {
                    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        // المفضّلة
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                                .background(pal.gold.copy(alpha = .12f))
                                .border(1.dp, pal.gold.copy(alpha = .22f), RoundedCornerShape(18.dp))
                                .clickable { openSheet("fav") }.padding(16.dp)
                        ) {
                            Column {
                                LineIcon(AppIcon.StarFill, pal.gold, 24.dp)
                                Spacer(Modifier.height(8.dp))
                                Text("المفضّلة", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                                Text(if (favCount > 0) "$favCount محفوظ" else "لا شيء بعد", color = pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                        // العلامات المرجعية
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                                .background(pal.emerald.copy(alpha = .10f))
                                .border(1.dp, pal.emerald.copy(alpha = .22f), RoundedCornerShape(18.dp))
                                .clickable { openSheet("bookmarks") }.padding(16.dp)
                        ) {
                            Column {
                                LineIcon(AppIcon.Scroll, pal.emerald, 24.dp)
                                Spacer(Modifier.height(8.dp))
                                Text("العلامات", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                                Text(if (bmCount > 0) "$bmCount علامة" else "لا شيء بعد", color = pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }

            // ===== رحلتي — مدخلٌ بارزٌ للوحة التقدّم =====
            run {
                val streak = settings.streak.value
                Row(
                    Modifier.fillMaxWidth().padding(top = 14.dp)
                        .shadow(8.dp, RoundedCornerShape(20.dp), spotColor = pal.emerald.copy(alpha = .22f))
                        .clip(RoundedCornerShape(20.dp))
                        .background(pal.heroBrush)
                        .clickable { openScreen("journey") }
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                        LineIcon(AppIcon.StarFill, Color.White, 26.dp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("رحلتي", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text(
                            if (streak > 0) "سلسلة مواظبتك: $streak ${if (streak == 1) "يوم" else "يوماً"} — تابِع تقدّمك"
                            else "ابدأ رحلتك الروحيّة وتابِع تقدّمك",
                            color = Color.White.copy(alpha = .85f), fontSize = 12.sp, lineHeight = 17.sp
                        )
                    }
                    LineIcon(AppIcon.ChevronStart, Color.White.copy(alpha = .8f), 20.dp)
                }
            }

            // ===== الوِرد اليومي =====
            SectionTitle(if (wirdDone) "وِرد اليوم — اكتمل، تقبّل الله ✓" else "وِرد اليوم")
            PlainCard(pal) {
                WirdRow(AppIcon.Book, if (dua != null) "دعاء اليوم: ${dua.title}" else "دعاء اليوم", wird and 1 != 0, pal) {
                    settings.markWird(0); openReader("osboo", duaId)
                }
                WirdRow(AppIcon.Beads, "تسبيح الزهراء (ع)", wird and 2 != 0, pal) {
                    settings.markWird(1); openSheet("tasbih")
                }
                WirdRow(AppIcon.Sparkle, "ذكر اليوم", wird and 4 != 0, pal) { if (wird and 4 == 0) haptics.celebrate(); settings.toggleWird(2) }
                WirdRow(AppIcon.Hands, "صدقة اليوم — ولو يسيرة", wird and 8 != 0, pal) { if (wird and 8 == 0) haptics.celebrate(); settings.toggleWird(3) }
                Spacer(Modifier.height(6.dp))
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(pal.gold.copy(alpha = if (pal.dark) .10f else .12f)).padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(dhikr.text, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp, lineHeight = 30.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(4.dp))
                    Text(dhikr.src, color = pal.gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                // عدّاد الأذكار اليومي المتدرّج — مرتبط بالتسبيح
                Spacer(Modifier.height(10.dp))
                val dCount = settings.dhikrTodayCount.value
                val dGoal = settings.dhikrGoal.value
                val dFrac = if (dGoal > 0) (dCount.toFloat() / dGoal).coerceIn(0f, 1f) else 0f
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(pal.emerald.copy(alpha = if (pal.dark) .12f else .08f))
                        .clickable { openSheet("tasbih") }.padding(14.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        LineIcon(AppIcon.Beads, pal.emerald, 18.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(if (dCount >= dGoal && dGoal > 0) "وِرد الذِّكر اليومي — اكتمل ✓" else "وِرد الذِّكر اليومي",
                            color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Text("$dCount / $dGoal", color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(99.dp)).background(pal.surface2)) {
                        Box(Modifier.fillMaxWidth(dFrac).height(10.dp).clip(RoundedCornerShape(99.dp)).background(pal.emerald))
                    }
                }
            }

            // ===== بطاقتا حكمة اليوم وزيارة اليوم (شبكة من بطاقتين) =====
            val zDay = listOf(
                Triple("أمير المؤمنين (ع)", "ziyarat", "z-amin"),
                Triple("الحسنان (ع)", "ziyarat", "z-warith"),
                Triple("السجاد والباقر والصادق (ع)", "ziyarat", "z-jamia"),
                Triple("الكاظم والرضا والجواد والهادي (ع)", "ziyarat", "z-redha"),
                Triple("العسكري (ع)", "ziyarat", "z-jamia"),
                Triple("صاحب الزمان (عج)", "ziyarat", "z-yasin"),
                Triple("النبي الأعظم (ص)", "ziyarat", "z-nabi")
            )[wd]
            SectionTitle("بطاقات اليوم")
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                // حكمة اليوم
                Box(
                    Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(categoryGradient("hikam")))
                        .clickable { openReader("hikam", "hk-ali-1") }
                ) {
                    IslamicPattern(Color.White.copy(alpha = .06f), Modifier.matchParentSize(), cell = 56f)
                    Column(Modifier.fillMaxSize().padding(14.dp)) {
                        Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                            LineIcon(AppIcon.Scroll, Color.White, 17.dp)
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("حكمة اليوم", color = Color.White.copy(alpha = .82f), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(4.dp))
                        Text("«${hikma.text}»", fontSize = 13.sp, lineHeight = 22.sp, fontWeight = FontWeight.Bold,
                            color = Color.White, maxLines = 4)
                        Spacer(Modifier.height(6.dp))
                        Text("— ${hikma.who}", color = Color.White.copy(alpha = .75f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                // زيارة اليوم
                Box(
                    Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(categoryGradient("ziyarat")))
                        .clickable { openReader(zDay.second, zDay.third) }
                ) {
                    IslamicPattern(Color.White.copy(alpha = .06f), Modifier.matchParentSize(), cell = 56f)
                    Column(Modifier.fillMaxSize().padding(14.dp)) {
                        Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                            LineIcon(AppIcon.Flag, Color.White, 17.dp)
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("زيارة اليوم", color = Color.White.copy(alpha = .82f), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(4.dp))
                        Text(zDay.first, fontSize = 14.sp, lineHeight = 23.sp, fontWeight = FontWeight.Bold,
                            color = Color.White, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(6.dp))
                        Text("بحسب المأثور", color = Color.White.copy(alpha = .75f), fontSize = 11.sp)
                    }
                }
            }
            // ===== بطاقتا اليوم المتخصّصتان: حقّ اليوم + دعاء هذه الساعة — صفٌّ واحد متساوي الارتفاع =====
            run {
                val hq = Data.categories.firstOrNull { it.id == "huquq" }
                val yw = Data.categories.firstOrNull { it.id == "yawm" }
                val right = hq?.takeIf { it.items.size > 2 }?.let { c ->
                    val rights = c.items.subList(1, c.items.size - 1)
                    rights[settings.dayOfYearIndex() % rights.size]
                }
                val pick = yw?.takeIf { it.items.isNotEmpty() }?.let { c ->
                    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                    val bucket = when {
                        hour < 10 -> listOf("hj-intibah", "hj-wudu", "hj-libs-hamd", "hj-libs-yumn")
                        hour < 15 -> listOf("hj-taam", "hj-ghasl-taam", "hj-adha-taam", "hj-thawb-jadid")
                        else -> listOf("hj-masjid-going", "hj-masjid-enter", "hj-tawajjuh", "hj-adhan-iqama")
                    }
                    val ids = bucket.filter { b -> c.items.any { it.id == b } }
                    if (ids.isNotEmpty()) c.items.first { it.id == ids[settings.dayOfYearIndex() % ids.size] } else null
                }
                if (right != null || pick != null) {
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (right != null) {
                            Column(
                                Modifier.weight(1f).fillMaxHeight().gradientCard(20)
                                    .background(Brush.linearGradient(categoryGradient("huquq")))
                                    .pressable { openReader("huquq", right.id) }
                                    .padding(14.dp)
                            ) {
                                Text("حقّ اليوم", color = Color.White.copy(alpha = .82f), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                                Spacer(Modifier.height(4.dp))
                                Text(right.title, color = Color.White, fontSize = 14.sp, lineHeight = 20.sp,
                                    fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.weight(1f)); Spacer(Modifier.height(4.dp))
                                Text("رسالة الحقوق", color = Color.White.copy(alpha = .6f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (pick != null) {
                            Column(
                                Modifier.weight(1f).fillMaxHeight().gradientCard(20)
                                    .background(Brush.linearGradient(categoryGradient("yawm")))
                                    .pressable { openReader("yawm", pick.id) }
                                    .padding(14.dp)
                            ) {
                                Text("دعاء هذه الساعة", color = Color.White.copy(alpha = .82f), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                                Spacer(Modifier.height(4.dp))
                                Text(pick.title, color = Color.White, fontSize = 14.sp, lineHeight = 20.sp,
                                    fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.weight(1f)); Spacer(Modifier.height(4.dp))
                                Text("اليوم والليلة", color = Color.White.copy(alpha = .6f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))

            SectionTitle("أعمال وأدوات")
            QuickGrid(pal, openReader, openSheet, openScreen, goTab)
            Spacer(Modifier.height(24.dp))
        }
    }
}

/** حلقة العدّ التنازلي للصلاة القادمة. */
@Composable
private fun CountdownRing(hh: Int, mm: Int, pal: DuaaPalette, modifier: Modifier = Modifier) {
    val totalMin = hh * 60 + mm
    val frac = 1f - (totalMin.coerceIn(0, 360) / 360f)  // الحلقة تمتلئ كلما اقترب الوقت (أفق 6 ساعات)
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 7f; val d = size.minDimension - sw
            val tl = Offset((size.width - d) / 2, (size.height - d) / 2)
            drawArc(pal.line, -90f, 360f, false, topLeft = tl, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(pal.gold, -90f, 360f * frac, false, topLeft = tl, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (hh > 0) "$hh:${if (mm < 10) "0$mm" else "$mm"}" else "$mm",
                color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = if (hh > 0) 16.sp else 22.sp)
            Text(if (hh > 0) "ساعة" else "دقيقة", color = pal.ink2, fontSize = 10.sp)
        }
    }
}

@Composable
private fun QuickGrid(pal: DuaaPalette, openReader: (String, String) -> Unit, openSheet: (String) -> Unit, openScreen: (String) -> Unit, goTab: (String) -> Unit) {
    // ⚠ قاعدة حوكمة الشبكة: ١٢ بلاطةً (٤ صفوف × ٣) هي السقف الثابت.
    // أيّ أداةٍ جديدة يجب أن تحلّ محلّ بلاطةٍ قائمة (تُنقَل المُزاحة إلى قائمة «المزيد»)، لا أن تُضاف صفّاً خامساً.
    // كلّ وجهات الشبكة موجودة أيضاً في «المزيد»، فالإنزال آمنٌ دائماً ولا يفقد المستخدم الوصول.
    data class Quick(val ic: AppIcon, val label: String, val grad: List<Color>, val action: () -> Unit)
    val items = listOf(
        Quick(AppIcon.Dome, "الحجّ والعمرة", categoryGradient("ziyarat")) { openScreen("hajj") },
        Quick(AppIcon.Star8, "خيرة القرآن", categoryGradient("hikam")) { openScreen("khira") },
        Quick(AppIcon.Calc, "حاسبة الخمس", categoryGradient("hajat")) { openScreen("khums") },
        Quick(AppIcon.Book, "المعصومون", categoryGradient("rajab")) { openScreen("masoom") },
        Quick(AppIcon.StarFill, "محاسبة النفس", categoryGradient("tarbiya")) { openScreen("muhasaba") },
        Quick(AppIcon.Clock, "قضاء الفوائت", categoryGradient("osboo")) { openScreen("qada") },
        Quick(AppIcon.Pin, "اتجاه القبلة", categoryGradient("salawat")) { openScreen("qibla") },
        Quick(AppIcon.Sparkle, "أسماء الله", categoryGradient("nawafil")) { openScreen("asma") },
        Quick(AppIcon.Book, "نقاط القرآن", categoryGradient("quran")) { openScreen("qpoints") },
        Quick(AppIcon.Moon2, "صلاة الليل", categoryGradient("ramadan")) { openScreen("layl") },
        Quick(AppIcon.Crescent, "أعمال اليوم", categoryGradient("jumaa")) { openScreen("amaal") },
        Quick(AppIcon.Beads, "السبحة", categoryGradient("munajat")) { openSheet("tasbih") }
    )
    Column {
        items.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { q ->
                    Box(
                        Modifier.weight(1f).height(96.dp).clip(RoundedCornerShape(18.dp))
                            .background(Brush.linearGradient(q.grad))
                            .pressable(q.action)
                    ) {
                        IslamicPattern(Color.White.copy(alpha = .06f), Modifier.matchParentSize(), cell = 54f)
                        Column(
                            Modifier.fillMaxSize().padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = .18f)),
                                contentAlignment = Alignment.Center
                            ) { LineIcon(q.ic, Color.White, 20.dp) }
                            Spacer(Modifier.height(8.dp))
                            Text(q.label, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = Color.White,
                                textAlign = TextAlign.Center, lineHeight = 15.sp, maxLines = 2)
                        }
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        letterSpacing = 0.3.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 11.dp, start = 4.dp)
    )
}

@Composable
fun WirdRow(icon: AppIcon, label: String, done: Boolean, pal: DuaaPalette, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(14.dp))
            .background(if (done) pal.good.copy(alpha = .10f) else pal.surface2.copy(alpha = .5f))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(24.dp).clip(CircleShape)
                .background(if (done) pal.good else Color.Transparent)
                .border(1.5.dp, if (done) pal.good else pal.line, CircleShape),
            contentAlignment = Alignment.Center
        ) { if (done) Text("✓", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(10.dp))
        LineIcon(icon, pal.emerald, 16.dp); Spacer(Modifier.width(8.dp))
        Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
        LineIcon(AppIcon.ChevronEnd, pal.ink2, 18.dp)
    }
}

@Composable
fun OccBadge(kind: String, text: String, pal: DuaaPalette) {
    val (bg, fg) = when (kind) {
        "eid" -> pal.good.copy(alpha = .18f) to pal.good
        "birth" -> pal.gold.copy(alpha = .18f) to pal.gold
        "death" -> pal.danger.copy(alpha = .15f) to pal.danger
        else -> pal.surface2 to pal.ink2
    }
    Row(Modifier.clip(RoundedCornerShape(99.dp)).background(bg).padding(horizontal = 12.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(fg)); Spacer(Modifier.width(6.dp))
        Text(text, color = fg, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ItemRow(title: String, subtitle: String?, pal: DuaaPalette, catId: String? = null, read: Boolean = false, fav: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 10.dp)
            .paper(pal, 18)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // شارة أيقونة الباب — تعطي عمقاً كبطاقات الرئيسية
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
                .background(pal.gold.copy(alpha = if (pal.dark) .16f else .12f)),
            contentAlignment = Alignment.Center
        ) { LineIcon(if (catId != null) categoryIcon(catId) else AppIcon.Beads, pal.gold, 20.dp) }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 21.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) {
                Spacer(Modifier.height(2.dp))
                Text(subtitle, color = pal.ink2, fontSize = 12.sp, maxLines = 2, lineHeight = 16.sp)
            }
        }
        Spacer(Modifier.width(8.dp))
        // مؤشّرات هادئة: نجمة للمفضّل، علامة للنصّ المقروء سابقاً — للاهتداء في القوائم الطويلة
        if (fav) {
            LineIcon(AppIcon.StarFill, pal.gold, 15.dp)
            Spacer(Modifier.width(6.dp))
        } else if (read) {
            Text("✓", color = pal.good.copy(alpha = .75f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
        }
        LineIcon(AppIcon.ChevronEnd, pal.ink2.copy(alpha = .6f), 18.dp)
    }
}

// ============ المكتبة + البحث ============
@Composable
fun LibraryScreen(settings: Settings, pal: DuaaPalette, openReader: (String, String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var openCat by remember { mutableStateOf<String?>(null) }
    var searchFocused by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (openCat == null) {
            // شريط البحث
            Row(
                Modifier.fillMaxWidth().padding(bottom = 14.dp).paper(pal, 20)
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LineIcon(AppIcon.Search, pal.ink2, 17.dp)
                Spacer(Modifier.width(8.dp))
                TextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("ابحث في الأدعية والزيارات…", color = pal.ink2) },
                    singleLine = true,
                    modifier = Modifier.weight(1f).onFocusChanged { searchFocused = it.isFocused },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
                    )
                )
            }
            if (query.isBlank()) {
                LazyColumn {
                    item {
                        // رقاقات «الأكثر طلباً» تظهر فقط عند النقر على البحث — لتبقى الشاشة هادئة
                        if (searchFocused) {
                            Text("الأكثر طلباً", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp))
                            val quick = listOf(
                                "كميل" to ("mashhura" to "m-kumayl"),
                                "زيارة عاشوراء" to ("ziyarat" to "z-ashura"),
                                "الندبة" to ("mashhura" to "m-nudba"),
                                "التوسّل" to ("mashhura" to "m-tawassul"),
                                "الجوشن الكبير" to ("ramadan" to "r-jawshan"),
                                "أبو حمزة" to ("ramadan" to "r-abuhamza"),
                                "تسبيح الزهراء" to ("nawafil" to "nf-tasbih-fatima"),
                                "الزيارة الجامعة" to ("ziyarat" to "z-jamia")
                            )
                            Column(Modifier.padding(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                quick.chunked(2).forEach { row ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        row.forEach { (label, dest) ->
                                            Box(
                                                Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(pal.emerald.copy(alpha = .10f))
                                                    .border(1.dp, pal.emerald.copy(alpha = .22f), RoundedCornerShape(14.dp))
                                                    .clickable { openReader(dest.first, dest.second) }
                                                    .padding(vertical = 13.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(label, color = pal.emerald, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        if (row.size == 1) Spacer(Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                        Text("تصفّح الأبواب", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp))
                    }
                    items(Data.categories) { c ->
                        CatCard(c.id, c.name, c.desc, c.items.size, pal) { openCat = c.id }
                    }
                }
            } else {
                val hits = remember(query) { ArabicSearch.search(query) }
                if (hits.isEmpty()) {
                    PlainCard(pal) { Text("لا توجد نتائج لـ «$query»", color = pal.ink2, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
                } else {
                    Text("${hits.size} نتيجة", color = pal.ink2, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
                    LazyColumn {
                        items(hits) { h ->
                            val sub = h.cat.name + (if (h.snippet.isNotEmpty()) " — ${h.snippet}" else "")
                            ItemRow(h.item.title, sub, pal, h.cat.id) { openReader(h.cat.id, h.item.id) }
                        }
                    }
                }
            }
        } else {
            val c = Data.categories.first { it.id == openCat }
            // ترويسة متدرّجة تطابق بطاقة الباب التي ضُغطت — استمراريّة بصرية
            Box(
                Modifier.fillMaxWidth().padding(bottom = 14.dp)
                    .shadow(6.dp, RoundedCornerShape(20.dp), spotColor = categoryGradient(c.id).first().copy(alpha = .25f), ambientColor = Color.Black.copy(alpha = .06f))
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(categoryGradient(c.id))).height(84.dp)
            ) {
                IslamicPattern(Color.White.copy(alpha = .07f), Modifier.matchParentSize(), cell = 64f)
                Box(Modifier.align(Alignment.CenterEnd).padding(end = 4.dp)) {
                    StarTile(Color.White.copy(alpha = .07f), 92.dp)
                }
                Row(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = .18f))
                        .clickable { openCat = null }, contentAlignment = Alignment.Center) {
                        LineIcon(AppIcon.ChevronStart, Color.White, 17.dp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .16f))
                        .border(1.dp, Color.White.copy(alpha = .25f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        LineIcon(categoryIcon(c.id), Color.White, 23.dp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color.White, lineHeight = 23.sp,
                            style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = .30f), blurRadius = 6f)))
                        Text("${c.items.size} نصّاً", color = Color.White.copy(alpha = .95f), fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = .35f), blurRadius = 6f)))
                    }
                }
            }
            val readSet = remember(c.id) { settings.readKeys() }
            LazyColumn {
                items(c.items) { it2 -> ItemRow(it2.title, it2.src, pal, c.id, read = readSet.contains("${c.id}|${it2.id}"), fav = settings.isFav(c.id, it2.id)) { openReader(c.id, it2.id) } }
            }
        }
    }
}

@Composable
private fun CatCard(catId: String, name: String, desc: String, count: Int, pal: DuaaPalette, onClick: () -> Unit) {
    val grad = categoryGradient(catId)
    Box(
        Modifier.fillMaxWidth().padding(bottom = 12.dp)
            .shadow(6.dp, RoundedCornerShape(20.dp), spotColor = grad.first().copy(alpha = .25f), ambientColor = Color.Black.copy(alpha = .06f))
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(grad))
            .pressable(onClick)
            .height(96.dp)
    ) {
        IslamicPattern(Color.White.copy(alpha = .07f), Modifier.matchParentSize(), cell = 70f)
        // زخرفة النجمة الثمانية تعطي عمقاً بصرياً بديلاً عن الصورة
        Box(Modifier.align(Alignment.CenterStart).padding(start = 8.dp)) {
            StarTile(Color.White.copy(alpha = .08f), 110.dp)
        }
        Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) {
            StarTile(Color.White.copy(alpha = .06f), 56.dp)
        }
        Row(
            Modifier.fillMaxSize().padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(54.dp).clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = .16f))
                    .border(1.dp, Color.White.copy(alpha = .25f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) { LineIcon(categoryIcon(catId), Color.White, 26.dp) }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = Color.White, lineHeight = 24.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = .30f), blurRadius = 6f)))
                Spacer(Modifier.height(3.dp))
                Text(desc, color = Color.White.copy(alpha = .95f), fontSize = 13.sp, maxLines = 2, lineHeight = 18.sp,
                    overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium,
                    style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = .35f), blurRadius = 6f)))
            }
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.clip(RoundedCornerShape(99.dp)).background(Color.White.copy(alpha = .18f))
                    .padding(horizontal = 11.dp, vertical = 5.dp)
            ) {
                Text("$count", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
            }
        }
    }
}

// ============ القارئ ============
@Composable
fun ReaderScreen(
    settings: Settings, pal: DuaaPalette, catId: String, itemId: String,
    onClose: () -> Unit, onNavigate: (String, String) -> Unit, onHome: () -> Unit
) {
    val haptics = rememberHaptics()
    val cat = Data.categories.firstOrNull { it.id == catId }
    val item = cat?.items?.firstOrNull { it.id == itemId }
    if (cat == null || item == null) {
        // محتوى غير موجود — واجهةٌ لطيفةٌ بدل الانهيار
        Column(Modifier.fillMaxSize().background(pal.bgBrush)) {
            ScreenTopBar("تعذّر العرض", pal, onClose)
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("تعذّر فتح هذا المحتوى، قد يكون غير متوفّر حالياً.", color = pal.ink2, textAlign = TextAlign.Center)
            }
        }
        return
    }
    val idx = cat.items.indexOfFirst { it.id == itemId }
    val prev = if (idx > 0) cat.items[idx - 1] else null
    val next = if (idx < cat.items.size - 1) cat.items[idx + 1] else null
    val tashkeel = settings.tashkeelOn.value
    var isFav by remember(itemId) { mutableStateOf(settings.isFav(catId, itemId)) }
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current
    val scroll = rememberScrollState()

    // سجِّل فتح النص (للمتابعة + المقروء حديثاً + الأكثر قراءة)
    LaunchedEffect(catId, itemId) { settings.recordRead(catId, itemId) }
    // احفظ موضع التمرير دورياً للمتابعة من نفس المكان
    LaunchedEffect(scroll.value) {
        kotlinx.coroutines.delay(400)
        settings.saveScroll(catId, itemId, scroll.value)
    }

    // ===== الوضع التفاعلي: تقسيم النص إلى فقرات + متابعة الفقرة الحالية =====
    var interactive by remember { mutableStateOf(false) }
    var current by remember(itemId) { mutableStateOf(0) }
    val paras = remember(itemId, tashkeel) {
        val raw = if (tashkeel) item.text else ArabicSearch.stripTashkeel(item.text)
        raw.split("\n\n").map { it.trim() }.filter { it.isNotEmpty() }
    }
    var flash by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(flash) { if (flash != null) { kotlinx.coroutines.delay(1800); flash = null } }
    LaunchedEffect(itemId) {
        val saved = settings.loadScroll(catId, itemId)
        scroll.scrollTo(saved); current = 0
        // إشعار الاستئناف — فقط إذا استُعيد موضعٌ متقدّم فعلاً
        if (saved > 600) flash = "استُؤنِفت القراءة من موضعك الأخير ✓"
    }
    androidx.activity.compose.BackHandler { onClose() }

    // ===== تحفيز قراءة القرآن: منح نقاط عند إكمال السورة =====
    var awardBanner by remember(itemId) { mutableStateOf(0) }   // عدد النقاط الممنوحة للعرض
    var alreadyAwarded by remember(itemId) { mutableStateOf(settings.isSurahDone(itemId)) }
    // السور القصيرة التي تظهر كاملةً دون تمرير: تُحتسب بعد دقيقة قراءة (بعد استقرار التخطيط)
    LaunchedEffect(itemId) {
        if (catId == "quran" && !alreadyAwarded) {
            kotlinx.coroutines.delay(8000)   // مهلة قراءة قصيرة
            if (scroll.maxValue == 0 && !alreadyAwarded) {
                val granted = settings.completeSurah(itemId)
                if (granted > 0) { awardBanner = granted; alreadyAwarded = true; haptics.celebrate() }
            }
        }
    }

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        val sepiaBg = Color(0xFFF4ECD8)
        Box(Modifier.fillMaxSize().then(
            if (settings.readerSepia.value) Modifier.background(sepiaBg) else Modifier.background(pal.bgBrush)
        )) {
        Column(Modifier.fillMaxSize()) {
            // الشريط العلوي
            Box(Modifier.fillMaxWidth().background(pal.heroBrush)) {
                IslamicPattern(Color.White.copy(alpha = .05f), Modifier.matchParentSize(), cell = 80f)
                // مؤشّر تقدّم القراءة — خيطٌ ذهبيّ أسفل الشريط، يظهر في النصوص الطويلة فقط
                if (scroll.maxValue > 200) {
                    Box(Modifier.matchParentSize()) {
                        Box(Modifier.align(Alignment.BottomStart)
                            .fillMaxWidth((scroll.value.toFloat() / scroll.maxValue).coerceIn(0f, 1f))
                            .height(2.5.dp).background(pal.gold))
                    }
                }
                Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    ReaderIconBtn(AppIcon.ChevronStart, pal) { onClose() }
                    Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Text(item.title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, maxLines = 2)
                        Text("${cat.name} · ${idx + 1} من ${cat.items.size}", color = Color.White.copy(alpha = .7f), fontSize = 10.sp)
                    }
                    ReaderIconBtn(if (isFav) AppIcon.StarFill else AppIcon.Star, pal) { settings.toggleFav(catId, itemId); isFav = !isFav }
                    Spacer(Modifier.width(6.dp))
                    ReaderIconBtn(AppIcon.Copy, pal) { clipboard.setText(AnnotatedString(item.title + "\n\n" + item.text)); flash = "نُسِخ النصّ ✓" }
                    ReaderIconBtn(AppIcon.Flag, pal) {
                        val subject = "بلاغ عن خطأ في نصّ: ${item.title} [$catId/$itemId]"
                        val mailBody = "السلام عليكم،\nلاحظتُ ما يلي في نصّ «${item.title}» (المعرّف: $catId/$itemId):\n\n(صِف الخطأ هنا)\n\nوجزاكم الله خيراً."
                        val uri = android.net.Uri.parse("mailto:$SUPPORT_EMAIL?subject=" + android.net.Uri.encode(subject) + "&body=" + android.net.Uri.encode(mailBody))
                        try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, uri)) } catch (_: Exception) {}
                    }
                    Spacer(Modifier.width(6.dp))
                    ReaderIconBtn(AppIcon.Share, pal) {
                        com.shirazi.duaa.logic.ShareCard.shareText(ctx, item.title, item.text, item.src)
                    }
                }
            }
            // شريط تقدّم القراءة — تفاعلياً بالفقرات، وفي القراءة الحرّة بالتمرير
            run {
                val frac = if (interactive && paras.size > 1) {
                    (current + 1f) / paras.size
                } else {
                    val mx = scroll.maxValue
                    if (mx > 0) (scroll.value.toFloat() / mx).coerceIn(0f, 1f) else 0f
                }
                if (frac > 0f) {
                    Box(Modifier.fillMaxWidth().height(4.dp).background(pal.line)) {
                        Box(Modifier.fillMaxWidth(frac).height(4.dp).background(pal.gold))
                    }
                }
                // إكمال سورة قرآنية ⇐ منح نقاط (مرّة واحدة لكلّ سورة)
                if (catId == "quran" && !alreadyAwarded && frac >= 0.95f) {
                    val granted = settings.completeSurah(itemId)
                    if (granted > 0) { awardBanner = granted; alreadyAwarded = true; haptics.celebrate() }
                }
            }
            Column(Modifier.weight(1f).verticalScroll(scroll).padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 20.dp)) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(start = 2.dp, end = 16.dp, bottom = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ToolChip(if (interactive) "تفاعلي ✓" else "تفاعلي", interactive, pal) { interactive = !interactive; current = 0 }
                    ToolChip(if (tashkeel) "التشكيل ✓" else "التشكيل", tashkeel, pal) { settings.tashkeelOn.value = !tashkeel; settings.saveReaderPrefs() }
                    ToolChip("حجم −", false, pal) { settings.fontSize.value = (settings.fontSize.value - 2).coerceAtLeast(15f); settings.save() }
                    ToolChip("حجم +", false, pal) { settings.fontSize.value = (settings.fontSize.value + 2).coerceAtMost(40f); settings.save() }
                    ToolChip("تباعد ${when { settings.lineHeight.value >= 2.35f -> "٣"; settings.lineHeight.value >= 2.05f -> "٢"; else -> "١" }}", false, pal) {
                        val nv = if (settings.lineHeight.value >= 2.4f) 1.7f else settings.lineHeight.value + 0.2f
                        settings.lineHeight.value = nv; settings.saveReaderPrefs()
                    }
                    ToolChip(if (settings.readerSepia.value) "ورقي ✓" else "ورقي", settings.readerSepia.value, pal) {
                        settings.readerSepia.value = !settings.readerSepia.value; settings.saveReaderPrefs()
                    }
                    ToolChip("ضع علامة", false, pal) {
                        settings.addBookmark(catId, itemId, scroll.value, item.title)
                        flash = "حُفظت العلامة ✓"; haptics.confirm()
                    }
                }
                // ميدالية اسم السورة (للقرآن) — على نسق التصميم
                if (catId == "quran") {
                    Box(Modifier.fillMaxWidth().padding(bottom = 16.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(150.dp).clip(RoundedCornerShape(28.dp))
                                    .background(pal.emerald.copy(alpha = if (pal.dark) .14f else .08f))
                                    .border(1.5.dp, pal.emerald.copy(alpha = .35f), RoundedCornerShape(28.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                StarTile(pal.emerald.copy(alpha = .10f), 130.dp)
                                Text(item.title.replace("سورة ", ""), color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
                            }
                            if (item.intro != null) {
                                Spacer(Modifier.height(12.dp))
                                Text(item.intro.replace("\n", " · "), color = pal.ink2, fontSize = 12.sp,
                                    textAlign = TextAlign.Center, lineHeight = 19.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp))
                            }
                        }
                    }
                }
                if (item.src != null && catId != "quran") {
                    Row(
                        Modifier.clip(RoundedCornerShape(99.dp)).background(pal.gold.copy(alpha = .14f))
                            .border(1.dp, pal.gold.copy(alpha = .25f), RoundedCornerShape(99.dp))
                            .padding(horizontal = 13.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LineIcon(AppIcon.Book, pal.gold, 14.dp)
                        Spacer(Modifier.width(6.dp))
                        Text(item.src, color = pal.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(14.dp))
                }
                if (item.intro != null && catId != "quran") {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(pal.emerald.copy(alpha = if (pal.dark) .10f else .07f))
                            .padding(16.dp)
                    ) {
                        Box(Modifier.size(width = 3.dp, height = 36.dp).clip(RoundedCornerShape(2.dp)).background(pal.emerald))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("نبذة", color = pal.emerald, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(Modifier.height(4.dp))
                            Text(item.intro, color = pal.ink2, fontSize = 14.sp, lineHeight = 23.sp)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }
                val fs = settings.fontSize.value
                val lh = settings.lineHeight.value
                val sepiaInk = Color(0xFF3A2E1A)
                val readInk = if (settings.readerSepia.value) sepiaInk else MaterialTheme.colorScheme.onBackground
                if (interactive) {
                    // فقرات قابلة للنقر في بطاقةٍ موحّدة: المقروء باهت، الحالية مظلّلة، القادم عادي
                    val cardBg = if (settings.readerSepia.value) Color(0xFFFBF6E9) else MaterialTheme.colorScheme.surface
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                            .background(cardBg)
                            .border(1.dp, pal.line.copy(alpha = .6f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 14.dp, vertical = 14.dp)
                    ) {
                    paras.forEachIndexed { i, p ->
                        val isCur = i == current
                        val isDone = i < current
                        Box(
                            Modifier.fillMaxWidth().padding(bottom = if (i < paras.lastIndex) 8.dp else 0.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isCur) pal.gold.copy(alpha = if (pal.dark) .16f else .14f) else Color.Transparent)
                                .clickable { current = i }
                                .padding(if (isCur) 14.dp else 6.dp)
                        ) {
                            Text(
                                p, fontSize = fs.sp, lineHeight = (fs * lh).sp,
                                fontFamily = AppFonts.scripture,
                                color = when {
                                    isCur -> readInk
                                    isDone -> (if (settings.readerSepia.value) sepiaInk else pal.ink2).copy(alpha = .5f)
                                    else -> readInk
                                },
                                fontWeight = if (isCur) FontWeight.Bold else FontWeight.Normal,
                                textAlign = TextAlign.Start, modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    }
                } else {
                    val text = if (tashkeel) item.text else ArabicSearch.stripTashkeel(item.text)
                    // النصّ في بطاقةٍ أنيقة بدل أن يكون عائماً
                    val cardBg = if (settings.readerSepia.value) Color(0xFFFBF6E9) else MaterialTheme.colorScheme.surface
                    val paragraphs = text.split("\n\n").map { it.trim() }.filter { it.isNotEmpty() }
                    Box(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                            .background(cardBg)
                            .border(1.dp, pal.line.copy(alpha = .6f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 20.dp, vertical = 22.dp)
                    ) {
                        SelectionContainer {
                            Column(Modifier.fillMaxWidth()) {
                                paragraphs.forEachIndexed { pi, para ->
                                    // البسملة إذا كانت في سطرٍ مستقلّ: تُبرَز في الوسط بلون ذهبيّ
                                    val isBasmala = ArabicSearch.stripTashkeel(para).startsWith("بسم الله الرحمن الرحيم") && para.length < 60
                                    if (isBasmala) {
                                        Text(para, fontSize = (fs * 0.98f).sp, lineHeight = (fs * lh).sp,
                                            fontFamily = AppFonts.scripture, color = pal.gold, fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp))
                                    } else {
                                        Text(para, fontSize = fs.sp, lineHeight = (fs * lh).sp,
                                            fontFamily = AppFonts.scripture,
                                            color = readInk, textAlign = TextAlign.Start, modifier = Modifier.fillMaxWidth())
                                        if (pi < paragraphs.lastIndex) Spacer(Modifier.height((fs * 0.55f).dp))
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
            }
            // شريط التنقّل السفلي
            if (interactive) {
                // تنقّل بين الفقرات داخل الدعاء
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(bottom = 12.dp).navigationBarsPadding()
                        .paper(pal, 24).padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    NavPill("المقطع السابق", AppIcon.ChevronStart, true, current > 0, pal, Modifier.weight(1f)) { if (current > 0) current-- }
                    Box(Modifier.clip(RoundedCornerShape(12.dp)).background(pal.surface2).padding(horizontal = 12.dp, vertical = 10.dp)) {
                        Text("${current + 1}/${paras.size}", color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                    }
                    NavPill("المقطع التالي", AppIcon.ChevronEnd, false, current < paras.size - 1, pal, Modifier.weight(1f)) { if (current < paras.size - 1) current++ }
                }
            } else {
                // تنقّل بين الأدعية
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(bottom = 12.dp).navigationBarsPadding()
                        .paper(pal, 24).padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    NavPill("النصّ السابق", AppIcon.ChevronStart, true, prev != null, pal, Modifier.weight(1f)) { prev?.let { onNavigate(catId, it.id) } }
                    NavPill("النصّ التالي", AppIcon.ChevronEnd, false, next != null, pal, Modifier.weight(1f)) { next?.let { onNavigate(catId, it.id) } }
                }
            }
        }
        // ===== بطاقة المكافأة عند إكمال سورة =====
        AnimatedVisibility(
            visible = awardBanner > 0,
            enter = fadeIn(tween(300)) + scaleIn(tween(300), initialScale = 0.85f) + slideInVertically(tween(300)) { it / 3 },
            exit = fadeOut(tween(200)),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            val isKhatma = awardBanner >= 500
            Box(
                Modifier.fillMaxWidth()
                    .padding(horizontal = 18.dp).padding(bottom = 90.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.linearGradient(listOf(pal.gold, Color(0xFFD8A74E))))
                    .clickable { awardBanner = 0 }
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LineIcon(AppIcon.Star8, Color.White, 30.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (isKhatma) "ختمتَ القرآن الكريم! 🎉" else "أحسنت — أتممتَ السورة",
                            color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp
                        )
                        Text(
                            if (isKhatma) "+$awardBanner نقطة (تشمل مكافأة الختمة)" else "+$awardBanner نقطة",
                            color = Color.White.copy(alpha = .92f), fontSize = 13.sp, fontWeight = FontWeight.Bold
                        )
                    }
                    Text("المجموع ${settings.quranPoints.value}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        // ===== تأكيد حفظ العلامة =====
        AnimatedVisibility(
            visible = flash != null,
            enter = fadeIn(tween(200)) + slideInVertically(tween(200)) { it / 2 },
            exit = fadeOut(tween(200)),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Box(
                Modifier.padding(bottom = 90.dp)
                    .clip(RoundedCornerShape(99.dp)).background(pal.emerald).padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(flash ?: "", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
        }
    }
}

@Composable
private fun NavPill(label: String, icon: AppIcon, iconFirst: Boolean, enabled: Boolean, pal: DuaaPalette, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(18.dp))
            .background(if (enabled) pal.pillBrush else androidx.compose.ui.graphics.SolidColor(pal.surface2.copy(alpha = .5f)))
            .clickable(enabled = enabled, onClick = onClick).padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        val tint = if (enabled) Color.White else pal.ink2
        if (iconFirst) { LineIcon(icon, tint, 18.dp); Spacer(Modifier.width(6.dp)) }
        Text(label, color = tint, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (!iconFirst) { Spacer(Modifier.width(6.dp)); LineIcon(icon, tint, 18.dp) }
    }
}

@Composable
private fun ReaderIconBtn(icon: AppIcon, pal: DuaaPalette, onClick: () -> Unit) {
    Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = .14f)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        LineIcon(icon, Color.White, 17.dp)
    }
}

@Composable
private fun ToolChip(label: String, on: Boolean, pal: DuaaPalette, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(10.dp))
            .background(if (on) pal.emerald else MaterialTheme.colorScheme.surface)
            .border(1.dp, if (on) pal.emerald else pal.line, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp)
    ) { Text(label, color = if (on) Color.White else MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}
