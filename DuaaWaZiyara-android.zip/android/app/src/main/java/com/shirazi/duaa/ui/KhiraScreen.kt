package com.shirazi.duaa.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Data
import com.shirazi.duaa.data.KhiraAyah
import kotlinx.coroutines.delay
import kotlin.math.min

/** خِيرة القرآن — تدفّق: الآداب ← اضغط مطوّلاً ← النتيجة */
@Composable
fun KhiraScreen(pal: DuaaPalette, onClose: () -> Unit) {
    val haptics = rememberHaptics()
    val done = remember { mutableStateListOf(false, false, false, false) }
    var result by remember { mutableStateOf<KhiraAyah?>(null) }
    var pressing by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    val allDone = done.all { it }

    // تقدّم الضغط المطوّل (1.4 ثانية)
    LaunchedEffect(pressing) {
        if (pressing) {
            val start = System.currentTimeMillis()
            while (pressing && progress < 1f) {
                progress = min(1f, (System.currentTimeMillis() - start) / 1400f)
                if (progress >= 1f) { result = Data.khiraAyat.random(); haptics.confirm() }
                delay(16)
            }
        } else if (result == null) progress = 0f
    }

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                ScreenTopBar("خِيرة القرآن الكريم", pal, onClose)
                Column(Modifier.padding(18.dp)) {
                    if (result == null) {
                        Text("أتمم الآداب الأربعة، ثم اضغط مطوّلاً على الخاتم لفتح المصحف",
                            color = pal.ink2, fontSize = 13.sp, lineHeight = 22.sp,
                            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp))
                        val doneCount = done.count { it }
                        if (doneCount in 1..3) {
                            Box(Modifier.padding(bottom = 12.dp).align(Alignment.CenterHorizontally)
                                .clip(RoundedCornerShape(99.dp)).background(pal.emerald.copy(alpha = .12f))
                                .padding(horizontal = 14.dp, vertical = 5.dp)) {
                                Text("أتممتَ $doneCount من ٤", color = pal.emerald, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        } else Spacer(Modifier.height(6.dp))
                        // خطوات الآداب
                        Data.khiraSteps.forEachIndexed { i, step ->
                            val isDone = done[i]
                            Row(
                                Modifier.fillMaxWidth().padding(bottom = 10.dp).paper(pal, 20)
                                    .clickable { done[i] = !done[i]; haptics.tick() }.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier.size(28.dp).clip(CircleShape)
                                        .background(if (isDone) pal.emerald else pal.surface2)
                                        .border(1.5.dp, if (isDone) pal.emerald else pal.line, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) { Text(if (isDone) "✓" else listOf("١","٢","٣","٤")[i], color = if (isDone) Color.White else pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(step.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text(step.desc, color = pal.ink2, fontSize = 12.sp, lineHeight = 19.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        // خاتم الضغط المطوّل
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Box(
                                Modifier.size(190.dp).pointerInput(allDone) {
                                    if (allDone) detectTapGestures(
                                        onPress = { pressing = true; tryAwaitRelease(); pressing = false }
                                    )
                                },
                                contentAlignment = Alignment.Center
                            ) {
                                Canvas(Modifier.fillMaxSize()) {
                                    val sw = 14f
                                    val d = min(size.width, size.height) - sw * 2
                                    val tl = Offset((size.width - d) / 2, (size.height - d) / 2)
                                    drawArc(if (allDone) pal.gold.copy(alpha = .25f) else pal.line, -90f, 360f, false,
                                        topLeft = tl, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                                    drawArc(pal.gold, -90f, 360f * progress, false,
                                        topLeft = tl, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                                    // نجمة ثمانية مبسطة: دائرتان داخليتان
                                    drawCircle(pal.gold.copy(alpha = .5f), radius = d * 0.30f, style = Stroke(3f))
                                    // أربع نقاطٍ لآداب الخِيرة: تمتلئ كلّما أتممتَ أدباً
                                    val dotR = 7f; val gap = 26f
                                    val cy = size.height / 2
                                    val cx0 = size.width / 2 - gap * 1.5f
                                    for (di in 0 until 4) {
                                        val filled = di < done.count { it }
                                        drawCircle(if (filled) pal.gold else pal.line, radius = dotR,
                                            center = Offset(cx0 + gap * di, cy))
                                    }
                                }
                                Text(if (allDone) "اضغط مطوّلاً" else "أتمم الآداب أولاً",
                                    color = if (allDone) pal.emerald else pal.ink2,
                                    fontWeight = FontWeight.Bold, fontSize = 13.sp,
                                    modifier = Modifier.padding(top = 90.dp))
                            }
                        }
                        Spacer(Modifier.height(30.dp))
                    } else {
                        // النتيجة
                        val a = result!!
                        val (chipBg, chipFg, label) = when (a.v) {
                            "good" -> Triple(pal.good.copy(alpha = .15f), pal.good, "خِيَرَتُها جيّدة")
                            "bad" -> Triple(pal.danger.copy(alpha = .13f), pal.danger, "خِيَرَتُها غير جيّدة")
                            else -> Triple(pal.mid.copy(alpha = .15f), pal.mid, "وَسَط")
                        }
                        Column(Modifier.fillMaxWidth().paper(pal, 24).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.clip(RoundedCornerShape(99.dp)).background(chipBg).padding(horizontal = 16.dp, vertical = 6.dp)) {
                                Text(label, color = chipFg, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                            }
                            Spacer(Modifier.height(18.dp))
                            Text("﴿ ${a.t} ﴾", fontFamily = AppFonts.scripture, fontSize = 24.sp, lineHeight = 44.sp, textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurface)
                            Spacer(Modifier.height(10.dp))
                            Text("سورة ${a.s}", color = pal.gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(14.dp))
                            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(chipBg).padding(12.dp)) {
                                Text(a.m, color = chipFg, fontSize = 14.sp, lineHeight = 24.sp, textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth())
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        BigButton("خِيرة جديدة", pal, true) {
                            result = null; progress = 0f
                            for (i in done.indices) done[i] = false
                        }
                        Spacer(Modifier.height(10.dp))
                        BigButton("الرجوع للرئيسية", pal, false) { onClose() }
                    }
                    Spacer(Modifier.height(90.dp))
                }
            }
        }
    }
}

@Composable
fun ScreenTopBar(title: String, pal: DuaaPalette, onClose: () -> Unit) {
    Box(Modifier.fillMaxWidth().background(pal.heroBrush)) {
        IslamicPattern(Color.White.copy(alpha = .05f), Modifier.matchParentSize(), cell = 80f)
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = .14f)).clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) { LineIcon(AppIcon.ChevronStart, Color.White, 17.dp) }
            Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp,
                modifier = Modifier.padding(start = 12.dp))
        }
    }
}
