package com.shirazi.duaa.ui

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Data
import com.shirazi.duaa.data.KhiraPages
import com.shirazi.duaa.data.KhiraVerdicts
import com.shirazi.duaa.logic.ShareCard
import kotlinx.coroutines.delay
import kotlin.math.min

/** آيةٌ من المصحف كاملاً (٦٢٣٦ آية)، مفصولةٌ من نصّ القرآن في التطبيق عند أرقام الآيات. */
data class KhiraVerse(val sura: Int, val suraName: String, val n: Int, val text: String)

private object QuranIndex {
    val verses: List<KhiraVerse> by lazy {
        val quran = Data.categories.firstOrNull { it.id == "quran" } ?: return@lazy emptyList<KhiraVerse>()
        val rx = Regex("""([^()]+?)\s*\((\d+)\)""", RegexOption.DOT_MATCHES_ALL)
        quran.items.flatMap { item ->
            val s = item.id.removePrefix("q-").toIntOrNull() ?: 0
            val name = item.title.removePrefix("سورة ").trim()
            rx.findAll(item.text).map { m ->
                val n = m.groupValues[2].toInt()
                var seg = m.groupValues[1].trim()
                // البسملة سطرٌ مستقلّ قبل الآية الأولى في غير الفاتحة والتوبة
                if (s != 1 && s != 9 && n == 1 && seg.contains('\n')) seg = seg.substringAfterLast('\n').trim()
                KhiraVerse(s, name, n, seg)
            }.toList()
        }
    }
}

private val arabicDigits = "٠١٢٣٤٥٦٧٨٩"
private fun ar(n: Int): String = n.toString().map { arabicDigits[it - '0'] }.joinToString("")
private fun parseDigits(s: String): Int? =
    s.map { c -> val i = arabicDigits.indexOf(c); if (i >= 0) ('0' + i) else c }
        .filter { it.isDigit() }.joinToString("").take(4).toIntOrNull()

/** سجلّ الخِيَر: محفوظٌ على الجهاز فقط، آخر ١٠٠ خيرة. */
private data class KhiraEntry(val at: Long, val page: Int, val intent: String)

private object KhiraLog {
    private const val PREFS = "khira_log"
    private const val KEY = "log"
    fun load(ctx: Context): List<KhiraEntry> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
        return raw.split('\n').mapNotNull { line ->
            val p = line.split('|')
            if (p.size < 3) null else {
                val at = p[0].toLongOrNull(); val page = p[1].toIntOrNull()
                if (at == null || page == null) null else KhiraEntry(at, page, p.drop(2).joinToString(" "))
            }
        }
    }
    private fun save(ctx: Context, list: List<KhiraEntry>) {
        val raw = list.take(100).joinToString("\n") { "${it.at}|${it.page}|${it.intent}" }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, raw).apply()
    }
    fun add(ctx: Context, e: KhiraEntry) {
        val clean = e.copy(intent = e.intent.replace('|', ' ').replace('\n', ' ').trim().take(140))
        save(ctx, listOf(clean) + load(ctx))
    }
    fun remove(ctx: Context, at: Long) = save(ctx, load(ctx).filter { it.at != at })
}

/** حكم الصفحة: أوّل آيةٍ فيها (أوّل سطر في الصفحة اليمنى)، وما يليها في الصفحة نفسها عند خلوّها من دلالة. */
private fun verdictOfPage(page: Int): Char =
    KhiraPages.PAGE_VERDICT.getOrElse(page - 1) { 'm' }

private fun themesOfPage(page: Int): List<String> =
    listOf(KhiraPages.PAGE_THEME_A.getOrElse(page - 1) { '-' }, KhiraPages.PAGE_THEME_B.getOrElse(page - 1) { '-' })
        .filter { it != '-' }.mapNotNull { KhiraVerdicts.LABELS[it] }.distinct()

private fun verdictTitle(c: Char) = when (c) { 'g' -> "خيرةٌ جيّدة"; 'b' -> "خيرةٌ غير جيّدة"; else -> "خيرةٌ وسط" }
private fun verdictShort(c: Char) = when (c) { 'g' -> "جيّدة"; 'b' -> "غير جيّدة"; else -> "وسط" }

/** تفصيل الخيرة في الأمور الغالبة؛ إرشادٌ مستفادٌ من حكم الآية لا نصٌّ منقول. */
private fun detailRows(c: Char): List<Pair<String, String>> = when (c) {
    'g' -> listOf(
        "عامّة" to "خيرٌ ظاهر، فامضِ في أمرك متوكّلاً على الله.",
        "الزواج" to "فيه توفيقٌ وألفة إن شاء الله، فأقدِم بعد السؤال والتحقّق.",
        "العمل والتجارة" to "مظنّة ربحٍ وبركة، فأقدِم مع حسن التدبير.",
        "السفر" to "سفرٌ ميسَّر إن شاء الله، وتصدّق قبل خروجك."
    )
    'b' -> listOf(
        "عامّة" to "الأولى ترك الأمر أو تأجيله، والتماس غيره ممّا فيه الخير.",
        "الزواج" to "الأولى عدم الإقدام الآن.",
        "العمل والتجارة" to "مظنّة تعبٍ أو خسارة، فالأولى تركه.",
        "السفر" to "الأولى تأجيله أو تركه."
    )
    else -> listOf(
        "عامّة" to "لا يترجّح فيه فعلٌ ولا ترك، والأمر إلى اختيارك وتدبيرك.",
        "الزواج" to "لا بأس به، فقدّم المشورة والتحرّي ثم اختر.",
        "العمل والتجارة" to "متوسّط العاقبة، فادرسه واستشر أهل الخبرة.",
        "السفر" to "لا بأس به، مع حسن التدبير."
    )
}

private fun verdictColor(c: Char, pal: DuaaPalette): Color = when (c) { 'g' -> pal.good; 'b' -> pal.danger; else -> pal.mid }

/**
 * خِيرة القرآن على الطريقة المعروفة: بعد الآداب الأربعة يُفتح المصحف، ويُنظر في أوّل سطرٍ من الصفحة اليمنى.
 * التطبيق يفتح صفحةً يمنى (فرديّة) من مصحف المدينة، ويقرأ أوّل آيةٍ فيها ويبيّن الحكم وتفصيله.
 * ومن استخار بمصحفه الورقي أدخل رقم الصفحة فيرى البيان نفسه. والسجلّ محفوظٌ على الجهاز فقط.
 */
@Composable
fun KhiraScreen(pal: DuaaPalette, openReader: (String, String) -> Unit = { _, _ -> }, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }                       // ٠ استخارة · ١ بمصحفك · ٢ السجلّ
    var result by remember { mutableStateOf<KhiraEntry?>(null) }
    var log by remember { mutableStateOf(KhiraLog.load(ctx)) }
    var intent by remember { mutableStateOf("") }

    BackHandler(enabled = result != null) { result = null }

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
            Column(Modifier.fillMaxSize()) {
                ScreenTopBar("خِيرة القرآن الكريم", pal, onClose = { if (result != null) result = null else onClose() })
                Crossfade(targetState = result, animationSpec = tween(320), label = "khira") { shown: KhiraEntry? ->
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
                        Spacer(Modifier.height(14.dp))
                        if (shown != null) {
                            KhiraResultView(shown, pal, openReader,
                                onNew = { result = null; intent = ""; tab = 0 },
                                onDelete = { KhiraLog.remove(ctx, shown.at); log = KhiraLog.load(ctx); result = null; tab = 2 })
                        } else {
                            KhiraTabs(tab, log.size, pal) { tab = it }
                            Spacer(Modifier.height(14.dp))
                            when (tab) {
                                0 -> KhiraDrawView(pal, intent, onIntent = { intent = it }) { page ->
                                    val e = KhiraEntry(System.currentTimeMillis(), page, intent)
                                    KhiraLog.add(ctx, e); log = KhiraLog.load(ctx); result = e
                                }
                                1 -> KhiraLookupView(pal) { page ->
                                    val e = KhiraEntry(System.currentTimeMillis(), page, "بالمصحف الورقي")
                                    KhiraLog.add(ctx, e); log = KhiraLog.load(ctx); result = e
                                }
                                else -> KhiraLogView(log, pal) { result = it }
                            }
                        }
                        Spacer(Modifier.height(90.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun KhiraTabs(tab: Int, logCount: Int, pal: DuaaPalette, onTab: (Int) -> Unit) {
    val labels = listOf("استخارة", "بمصحفك", if (logCount > 0) "السجلّ · ${ar(logCount)}" else "السجلّ")
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(pal.surface2).padding(4.dp)
    ) {
        labels.forEachIndexed { i, l ->
            val on = i == tab
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                    .background(if (on) MaterialTheme.colorScheme.surface else Color.Transparent)
                    .clickable { onTab(i) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(l, fontSize = 13.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                    color = if (on) pal.emerald else pal.ink2, maxLines = 1)
            }
        }
    }
}

@Composable
private fun SoftField(value: String, onValue: (String) -> Unit, hint: String, pal: DuaaPalette, number: Boolean = false) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.background)
            .border(1.dp, pal.line, RoundedCornerShape(14.dp))
    ) {
        TextField(
            value = value,
            onValueChange = onValue,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(hint, color = pal.ink2, fontSize = 13.sp) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Number else KeyboardType.Text),
            textStyle = MaterialTheme.typography.bodyLarge.copy(fontSize = 15.sp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
            )
        )
    }
}

// ===================== الاستخارة: النيّة ← الآداب ← فتح المصحف =====================
@Composable
private fun KhiraDrawView(pal: DuaaPalette, intent: String, onIntent: (String) -> Unit, onDrawn: (Int) -> Unit) {
    val haptics = rememberHaptics()
    val steps = Data.khiraSteps
    val done = remember { mutableStateListOf<Boolean>().apply { repeat(steps.size) { add(false) } } }
    var pressing by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    val allDone = done.all { it }
    val doneCount = done.count { it }

    LaunchedEffect(pressing) {
        if (pressing) {
            val start = System.currentTimeMillis()
            while (pressing && progress < 1f) {
                progress = min(1f, (System.currentTimeMillis() - start) / 1600f)
                if (progress >= 1f) {
                    haptics.confirm()
                    // صفحةٌ يمنى (فرديّة) من صفحات مصحف المدينة الـ٦٠٤
                    onDrawn((0 until KhiraPages.COUNT / 2).random() * 2 + 1)
                }
                delay(16)
            }
        } else progress = 0f
    }

    // النيّة (اختيارية)
    Column(Modifier.fillMaxWidth().paper(pal, 20).padding(16.dp)) {
        Text("في أيّ أمرٍ تستخير؟", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
        Text("اختياري، ويُحفظ في سجلّك على هذا الجهاز فقط.", color = pal.ink2, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        SoftField(intent, { onIntent(it.take(140)) }, "مثلاً: عرض عمل، سفر، خطبة…", pal)
    }
    Spacer(Modifier.height(16.dp))

    // الآداب الأربعة
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("آداب الخيرة", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f))
        Text("${ar(doneCount)} من ${ar(steps.size)}", color = if (allDone) pal.emerald else pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
    Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(pal.line)) {
        Box(Modifier.fillMaxWidth(doneCount.toFloat() / steps.size).fillMaxHeight().clip(RoundedCornerShape(2.dp)).background(pal.emerald))
    }
    Spacer(Modifier.height(12.dp))
    steps.forEachIndexed { i, step ->
        val isDone = done[i]
        Row(
            Modifier.fillMaxWidth().padding(bottom = 10.dp).paper(pal, 18)
                .clickable { done[i] = !done[i]; haptics.tick() }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(30.dp).clip(CircleShape)
                    .background(if (isDone) pal.emerald else pal.surface2)
                    .border(1.5.dp, if (isDone) pal.emerald else pal.line, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(if (isDone) "✓" else ar(i + 1), color = if (isDone) Color.White else pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(step.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                Text(step.desc, color = pal.ink2, fontSize = 12.sp, lineHeight = 19.sp)
            }
        }
    }
    Spacer(Modifier.height(14.dp))

    // الخاتم: ضغطٌ مطوّل يفتح المصحف
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(210.dp).pointerInput(allDone) {
                if (allDone) detectTapGestures(onPress = { pressing = true; tryAwaitRelease(); pressing = false })
            },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 12f
                val d = min(size.width, size.height) - sw * 2
                val tl = Offset((size.width - d) / 2, (size.height - d) / 2)
                drawArc(if (allDone) pal.gold.copy(alpha = .22f) else pal.line, -90f, 360f, false,
                    topLeft = tl, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                drawArc(pal.gold, -90f, 360f * progress, false,
                    topLeft = tl, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                drawCircle(if (allDone) pal.emerald.copy(alpha = .10f) else pal.surface2, radius = d * 0.38f)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                LineIcon(AppIcon.Book, if (allDone) pal.emerald else pal.ink2, 34.dp)
                Spacer(Modifier.height(8.dp))
                Text(if (allDone) "اضغط مطوّلاً" else "أتمم الآداب أولاً",
                    color = if (allDone) pal.emerald else pal.ink2, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                if (allDone) Text("لفتح المصحف", color = pal.ink2, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("يُفتح المصحف على صفحةٍ يمنى، ويُقرأ أوّل سطرٍ منها.", color = pal.ink2, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

// ===================== الخيرة بالمصحف الورقي =====================
@Composable
private fun KhiraLookupView(pal: DuaaPalette, onPage: (Int) -> Unit) {
    var input by remember { mutableStateOf("") }
    val page = parseDigits(input)
    val valid = page != null && page in 1..KhiraPages.COUNT
    Column(Modifier.fillMaxWidth().paper(pal, 20).padding(18.dp)) {
        Text("استخرتَ بمصحفك؟", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(4.dp))
        Text("بعد الآداب الأربعة افتح المصحف، وانظر في الصفحة اليمنى، ثم أدخل رقمها ليُبيَّن لك حكم أوّل آيةٍ فيها.",
            color = pal.ink2, fontSize = 13.sp, lineHeight = 21.sp)
        Spacer(Modifier.height(14.dp))
        SoftField(input, { input = it.take(4) }, "رقم الصفحة (١ إلى ٦٠٤)", pal, number = true)
        if (page != null && valid && page % 2 == 0) {
            Spacer(Modifier.height(8.dp))
            Text("الصفحة اليمنى في مصحف المدينة فرديّة الرقم غالباً؛ تأكّد من الرقم.", color = pal.mid, fontSize = 12.sp)
        }
        if (page != null && !valid) {
            Spacer(Modifier.height(8.dp))
            Text("عدد صفحات المصحف ٦٠٤.", color = pal.danger, fontSize = 12.sp)
        }
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                .background(if (valid) pal.emerald else pal.line)
                .clickable(enabled = valid) { if (page != null) onPage(page) }.padding(14.dp),
            contentAlignment = Alignment.Center
        ) { Text("اعرض الخيرة", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp) }
    }
    Spacer(Modifier.height(12.dp))
    Text("الترقيم بحسب مصحف المدينة المنوّرة ذي الـ٦٠٤ صفحات، وهو الأشيع.", color = pal.ink2, fontSize = 12.sp,
        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
}

// ===================== السجلّ =====================
@Composable
private fun KhiraLogView(log: List<KhiraEntry>, pal: DuaaPalette, onOpen: (KhiraEntry) -> Unit) {
    val verses = QuranIndex.verses
    var filter by remember { mutableStateOf('a') }
    if (log.isEmpty()) {
        Column(Modifier.fillMaxWidth().paper(pal, 20).padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            LineIcon(AppIcon.Book, pal.ink2, 30.dp)
            Spacer(Modifier.height(10.dp))
            Text("لا خِيَر محفوظة بعد", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
            Text("تُحفظ كلّ خيرةٍ هنا مع نيّتها، لتعود إليها.", color = pal.ink2, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
        return
    }
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf('a' to "الكلّ", 'g' to "جيّدة", 'm' to "وسط", 'b' to "غير جيّدة").forEach { (k, l) ->
            val on = filter == k
            Text(l, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                color = if (on) Color.White else pal.ink2,
                modifier = Modifier.clip(RoundedCornerShape(99.dp))
                    .background(if (on) (if (k == 'a') pal.emerald else verdictColor(k, pal)) else pal.surface2)
                    .clickable { filter = k }.padding(horizontal = 14.dp, vertical = 7.dp))
        }
    }
    val fmt = remember { java.text.SimpleDateFormat("d MMMM yyyy · h:mm a", java.util.Locale.forLanguageTag("ar")) }
    log.forEach { e ->
        val idx = KhiraPages.START.getOrElse(e.page - 1) { 0 }
        val c = verdictOfPage(e.page)
        if (filter != 'a' && filter != c) return@forEach
        val col = verdictColor(c, pal)
        Row(
            Modifier.fillMaxWidth().padding(bottom = 10.dp).paper(pal, 18).clickable { onOpen(e) }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(col))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(e.intent.ifBlank { "خيرة" }, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val v = verses.getOrNull(idx)
                Text((if (v != null) "سورة ${v.suraName} · " else "") + "الصفحة ${ar(e.page)} · " + fmt.format(java.util.Date(e.at)),
                    color = pal.ink2, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(8.dp))
            Text(verdictShort(c), color = col, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.clip(RoundedCornerShape(99.dp)).background(col.copy(alpha = .12f))
                    .padding(horizontal = 10.dp, vertical = 4.dp))
        }
    }
}

// ===================== النتيجة =====================
@Composable
private fun KhiraResultView(
    e: KhiraEntry, pal: DuaaPalette, openReader: (String, String) -> Unit,
    onNew: () -> Unit, onDelete: () -> Unit
) {
    val ctx = LocalContext.current
    val verses = QuranIndex.verses
    if (verses.isEmpty()) { Text("تعذّر تحميل المصحف.", color = pal.danger); return }
    val range = KhiraPages.versesOf(e.page, verses.size)
    val first = range.first.coerceIn(0, verses.size - 1)
    val v = verses[first]
    val c = verdictOfPage(e.page)
    val col = verdictColor(c, pal)
    val themes = themesOfPage(e.page)
    var fullPage by remember(e.at) { mutableStateOf(false) }
    var copied by remember(e.at) { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current

    // ===== الحكم =====
    Box(
        Modifier.fillMaxWidth().heroCard(col, 24, 8)
            .background(Brush.linearGradient(listOf(col, col.copy(alpha = .78f))))
    ) {
        Box(Modifier.align(Alignment.TopStart).padding(6.dp)) { StarTile(Color.White.copy(alpha = .10f), 96.dp) }
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (e.intent.isNotBlank()) {
                Text(e.intent, color = Color.White.copy(alpha = .88f), fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(6.dp))
            }
            Text(verdictTitle(c), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
            Spacer(Modifier.height(4.dp))
            Text("الصفحة ${ar(e.page)} · سورة ${v.suraName} · الآية ${ar(v.n)}",
                color = Color.White.copy(alpha = .9f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
    Spacer(Modifier.height(14.dp))

    // ===== صفحة المصحف =====
    val pageBg = if (pal.dark) MaterialTheme.colorScheme.surface else Color(0xFFFBF6E9)
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(pageBg)
            .border(1.dp, pal.gold.copy(alpha = .55f), RoundedCornerShape(20.dp)).padding(5.dp)
            .border(1.dp, pal.gold.copy(alpha = .30f), RoundedCornerShape(16.dp)).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("سورة ${v.suraName}", color = pal.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("صفحة ${ar(e.page)}", color = pal.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Text("${v.text} ﴿${ar(v.n)}﴾", fontFamily = AppFonts.scripture, fontSize = 24.sp, lineHeight = 44.sp,
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(pal.gold.copy(alpha = .13f)).padding(12.dp))
        Spacer(Modifier.height(4.dp))
        Text("أوّل سطرٍ في الصفحة", color = pal.ink2, fontSize = 11.sp)
        if (range.last > range.first) {
            if (fullPage) {
                Spacer(Modifier.height(10.dp))
                val rest = (range.first + 1..range.last).mapNotNull { verses.getOrNull(it) }
                    .joinToString("  ") { "${it.text} ﴿${ar(it.n)}﴾" }
                Text(rest, fontFamily = AppFonts.scripture, fontSize = 18.sp, lineHeight = 34.sp,
                    textAlign = TextAlign.Justify, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .78f),
                    modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(10.dp))
            Text(if (fullPage) "إخفاء بقية الصفحة" else "اقرأ الصفحة كاملة", color = pal.emerald, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.clip(RoundedCornerShape(99.dp)).clickable { fullPage = !fullPage }.padding(horizontal = 12.dp, vertical = 6.dp))
        }
    }
    Spacer(Modifier.height(14.dp))

    // ===== البيان =====
    Column(Modifier.fillMaxWidth().paper(pal, 20).padding(18.dp)) {
        Text("بيان الخيرة", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(6.dp))
        val why = when {
            c == 'm' -> "الآية قصصٌ أو أحكامٌ أو أخبار، لا بشارة فيها ولا تحذير."
            themes.isNotEmpty() -> "في الآية وما يليها ذكرُ " + themes.joinToString(" و") + "."
            c == 'g' -> "في الآية بشارةٌ أو وعدٌ بالخير."
            else -> "في الآية إنذارٌ أو نهيٌ أو ذمّ."
        }
        if (why.isNotEmpty()) Text(why, color = pal.ink2, fontSize = 13.sp, lineHeight = 22.sp)
        Spacer(Modifier.height(10.dp))
        detailRows(c).forEachIndexed { i, (label, text) ->
            if (i > 0) Box(Modifier.fillMaxWidth().padding(vertical = 10.dp).height(1.dp).background(pal.line))
            Row(verticalAlignment = Alignment.Top) {
                Text(label, color = col, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.width(96.dp))
                Text(text, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, lineHeight = 22.sp, modifier = Modifier.weight(1f))
            }
        }
    }
    Spacer(Modifier.height(14.dp))

    // ===== أفعال =====
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        KhiraAction("مشاركة", AppIcon.Share, pal, Modifier.weight(1f)) {
            val title = verdictTitle(c) + (if (e.intent.isNotBlank()) " · " + e.intent else "")
            ShareCard.shareText(ctx, title, "${v.text} ﴿${ar(v.n)}﴾", "سورة ${v.suraName} · الصفحة ${ar(e.page)}")
        }
        KhiraAction("السورة", AppIcon.Book, pal, Modifier.weight(1f)) {
            openReader("quran", "q-" + v.sura.toString().padStart(3, '0'))
        }
        KhiraAction(if (copied) "نُسخت ✓" else "نسخ", AppIcon.Copy, pal, Modifier.weight(1f)) {
            clipboard.setText(AnnotatedString(verdictTitle(c) + "\n" + v.text + " ﴿" + ar(v.n) + "﴾\nسورة " + v.suraName + " · الصفحة " + ar(e.page)))
            copied = true
        }
    }
    Spacer(Modifier.height(12.dp))
    BigButton("خيرة جديدة", pal, true, onNew)
    Spacer(Modifier.height(4.dp))
    Text("حذف من السجلّ", color = pal.danger, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(99.dp)).clickable(onClick = onDelete).padding(10.dp))
    Spacer(Modifier.height(8.dp))
    Text("الخيرة إرشادٌ عند الحيرة بعد التدبّر والمشورة، والقرار بعدها لك متوكّلاً على الله.",
        color = pal.ink2, fontSize = 12.sp, lineHeight = 20.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
}

@Composable
private fun KhiraAction(label: String, icon: AppIcon, pal: DuaaPalette, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.paper(pal, 16).clickable(onClick = onClick).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LineIcon(icon, pal.emerald, 20.dp)
        Spacer(Modifier.height(4.dp))
        Text(label, color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ScreenTopBar(title: String, pal: DuaaPalette, onClose: () -> Unit) {
    Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.a11yIconButton("رجوع", 40.dp, pal.surface2, radius = 14.dp, onClick = onClose),
                contentAlignment = Alignment.Center
            ) { LineIcon(AppIcon.ChevronStart, MaterialTheme.colorScheme.onSurface, 18.dp) }
            Text(title, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp,
                modifier = Modifier.padding(start = 8.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
