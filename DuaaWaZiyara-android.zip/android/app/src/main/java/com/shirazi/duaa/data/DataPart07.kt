package com.shirazi.duaa.data

internal val cat_quran: Category = Category("quran", "📖", "القرآن الكريم", """سور القرآن الكريم كاملة مع ترقيم الآيات""", quranItems01 + quranItems02 + quranItems03 + quranItems04 + quranItems05)
