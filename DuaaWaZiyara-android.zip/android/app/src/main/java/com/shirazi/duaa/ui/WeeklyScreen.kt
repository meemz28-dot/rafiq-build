package com.shirazi.duaa.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Data

/**
 * البرنامج الأسبوعي: لكلّ يومٍ دعاؤه (الموروث عن الإمام السجّاد ع) وزيارته (المعصوم المخصوص به)،
 * ولليلة الجمعة ويومها أعمالها المشهورة: كميل ليلتها، والندبة صباحها، والسمات عصرها. يُبرَز يوم المستخدم الحالي.
 */
private data class WeekDay(val name: String, val duaId: String, val ziyaraId: String, val extras: List<Triple<String, String, String>>)

private val WEEK: List<WeekDay> = listOf(
    WeekDay("السبت", "d-sat", "z-nabi", emptyList()),
    WeekDay("الأحد", "d-sun", "z-amin", emptyList()),
    WeekDay("الإثنين", "d-mon", "z-mutlaqa", emptyList()),
    WeekDay("الثلاثاء", "d-tue", "z-baqi", emptyList()),
    WeekDay("الأربعاء", "d-wed", "z-kadhim", emptyList()),
    WeekDay("الخميس", "d-thu", "z-askari", listOf(Triple("ليلة الجمعة: دعاء كميل", "mashhura", "m-kumayl"))),
    WeekDay("الجمعة", "d-fri", "z-yasin", listOf(
        Triple("صباح الجمعة: دعاء الندبة", "mashhura", "m-nudba"),
        Triple("عصر الجمعة: دعاء السمات", "jumaa", "j-samat"))),
)

private fun titleOf(catId: String, itemId: String): String =
    Data.categories.firstOrNull { it.id == catId }?.items?.firstOrNull { it.id == itemId }?.title ?: itemId

@Composable
fun WeeklyScreen(pal: DuaaPalette, openReader: (String, String) -> Unit, onClose: () -> Unit) {
    // Calendar: SATURDAY=7, SUNDAY=1 … FRIDAY=6 → فهرسٌ يبدأ بالسبت
    val todayIdx = remember { java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK) % 7 }
    androidx.activity.compose.BackHandler { onClose() }
    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                ScreenTopBar("البرنامج الأسبوعي", pal, onClose)
                Column(Modifier.padding(18.dp)) {
                    Text("دعاء كلّ يومٍ وزيارتُه، وأعمال ليلة الجمعة ويومها.", color = pal.ink2, fontSize = 13.sp,
                        lineHeight = 21.sp, modifier = Modifier.padding(bottom = 14.dp))
                    WEEK.forEachIndexed { idx, d ->
                        val isToday = idx == todayIdx
                        Column(
                            Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(18.dp))
                                .background(if (isToday) pal.gold.copy(alpha = if (pal.dark) .16f else .11f) else MaterialTheme.colorScheme.surface)
                                .border(if (isToday) 1.5.dp else 1.dp, if (isToday) pal.gold else pal.line, RoundedCornerShape(18.dp))
                                .padding(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(d.name, color = if (isToday) pal.gold else MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                                if (isToday) Text("اليوم", color = pal.gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(8.dp))
                            WeekRow("دعاء اليوم", titleOf("osboo", d.duaId), pal) { openReader("osboo", d.duaId) }
                            WeekRow("زيارة اليوم", titleOf("ziyarat", d.ziyaraId), pal) { openReader("ziyarat", d.ziyaraId) }
                            d.extras.forEach { (label, cat, id) -> WeekRow(label, titleOf(cat, id), pal, gold = true) { openReader(cat, id) } }
                        }
                    }
                    Text("دعاء كلّ يومٍ مرويٌّ عن الإمام زين العابدين (ع)، وزيارة كلّ يومٍ على ما ذكره العلماء من تخصيص أيّام الأسبوع بالمعصومين (ع).",
                        color = pal.ink2, fontSize = 11.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 4.dp))
                    Spacer(Modifier.height(90.dp))
                }
            }
        }
    }
}

@Composable
private fun WeekRow(label: String, title: String, pal: DuaaPalette, gold: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp))
            .background(if (gold) pal.gold.copy(alpha = .10f) else pal.surface2)
            .clickable(onClick = onClick).semantics { role = Role.Button }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LineIcon(if (gold) AppIcon.Star8 else AppIcon.Book, if (gold) pal.gold else pal.emerald, 16.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = if (gold) pal.gold else pal.ink2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(title, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        LineIcon(AppIcon.ChevronEnd, pal.ink2, 14.dp)
    }
}
