package com.shirazi.duaa.ui

import androidx.compose.foundation.border
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * دليل صلاة الليل خطوة بخطوة — مُوجَّه للمبتدئ الذي لم يصلِّها من قبل.
 * كل خطوة تشرح الوضعية (قيام/ركوع/سجود/جلوس) وتُعطي النصّ المقروء بخطٍّ كبير.
 */
private enum class Pose { INFO, STAND, BOW, PROSTRATE, SIT, DONE }

// نصوص السور المُستعملة في الدليل — تُعرض كاملةً عند ذكرها
private object GuideSurah {
    const val IKHLAS = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ هُوَ اللَّهُ أَحَدٌ ﴿١﴾ اللَّهُ الصَّمَدُ ﴿٢﴾ لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ ﴿٤﴾"
    const val KAFIRUN = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ يَا أَيُّهَا الْكَافِرُونَ ﴿١﴾ لَا أَعْبُدُ مَا تَعْبُدُونَ ﴿٢﴾ وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ ﴿٣﴾ وَلَا أَنَا عَابِدٌ مَّا عَبَدتُّمْ ﴿٤﴾ وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ ﴿٥﴾ لَكُمْ دِينُكُمْ وَلِيَ دِينِ ﴿٦﴾"
    const val FALAQ = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ﴿١﴾ مِن شَرِّ مَا خَلَقَ ﴿٢﴾ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ﴿٣﴾ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ﴿٤﴾ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ ﴿٥﴾"
    const val NAS = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ أَعُوذُ بِرَبِّ النَّاسِ ﴿١﴾ مَلِكِ النَّاسِ ﴿٢﴾ إِلَٰهِ النَّاسِ ﴿٣﴾ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ﴿٤﴾ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ﴿٥﴾ مِنَ الْجِنَّةِ وَالنَّاسِ ﴿٦﴾"
}

private data class Step(
    val pose: Pose,
    val phase: String,      // المرحلة (نافلة الليل / الشفع / الوتر)
    val title: String,      // عنوان الخطوة
    val how: String,        // كيف تفعلها (وصف الحركة)
    val say: String? = null,// ما يُقال حرفياً
    val sayNote: String? = null,
    val counter: Int? = null,         // عدّاد تفاعليّ بهدفٍ معيّن (٣ تسبيحات، ٣٠٠ عفو...)
    val counterLabel: String? = null, // ما يُعدّ (مثل «العَفوَ»)
    val surahs: List<Pair<String, String>> = emptyList() // سور تُعرض كاملة: (الاسم، النصّ)
)

private val steps = listOf(
    Step(Pose.INFO, "تمهيد", "ما هي صلاة الليل؟",
        "صلاة الليل إحدى عشرة ركعة، وقتها من منتصف الليل إلى أذان الفجر، وأفضله السحر (قبيل الفجر). تنقسم إلى:\n\n• ٨ ركعات «نافلة الليل» — تُصلّى ركعتين ركعتين (أربع صلوات).\n• ركعتان تُسمّيان «الشفع».\n• ركعة واحدة تُسمّى «الوتر».\n\nكلها تُصلّى كصلاة الصبح في الكيفية. سنمشي معك خطوة بخطوة من البداية."),

    // ركعتان نموذج كامل (نافلة الليل 1)
    Step(Pose.STAND, "نافلة الليل · الصلاة ١", "النيّة",
        "قف مستقبلاً القبلة، واخطر بقلبك أنك تصلّي ركعتين من نافلة الليل قربةً إلى الله. لا يلزم التلفّظ، لكن يجوز أن تقول بقلبك أو لسانك:",
        "أُصَلّي رَكعَتَينِ مِن نافِلَةِ اللَّيلِ قُربَةً إلى اللهِ تَعالى."),
    Step(Pose.STAND, "نافلة الليل · الصلاة ١", "تكبيرة الإحرام",
        "ارفع يديك إلى حذاء أُذنيك، ثم قل وأنت قائم:",
        "اللَّهُ أَكْبَر",
        "بهذه التكبيرة تدخل في الصلاة، فلا تلتفت ولا تتكلّم بغير الصلاة بعدها."),
    Step(Pose.STAND, "نافلة الليل · الصلاة ١", "قراءة الفاتحة",
        "وأنت قائم، اقرأ سورة الفاتحة:",
        "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ﴿١﴾ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ﴿٢﴾ الرَّحْمَٰنِ الرَّحِيمِ ﴿٣﴾ مَالِكِ يَوْمِ الدِّينِ ﴿٤﴾ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ﴿٥﴾ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ﴿٦﴾ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ ﴿٧﴾"),
    Step(Pose.STAND, "نافلة الليل · الصلاة ١", "قراءة سورة بعد الفاتحة",
        "ثم اقرأ سورةً قصيرة. يُستحب «قل هو الله أحد». وإن ضاق وقتك يجوز الاقتصار على الفاتحة وحدها.",
        "قُلْ هُوَ اللَّهُ أَحَدٌ ﴿١﴾ اللَّهُ الصَّمَدُ ﴿٢﴾ لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ ﴿٤﴾"),
    Step(Pose.BOW, "نافلة الليل · الصلاة ١", "الركوع",
        "كبِّر (اللَّهُ أَكْبَر)، ثم انحنِ راكعاً وضع يديك على ركبتيك، وقل ثلاثاً (أو مرة):",
        "سُبْحَانَ رَبِّيَ الْعَظِيمِ وَبِحَمْدِهِ",
        "ثم ارفع رأسك من الركوع قائماً وقل: سَمِعَ اللَّهُ لِمَنْ حَمِدَه.",
        counter = 3, counterLabel = "سُبْحَانَ رَبِّيَ الْعَظِيمِ وَبِحَمْدِهِ"),
    Step(Pose.PROSTRATE, "نافلة الليل · الصلاة ١", "السجدة الأولى",
        "كبِّر، ثم اسجد على الأرض (الجبهة واليدان والركبتان وأطراف القدمين)، وقل ثلاثاً (أو مرة):",
        "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ",
        counter = 3, counterLabel = "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ"),
    Step(Pose.SIT, "نافلة الليل · الصلاة ١", "الجلوس بين السجدتين",
        "ارفع رأسك من السجود واجلس مطمئناً، وقل:",
        "أَسْتَغْفِرُ اللَّهَ رَبِّي وَأَتُوبُ إِلَيْهِ"),
    Step(Pose.PROSTRATE, "نافلة الليل · الصلاة ١", "السجدة الثانية",
        "كبِّر واسجد ثانيةً، وقل ثلاثاً (أو مرة):",
        "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ",
        "بهذا تمّت الركعة الأولى. قُم للركعة الثانية.",
        counter = 3, counterLabel = "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ"),
    Step(Pose.STAND, "نافلة الليل · الصلاة ١", "الركعة الثانية",
        "قُم للركعة الثانية، واقرأ الفاتحة ثم سورة (يُستحب «قل يا أيها الكافرون»)، ثم اركع واسجد سجدتين كما فعلت تماماً في الركعة الأولى.",
        null,
        "بعد السجدة الثانية من الركعة الثانية، اجلس للتشهّد.",
        surahs = listOf("سورة الكافرون" to GuideSurah.KAFIRUN)),
    Step(Pose.SIT, "نافلة الليل · الصلاة ١", "التشهّد",
        "اجلس بعد السجدتين وقل:",
        "أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ. اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَآلِ مُحَمَّد"),
    Step(Pose.SIT, "نافلة الليل · الصلاة ١", "التسليم",
        "ثم سلِّم لإنهاء الصلاة، وتقول:",
        "السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُه",
        "بهذا تمّت أوّل صلاتين (ركعتان). تبقّى ٦ ركعات من نافلة الليل بنفس الكيفية."),

    Step(Pose.INFO, "نافلة الليل · الصلوات ٢–٤", "أكمل بقية النافلة",
        "كرّر نفس ما فعلتَه ثلاث مرّات أخرى — أي ٦ ركعات (كل ركعتين بتسليم مستقل) — حتى تُتمّ ثماني ركعات نافلة الليل.\n\nفي كل ركعة: نيّة، تكبيرة، فاتحة، سورة، ركوع، سجدتان، ثم التشهّد والتسليم في الركعة الثانية. يجوز الاقتصار على الفاتحة عند ضيق الوقت."),

    // الشفع
    Step(Pose.STAND, "صلاة الشفع", "نيّة الشفع",
        "بعد إتمام الثماني، قف لصلاة الشفع (ركعتان). انوِ:",
        "أُصَلّي رَكعَتَيِ الشَّفعِ قُربَةً إلى اللهِ تَعالى."),
    Step(Pose.STAND, "صلاة الشفع", "قراءة الشفع",
        "كبّر تكبيرة الإحرام، ثم في الركعة الأولى اقرأ الفاتحة و«قل أعوذ برب الناس»، وفي الثانية الفاتحة و«قل أعوذ برب الفلق». بلا قنوت. ثم أكمل الركوع والسجود والتشهّد والتسليم كالمعتاد.",
        null,
        "بعد التسليم، قُم لركعة الوتر.",
        surahs = listOf("سورة الناس (الركعة الأولى)" to GuideSurah.NAS, "سورة الفلق (الركعة الثانية)" to GuideSurah.FALAQ)),

    // الوتر
    Step(Pose.STAND, "صلاة الوتر", "نيّة الوتر",
        "قُم لركعة الوتر (ركعة واحدة). انوِ:",
        "أُصَلّي رَكعَةَ الوَترِ قُربَةً إلى اللهِ تَعالى."),
    Step(Pose.STAND, "صلاة الوتر", "قراءة الوتر",
        "كبّر، ثم اقرأ الفاتحة، ثم «قل هو الله أحد» ثلاث مرّات (ويُستحب معها الفلق والناس مرّة).",
        "قُلْ هُوَ اللَّهُ أَحَدٌ... (ثلاث مرّات)",
        counter = 3, counterLabel = "سورة الإخلاص",
        surahs = listOf("سورة الإخلاص" to GuideSurah.IKHLAS, "سورة الفلق" to GuideSurah.FALAQ, "سورة الناس" to GuideSurah.NAS)),
    Step(Pose.STAND, "صلاة الوتر", "القنوت",
        "قبل الركوع، ارفع يديك للقنوت. القنوت مستحب. أبسط صورة أن تستغفر وتدعو:",
        "أَسْتَغْفِرُ اللَّهَ رَبِّي وَأَتُوبُ إِلَيْه (سبعين مرّة إن استطعت)\nرَبِّ اغْفِرْ لِي وَارْحَمْنِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيم",
        "يُستحب أيضاً قول «العَفوَ» ٣٠٠ مرّة، والاستغفار لأربعين مؤمناً. ومن لم يحفظ يكفيه الاستغفار والدعاء بما تيسّر.",
        counter = 300, counterLabel = "العَفوَ"),
    Step(Pose.BOW, "صلاة الوتر", "الركوع",
        "بعد القنوت، كبّر واركع وقل ثلاثاً (أو مرة):",
        "سُبْحَانَ رَبِّيَ الْعَظِيمِ وَبِحَمْدِهِ"),
    Step(Pose.PROSTRATE, "صلاة الوتر", "السجدتان",
        "اسجد سجدتين (بينهما جلوس واستغفار) كما تعلّمت، قائلاً في كل سجدة:",
        "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ"),
    Step(Pose.SIT, "صلاة الوتر", "التشهّد والتسليم",
        "اجلس بعد السجدتين، تشهّد ثم سلِّم:",
        "أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ... اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَآلِ مُحَمَّد\nالسَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُه"),
    Step(Pose.DONE, "تمّت", "تقبّل الله صلاتك",
        "بهذا أتممتَ صلاة الليل كاملةً (١١ ركعة). إن كان الوقت ضيّقاً في ليلةٍ ما، يجوز الاقتصار على الشفع والوتر، بل على الوتر وحدها.\n\nواظِب عليها ولو ركعةً واحدة، فثوابها عظيم وأثرها في القلب كبير.")
)

private fun poseLabel(p: Pose) = when (p) {
    Pose.STAND -> "قيام"; Pose.BOW -> "ركوع"; Pose.PROSTRATE -> "سجود"
    Pose.SIT -> "جلوس"; Pose.DONE -> "تمّ"; Pose.INFO -> "تمهيد"
}

private fun poseIcon(p: Pose) = when (p) {
    Pose.STAND -> AppIcon.HomeMini; Pose.BOW -> AppIcon.ChevronEnd
    Pose.PROSTRATE -> AppIcon.Drop; Pose.SIT -> AppIcon.Beads
    Pose.DONE -> AppIcon.StarFill; Pose.INFO -> AppIcon.Scroll
}

@Composable
fun LaylGuideScreen(settings: com.shirazi.duaa.data.Settings, pal: DuaaPalette, onClose: () -> Unit) {
    var i by remember { mutableStateOf(0) }
    val fontScale = settings.fontSize.value / 21f   // تكبير الخط — موحّد مع تفضيل القارئ المحفوظ
    val step = steps[i]
    val isLast = i == steps.lastIndex

    // إبقاء الشاشة مضاءة أثناء الدليل (لئلّا تُقفل أثناء الصلاة)
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
            Column(Modifier.fillMaxSize()) {
                // شريط علوي مع التحكّم بحجم الخط
                Box(Modifier.fillMaxWidth().background(pal.heroBrush)) {
                    Row(
                        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = .14f))
                                .clickable(onClick = onClose), contentAlignment = Alignment.Center
                        ) { LineIcon(AppIcon.ChevronStart, Color.White, 17.dp) }
                        Text("دليل صلاة الليل", color = Color.White, fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp, modifier = Modifier.padding(start = 12.dp).weight(1f))
                        // أزرار حجم الخط — أكبر لسهولة النقر أثناء الصلاة (محفوظة مع تفضيل القارئ)
                        Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = .16f))
                            .clickable { settings.fontSize.value = (settings.fontSize.value - 2).coerceAtLeast(15f); settings.save() }, contentAlignment = Alignment.Center) {
                            Text("أ−", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = .16f))
                            .clickable { settings.fontSize.value = (settings.fontSize.value + 2).coerceAtMost(40f); settings.save() }, contentAlignment = Alignment.Center) {
                            Text("أ+", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // شريط التقدّم
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    steps.indices.forEach { idx ->
                        Box(
                            Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp))
                                .background(if (idx <= i) pal.gold else pal.line)
                        )
                    }
                }

                Column(Modifier.weight(1f)) {
                    // منطقة المحتوى — النقر في أي مكانٍ فيها ينتقل للخطوة التالية (مناسب أثناء الصلاة)
                    Column(
                        Modifier.weight(1f).fillMaxWidth()
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() }
                            ) { if (!isLast) i++ else onClose() }
                            .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)
                    ) {
                    AnimatedContent(targetState = i, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "s") { idx ->
                        val s = steps[idx]
                        Column {
                            // شارة المرحلة + الوضعية
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier.clip(RoundedCornerShape(99.dp)).background(pal.emerald.copy(alpha = .12f))
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(s.phase, color = pal.emerald, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                                }
                                Spacer(Modifier.weight(1f))
                                if (s.pose != Pose.INFO && s.pose != Pose.DONE) {
                                    Row(
                                        Modifier.clip(RoundedCornerShape(99.dp)).background(pal.gold.copy(alpha = .15f))
                                            .padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        LineIcon(poseIcon(s.pose), pal.gold, 14.dp)
                                        Spacer(Modifier.width(6.dp))
                                        Text(poseLabel(s.pose), color = pal.gold, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                                    }
                                }
                            }
                            Spacer(Modifier.height(16.dp))

                            // العنوان
                            Text(s.title, fontSize = (26 * fontScale).sp, fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onBackground, lineHeight = (34 * fontScale).sp)
                            Spacer(Modifier.height(14.dp))

                            // كيف تفعلها
                            Text(s.how, fontSize = (18 * fontScale).sp, lineHeight = (34 * fontScale).sp,
                                color = MaterialTheme.colorScheme.onSurface)

                            // النصّ المقروء — بخطٍّ كبير داخل بطاقة بارزة
                            if (s.say != null) {
                                Spacer(Modifier.height(18.dp))
                                Column(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                                        .background(pal.emerald.copy(alpha = if (pal.dark) .14f else .10f))
                                        .padding(20.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(8.dp).clip(CircleShape).background(pal.gold))
                                        Spacer(Modifier.width(8.dp))
                                        Text("تقول:", color = pal.gold, fontSize = (14 * fontScale).sp, fontWeight = FontWeight.ExtraBold)
                                    }
                                    Spacer(Modifier.height(12.dp))
                                    Text(
                                        s.say,
                                        fontSize = (26 * fontScale).sp,      // خط كبير للقراءة أثناء الصلاة
                                        lineHeight = (48 * fontScale).sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                            // ===== السور المُشار إليها — تُعرض كاملةً =====
                            s.surahs.forEach { (sName, sText) ->
                                Spacer(Modifier.height(14.dp))
                                Column(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                                        .background(pal.gold.copy(alpha = if (pal.dark) .12f else .10f))
                                        .border(1.dp, pal.gold.copy(alpha = .25f), RoundedCornerShape(18.dp))
                                        .padding(18.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        LineIcon(AppIcon.Book, pal.gold, 16.dp)
                                        Spacer(Modifier.width(8.dp))
                                        Text(sName, color = pal.gold, fontSize = (14 * fontScale).sp, fontWeight = FontWeight.ExtraBold)
                                    }
                                    Spacer(Modifier.height(12.dp))
                                    Text(
                                        sText, fontSize = (23 * fontScale).sp, lineHeight = (44 * fontScale).sp,
                                        fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                            // ===== عدّاد تفاعليّ (تسبيح/استغفار/عفو...) =====
                            if (s.counter != null) {
                                Spacer(Modifier.height(14.dp))
                                var count by remember(idx) { mutableStateOf(0) }
                                val target = s.counter
                                val done = count >= target
                                Column(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                                        .background(if (done) pal.good.copy(alpha = .15f) else pal.emerald.copy(alpha = .12f))
                                        .border(1.dp, (if (done) pal.good else pal.emerald).copy(alpha = .3f), RoundedCornerShape(20.dp))
                                        .clickable(
                                            indication = null,
                                            interactionSource = remember { MutableInteractionSource() }
                                        ) { if (count < target) count++ }
                                        .padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    if (s.counterLabel != null) {
                                        Text(s.counterLabel, color = MaterialTheme.colorScheme.onSurface, fontSize = (18 * fontScale).sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(12.dp))
                                    }
                                    Text(
                                        if (done) "تمّ ✓  ($target)" else "$count / $target",
                                        color = if (done) pal.good else pal.emerald,
                                        fontSize = (40 * fontScale).sp, fontWeight = FontWeight.ExtraBold
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        if (done) "اكتمل العدد" else "انقر هنا لكلّ مرّة",
                                        color = pal.ink2, fontSize = (13 * fontScale).sp, fontWeight = FontWeight.Medium
                                    )
                                    if (count > 0 && !done) {
                                        Spacer(Modifier.height(8.dp))
                                        Text("إعادة", color = pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                            modifier = Modifier.clip(RoundedCornerShape(99.dp)).clickable { count = 0 }.padding(horizontal = 14.dp, vertical = 6.dp))
                                    }
                                }
                            }
                            if (s.sayNote != null) {
                                Spacer(Modifier.height(14.dp))
                                Row(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                        .background(pal.surface2.copy(alpha = .6f)).padding(14.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    LineIcon(AppIcon.Sparkle, pal.ink2, 16.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Text(s.sayNote, fontSize = (15 * fontScale).sp, lineHeight = (26 * fontScale).sp, color = pal.ink2)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    }

                    // تلميح: انقر في أي مكان للمتابعة
                    Text(
                        "انقر في أيّ مكان للانتقال للخطوة التالية",
                        color = pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    )
                }

                // أزرار التنقّل — كبيرة وسهلة النقر أثناء الصلاة
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp).navigationBarsPadding(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    if (i > 0) {
                        Box(
                            Modifier.weight(1f).heightIn(min = 68.dp).clip(RoundedCornerShape(20.dp)).background(pal.surface2)
                                .clickable { i-- }, contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                LineIcon(AppIcon.ChevronStart, pal.emerald, 24.dp); Spacer(Modifier.width(8.dp))
                                Text("السابق", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            }
                        }
                    }
                    Box(
                        Modifier.weight(if (i > 0) 1.7f else 1f).heightIn(min = 68.dp).clip(RoundedCornerShape(20.dp)).background(pal.pillBrush)
                            .clickable { if (isLast) onClose() else i++ }, contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (isLast) "تمّ — إغلاق" else "التالي",
                                color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                            if (!isLast) { Spacer(Modifier.width(8.dp)); LineIcon(AppIcon.ChevronEnd, Color.White, 24.dp) }
                        }
                    }
                }
            }
        }
    }
}
