package com.shirazi.duaa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Settings

private fun arDigit(n: Int): String = n.toString().map { "٠١٢٣٤٥٦٧٨٩"[it - '0'] }.joinToString("")

@Composable
fun HajjScreen(settings: Settings, pal: DuaaPalette, openReader: (String, String) -> Unit = { _, _ -> }, onClose: () -> Unit) {
    var guide by remember { mutableStateOf<String?>(null) }
    if (guide != null) HajjGuide(settings, pal, guide!!) { guide = null }
    else HajjHub(settings, pal, onClose, openReader) { guide = it }
}

@Composable
private fun HajjHub(settings: Settings, pal: DuaaPalette, onClose: () -> Unit, openReader: (String, String) -> Unit, onOpenGuide: (String) -> Unit) {
    val ctx = LocalContext.current
    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
            Column(Modifier.fillMaxSize()) {
                ScreenTopBar("الحجّ والعمرة", pal, onClose)
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {

                    // ===== أدعية المواقف: جسرٌ إلى باب «أدعية الحجّ والعمرة» =====
                    val hajjDuas = remember { com.shirazi.duaa.data.Data.categories.firstOrNull { it.id == "hajj" }?.items ?: emptyList() }
                    if (hajjDuas.isNotEmpty()) {
                        Column(
                            Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(18.dp))
                                .background(Brush.linearGradient(categoryGradient("hajj"))).padding(16.dp)
                        ) {
                            Text("أدعية المواقف", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                            Text("ما يُقال في كلّ موقفٍ بترتيب المناسك", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
                            Spacer(Modifier.height(10.dp))
                            hajjDuas.forEachIndexed { i, it ->
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp))
                                        .background(Color.White.copy(alpha = .12f))
                                        .clickable { openReader("hajj", it.id) }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("${i + 1}", color = Color.White.copy(alpha = .75f), fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold, modifier = Modifier.width(22.dp))
                                    Text(it.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    LineIcon(AppIcon.ChevronStart, Color.White.copy(alpha = .8f), 14.dp)
                                }
                            }
                        }
                    }

                    // تنبيهٌ فقهيّ
                    Box(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(pal.gold.copy(alpha = if (pal.dark) .14f else .12f)).padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.Top) {
                            LineIcon(AppIcon.Flag, pal.gold, 20.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                "دليلٌ إرشاديٌّ للتسلسل العامّ للمناسك. الأحكامُ التفصيليّةُ في مناسك مرجعك، ولا يُعتمَد عليه في أداء المناسك دون الرجوع إليها.",
                                color = MaterialTheme.colorScheme.onSurface, fontSize = 12.5.sp, lineHeight = 20.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(20.dp))

                    // بطاقتا الدخول للمناسك
                    SectionTitle("ابدأ المناسك خطوةً بخطوة")
                    RitualCard(pal, "عمرة التمتّع", "u-", UMRAH_STEPS.size, settings.hajjDoneCount("u-"), pal.emerald) { onOpenGuide("umrah") }
                    Spacer(Modifier.height(12.dp))
                    RitualCard(pal, "حجّ التمتّع", "h-", HAJJ_STEPS.size, settings.hajjDoneCount("h-"), pal.gold) { onOpenGuide("hajj") }
                    Spacer(Modifier.height(8.dp))

                    // مقدّماتٌ ومسائل
                    SectionTitle("مقدّمات ومسائل")
                    PlainCard(pal) {
                        HAJJ_PRELIMINARIES.forEachIndexed { idx, t ->
                            TopicRow(pal, t)
                            if (idx < HAJJ_PRELIMINARIES.lastIndex) Box(Modifier.fillMaxWidth().height(1.dp).background(pal.line))
                        }
                    }
                    Spacer(Modifier.height(8.dp))

                    // عدّاد سريع
                    SectionTitle("عدّاد الطواف والسعي")
                    TawafCounter(pal, null)
                    Spacer(Modifier.height(8.dp))

                    // التلبية
                    SectionTitle("التلبية")
                    Box(
                        Modifier.fillMaxWidth().paper(pal, 18).padding(vertical = 22.dp, horizontal = 20.dp)
                    ) {
                        Text(
                            "لَبَّيْكَ اللّٰهُمَّ لَبَّيْكَ، لَبَّيْكَ لا شَريكَ لَكَ لَبَّيْكَ، إِنَّ الْحَمْدَ وَالنِّعْمَةَ لَكَ وَالْمُلْكَ، لا شَريكَ لَكَ لَبَّيْكَ.",
                            color = MaterialTheme.colorScheme.onSurface, fontSize = 17.sp, lineHeight = 32.sp, fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(Modifier.height(12.dp))

                    ReportRow(pal, ctx)
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun RitualCard(pal: DuaaPalette, title: String, prefix: String, total: Int, done: Int, accent: Color, onClick: () -> Unit) {
    val frac = (if (total > 0) done.toFloat() / total else 0f).coerceIn(0f, 1f)
    Box(
        Modifier.fillMaxWidth().paper(pal, 20).clickable(onClick = onClick).padding(16.dp)
    ) {
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(accent.copy(alpha = .12f)),
                    contentAlignment = Alignment.Center
                ) { LineIcon(AppIcon.Dome, accent, 24.dp) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    Spacer(Modifier.height(2.dp))
                    Text("${arDigit(done)} من ${arDigit(total)} خطوةً مكتملة", color = pal.ink2, fontSize = 12.sp)
                }
                LineIcon(AppIcon.ChevronStart, pal.ink2, 20.dp)
            }
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(99.dp)).background(pal.line)) {
                if (frac > 0f) Box(Modifier.fillMaxWidth(frac).height(6.dp).clip(RoundedCornerShape(99.dp)).background(accent))
            }
        }
    }
}

@Composable
private fun HajjGuide(settings: Settings, pal: DuaaPalette, ritual: String, onBack: () -> Unit) {
    val steps = if (ritual == "umrah") UMRAH_STEPS else HAJJ_STEPS
    val title = if (ritual == "umrah") "عمرة التمتّع" else "حجّ التمتّع"
    var i by remember { mutableStateOf(0) }
    val step = steps[i]
    val done = settings.isHajjDone(step.id)
    val isLast = i == steps.lastIndex

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
            Column(Modifier.fillMaxSize()) {
                // شريط علوي + تقدّم
                Box(Modifier.fillMaxWidth().background(pal.heroBrush)) {
                    Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.a11yIconButton("رجوع", 38.dp, Color.White.copy(alpha = .14f), onClick = onBack), contentAlignment = Alignment.Center
                            ) { LineIcon(AppIcon.ChevronStart, Color.White, 17.dp) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                Text("الخطوة ${arDigit(i + 1)} من ${arDigit(steps.size)}", color = Color.White.copy(alpha = .8f), fontSize = 11.sp)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(99.dp)).background(Color.White.copy(alpha = .22f))) {
                            Box(Modifier.fillMaxWidth(((i + 1f) / steps.size).coerceIn(0f, 1f)).height(5.dp).clip(RoundedCornerShape(99.dp)).background(Color.White))
                        }
                    }
                }

                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
                    // شارة المكان
                    Box(Modifier.clip(RoundedCornerShape(99.dp)).background(pal.emerald.copy(alpha = .12f)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LineIcon(AppIcon.Pin, pal.emerald, 13.dp)
                            Spacer(Modifier.width(5.dp))
                            Text(step.place, color = pal.emerald, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    // العنوان
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).clip(CircleShape).background(pal.emerald), contentAlignment = Alignment.Center) {
                            Text(arDigit(i + 1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(step.title, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(step.desc, color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp, lineHeight = 26.sp)
                    Spacer(Modifier.height(16.dp))

                    // أحكام هذه الخطوة (قابلة للطيّ — تُملأ من مناسك المرجع)
                    RulingBlock(pal, step)
                    Spacer(Modifier.height(16.dp))

                    // عدّاد الطواف/السعي (يُعاد ضبطه لكلّ خطوة عبر key)
                    if (step.counter == 7) {
                        key(step.id) { TawafCounter(pal, step.kind) }
                        Spacer(Modifier.height(18.dp))
                    }

                    // زرّ الإتمام
                    Box(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(if (done) pal.good.copy(alpha = .15f) else pal.emerald.copy(alpha = .10f))
                            .border(1.dp, if (done) pal.good else pal.emerald.copy(alpha = .3f), RoundedCornerShape(16.dp))
                            .clickable { settings.toggleHajjStep(step.id) }.padding(vertical = 15.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (done) "أُتمّت هذه الخطوة ✓ — اضغط للتراجع" else "أتممتُ هذه الخطوة",
                            color = if (done) pal.good else pal.emerald, fontWeight = FontWeight.Bold, fontSize = 14.sp
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                }

                // تنقّل
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(Modifier.weight(1f)) { BigButton("السابق", pal, false) { if (i > 0) i-- } }
                    Box(Modifier.weight(1f)) { BigButton(if (isLast) "إنهاء" else "التالي", pal, true) { if (isLast) onBack() else i++ } }
                }
            }
        }
    }
}

@Composable
private fun TawafCounter(pal: DuaaPalette, fixedKind: String?) {
    val haptics = rememberHaptics()
    var mode by remember(fixedKind) { mutableStateOf(fixedKind ?: "tawaf") }
    var count by remember(mode) { mutableStateOf(0) }
    val done = count >= 7

    Column(
        Modifier.fillMaxWidth().paper(pal, 20).padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (fixedKind == null) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(pal.emerald.copy(alpha = .08f)).padding(4.dp)) {
                listOf("الطواف" to "tawaf", "السعي" to "sai").forEach { (label, k) ->
                    val sel = mode == k
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(9.dp)).background(if (sel) pal.emerald else Color.Transparent)
                            .clickable { mode = k }.padding(vertical = 9.dp), contentAlignment = Alignment.Center
                    ) { Text(label, color = if (sel) Color.White else pal.ink2, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        Text("$count", color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 64.sp)
        Text(if (mode == "tawaf") "من 7 أشواطٍ حول الكعبة" else "من 7 أشواطٍ بين الصفا والمروة", color = pal.ink2, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(7) { d ->
                Box(Modifier.size(if (d < count) 12.dp else 10.dp).clip(CircleShape).background(if (d < count) pal.emerald else pal.line))
            }
        }
        Spacer(Modifier.height(14.dp))

        if (mode == "tawaf") {
            if (count in 1..7) {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.emerald.copy(alpha = .07f)).padding(14.dp)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text("دعاء الشوط ${listOf("الأول","الثاني","الثالث","الرابع","الخامس","السادس","السابع").getOrElse(count - 1) { "" }}", color = pal.emerald, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(TAWAF_DUAS[count - 1], color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp, lineHeight = 28.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(8.dp))
                        Text("مأثورٌ عن الإمام الصادق (ع) برواية معاوية بن عمّار", color = pal.gold, fontSize = 11.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
                    }
                }
            } else {
                Text("اضغط «الشوط التالي» عند إتمام كلّ شوط، مبتدئاً من الحجر الأسود.", color = pal.ink2, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        } else {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.emerald.copy(alpha = .07f)).padding(14.dp)) {
                Text(SAI_GUIDANCE, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, lineHeight = 23.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) {
                BigButton(if (done) "اكتملت ٧ أشواط ✓" else "الشوط التالي", pal, !done) {
                    if (count < 7) { count++; if (count == 7) haptics.celebrate() else haptics.tick() }
                }
            }
            Box(
                Modifier.clip(RoundedCornerShape(14.dp)).background(pal.emerald.copy(alpha = .10f))
                    .clickable { count = 0; haptics.tick() }.padding(horizontal = 18.dp, vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) { Text("تصفير", color = pal.emerald, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        }
    }
}

@Composable
private fun ReportRow(pal: DuaaPalette, ctx: android.content.Context) {
    Box(
        Modifier.fillMaxWidth().paper(pal, 14)
            .clickable {
                val uri = android.net.Uri.parse("mailto:$SUPPORT_EMAIL?subject=" + android.net.Uri.encode("ملاحظة على دليل الحجّ والعمرة"))
                try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, uri)) } catch (_: Exception) {}
            }.padding(horizontal = 16.dp, vertical = 14.dp), contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LineIcon(AppIcon.Flag, pal.ink2, 16.dp)
            Spacer(Modifier.width(8.dp))
            Text("أبلِغ عن ملاحظةٍ أو خطأ", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun TopicRow(pal: DuaaPalette, topic: HajjTopic) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(topic.title, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(if (open) "▾" else "▸", color = pal.emerald, fontSize = 14.sp)
        }
        if (open) {
            Text(topic.note, color = pal.ink2, fontSize = 12.5.sp, lineHeight = 21.sp, modifier = Modifier.padding(bottom = 12.dp))
        }
    }
}

@Composable
private fun RulingBlock(pal: DuaaPalette, step: HajjStep) {
    var open by remember(step.id) { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.emerald.copy(alpha = .06f))) {
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LineIcon(AppIcon.Book, pal.emerald, 16.dp)
            Spacer(Modifier.width(10.dp))
            Text("أحكام هذه الخطوة", color = pal.emerald, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(if (open) "▾" else "▸", color = pal.emerald, fontSize = 14.sp)
        }
        if (open) {
            Text(
                step.ruling.ifEmpty { "الأحكامُ التفصيليّةُ لهذه الخطوة تُضاف من مصدرٍ موثّق. يُرجى الرجوع إلى مناسك مرجعك في هذه المسألة." },
                color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, lineHeight = 22.sp,
                modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp)
            )
        }
    }
}
