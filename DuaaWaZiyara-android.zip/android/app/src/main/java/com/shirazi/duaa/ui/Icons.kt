package com.shirazi.duaa.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/** أيقونات خطّية مخصّصة مرسومة بالكود — بأسلوب 2026 (خط 2dp، رؤوس مدوّرة). */
enum class AppIcon {
    Dome, Book, Clock, Crescent, Sparkle, Star8, Calc, Beads, Star, StarFill,
    Gear, Theme, Copy, ChevronStart, ChevronEnd, Sunrise, Flag, Scroll, Hands,
    Pin, HomeMini, Drop, Moon2, Search, Flame, Share
}

@Composable
fun LineIcon(icon: AppIcon, tint: Color, size: Dp = 22.dp, modifier: Modifier = Modifier, label: String? = null) {
    // label != null يجعل الأيقونة مقروءة بقارئ الشاشة؛ الأيقونات الزخرفية تبقى مخفيّة عنه
    val m = if (label != null) modifier.semantics { contentDescription = label }
            else modifier.clearAndSetSemantics { }
    Canvas(m.size(size)) {
        val w = this.size.width; val h = this.size.height
        val sw = w * 0.11f
        val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(w * x, h * y)
        fun line(a: Offset, b: Offset) = drawLine(tint, a, b, sw, StrokeCap.Round)
        fun poly(pts: List<Offset>) { for (i in 0 until pts.size - 1) line(pts[i], pts[i + 1]) }

        when (icon) {
            AppIcon.Dome -> { // قبة ومئذنة
                val path = Path().apply {
                    moveTo(w * .18f, h * .80f); lineTo(w * .18f, h * .52f)
                    cubicTo(w * .18f, h * .26f, w * .82f, h * .26f, w * .82f, h * .52f)
                    lineTo(w * .82f, h * .80f)
                }
                drawPath(path, tint, style = stroke)
                line(p(.10f, .80f), p(.90f, .80f))
                line(p(.50f, .26f), p(.50f, .14f))
                drawCircle(tint, sw * .9f, p(.50f, .11f))
            }
            AppIcon.Book -> { // كتاب مفتوح
                val l = Path().apply { moveTo(w * .50f, h * .26f); cubicTo(w * .38f, h * .18f, w * .20f, h * .18f, w * .12f, h * .24f); lineTo(w * .12f, h * .76f); cubicTo(w * .20f, h * .70f, w * .38f, h * .70f, w * .50f, h * .78f) }
                val r = Path().apply { moveTo(w * .50f, h * .26f); cubicTo(w * .62f, h * .18f, w * .80f, h * .18f, w * .88f, h * .24f); lineTo(w * .88f, h * .76f); cubicTo(w * .80f, h * .70f, w * .62f, h * .70f, w * .50f, h * .78f) }
                drawPath(l, tint, style = stroke); drawPath(r, tint, style = stroke)
                line(p(.50f, .26f), p(.50f, .78f))
            }
            AppIcon.Clock -> {
                drawCircle(tint, w * .38f, p(.50f, .50f), style = stroke)
                poly(listOf(p(.50f, .30f), p(.50f, .52f), p(.66f, .60f)))
            }
            AppIcon.Crescent, AppIcon.Moon2 -> { // هلال
                val path = Path().apply {
                    moveTo(w * .62f, h * .12f)
                    cubicTo(w * .28f, h * .20f, w * .28f, h * .80f, w * .62f, h * .88f)
                    cubicTo(w * .40f, h * .90f, w * .14f, h * .74f, w * .14f, h * .50f)
                    cubicTo(w * .14f, h * .26f, w * .40f, h * .10f, w * .62f, h * .12f)
                }
                drawPath(path, tint, style = stroke)
            }
            AppIcon.Sparkle -> { // نجمة رباعية
                val path = Path().apply {
                    moveTo(w * .50f, h * .10f); cubicTo(w * .54f, h * .38f, w * .62f, h * .46f, w * .90f, h * .50f)
                    cubicTo(w * .62f, h * .54f, w * .54f, h * .62f, w * .50f, h * .90f)
                    cubicTo(w * .46f, h * .62f, w * .38f, h * .54f, w * .10f, h * .50f)
                    cubicTo(w * .38f, h * .46f, w * .46f, h * .38f, w * .50f, h * .10f); close()
                }
                drawPath(path, tint, style = stroke)
            }
            AppIcon.Star8 -> { // نجمة ثمانية (خيرة)
                fun sq(rot: Float): Path { val r = w * .36f; val c = p(.5f, .5f); val pa = Path()
                    for (i in 0..3) { val a = rot + i * Math.PI.toFloat() / 2
                        val pt = Offset(c.x + cos(a) * r, c.y + sin(a) * r)
                        if (i == 0) pa.moveTo(pt.x, pt.y) else pa.lineTo(pt.x, pt.y) }
                    pa.close(); return pa }
                drawPath(sq(0f), tint, style = stroke)
                drawPath(sq(Math.PI.toFloat() / 4), tint, style = stroke)
                drawCircle(tint, sw, p(.5f, .5f))
            }
            AppIcon.Calc -> {
                drawRoundRect(tint, p(.20f, .12f), Size(w * .60f, h * .76f), androidx.compose.ui.geometry.CornerRadius(w * .10f), stroke)
                line(p(.30f, .28f), p(.70f, .28f))
                for (ry in listOf(.48f, .64f)) for (rx in listOf(.32f, .50f, .68f)) drawCircle(tint, sw * .8f, p(rx, ry + .06f))
            }
            AppIcon.Beads -> { // سبحة
                val c = p(.5f, .44f); val r = w * .30f
                for (i in 0..7) { val a = (i / 8f) * 2 * Math.PI.toFloat() - Math.PI.toFloat() / 2
                    if (i == 4) continue
                    drawCircle(tint, sw * .95f, Offset(c.x + cos(a) * r, c.y + sin(a) * r)) }
                line(p(.5f, .74f), p(.5f, .86f)); drawCircle(tint, sw * 1.1f, p(.5f, .91f))
            }
            AppIcon.Star, AppIcon.StarFill -> { // نجمة خماسية
                val c = p(.5f, .54f); val rO = w * .40f; val rI = w * .17f; val path = Path()
                for (i in 0..9) { val a = (-Math.PI / 2 + i * Math.PI / 5).toFloat()
                    val r = if (i % 2 == 0) rO else rI
                    val pt = Offset(c.x + cos(a) * r, c.y + sin(a) * r)
                    if (i == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y) }
                path.close()
                if (icon == AppIcon.StarFill) drawPath(path, tint) else drawPath(path, tint, style = stroke)
            }
            AppIcon.Gear -> {
                drawCircle(tint, w * .16f, p(.5f, .5f), style = stroke)
                for (i in 0..7) { val a = (i / 8f) * 2 * Math.PI.toFloat()
                    val o = Offset(cos(a), sin(a))
                    line(Offset(w * .5f + o.x * w * .30f, h * .5f + o.y * h * .30f),
                         Offset(w * .5f + o.x * w * .42f, h * .5f + o.y * h * .42f)) }
            }
            AppIcon.Theme -> { // نصف مضيء
                drawCircle(tint, w * .36f, p(.5f, .5f), style = stroke)
                val half = Path().apply { moveTo(w * .5f, h * .14f); arcTo(androidx.compose.ui.geometry.Rect(p(.14f, .14f), Size(w * .72f, h * .72f)), -90f, 180f, false); close() }
                drawPath(half, tint)
            }
            AppIcon.Copy -> {
                drawRoundRect(tint, p(.30f, .26f), Size(w * .48f, h * .56f), androidx.compose.ui.geometry.CornerRadius(w * .08f), stroke)
                poly(listOf(p(.22f, .66f), p(.14f, .66f), p(.14f, .10f), p(.58f, .10f), p(.58f, .18f)))
            }
            AppIcon.Share -> {
                val r = w * .10f
                drawCircle(tint, r, p(.72f, .22f), style = stroke)
                drawCircle(tint, r, p(.72f, .78f), style = stroke)
                drawCircle(tint, r, p(.24f, .50f), style = stroke)
                line(p(.34f, .44f), p(.62f, .28f))
                line(p(.34f, .56f), p(.62f, .72f))
            }
            AppIcon.ChevronStart -> poly(listOf(p(.40f, .22f), p(.64f, .50f), p(.40f, .78f))) // يشير لبداية السطر RTL (رجوع)
            AppIcon.ChevronEnd -> poly(listOf(p(.60f, .22f), p(.36f, .50f), p(.60f, .78f)))   // يشير لنهاية السطر RTL (تقدّم)
            AppIcon.Sunrise -> {
                val rect = androidx.compose.ui.geometry.Rect(p(.26f, .30f), Size(w * .48f, h * .48f))
                drawArc(tint, 180f, 180f, false, rect.topLeft, rect.size, style = stroke)
                line(p(.10f, .54f), p(.90f, .54f).copy(y = h * .54f))
                line(p(.50f, .08f), p(.50f, .20f))
                line(p(.22f, .20f), p(.30f, .28f)); line(p(.78f, .20f), p(.70f, .28f))
            }
            AppIcon.Flag -> {
                line(p(.26f, .12f), p(.26f, .88f))
                val path = Path().apply { moveTo(w * .26f, h * .16f); lineTo(w * .78f, h * .26f); lineTo(w * .60f, h * .38f); lineTo(w * .78f, h * .50f); lineTo(w * .26f, h * .56f) }
                drawPath(path, tint, style = stroke)
            }
            AppIcon.Scroll -> { // مخطوطة
                drawRoundRect(tint, p(.22f, .12f), Size(w * .56f, h * .76f), androidx.compose.ui.geometry.CornerRadius(w * .12f), stroke)
                for (y in listOf(.32f, .48f, .64f)) line(p(.34f, y), p(.66f, y))
            }
            AppIcon.Hands -> { // كفّا الدعاء (قوسان)
                val l = Path().apply { moveTo(w * .42f, h * .16f); cubicTo(w * .18f, h * .30f, w * .16f, h * .62f, w * .40f, h * .82f) }
                val r = Path().apply { moveTo(w * .58f, h * .16f); cubicTo(w * .82f, h * .30f, w * .84f, h * .62f, w * .60f, h * .82f) }
                drawPath(l, tint, style = stroke); drawPath(r, tint, style = stroke)
                drawCircle(tint, sw * .8f, p(.5f, .36f))
            }
            AppIcon.Pin -> {
                val path = Path().apply { moveTo(w * .5f, h * .88f); cubicTo(w * .20f, h * .56f, w * .22f, h * .16f, w * .50f, h * .16f); cubicTo(w * .78f, h * .16f, w * .80f, h * .56f, w * .50f, h * .88f) }
                drawPath(path, tint, style = stroke)
                drawCircle(tint, w * .09f, p(.5f, .38f), style = stroke)
            }
            AppIcon.HomeMini -> {
                poly(listOf(p(.14f, .50f), p(.50f, .16f), p(.86f, .50f)))
                val path = Path().apply { moveTo(w * .24f, h * .46f); lineTo(w * .24f, h * .84f); lineTo(w * .76f, h * .84f); lineTo(w * .76f, h * .46f) }
                drawPath(path, tint, style = stroke)
            }
            AppIcon.Search -> {
                drawCircle(tint, w * .26f, p(.42f, .42f), style = stroke)
                line(p(.62f, .62f), p(.84f, .84f))
            }
            AppIcon.Flame -> {
                val path = Path().apply { moveTo(w * .5f, h * .10f); cubicTo(w * .70f, h * .30f, w * .82f, h * .48f, w * .78f, h * .64f); cubicTo(w * .74f, h * .82f, w * .26f, h * .82f, w * .22f, h * .64f); cubicTo(w * .18f, h * .48f, w * .34f, h * .34f, w * .40f, h * .22f); cubicTo(w * .44f, h * .30f, w * .48f, h * .26f, w * .50f, h * .10f) }
                drawPath(path, tint, style = stroke)
            }
            AppIcon.Drop -> { // قطرة (مناجاة)
                val path = Path().apply { moveTo(w * .5f, h * .10f); cubicTo(w * .80f, h * .46f, w * .76f, h * .82f, w * .50f, h * .86f); cubicTo(w * .24f, h * .82f, w * .20f, h * .46f, w * .50f, h * .10f) }
                drawPath(path, tint, style = stroke)
            }
        }
    }
}

/** أيقونة كل باب من أبواب المكتبة. */
fun categoryIcon(catId: String): AppIcon = when (catId) {
    "taqibat" -> AppIcon.Beads
    "sabah" -> AppIcon.Sunrise
    "osboo" -> AppIcon.Clock
    "jumaa" -> AppIcon.Dome
    "mashhura" -> AppIcon.Star
    "munajat" -> AppIcon.Drop
    "hawaij" -> AppIcon.Hands
    "ramadan" -> AppIcon.Crescent
    "ziyarat" -> AppIcon.Flag
    "hajj" -> AppIcon.Dome
    "rajab" -> AppIcon.Moon2
    "hikam" -> AppIcon.Scroll
    "hajat" -> AppIcon.Hands
    "tarbiya" -> AppIcon.Sparkle
    "quran" -> AppIcon.Book
    "nahj" -> AppIcon.Scroll
    "salawat" -> AppIcon.Hands
    "nawafil" -> AppIcon.Dome
    "akhlaq" -> AppIcon.StarFill
    "ahadith" -> AppIcon.Scroll
    "khutab" -> AppIcon.Book
    "sahifa" -> AppIcon.Scroll
    "yawm" -> AppIcon.Clock
    "huquq" -> AppIcon.Scroll
    "kafi-dua" -> AppIcon.Hands
    "kafi-quran" -> AppIcon.Book
    "kafi-ishra" -> AppIcon.StarFill
    else -> AppIcon.Sparkle
}

/** تدرّج لوني مميّز لكل باب — يعطي كل بطاقة هويّتها البصرية (بديل عن الصور). */
fun categoryGradient(catId: String): List<androidx.compose.ui.graphics.Color> = when (catId) {
    "taqibat"  -> listOf(androidx.compose.ui.graphics.Color(0xFF17695F), androidx.compose.ui.graphics.Color(0xFF2A8A7C))
    "sabah"    -> listOf(androidx.compose.ui.graphics.Color(0xFF8C6526), androidx.compose.ui.graphics.Color(0xFFB08433))
    "osboo"    -> listOf(androidx.compose.ui.graphics.Color(0xFF144B52), androidx.compose.ui.graphics.Color(0xFF23707A))
    "jumaa"    -> listOf(androidx.compose.ui.graphics.Color(0xFF1D3B45), androidx.compose.ui.graphics.Color(0xFF2F5A66))
    "mashhura" -> listOf(androidx.compose.ui.graphics.Color(0xFF144B52), androidx.compose.ui.graphics.Color(0xFF23707A))
    "munajat"  -> listOf(androidx.compose.ui.graphics.Color(0xFF1D3B45), androidx.compose.ui.graphics.Color(0xFF2F5A66))
    "sahifa"   -> listOf(androidx.compose.ui.graphics.Color(0xFF17695F), androidx.compose.ui.graphics.Color(0xFF2A8A7C))
    "huquq"    -> listOf(androidx.compose.ui.graphics.Color(0xFF1D3B45), androidx.compose.ui.graphics.Color(0xFF2F5A66))
    "yawm"     -> listOf(androidx.compose.ui.graphics.Color(0xFF8C6526), androidx.compose.ui.graphics.Color(0xFFB08433))
    "hawaij"   -> listOf(androidx.compose.ui.graphics.Color(0xFF8C6526), androidx.compose.ui.graphics.Color(0xFFB08433))
    "ramadan"  -> listOf(androidx.compose.ui.graphics.Color(0xFF1D3B45), androidx.compose.ui.graphics.Color(0xFF2F5A66))
    "ziyarat"  -> listOf(androidx.compose.ui.graphics.Color(0xFF144B52), androidx.compose.ui.graphics.Color(0xFF23707A))
    "hajj"     -> listOf(androidx.compose.ui.graphics.Color(0xFF17695F), androidx.compose.ui.graphics.Color(0xFF2A8A7C))
    "rajab"    -> listOf(androidx.compose.ui.graphics.Color(0xFF1D3B45), androidx.compose.ui.graphics.Color(0xFF2F5A66))
    "hikam"    -> listOf(androidx.compose.ui.graphics.Color(0xFF8C6526), androidx.compose.ui.graphics.Color(0xFFB08433))
    "hajat"    -> listOf(androidx.compose.ui.graphics.Color(0xFF17695F), androidx.compose.ui.graphics.Color(0xFF2A8A7C))
    "tarbiya"  -> listOf(androidx.compose.ui.graphics.Color(0xFF144B52), androidx.compose.ui.graphics.Color(0xFF23707A))
    "quran"    -> listOf(androidx.compose.ui.graphics.Color(0xFF17695F), androidx.compose.ui.graphics.Color(0xFF2A8A7C))
    "nahj"     -> listOf(androidx.compose.ui.graphics.Color(0xFF8C6526), androidx.compose.ui.graphics.Color(0xFFB08433))
    "salawat"  -> listOf(androidx.compose.ui.graphics.Color(0xFF144B52), androidx.compose.ui.graphics.Color(0xFF23707A))
    "nawafil"  -> listOf(androidx.compose.ui.graphics.Color(0xFF144B52), androidx.compose.ui.graphics.Color(0xFF23707A))
    "akhlaq"   -> listOf(androidx.compose.ui.graphics.Color(0xFF17695F), androidx.compose.ui.graphics.Color(0xFF2A8A7C))
    "ahadith"  -> listOf(androidx.compose.ui.graphics.Color(0xFF8C6526), androidx.compose.ui.graphics.Color(0xFFB08433))
    "kafi-dua" -> listOf(androidx.compose.ui.graphics.Color(0xFF17695F), androidx.compose.ui.graphics.Color(0xFF2A8A7C))
    "kafi-quran" -> listOf(androidx.compose.ui.graphics.Color(0xFF144B52), androidx.compose.ui.graphics.Color(0xFF23707A))
    "kafi-ishra" -> listOf(androidx.compose.ui.graphics.Color(0xFF1D3B45), androidx.compose.ui.graphics.Color(0xFF2F5A66))
    "khutab"   -> listOf(androidx.compose.ui.graphics.Color(0xFF8C6526), androidx.compose.ui.graphics.Color(0xFFB08433))
    else       -> listOf(androidx.compose.ui.graphics.Color(0xFF144B52), androidx.compose.ui.graphics.Color(0xFF23707A))
}

/* ===== التوقيع البصري: نجمة ثمانية إسلامية + فاصل مُذهّب ===== */

/** نجمة ثمانية (رسم خطّي) — تُستخدم كزخرفة خلف الرأس وكعلامة الباب. */
@Composable
fun StarTile(tint: androidx.compose.ui.graphics.Color, size: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier, stroke: Boolean = true) {
    androidx.compose.foundation.Canvas(modifier.size(size)) {
        val w = this.size.width; val c = androidx.compose.ui.geometry.Offset(w / 2, w / 2)
        val rO = w * 0.46f; val rI = w * 0.19f
        val path = androidx.compose.ui.graphics.Path()
        for (i in 0..15) {
            val a = (-Math.PI / 2 + i * Math.PI / 8).toFloat()
            val r = if (i % 2 == 0) rO else rI
            val p = androidx.compose.ui.geometry.Offset(c.x + kotlin.math.cos(a) * r, c.y + kotlin.math.sin(a) * r)
            if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
        }
        path.close()
        if (stroke) drawPath(path, tint, style = androidx.compose.ui.graphics.drawscope.Stroke(width = w * 0.03f))
        else drawPath(path, tint)
        // مربعان متقاطعان داخليان يكمّلان شكل النجمة الثمانية الكلاسيكية
        if (stroke) {
            for (rot in listOf(0f, (Math.PI / 4).toFloat())) {
                val sq = androidx.compose.ui.graphics.Path()
                for (k in 0..3) {
                    val a = rot + k * (Math.PI / 2).toFloat()
                    val p = androidx.compose.ui.geometry.Offset(c.x + kotlin.math.cos(a) * rO * 0.62f, c.y + kotlin.math.sin(a) * rO * 0.62f)
                    if (k == 0) sq.moveTo(p.x, p.y) else sq.lineTo(p.x, p.y)
                }
                sq.close()
                drawPath(sq, tint, style = androidx.compose.ui.graphics.drawscope.Stroke(width = w * 0.022f))
            }
        }
    }
}

/** فاصل مُذهّب: خط شعري مع نقطة معيّنة في الوسط. */
@Composable
fun GoldDivider(pal: DuaaPalette, modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier.fillMaxWidth().height(14.dp)) {
        val w = size.width; val midY = size.height / 2
        val gold = pal.gold
        drawLine(gold.copy(alpha = .45f), androidx.compose.ui.geometry.Offset(0f, midY), androidx.compose.ui.geometry.Offset(w / 2 - 12, midY), 1.2f)
        drawLine(gold.copy(alpha = .45f), androidx.compose.ui.geometry.Offset(w / 2 + 12, midY), androidx.compose.ui.geometry.Offset(w, midY), 1.2f)
        val cx = w / 2
        val dpath = androidx.compose.ui.graphics.Path().apply {
            moveTo(cx, midY - 5); lineTo(cx + 5, midY); lineTo(cx, midY + 5); lineTo(cx - 5, midY); close()
        }
        drawPath(dpath, gold)
    }
}

/* =====================================================================
 * نمط هندسي إسلامي (girih) مرسوم بالكود — بديل عن الصور لإعطاء العمق والهوية.
 * شبكة متكرّرة من النجوم الثمانية المتشابكة. يُرسم كخلفية للرؤوس والبطاقات.
 * ===================================================================== */
@Composable
fun IslamicPattern(
    tint: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
    cell: Float = 120f,
    strokeW: Float = 1.4f
) {
    androidx.compose.foundation.Canvas(modifier) {
        val w = size.width; val h = size.height
        val s = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeW)
        val sThin = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeW * 0.7f)

        // تلاشٍ قطريّ: تكثُف الزخرفة عند منبع الضوء وتخفت عند الأطراف — عمقٌ بدل ورق حائط
        val bloom = androidx.compose.ui.geometry.Offset(w * 0.22f, h * 0.18f)
        val fade = androidx.compose.ui.graphics.Brush.radialGradient(
            colors = listOf(tint, tint.copy(alpha = tint.alpha * 0.28f)),
            center = bloom,
            radius = kotlin.math.max(w, h) * 0.95f
        )
        val fadeSoft = androidx.compose.ui.graphics.Brush.radialGradient(
            colors = listOf(tint.copy(alpha = tint.alpha * 0.55f), tint.copy(alpha = tint.alpha * 0.10f)),
            center = bloom,
            radius = kotlin.math.max(w, h) * 0.95f
        )

        fun star(cx: Float, cy: Float, rO: Float, rI: Float): androidx.compose.ui.graphics.Path {
            val p = androidx.compose.ui.graphics.Path()
            for (i in 0..15) {
                val a = (-Math.PI / 2 + i * Math.PI / 8).toFloat()
                val r = if (i % 2 == 0) rO else rI
                val px = cx + kotlin.math.cos(a) * r
                val py = cy + kotlin.math.sin(a) * r
                if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
            }
            p.close(); return p
        }

        fun octagon(cx: Float, cy: Float, r: Float): androidx.compose.ui.graphics.Path {
            val p = androidx.compose.ui.graphics.Path()
            for (i in 0..7) {
                val a = (Math.PI / 8 + i * Math.PI / 4).toFloat()
                val px = cx + kotlin.math.cos(a) * r
                val py = cy + kotlin.math.sin(a) * r
                if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
            }
            p.close(); return p
        }

        // ===== الشبكة الأساسية: نجمة ثمانية + ثُمانيّ داخليّ =====
        var y = 0f
        while (y < h + cell) {
            var x = 0f
            while (x < w + cell) {
                val cx = x + cell / 2; val cy = y + cell / 2
                val rO = cell * 0.46f; val rI = cell * 0.20f
                drawPath(star(cx, cy, rO, rI), fade, style = s)
                drawPath(octagon(cx, cy, cell * 0.135f), fadeSoft, style = sThin)
                val half = cell / 2
                drawLine(fade, androidx.compose.ui.geometry.Offset(cx, cy - rO),
                    androidx.compose.ui.geometry.Offset(cx, cy - half), strokeW)
                drawLine(fade, androidx.compose.ui.geometry.Offset(cx + rO, cy),
                    androidx.compose.ui.geometry.Offset(cx + half, cy), strokeW)
                x += cell
            }
            y += cell
        }

        // ===== شبكة متشابكة مُزاحة بنصف خليّة: تعطي تداخل الگيري الأصيل =====
        val off = cell / 2
        var y2 = -off
        while (y2 < h + cell) {
            var x2 = -off
            while (x2 < w + cell) {
                val cx = x2 + cell / 2; val cy = y2 + cell / 2
                drawPath(star(cx, cy, cell * 0.26f, cell * 0.115f), fadeSoft, style = sThin)
                x2 += cell
            }
            y2 += cell
        }
    }
}

/** وهجُ ضوءٍ ناعم يُوضع فوق الترويسات: يمنح التدرّج عمقاً ماديّاً بلا تغيير لونيّ. */
@Composable
fun HeroSheen(modifier: Modifier = Modifier, strength: Float = 0.16f) {
    Canvas(modifier) {
        val w = size.width; val h = size.height
        drawCircle(
            brush = androidx.compose.ui.graphics.Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = strength), Color.White.copy(alpha = 0f)),
                center = Offset(w * 0.24f, h * 0.10f),
                radius = kotlin.math.max(w, h) * 0.62f
            ),
            radius = kotlin.math.max(w, h) * 0.62f,
            center = Offset(w * 0.24f, h * 0.10f)
        )
        // ظلّ سفليّ خفيف يُرسّخ البطاقة على الخلفية
        drawRect(
            brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                colors = listOf(Color.Transparent, Color.Black.copy(alpha = strength * 0.55f)),
                startY = h * 0.55f, endY = h
            ),
            size = size
        )
    }
}

/* ============ مشهد الغروب للبطاقة (رسم برمجيّ بدل صورة) ============ */
@Composable
fun DuskScene(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width; val h = size.height
        // سماء متدرّجة بدفءٍ نحو الأفق
        drawRect(
            brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                0f to Color(0xFF2E8A7C), 0.5f to Color(0xFF7DB8A8), 1f to Color(0xFFEAD9B6)
            ), size = size
        )
        // وهج الشمس عند الأفق
        drawCircle(Color(0xFFFFF1CE).copy(alpha = .60f), w * .30f, Offset(w * .5f, h * 1.04f))
        drawCircle(Color(0xFFFFE7AC).copy(alpha = .55f), w * .16f, Offset(w * .5f, h * 1.0f))

        val silh = Color(0xFF0F4A42)
        val groundY = h * .87f; val cx = w * .5f

        // ===== هلالٌ ونجمة =====
        val mcx = w * .24f; val mcy = h * .29f; val mr = h * .135f
        drawCircle(Color(0xFFFFF6E0), mr, Offset(mcx, mcy))
        drawCircle(Color(0xFF5FA596), mr * 1.04f, Offset(mcx + mr * .52f, mcy - mr * .30f))
        run {
            val sx = mcx + mr * 1.7f; val sy = mcy + mr * .1f; val sr = mr * .42f
            val p = Path()
            for (i in 0 until 10) {
                val rr = if (i % 2 == 0) sr else sr * .42f
                val a = Math.toRadians((i * 36.0) - 90.0)
                val px = sx + (rr * Math.cos(a)).toFloat(); val py = sy + (rr * Math.sin(a)).toFloat()
                if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
            }
            p.close(); drawPath(p, Color(0xFFFFF6E0))
        }

        // ===== تلال خلفية =====
        drawPath(Path().apply {
            moveTo(0f, h * .80f); cubicTo(w * .3f, h * .72f, w * .62f, h * .84f, w, h * .76f)
            lineTo(w, h); lineTo(0f, h); close()
        }, Color(0xFF2A8A7C).copy(alpha = .45f))
        // ===== أرضٌ أماميّة =====
        drawPath(Path().apply {
            moveTo(0f, h * .855f); cubicTo(w * .3f, h * .835f, w * .7f, h * .875f, w, h * .85f)
            lineTo(w, h); lineTo(0f, h); close()
        }, Color(0xFF1F6B60).copy(alpha = .55f))

        // ===== دوالّ مساعدة =====
        // قبّةٌ بصليّة (شكل البصلة المميّز للعمارة الإسلاميّة)
        fun onion(dcx: Float, baseY: Float, dw: Float): Path = Path().apply {
            moveTo(dcx - dw / 2, baseY)
            cubicTo(dcx - dw * .58f, baseY - dw * .60f, dcx - dw * .16f, baseY - dw * .94f, dcx, baseY - dw * 1.04f)
            cubicTo(dcx + dw * .16f, baseY - dw * .94f, dcx + dw * .58f, baseY - dw * .60f, dcx + dw / 2, baseY)
            close()
        }
        // هلالٌ على القمّة (سارية + هلال)
        fun finial(fx: Float, baseY: Float, s: Float) {
            drawLine(silh, Offset(fx, baseY), Offset(fx, baseY - s * 1.6f), strokeWidth = s * .5f, cap = StrokeCap.Round)
            drawArc(silh, 60f, 240f, false, topLeft = Offset(fx - s, baseY - s * 2.8f),
                size = Size(s * 2, s * 2), style = Stroke(width = s * .5f, cap = StrokeCap.Round))
        }

        // ===== المئذنتان =====
        fun minaret(mx: Float) {
            val mw = h * .036f; val colTop = groundY - h * .47f
            drawRect(silh, topLeft = Offset(mx - mw / 2, colTop), size = Size(mw, groundY - colTop))
            // شُرفة المؤذّن
            drawRect(silh, topLeft = Offset(mx - mw * .95f, colTop + h * .10f), size = Size(mw * 1.9f, mw * .5f))
            drawPath(onion(mx, colTop, mw * 1.5f), silh)
            finial(mx, colTop - mw * 1.5f * 1.04f, mw * .5f)
        }
        minaret(cx - w * .21f); minaret(cx + w * .21f)

        // ===== قاعدة المسجد + القبّة المركزيّة =====
        val bw = w * .28f; val bh = h * .22f
        drawRect(silh, topLeft = Offset(cx - bw / 2, groundY - bh), size = Size(bw, bh))
        val dw = bw * .76f; val db = groundY - bh
        drawPath(onion(cx, db, dw), silh)
        finial(cx, db - dw * 1.04f, dw * .17f)

        // ===== بابٌ مقوّسٌ مضيء (قوسٌ مدبّب) =====
        val doorW = bw * .22f; val doorH = bh * .62f
        drawPath(Path().apply {
            moveTo(cx - doorW / 2, groundY); lineTo(cx - doorW / 2, groundY - doorH * .55f)
            cubicTo(cx - doorW / 2, groundY - doorH * .92f, cx, groundY - doorH * 1.05f, cx, groundY - doorH * 1.05f)
            cubicTo(cx, groundY - doorH * 1.05f, cx + doorW / 2, groundY - doorH * .92f, cx + doorW / 2, groundY - doorH * .55f)
            lineTo(cx + doorW / 2, groundY); close()
        }, Color(0xFFFFE3A0).copy(alpha = .92f))

        // ===== نخلتان =====
        fun palm(px: Float, hgt: Float, col: Color) {
            drawPath(Path().apply {
                moveTo(px, groundY); cubicTo(px - hgt * .06f, groundY - hgt * .45f, px + hgt * .05f, groundY - hgt * .75f, px - hgt * .02f, groundY - hgt)
            }, col, style = Stroke(width = hgt * .07f, cap = StrokeCap.Round))
            val tx = px - hgt * .02f; val ty = groundY - hgt
            listOf(-.42f to -.02f, -.30f to .14f, .30f to .14f, .42f to -.02f, 0f to -.26f).forEach { (exF, eyF) ->
                drawPath(Path().apply {
                    moveTo(tx, ty); cubicTo(tx + hgt * exF * .4f, ty - hgt * .14f, tx + hgt * exF * .8f, ty + hgt * eyF - hgt * .04f, tx + hgt * exF, ty + hgt * eyF)
                }, col, style = Stroke(width = hgt * .05f, cap = StrokeCap.Round))
            }
        }
        palm(w * .12f, h * .24f, silh)
        palm(cx + w * .37f, h * .19f, silh.copy(alpha = .92f))
    }
}

/* ============ أيقونات أوقات الصلاة (شمس/غيوم/هلال) ============ */
enum class PrayerGlyph { Dawn, Sun, Cloud, Dusk, Night }

@Composable
fun PrayerIcon(glyph: PrayerGlyph, tint: Color, size: Dp = 22.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val w = size.toPx().let { this.size.width }
        val h = this.size.height
        val sw = w * .10f
        val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(w * x, h * y)
        fun ray(a: Float, b: Float) = drawLine(tint, a.let { p(.5f, .5f) }, p(.5f, .5f), sw)
        when (glyph) {
            PrayerGlyph.Dawn -> {
                drawArc(tint, 180f, 180f, false, topLeft = Offset(w * .22f, h * .30f),
                    size = Size(w * .56f, w * .56f), style = stroke)
                drawLine(tint, p(.12f, .72f), p(.88f, .72f), sw)
                for (ang in listOf(.30f, .5f, .70f)) drawLine(tint, p(ang, .30f), p(ang, .20f), sw)
            }
            PrayerGlyph.Sun -> {
                drawCircle(tint, w * .16f, p(.5f, .5f), style = stroke)
                for (i in 0 until 8) {
                    val a = Math.toRadians((i * 45).toDouble())
                    val cx = .5f + .30f * cos(a).toFloat(); val cy = .5f + .30f * sin(a).toFloat()
                    val ix = .5f + .24f * cos(a).toFloat(); val iy = .5f + .24f * sin(a).toFloat()
                    drawLine(tint, p(ix, iy), p(cx, cy), sw)
                }
            }
            PrayerGlyph.Cloud -> {
                drawArc(tint, 0f, 360f, false, topLeft = Offset(w * .20f, h * .30f),
                    size = Size(w * .35f, w * .35f), style = stroke)
                drawArc(tint, 0f, 360f, false, topLeft = Offset(w * .42f, h * .24f),
                    size = Size(w * .40f, w * .40f), style = stroke)
                drawLine(tint, p(.24f, .68f), p(.78f, .68f), sw)
            }
            PrayerGlyph.Dusk -> {
                drawArc(tint, 180f, 180f, false, topLeft = Offset(w * .24f, h * .34f),
                    size = Size(w * .52f, w * .52f), style = stroke)
                drawLine(tint, p(.10f, .74f), p(.90f, .74f), sw)
                drawLine(tint, p(.5f, .60f), p(.5f, .46f), sw)
                drawLine(tint, p(.40f, .50f), p(.36f, .44f), sw)
                drawLine(tint, p(.60f, .50f), p(.64f, .44f), sw)
            }
            PrayerGlyph.Night -> {
                val crescent = Path().apply {
                    addArc(androidx.compose.ui.geometry.Rect(Offset(w * .28f, h * .22f), Size(w * .46f, w * .46f)), -60f, 300f)
                }
                drawPath(crescent, tint, style = stroke)
            }
        }
    }
}
