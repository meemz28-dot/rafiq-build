package com.shirazi.duaa.data

// أبواب أصول الكافي (ج٢) — مولَّدٌ من tools/hadith/import_kafi.py

internal val cat_kafidua: Category = Category("kafi-dua", "📜", """الكافي: كتاب الدعاء""", """فضل الدعاء وآدابه وأوقاته وما ورد فيه من أصول الكافي""", kafi4Kafidua)
internal val cat_kafiquran: Category = Category("kafi-quran", "📜", """الكافي: فضل القرآن""", """فضل القرآن وحَمَلته وتلاوته من أصول الكافي""", kafi4Kafiquran + kafi5Kafiquran)
internal val cat_kafiishra: Category = Category("kafi-ishra", "📜", """الكافي: العِشرة""", """آداب المعاشرة والصحبة والجوار من أصول الكافي""", kafi5Kafiishra)
internal val kafiIman: List<DuaaItem> = kafi1Ahadith + kafi2Ahadith + kafi3Ahadith + kafi4Ahadith
