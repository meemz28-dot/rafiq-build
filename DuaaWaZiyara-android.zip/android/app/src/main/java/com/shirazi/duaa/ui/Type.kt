package com.shirazi.duaa.ui

import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.R

/* =====================================================================
 * مقياس الطباعة (Type Scale) — مصدرٌ واحد لكلّ أحجام النصّ وأوزانه.
 *
 * الهوية الطباعية:
 *   • الواجهة: خطّ Cairo (عربيّ حديث أنيق) بكامل أوزانه.
 *   • النصّ المقدّس (قرآن/أدعية): خطّ Amiri (نسخ كلاسيكيّ جميل).
 * الأوزان مربوطة تلقائياً، فيختار النظام الوزن الصحيح عند FontWeight.Bold إلخ.
 * ===================================================================== */

object AppFonts {
    // خطّ الواجهة: Cairo بكامل أوزانه — يُختار الوزن تلقائياً حسب FontWeight
    val ui: FontFamily = FontFamily(
        Font(R.font.cairo_regular, FontWeight.Normal),
        Font(R.font.cairo_medium, FontWeight.Medium),
        Font(R.font.cairo_semibold, FontWeight.SemiBold),
        Font(R.font.cairo_bold, FontWeight.Bold),
        Font(R.font.cairo_extrabold, FontWeight.ExtraBold)
    )
    // خطّ النصّ المقدّس: Amiri (نسخ) — للقرآن والأدعية
    val scripture: FontFamily = FontFamily(
        Font(R.font.amiri_regular, FontWeight.Normal),
        Font(R.font.amiri_bold, FontWeight.Bold)
    )
}

/* مقياس المسافات والانحناءات — قيمٌ موحّدة تُستعمل عبر التطبيق.
 * هامش الشاشة الموحّد = 16dp. انحناء البطاقات = 18dp، الحبوب = 99dp. */
object AppSpace {
    val screenMargin = 16   // dp — هامش جانبيّ موحّد لكلّ الشاشات
    val cardRadius = 18     // dp — انحناء البطاقات الكبيرة
    val tileRadius = 14     // dp — انحناء العناصر الصغيرة (صفوف/رقاقات داخلية)
    val pill = 99           // dp — الحبوب والأزرار الدائرية
    val gap = 12            // dp — فجوة قياسية بين العناصر
    val gapLg = 18          // dp — فجوة بين الأقسام
}

object AppType {
    // عناوين كبيرة (هوية، أسماء السور في القارئ)
    val display = TextStyle(fontFamily = AppFonts.ui, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, lineHeight = 34.sp)
    val title = TextStyle(fontFamily = AppFonts.ui, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, lineHeight = 28.sp)
    val heading = TextStyle(fontFamily = AppFonts.ui, fontWeight = FontWeight.Bold, fontSize = 17.sp, lineHeight = 24.sp)

    // نصوص الواجهة
    val bodyLarge = TextStyle(fontFamily = AppFonts.ui, fontWeight = FontWeight.Medium, fontSize = 15.sp, lineHeight = 24.sp)
    val body = TextStyle(fontFamily = AppFonts.ui, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 22.sp)
    val label = TextStyle(fontFamily = AppFonts.ui, fontWeight = FontWeight.Bold, fontSize = 13.sp, lineHeight = 18.sp)
    val caption = TextStyle(fontFamily = AppFonts.ui, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 17.sp)
    val tiny = TextStyle(fontFamily = AppFonts.ui, fontWeight = FontWeight.Bold, fontSize = 10.sp, lineHeight = 14.sp)

    // النصّ المقدّس في القارئ (يُضرب حجمه في تفضيل المستخدم)
    val scripture = TextStyle(fontFamily = AppFonts.scripture, fontWeight = FontWeight.Normal, textAlign = TextAlign.Start)
}
