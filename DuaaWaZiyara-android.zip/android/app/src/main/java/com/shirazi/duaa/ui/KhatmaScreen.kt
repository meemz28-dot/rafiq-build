package com.shirazi.duaa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Data
import com.shirazi.duaa.data.Settings
import java.util.Calendar
import kotlin.math.roundToInt

/**
 * الختمة: خطّة لختم القرآن الكريم بالتزامٍ يوميّ.
 * تقسّم السور على أيّام الخطّة بالتساوي تقريباً بحسب الطول، وتتابع المنجَز يوماً بيوم.
 */
@Composable
fun KhatmaScreen(settings: Settings, pal: DuaaPalette, openReader: (String, String) -> Unit, onClose: () -> Unit) {
    val suras = remember { Data.categories.firstOrNull { it.id == "quran" }?.items ?: emptyList() }
    val plan = settings.khatmaPlan.value
    val days = plan.toIntOrNull() ?: 0

    // اليوم الميلادي المطلق — لحساب اليوم الحاليّ من الخطّة
    val todayEpoch = remember {
        val c = Calendar.getInstance()
        (c.timeInMillis / 86_400_000L).toInt()
    }

    // توزيع السور على الأيّام بحسب الحجم لا بحسب العدد، فتتقارب الأحمال اليوميّة
    val schedule: List<List<Int>> = remember(plan, suras.size) {
        if (days <= 0 || suras.isEmpty()) emptyList()
        else {
            val weights = suras.map { it.text.length.coerceAtLeast(1) }
            val total = weights.sum().toLong()
            val target = total / days
            val out = ArrayList<MutableList<Int>>()
            var cur = ArrayList<Int>()
            var acc = 0L
            for (i in suras.indices) {
                cur.add(i)
                acc += weights[i]
                if (acc >= target && out.size < days - 1) {
                    out.add(cur); cur = ArrayList(); acc = 0
                }
            }
            if (cur.isNotEmpty()) out.add(cur)
            while (out.size < days) out.add(ArrayList())
            out
        }
    }

    val doneCount = settings.khatmaDone.size
    val pct = if (suras.isNotEmpty()) (doneCount * 100f / suras.size).roundToInt() else 0
    val dayIndex = if (days > 0) ((todayEpoch - settings.khatmaStart.value).coerceAtLeast(0)).coerceAtMost(days - 1) else 0

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                ScreenTopBar("الختمة", pal, onClose)
                Column(Modifier.padding(18.dp)) {

                    if (plan.isEmpty()) {
                        // ===== لا خطّة بعد: اختيار الخطّة =====
                        Column(
                            Modifier.fillMaxWidth().padding(bottom = 18.dp).clip(RoundedCornerShape(20.dp))
                                .background(pal.heroBrush).padding(vertical = 26.dp, horizontal = 20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("ابدأ ختمةً جديدة", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "اختر مدّة الختمة، ويقسّم التطبيق السور على أيّامها بأحمالٍ متقاربة، ويتابع معك ما أنجزت يوماً بيوم.",
                                color = Color.White.copy(alpha = .88f), fontSize = 13.sp,
                                textAlign = TextAlign.Center, lineHeight = 21.sp
                            )
                        }

                        listOf(
                            Triple("30", "ختمة الشهر", "جزءٌ كلّ يوم تقريباً — خطّة رمضان المعتادة"),
                            Triple("40", "ختمة الأربعين", "وِردٌ يوميّ أخفّ مع مداومة أربعين يوماً"),
                            Triple("90", "ختمة الفصل", "صفحاتٌ يسيرة كلّ يوم، الأنسب لمن يبدأ")
                        ).forEach { (key, title, sub) ->
                            Row(
                                Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(18.dp))
                                    .background(MaterialTheme.colorScheme.surface)
                                    .clickable { settings.startKhatma(key, todayEpoch) }
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(pal.emerald.copy(alpha = .14f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(key, color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                }
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(sub, color = pal.ink2, fontSize = 12.sp, lineHeight = 18.sp)
                                }
                                LineIcon(AppIcon.ChevronStart, pal.ink2, 18.dp)
                            }
                        }
                    } else {
                        // ===== خطّة جارية: لوحة التقدّم =====
                        Column(
                            Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(RoundedCornerShape(20.dp))
                                .background(pal.heroBrush).padding(vertical = 22.dp, horizontal = 20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("$pct%", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 40.sp)
                            Text("$doneCount من ${suras.size} سورة", color = Color.White.copy(alpha = .9f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(14.dp))
                            Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(Color.White.copy(alpha = .22f))) {
                                Box(Modifier.fillMaxWidth(pct / 100f).fillMaxHeight().clip(CircleShape).background(Color.White))
                            }
                            Spacer(Modifier.height(12.dp))
                            Text("اليوم ${dayIndex + 1} من $days", color = Color.White.copy(alpha = .88f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        // ===== وِرد اليوم =====
                        Text("وِرد اليوم", fontWeight = FontWeight.ExtraBold, color = pal.emerald, fontSize = 15.sp,
                            modifier = Modifier.padding(bottom = 10.dp))

                        val todays = schedule.getOrNull(dayIndex) ?: emptyList()
                        if (todays.isEmpty()) {
                            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp)) {
                                Text("لا سور مقرّرة لهذا اليوم — اغتنمه لمراجعة ما مضى.", color = pal.ink2, fontSize = 13.sp)
                            }
                        } else {
                            todays.forEach { si ->
                                val s = suras[si]
                                val done = settings.isKhatmaDone(s.id)
                                Row(
                                    Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp))
                                        .background(if (done) pal.good.copy(alpha = .10f) else MaterialTheme.colorScheme.surface)
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier.size(28.dp).clip(CircleShape)
                                            .background(if (done) pal.good else pal.line.copy(alpha = .5f))
                                            .clickable { settings.toggleKhatma(s.id) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (done) LineIcon(AppIcon.StarFill, Color.White, 14.dp, label = "منجَز")
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Text(
                                        s.title, modifier = Modifier.weight(1f).clickable { openReader("quran", s.id) },
                                        fontWeight = FontWeight.Bold, fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                    LineIcon(AppIcon.ChevronStart, pal.ink2, 16.dp)
                                }
                            }
                        }

                        // ===== خريطة الأيّام =====
                        Spacer(Modifier.height(10.dp))
                        Text("خريطة الخطّة", fontWeight = FontWeight.ExtraBold, color = pal.emerald, fontSize = 15.sp,
                            modifier = Modifier.padding(bottom = 10.dp))
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp)) {
                            Column {
                                var d = 0
                                while (d < schedule.size) {
                                    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                                        for (k in 0 until 10) {
                                            val idx = d + k
                                            if (idx < schedule.size) {
                                                val dayDone = schedule[idx].isNotEmpty() && schedule[idx].all { settings.isKhatmaDone(suras[it].id) }
                                                Box(
                                                    Modifier.weight(1f).padding(2.dp).height(24.dp).clip(RoundedCornerShape(6.dp))
                                                        .background(
                                                            when {
                                                                dayDone -> pal.good
                                                                idx == dayIndex -> pal.emerald.copy(alpha = .55f)
                                                                else -> pal.line.copy(alpha = .35f)
                                                            }
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text("${idx + 1}", fontSize = 9.sp,
                                                        color = if (dayDone || idx == dayIndex) Color.White else pal.ink2,
                                                        fontWeight = FontWeight.Bold)
                                                }
                                            } else {
                                                Box(Modifier.weight(1f).padding(2.dp))
                                            }
                                        }
                                    }
                                    d += 10
                                }
                            }
                        }

                        Spacer(Modifier.height(16.dp))
                        BigButton("إنهاء الختمة وبدء غيرها", pal, false) { settings.endKhatma() }
                    }

                    Spacer(Modifier.height(28.dp))
                }
            }
        }
    }
}
