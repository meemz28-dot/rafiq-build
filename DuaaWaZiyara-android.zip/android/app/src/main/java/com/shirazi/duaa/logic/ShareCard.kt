package com.shirazi.duaa.logic

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import com.shirazi.duaa.R
import java.io.File
import java.io.FileOutputStream

/**
 * يولّد بطاقة صورة مصمّمة لنصّ (دعاء/آية/حكمة) ويشاركها عبر تطبيقات المراسلة.
 * الرسم يتمّ بـ Android Canvas مباشرةً (مستقلّ عن Compose) لضمان موثوقية المشاركة.
 */
object ShareCard {

    private const val W = 1080
    private const val STORE_URL = "https://play.google.com/store/apps/details?id=com.shirazi.duaa"

    fun shareText(context: Context, title: String, body: String, source: String?) {
        try {
            val bmp = render(context, title, body, source)
            val dir = File(context.cacheDir, "shared").apply { mkdirs() }
            val file = File(dir, "dua_card.png")
            FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "$title\n\n— تطبيق رفيق المؤمن\n$STORE_URL")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            // احتياطياً: مشاركة نصّية إن تعذّرت الصورة
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "$title\n\n$body\n\n— تطبيق رفيق المؤمن")
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /** مقتطفٌ عند حدّ عبارة (نقطة، فاصلة، فاصلة منقوطة، سطر) — لا يُقطع النصّ في وسط كلمة أو عبارة. */
    private fun excerpt(text: String, limit: Int = 700): Pair<String, Boolean> {
        if (text.length <= limit) return text to false
        var cut = listOf('.', '،', '؛', '\n').maxOf { text.lastIndexOf(it, limit) }
        if (cut < limit / 2) cut = text.lastIndexOf(' ', limit)
        if (cut <= 0) cut = limit
        return (text.substring(0, cut + 1).trimEnd(' ', '،', '\n') + " …") to true
    }

    private fun font(context: Context, id: Int, fallback: Typeface): Typeface =
        try { ResourcesCompat.getFont(context, id) ?: fallback } catch (e: Exception) { fallback }

    private fun layout(text: String, paint: TextPaint, width: Int, spacingAdd: Float): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(spacingAdd, 1f)
            .setIncludePad(false)
            .build()

    /** نجمة ثمانية = مربّعان متراكبان بزاوية ٤٥°، كزخرفة التطبيق. */
    private fun star(cx: Float, cy: Float, r: Float): Path = Path().apply {
        for (rot in intArrayOf(0, 45)) {
            for (k in 0 until 4) {
                val a = Math.toRadians((rot + 45 + 90 * k).toDouble())
                val x = cx + r * Math.cos(a).toFloat(); val y = cy + r * Math.sin(a).toFloat()
                if (k == 0) moveTo(x, y) else lineTo(x, y)
            }
            close()
        }
    }

    private fun render(context: Context, title: String, bodyFull: String, source: String?): Bitmap {
        val pad = 72; val panelPad = 56
        val gold = Color.rgb(198, 160, 84); val cream = Color.rgb(251, 246, 233); val ink = Color.rgb(43, 35, 23)
        val (body, excerpted) = excerpt(bodyFull)

        val cairoX = font(context, R.font.cairo_extrabold, Typeface.DEFAULT_BOLD)
        val cairoB = font(context, R.font.cairo_bold, Typeface.DEFAULT_BOLD)
        val cairoS = font(context, R.font.cairo_semibold, Typeface.DEFAULT)
        val cairoM = font(context, R.font.cairo_medium, Typeface.DEFAULT)
        val amiri = font(context, R.font.amiri_regular, Typeface.SERIF)

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 56f; typeface = cairoX }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = ink; textSize = 46f; typeface = amiri }
        val srcPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(225, 251, 246, 233); textSize = 30f; typeface = cairoS }
        val brandPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(240, 255, 255, 255); textSize = 34f; typeface = cairoB; textAlign = Paint.Align.CENTER }
        val tagPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(175, 255, 255, 255); textSize = 24f; typeface = cairoM; textAlign = Paint.Align.CENTER }

        val titleL = layout(title, titlePaint, W - pad * 2, 14f)
        val bodyL = layout(body, bodyPaint, W - pad * 2 - panelPad * 2, 26f)
        val srcText = listOfNotNull(source, if (excerpted) "مقتطف" else null).joinToString("  ·  ")
        val srcL = if (srcText.isNotEmpty()) layout(srcText, srcPaint, W - pad * 2, 8f) else null

        val top = 150
        val panelH = bodyL.height + panelPad * 2
        val height = (top + titleL.height + 56 + panelH + 36 + (srcL?.height ?: 0) + 210).coerceAtLeast(1080)

        val bmp = Bitmap.createBitmap(W, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        // ١) خلفيّة: تدرّج تركوازيّ قطريّ بألوان التطبيق
        c.drawRect(0f, 0f, W.toFloat(), height.toFloat(), Paint().apply {
            shader = LinearGradient(0f, 0f, W.toFloat(), height.toFloat(), Color.rgb(74, 168, 181), Color.rgb(27, 84, 100), Shader.TileMode.CLAMP)
        })
        // ٢) شبكة الزخرفة: نجوم ثمانية تخفت كلّما ابتعدت عن مصدر الضوء أعلى اليسار
        val cell = 150f
        val maxD = Math.hypot(W.toDouble(), height.toDouble()).toFloat()
        val lattice = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f }
        var gy = -1
        while (gy * cell < height + cell) {
            var gx = -1
            while (gx * cell < W + cell) {
                val cx = gx * cell + (if (gy % 2 != 0) cell / 2 else 0f); val cy = gy * cell
                val fade = 1f - 0.8f * (Math.hypot(cx.toDouble(), cy.toDouble()).toFloat() / maxD)
                lattice.color = Color.argb((34 * fade).toInt().coerceIn(0, 255), 255, 255, 255)
                c.drawPath(star(cx, cy, cell * 0.36f), lattice)
                gx++
            }
            gy++
        }
        // ٣) لمعة ضوئيّة ناعمة
        c.drawRect(0f, 0f, W.toFloat(), height.toFloat(), Paint().apply {
            shader = RadialGradient(200f, 60f, 620f, Color.argb(56, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        })
        // ٤) إطار ذهبيّ ووسام علويّ
        c.drawRoundRect(26f, 26f, W - 26f, height - 26f, 44f, 44f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.argb(170, 198, 160, 84) })
        c.drawPath(star(W / 2f, 84f, 24f), Paint(Paint.ANTI_ALIAS_FLAG).apply { color = gold })
        c.drawCircle(W / 2f, 84f, 7f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(27, 84, 100) })

        // ٥) العنوان (يلتفّ على أكثر من سطر)
        var y = top.toFloat()
        c.save(); c.translate(pad.toFloat(), y); titleL.draw(c); c.restore()
        y += titleL.height + 56

        // ٦) لوح المخطوطة: خلفيّة كريميّة وإطار ذهبيّ، والمتن بخطّ أميري
        c.drawRoundRect(pad.toFloat(), y, (W - pad).toFloat(), y + panelH, 36f, 36f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = cream })
        c.drawRoundRect(pad.toFloat(), y, (W - pad).toFloat(), y + panelH, 36f, 36f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.argb(200, 198, 160, 84) })
        c.save(); c.translate((pad + panelPad).toFloat(), y + panelPad); bodyL.draw(c); c.restore()
        y += panelH + 36

        // ٧) المصدر (ومقتطف إن اختُصر النصّ)
        srcL?.let { c.save(); c.translate(pad.toFloat(), y); it.draw(c); c.restore() }

        // ٨) التوقيع
        c.drawLine(W / 2f - 60, height - 150f, W / 2f + 60, height - 150f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 198, 160, 84); strokeWidth = 2f })
        c.drawText("رفيق المؤمن", W / 2f, height - 100f, brandPaint)
        c.drawText("أدعية وزيارات موثّقة · بلا إعلانات", W / 2f, height - 62f, tagPaint)
        return bmp
    }
}
