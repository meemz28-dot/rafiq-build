package com.shirazi.duaa.logic

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

/**
 * يولّد بطاقة صورة مصمّمة لنصّ (دعاء/آية/حكمة) ويشاركها عبر تطبيقات المراسلة.
 * الرسم يتمّ بـ Android Canvas مباشرةً (مستقلّ عن Compose) لضمان موثوقية المشاركة.
 */
object ShareCard {

    private const val W = 1080

    fun shareText(context: Context, title: String, body: String, source: String?) {
        try {
            val bmp = render(title, body, source)
            val dir = File(context.cacheDir, "shared").apply { mkdirs() }
            val file = File(dir, "dua_card.png")
            FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "$title\n\n— تطبيق رفيق المؤمن")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            // احتياطياً: مشاركة نصّية إن تعذّرت الصورة
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "$title\n\n$body\n\n— تطبيق رفيق المؤمن")
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun render(title: String, bodyFull: String, source: String?): Bitmap {
        val pad = 80
        val contentW = W - pad * 2

        // حدّ النصّ المعروض على البطاقة (النصوص الطويلة تُقتطع بلطف)
        val body = if (bodyFull.length > 600) bodyFull.take(580).trimEnd() + " …" else bodyFull

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 52f; typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 44f; typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        }
        val srcPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(210, 240, 230, 207); textSize = 34f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD); textAlign = Paint.Align.CENTER
        }
        val brandPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(190, 255, 255, 255); textSize = 32f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD); textAlign = Paint.Align.CENTER
        }

        val bodyLayout = StaticLayout.Builder
            .obtain(body, 0, body.length, bodyPaint, contentW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(20f, 1.2f)
            .build()

        val titleH = 80
        val srcH = if (source != null) 70 else 0
        val brandH = 120
        val gap = 50
        val height = (pad * 2 + titleH + gap + bodyLayout.height + gap + srcH + brandH).coerceAtLeast(900)

        val bmp = Bitmap.createBitmap(W, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        // خلفية متدرّجة (أخضر المخطوطة → ذهبي خافت)
        val bg = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, height.toFloat(),
                Color.rgb(11, 93, 78), Color.rgb(8, 60, 50), Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, W.toFloat(), height.toFloat(), bg)

        // إطار ذهبي رفيع
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.argb(150, 176, 132, 51)
        }
        canvas.drawRoundRect(28f, 28f, W - 28f, height - 28f, 36f, 36f, border)

        var y = pad + 60f
        // العنوان
        canvas.drawText(title, W / 2f, y, titlePaint)
        y += gap + 20

        // خطّ فاصل ذهبي
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(120, 176, 132, 51); strokeWidth = 3f }
        canvas.drawLine(W / 2f - 80, y, W / 2f + 80, y, line)
        y += gap

        // المتن
        canvas.save()
        canvas.translate(pad.toFloat(), y)
        bodyLayout.draw(canvas)
        canvas.restore()
        y += bodyLayout.height + gap

        // المصدر
        if (source != null) { canvas.drawText(source, W / 2f, y, srcPaint); y += srcH }

        // اسم التطبيق
        canvas.drawText("رفيق المؤمن", W / 2f, height - 70f, brandPaint)

        return bmp
    }
}
