package com.shirazi.duaa.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Settings
import com.shirazi.duaa.data.Trait
import com.shirazi.duaa.data.traits

/**
 * صفة الشهر — رحلة تهذيب صفةٍ واحدة على منهج جامع السعادات:
 * اختيار الرذيلة، ثم العمل بضدّها يوماً بيوم (٣٠ أو ٤٠ يوماً) حتى التخرّج.
 */
@Composable
fun TraitJourneyScreen(
    settings: Settings,
    pal: DuaaPalette,
    onClose: () -> Unit,
    openScreen: (String) -> Unit,
    openReader: (String, String) -> Unit
) {
    BackHandler { onClose() }
    val haptics = rememberHaptics()
    var selected by remember { mutableStateOf<Trait?>(null) }
    var chosenDays by remember { mutableStateOf(30) }
    var refresh by remember { mutableStateOf(0) }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            ScreenTopBar("صفة الشهر", pal, onClose)
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
            key(refresh) {
            Text("تهذيب النفس على منهج جامع السعادات — تخليةٌ وتحلية",
                color = pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))

            val active = settings.traitActive.value
            val trait = traits.firstOrNull { it.id == settings.traitId.value }

            if (active && trait != null) {
                // ===== رحلة قائمة =====
                val day = settings.traitDayNumber()
                val target = settings.traitTarget.value
                val done = settings.traitDoneCount()
                val graduated = done >= target
                Column(
                    Modifier.fillMaxWidth()
                        .heroCard(if (graduated) pal.gold else pal.emerald)
                        .background(Brush.linearGradient(
                            if (graduated) listOf(Color(0xFF6D5518), Color(0xFF3E3110))
                            else listOf(Color(0xFF1F5A4E), Color(0xFF123C34))))
                        .padding(18.dp)
                ) {
                    Text(if (graduated) "أتممتَ الرحلة — هنيئاً" else "رحلتك الجارية",
                        color = pal.gold, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(4.dp))
                    Text("تخلية «${trait.vice}» وتحلية «${trait.virtue}»",
                        color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold,
                        maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(8.dp))
                    // شريط التقدّم: أيام الالتزام المُتمّة من الهدف
                    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(99.dp))
                        .background(Color.White.copy(alpha = .18f))) {
                        Box(Modifier.fillMaxWidth((done.toFloat() / target).coerceIn(0f, 1f))
                            .height(8.dp).clip(RoundedCornerShape(99.dp)).background(pal.gold))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("أتممتَ $done من $target يوماً — اليوم رقم $day",
                        color = Color.White.copy(alpha = .85f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))

                if (graduated) {
                    Column(Modifier.fillMaxWidth().paper(pal, 20).padding(16.dp)) {
                        Text("قال النراقي: الخُلق يُكتسب بتكرار الفعل حتى يصير مَلَكة. ثبّتك الله على ما بلغت.",
                            color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, lineHeight = 24.sp)
                        Spacer(Modifier.height(10.dp))
                        BigButton("اختم الرحلة وسجّلها", pal, true) {
                            settings.completeTrait(); haptics.confirm(); refresh++
                        }
                    }
                } else {
                    // ===== عمل اليوم =====
                    SectionTitle("عمل اليوم بالضدّ")
                    Column(Modifier.fillMaxWidth().paper(pal, 20).padding(16.dp)) {
                        Text(trait.commitment, color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp, fontWeight = FontWeight.Bold, lineHeight = 26.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(trait.hint, color = pal.ink2, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        val doneToday = settings.traitDoneToday()
                        if (doneToday) {
                            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                .background(pal.emerald.copy(alpha = .12f)).padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center) {
                                Text("أتممتَ عمل اليوم ✓", color = pal.emerald,
                                    fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        } else {
                            BigButton("أتممتُ عمل اليوم", pal, true) {
                                settings.traitTickToday(); haptics.confirm(); refresh++
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.weight(1f)) { BigButton("عيادة الصفة", pal, false) { openReader("akhlaq", trait.clinicId) } }
                        Box(Modifier.weight(1f)) { BigButton("محاسبة النفس", pal, false) { openScreen("muhasaba") } }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("إنهاء الرحلة دون إتمام", color = pal.ink2, fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().pressable { settings.abandonTrait(); refresh++ }.padding(12.dp))
                }
            } else {
                // ===== اختيار صفة =====
                Column(Modifier.fillMaxWidth().paper(pal, 20).padding(16.dp)) {
                    Text("طريق التهذيب خطوتان: تخليةٌ من الرذيلة بالعمل بضدّها، ثم تحليةٌ بالفضيلة حتى تصير مَلَكة. اختر صفةً واحدة، والتزم عملها اليوميّ الصغير ٣٠ أو ٤٠ يوماً.",
                        color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, lineHeight = 23.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("اقرأ المنهج كاملاً", color = pal.emerald, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.pressable { openReader("akhlaq", "ak-naraqi-manhaj") }.padding(10.dp))
                }
                Spacer(Modifier.height(6.dp))
                SectionTitle("اختر صفةً تعالجها")
                traits.forEach { t ->
                    val sel = selected?.id == t.id
                    Column(
                        Modifier.fillMaxWidth().padding(bottom = 8.dp).paper(pal, 18)
                            .pressable { selected = if (sel) null else t }
                            .padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(t.vice, color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 15.sp, fontWeight = FontWeight.ExtraBold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            Text("ضدّها: ${t.virtue}", color = pal.gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                        if (sel) {
                            Spacer(Modifier.height(6.dp))
                            Text(t.commitment, color = pal.ink2, fontSize = 12.sp, lineHeight = 21.sp)
                        }
                    }
                }
                selected?.let { t ->
                    Spacer(Modifier.height(6.dp))
                    SectionTitle("مدّة الرحلة")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.weight(1f)) { BigButton("٣٠ يوماً", pal, chosenDays == 30) { chosenDays = 30 } }
                        Box(Modifier.weight(1f)) { BigButton("٤٠ يوماً", pal, chosenDays == 40) { chosenDays = 40 } }
                    }
                    Spacer(Modifier.height(10.dp))
                    BigButton("ابدأ رحلة «${t.vice}»", pal, true) {
                        settings.startTrait(t.id, chosenDays); haptics.confirm(); refresh++
                    }
                }
            }

            // ===== رحلات مُتمّة =====
            val hist = settings.traitHistory()
            if (hist.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                SectionTitle("رحلات أتممتها")
                Column(Modifier.fillMaxWidth().paper(pal, 18).padding(12.dp)) {
                    hist.forEach { h ->
                        val parts = h.split("|")
                        val tName = traits.firstOrNull { it.id == parts.getOrNull(0) }?.vice ?: parts.getOrNull(0) ?: ""
                        Text("✓ $tName — ${parts.getOrNull(1) ?: "?"} يوماً",
                            color = pal.emerald, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 3.dp))
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            }
            }
        }
    }
}
