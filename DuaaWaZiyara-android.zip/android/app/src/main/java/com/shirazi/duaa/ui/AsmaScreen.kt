package com.shirazi.duaa.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.AsmaData
import com.shirazi.duaa.data.Settings

/** أسماء الله الحُسنى — اسمُ اليوم + معرضٌ كامل بخطّ النسخ. */
@Composable
fun AsmaScreen(settings: Settings, pal: DuaaPalette, onClose: () -> Unit) {
    val haptics = rememberHaptics()
    val todayName = remember { AsmaData.ofDay(settings.dayOfYearIndex()) }
    var selected by remember { mutableStateOf<Int?>(null) }

    // ألوانٌ جوهريّة تتدرّج عبر المعرض لإضفاء حياة
    val gemGrads = remember {
        listOf(
            categoryGradient("ziyarat"), categoryGradient("munajat"), categoryGradient("ramadan"),
            categoryGradient("jumaa"), categoryGradient("tarbiya"), categoryGradient("hawaij"),
            categoryGradient("rajab"), categoryGradient("sabah")
        )
    }

    Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
        Column(Modifier.fillMaxSize()) {
            ScreenTopBar("أسماء الله الحُسنى", pal, onClose)

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // بطاقة «اسم اليوم» تمتدّ عبر الصفّ
                item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(3) }) {
                    DailyNameHero(todayName, pal) {
                        haptics.tick()
                        selected = AsmaData.names.indexOf(todayName)
                    }
                }
                item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(3) }) {
                    Text(
                        "الأسماءُ التسعةُ والتسعون",
                        color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                    )
                }
                // المعرض الكامل
                items(AsmaData.names.size) { i ->
                    val name = AsmaData.names[i]
                    NameTile(i + 1, name.ar, gemGrads[i % gemGrads.size], pal) {
                        haptics.tick(); selected = i
                    }
                }
            }
        }

        // تفاصيل الاسم — يظهر بأناقة عند النقر
        AnimatedVisibility(
            visible = selected != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            val idx = selected
            if (idx != null) {
                NameDetailOverlay(
                    number = idx + 1,
                    name = AsmaData.names[idx],
                    pal = pal,
                    onDismiss = { selected = null }
                )
            }
        }
    }
}

@Composable
private fun DailyNameHero(name: AsmaData.Name, pal: DuaaPalette, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth()
            .heroCard(pal.emerald)
            .background(pal.heroBrush)
            .clickable(onClick = onClick)
    ) {
        IslamicPattern(Color.White.copy(alpha = .08f), Modifier.matchParentSize(), cell = 52f)
        Column(
            Modifier.fillMaxWidth().padding(vertical = 30.dp, horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("اسمُ اليوم", color = Color.White.copy(alpha = .82f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            Text(
                name.ar,
                color = Color.White,
                fontFamily = AppFonts.scripture,
                fontWeight = FontWeight.Bold,
                fontSize = 52.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(14.dp))
            Text(
                name.sharh,
                color = Color.White.copy(alpha = .9f),
                fontSize = 14.sp,
                lineHeight = 22.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(10.dp))
            Text("انقر للتأمّل ⟡", color = Color.White.copy(alpha = .6f), fontSize = 11.sp)
        }
    }
}

@Composable
private fun NameTile(num: Int, ar: String, grad: List<Color>, pal: DuaaPalette, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(104.dp)
            .gradientCard(18, 3)
            .background(Brush.linearGradient(grad))
            .clickable(onClick = onClick)
    ) {
        IslamicPattern(Color.White.copy(alpha = .06f), Modifier.matchParentSize(), cell = 40f)
        // رقم الاسم
        Text(
            "$num",
            color = Color.White.copy(alpha = .55f),
            fontSize = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
        )
        // الاسم بخطّ النسخ
        Text(
            ar,
            color = Color.White,
            fontFamily = AppFonts.scripture,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.align(Alignment.Center).padding(horizontal = 6.dp)
        )
    }
}

@Composable
private fun NameDetailOverlay(number: Int, name: AsmaData.Name, pal: DuaaPalette, onDismiss: () -> Unit) {
    // طبقةٌ معتمة تُغلِق عند النقر
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f))
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = onDismiss
            ),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(visible = true, enter = scaleIn(initialScale = .9f) + fadeIn(), exit = scaleOut() + fadeOut()) {
            Column(
                Modifier.fillMaxWidth().padding(28.dp)
                    .heroCard(pal.emerald, elevation = 20)
                    .background(pal.heroBrush)
                    // امتصاص النقر حتى لا يُغلِق عند لمس البطاقة
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    ) {}
                    .padding(vertical = 40.dp, horizontal = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = .18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("$number", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
                Spacer(Modifier.height(22.dp))
                Text(
                    name.ar,
                    color = Color.White,
                    fontFamily = AppFonts.scripture,
                    fontWeight = FontWeight.Bold,
                    fontSize = 64.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(24.dp))
                Box(Modifier.fillMaxWidth(.4f).height(1.dp).background(Color.White.copy(alpha = .25f)))
                Spacer(Modifier.height(24.dp))
                Text(
                    name.sharh,
                    color = Color.White.copy(alpha = .92f),
                    fontSize = 16.sp,
                    lineHeight = 28.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(28.dp))
                Box(
                    Modifier.clip(RoundedCornerShape(99.dp)).background(Color.White.copy(alpha = .16f))
                        .clickable(onClick = onDismiss).padding(horizontal = 28.dp, vertical = 12.dp)
                ) {
                    Text("إغلاق", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}
