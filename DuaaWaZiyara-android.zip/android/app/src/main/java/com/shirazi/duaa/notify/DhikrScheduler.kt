package com.shirazi.duaa.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.shirazi.duaa.data.Settings
import java.util.Calendar
import kotlin.random.Random

/**
 * جدولة تذكيرات الأذكار العشوائية (صلوات / استغفار / تهليل ...) على مدار اليوم.
 * توزّع عدداً من التذكيرات في ساعات اليقظة (٨ صباحاً – ١٠ مساءً) بأوقات عشوائية،
 * وكلّ تذكير يحمل ذِكراً مختاراً عشوائياً.
 */
object DhikrScheduler {

    const val START_HOUR = 8
    const val END_HOUR = 22
    private const val BASE_REQ = 500   // معرّفات مستقلة عن منبّهات الصلاة

    /** الأذكار المعروضة في التذكير: (عنوان، نصّ). */
    val ADHKAR = listOf(
        "صلِّ على محمد وآل محمد" to "اللّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَآلِ مُحَمَّدٍ",
        "استغفر الله" to "أَسْتَغْفِرُ اللهَ رَبِّي وَأَتُوبُ إِلَيْهِ",
        "سبحان الله" to "سُبْحَانَ اللهِ وَبِحَمْدِهِ، سُبْحَانَ اللهِ الْعَظِيمِ",
        "لا إله إلا الله" to "لاَ إِلٰهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ",
        "الحمد لله" to "الْحَمْدُ لِلّٰهِ رَبِّ الْعَالَمِينَ",
        "ذِكر الله" to "وَاذْكُرْ رَبَّكَ كَثِيراً وَسَبِّحْ بِالْعَشِيِّ وَالْإِبْكَارِ",
        "اللهم عجّل لوليّك الفرج" to "اللّهُمَّ عَجِّلْ لِوَلِيِّكَ الْفَرَجَ وَالْعَافِيَةَ وَالنَّصْرَ",
        "حسبنا الله" to "حَسْبُنَا اللهُ وَنِعْمَ الْوَكِيلُ",
        "لا حول ولا قوة إلا بالله" to "لاَ حَوْلَ وَلاَ قُوَّةَ إِلاَّ بِاللهِ الْعَلِيِّ الْعَظِيمِ",
        "اللهم صلِّ على فاطمة" to "اللّهُمَّ صَلِّ عَلَى فَاطِمَةَ وَأَبِيهَا وَبَعْلِهَا وَبَنِيهَا"
    )

    fun reschedule(context: Context) {
        val settings = Settings(context)
        cancelAll(context)
        if (!settings.dhikrEnabled.value) return

        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val count = settings.dhikrCount.value.coerceIn(1, 12)
        val now = Calendar.getInstance()

        // قسّم نافذة اليقظة إلى شرائح متساوية ثمّ ضع تذكيراً عشوائياً داخل كلّ شريحة
        // (يمنع التزاحم ويضمن توزّعاً طبيعياً على اليوم).
        val windowMin = (END_HOUR - START_HOUR) * 60
        val slot = windowMin / count

        var scheduled = 0
        for (i in 0 until count) {
            val slotStart = START_HOUR * 60 + i * slot
            val offsetInSlot = if (slot > 1) Random.nextInt(slot) else 0
            val totalMin = slotStart + offsetInSlot
            val h = totalMin / 60
            val m = totalMin % 60

            val fire = (now.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, h.coerceIn(0, 23))
                set(Calendar.MINUTE, m.coerceIn(0, 59))
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            // ما فات اليوم يُجدول لنفس الوقت غداً
            if (fire.timeInMillis <= now.timeInMillis) fire.add(Calendar.DAY_OF_YEAR, 1)

            val dhikrIdx = Random.nextInt(ADHKAR.size)
            val pi = pendingIntent(context, BASE_REQ + i, dhikrIdx)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                    am.setWindow(AlarmManager.RTC_WAKEUP, fire.timeInMillis, 300_000L, pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fire.timeInMillis, pi)
                }
            } catch (e: SecurityException) {
                am.set(AlarmManager.RTC_WAKEUP, fire.timeInMillis, pi)
            }
            scheduled++
        }
    }

    fun cancelAll(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0 until 12) am.cancel(pendingIntent(context, BASE_REQ + i, 0))
    }

    private fun pendingIntent(context: Context, reqId: Int, dhikrIdx: Int): PendingIntent {
        val intent = Intent(context, DhikrReceiver::class.java).apply {
            action = "com.shirazi.duaa.DHIKR_$reqId"
            putExtra("dhikrIdx", dhikrIdx)
        }
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags = flags or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, reqId, intent, flags)
    }
}
