package com.shirazi.duaa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import com.shirazi.duaa.data.Data
import com.shirazi.duaa.data.Settings
import com.shirazi.duaa.data.Amaal
import com.shirazi.duaa.logic.HijriCalendar
import com.shirazi.duaa.logic.PrayerTimes
import com.shirazi.duaa.notify.PrayerScheduler
import java.util.Calendar

// ============ الأوقات ============
@Composable
fun PrayerScreen(settings: Settings, pal: DuaaPalette, openSheet: (String) -> Unit, openTab: (String) -> Unit = {}) {
    // ساعة حيّة: تتجدّد كل ٣٠ ثانية حتى لا يتجمّد العدّاد ولا تبقى مواقيت يومٍ سابق بعد منتصف الليل
    var clockTick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(30_000); clockTick++ } }
    val now = remember(clockTick) { Calendar.getInstance() }
    val loc = settings.location()
    val times = remember(loc.lat, loc.lng, loc.tz, settings.method.value, now.get(Calendar.DAY_OF_YEAR)) {
        PrayerTimes.compute(now, loc.lat, loc.lng, loc.tz, settings.method.value)
    }
    val nowH = now.get(Calendar.HOUR_OF_DAY) + now.get(Calendar.MINUTE) / 60.0
    val (nextKey, dt) = PrayerTimes.next(times, nowH)
    val nextName = PrayerTimes.slots.firstOrNull { it.key == nextKey }?.name ?: ""
    // دقائق كاملة مقرّبة للأعلى: لا تظهر «٦٠د» ولا «٠د»
    val totalMin = kotlin.math.ceil(dt * 60).toInt().coerceAtLeast(0); val hh = totalMin / 60; val mm = totalMin % 60

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ArchCard(pal) {
            Text("الصلاة القادمة", color = Color.White.copy(alpha = .85f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(nextName, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
            Spacer(Modifier.height(4.dp))
            Text("${PrayerTimes.fmt(PrayerTimes.value(times, nextKey))} — ${if (hh > 0) "بعد ${hh}س ${mm}د" else if (mm > 0) "بعد ${mm}د" else "الآن"}", color = Color.White.copy(alpha = .92f), fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
        PlainCard(pal) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 6.dp)) {
                LineIcon(AppIcon.Pin, pal.ink2, 18.dp); Spacer(Modifier.width(5.dp))
                Text(loc.name, color = pal.ink2, fontSize = 13.sp)
            }
            PrayerTimes.slots.forEach { s ->
                val isNext = s.key == nextKey
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(12.dp))
                        .background(if (isNext) pal.emerald else pal.surface2.copy(alpha = .5f))
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isNext) {
                            Box(Modifier.size(7.dp).clip(CircleShape).background(pal.emerald))
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(s.name, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp,
                            color = if (isNext) Color.White else MaterialTheme.colorScheme.onSurface)
                    }
                    Text(PrayerTimes.fmt(PrayerTimes.value(times, s.key)),
                        fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
                        color = if (isNext) Color.White else pal.emerald)
                }
            }
        }
        SectionTitle("أوقات الفضيلة والكراهة")
        PlainCard(pal) {
            FadlRow("وقت فضيلة الفجر", "من الطلوع الصادق حتى الإسفار (قبيل الشروق)", true, pal)
            FadlRow("وقت فضيلة الظهر", "من الزوال إلى أن يصير ظلّ الشيء مثله", true, pal)
            FadlRow("وقت فضيلة العصر", "بعد أداء الظهر إلى أن يصير الظلّ مثليه", true, pal)
            FadlRow("وقت فضيلة المغرب", "أوّل دخول الوقت بعد ذهاب الحمرة المشرقية", true, pal)
            FadlRow("وقت فضيلة العشاء", "من ذهاب الشفق إلى ثلث الليل", true, pal)
            Spacer(Modifier.height(6.dp))
            FadlRow("يُكره النافلة المبتدأة", "بعد صلاة الصبح حتى الشروق، وبعد العصر حتى الغروب", false, pal)
            FadlRow("عند طلوع الشمس وغروبها", "يُكره التنفّل عند الشروق والاستواء والغروب", false, pal, last = true)
        }
        // جسر إلى التقويم — النوافل والأعمال اليومية انتقلت إلى قلب كل يوم
        Row(
            Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(16.dp))
                .background(pal.emerald.copy(alpha = .10f))
                .clickable { openTab("cal") }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(pal.emerald.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                LineIcon(AppIcon.Moon2, pal.emerald, 20.dp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("الصلوات والنوافل وأعمال كلّ يوم", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                Text("في التقويم — اختر أيّ يومٍ لترى عمله كاملاً", color = pal.emerald, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            }
            LineIcon(AppIcon.ChevronStart, pal.ink2, 18.dp)
        }
        BigButton("تغيير الموقع", pal, false) { openSheet("loc") }
        Spacer(Modifier.height(10.dp))
        BigButton("طريقة الحساب: ${PrayerTimes.methodByKey(settings.method.value).name}", pal, true) { openSheet("method") }
        Spacer(Modifier.height(14.dp))
        Text("الأوقات محسوبة فلكياً بحسب موقعك وتقريبية، وقد تختلف دقائق عن التقويم المحلي. يُحتاط في أوّل الوقت وآخره.",
            color = pal.ink2, fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 20.sp)
    }
}

@Composable
private fun NafilaRow(name: String, detail: String, pal: DuaaPalette, last: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(bottom = if (last) 0.dp else 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(pal.gold))
        Spacer(Modifier.width(9.dp))
        Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.width(8.dp))
        Text(detail, color = pal.ink2, fontSize = 12.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun FadlRow(name: String, detail: String, preferred: Boolean, pal: DuaaPalette, last: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(bottom = if (last) 0.dp else 11.dp), verticalAlignment = Alignment.Top) {
        Box(Modifier.padding(top = 3.dp).size(8.dp).clip(CircleShape).background(if (preferred) pal.good else pal.danger))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
            Text(detail, color = pal.ink2, fontSize = 12.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
fun BigButton(label: String, pal: DuaaPalette, gold: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
            .background(if (gold) pal.goldBrush else pal.pillBrush).clickable(onClick = onClick).padding(15.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
}

// ============ التقويم ============

// يُرجِع معرّف الغسل المستحبّ لليوم الهجري إن وُجد (شهر، يوم) → عنصر في باب النوافل
private fun ghuslForDay(m: Int, d: Int): String? = when {
    m == 10 && d == 1 -> "nf-ghusl-eid"          // عيد الفطر
    m == 12 && d == 10 -> "nf-ghusl-eid"         // عيد الأضحى
    m == 12 && d == 9 -> "nf-ghusl-times"        // يوم عرفة
    m == 12 && d == 18 -> "nf-ghusl-times"       // الغدير
    m == 7 && d == 27 -> "nf-ghusl-times"        // المبعث
    m == 1 && d == 10 -> "nf-ghusl-times"        // عاشوراء
    m == 11 && d == 25 -> "nf-ghusl-times"       // دحو الأرض
    m == 9 && (d == 19 || d == 21 || d == 23) -> "nf-ghusl-times" // ليالي القدر
    m == 7 && (d == 1 || d == 15) -> "nf-ghusl-times" // رجب
    m == 8 && d == 15 -> "nf-ghusl-times"        // نصف شعبان
    else -> null
}

@Composable
fun CalendarScreen(settings: Settings, pal: DuaaPalette, openReader: (String, String) -> Unit, openScreen: (String) -> Unit = {}) {
    val today = HijriCalendar.today(settings.hijriAdj.value)
    var calY by remember { mutableStateOf(today.y) }
    var calM by remember { mutableStateOf(today.m) }
    var selDay by remember { mutableStateOf(if (calY == today.y && calM == today.m) today.d else 1) }

    val adj = settings.hijriAdj.value
    val jd1 = HijriCalendar.hijriToJd(calY, calM, 1, adj)
    val g = HijriCalendar.jdToGreg(jd1)
    val dow = run {
        val c = Calendar.getInstance(); c.set(g.y, g.m - 1, g.d); c.get(Calendar.DAY_OF_WEEK) - 1
    }
    val days = HijriCalendar.monthLength(calY, calM, adj)

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            CalNavBtn(AppIcon.ChevronStart, pal, "الشهر السابق") { calM--; if (calM < 1) { calM = 12; calY-- }; selDay = 1 }
            Text("${HijriCalendar.months[calM - 1]} $calY هـ", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = MaterialTheme.colorScheme.onBackground)
            CalNavBtn(AppIcon.ChevronEnd, pal, "الشهر التالي") { calM++; if (calM > 12) { calM = 1; calY++ }; selDay = 1 }
        }
        // أيام الأسبوع + الشبكة
        val cells = ArrayList<Int?>()
        repeat(dow) { cells.add(null) }
        for (d in 1..days) cells.add(d)
        LazyVerticalGrid(columns = GridCells.Fixed(7), modifier = Modifier.height((((cells.size + 6) / 7 + 1) * 54).dp)) {
            items(HijriCalendar.weekDays) { wd -> Box(Modifier.padding(vertical = 4.dp), contentAlignment = Alignment.Center) { Text(wd.removePrefix("ال"), color = pal.ink2, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false) } }
            items(cells) { d ->
                if (d == null) Box(Modifier.padding(2.dp).aspectRatio(1f)) {}
                else {
                    val occ = Data.occasions.filter { it.m == calM && it.d == d }
                    val isToday = calY == today.y && calM == today.m && d == today.d
                    val isSel = d == selDay
                    Box(
                        Modifier.padding(2.dp).aspectRatio(1f).clip(RoundedCornerShape(12.dp))
                            .background(if (isToday) pal.emerald else MaterialTheme.colorScheme.surface)
                            .border(if (isSel && !isToday) 1.5.dp else 1.dp, if (isSel) pal.gold else pal.line, RoundedCornerShape(12.dp))
                            .clickable { selDay = d },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("$d", color = if (isToday) Color.White else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        if (occ.isNotEmpty()) {
                            val dotColor = when (occ[0].k) { "eid" -> pal.good; "birth" -> pal.gold; "death" -> pal.danger; else -> pal.ink2 }
                            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 5.dp).size(6.dp).clip(CircleShape).background(dotColor))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        // مناسبات اليوم المختار
        val occ = Data.occasions.filter { it.m == calM && it.d == selDay }
        val gg = HijriCalendar.jdToGreg(HijriCalendar.hijriToJd(calY, calM, selDay, adj))
        PlainCard(pal) {
            Text("$selDay ${HijriCalendar.months[calM - 1]} $calY هـ — ${gg.d}/${gg.m}/${gg.y}م",
                fontWeight = FontWeight.ExtraBold, color = pal.emerald, fontSize = 15.sp, modifier = Modifier.padding(bottom = 8.dp))
            if (selDay in 13..15) {
                Box(Modifier.padding(bottom = 8.dp).clip(RoundedCornerShape(99.dp)).background(pal.gold.copy(alpha = .15f)).padding(horizontal = 12.dp, vertical = 5.dp)) {
                    Text("من الأيام البيض — يُستحب صيامها ودعاء المجير", color = pal.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (occ.isEmpty() && selDay !in 13..15) Text("لا توجد مناسبة مسجّلة في هذا اليوم.", color = pal.ink2)
            else occ.forEach { o ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    val (bg, fg) = when (o.k) {
                        "eid" -> pal.good.copy(alpha = .18f) to pal.good
                        "birth" -> pal.gold.copy(alpha = .18f) to pal.gold
                        "death" -> pal.danger.copy(alpha = .15f) to pal.danger
                        else -> pal.surface2 to pal.ink2
                    }
                    val tag = when (o.k) { "eid" -> "عيد"; "birth" -> "ولادة"; "death" -> "وفاة"; else -> "مناسبة" }
                    Box(Modifier.clip(RoundedCornerShape(99.dp)).background(bg).padding(horizontal = 8.dp, vertical = 2.dp)) {
                        Text(tag, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(o.t, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                }
            }
        }

        // ===== دعاء وأعمال اليوم المختار =====
        run {
            // يوم الأسبوع الميلادي لليوم المختار (0=الأحد) لاقتراح دعاء/زيارة اليوم
            val gcal = java.util.Calendar.getInstance().apply { set(gg.y, gg.m - 1, gg.d) }
            val wd = gcal.get(java.util.Calendar.DAY_OF_WEEK) - 1
            val sg = com.shirazi.duaa.logic.Recommend.now(calM, selDay, wd, 9)
            val sgCat = Data.categories.firstOrNull { it.id == sg.catId }
            val sgItem = sgCat?.items?.firstOrNull { it.id == sg.itemId }
            // زيارة اليوم بحسب يوم الأسبوع (لكل يومٍ معصوم يُزار)
            val zName = listOf(
                "أمير المؤمنين (ع)", "الحسنان (ع)", "السجاد والباقر والصادق (ع)",
                "الكاظم والرضا والجواد والهادي (ع)", "العسكري (ع)", "صاحب الزمان (عج)", "النبي الأعظم (ص)"
            ).getOrElse(wd) { "" }
            if (sgItem != null) {
                PlainCard(pal) {
                    Text("دعاء وأعمال اليوم", fontWeight = FontWeight.ExtraBold, color = pal.emerald, fontSize = 15.sp, modifier = Modifier.padding(bottom = 10.dp))

                    // ===== مواقيت اليوم المختار — تُحسب لتاريخ اليوم نفسه لا لليوم الحاضر =====
                    val loc = settings.location()
                    val dayTimes = PrayerTimes.compute(gcal, loc.lat, loc.lng, loc.tz, settings.method.value)
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(pal.surface2.copy(alpha = .55f)).padding(vertical = 10.dp, horizontal = 6.dp)
                    ) {
                        listOf("الفجر" to "fajr", "الظهر" to "dhuhr", "العصر" to "asr", "المغرب" to "maghrib", "العشاء" to "isha").forEach { (nm, k) ->
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(nm, color = pal.ink2, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Spacer(Modifier.height(2.dp))
                                Text(PrayerTimes.fmt(PrayerTimes.value(dayTimes, k)), color = pal.emerald,
                                    fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(pal.emerald.copy(alpha = .12f)), contentAlignment = Alignment.Center) {
                            LineIcon(categoryIcon(sg.catId), pal.emerald, 20.dp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(sg.label, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(sg.reason, color = pal.ink2, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    val zItemId = listOf("z-amin", "z-mutlaqa", "z-baqi", "z-kadhim", "z-askari", "z-yasin", "z-nabi").getOrNull(wd)
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .then(if (zItemId != null) Modifier.clickable { openReader("ziyarat", zItemId) } else Modifier)
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(pal.gold.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                            LineIcon(AppIcon.Dome, pal.gold, 20.dp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("زيارة اليوم: $zName", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(if (zItemId != null) "اضغط لقراءة زيارة هذا اليوم" else "لكلّ يومٍ من الأسبوع معصومٌ يُستحبّ زيارته",
                                color = if (zItemId != null) pal.gold else pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                        if (zItemId != null) LineIcon(AppIcon.ChevronStart, pal.ink2, 18.dp)
                    }
                    // غسل اليوم — إن كان لليوم غسلٌ مستحبّ، رابطٌ لتفاصيله في الفهرس
                    val ghuslId = ghuslForDay(calM, selDay)
                    if (ghuslId != null) {
                        Spacer(Modifier.height(10.dp))
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .background(pal.emerald.copy(alpha = .08f))
                                .clickable { openReader("nawafil", ghuslId) }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(pal.emerald.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                                LineIcon(AppIcon.Drop, pal.emerald, 20.dp)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("غسل اليوم مستحبّ", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("اضغط لمعرفة كيفيّته وأحكامه", color = pal.emerald, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                            LineIcon(AppIcon.ChevronStart, pal.ink2, 18.dp)
                        }
                    }

                    // ===== دمج المستحبّات: صيام اليوم المختار =====
                    val fast = Amaal.fastingRec(calM, selDay, wd)
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(if (fast.recommended) pal.good.copy(alpha = .10f) else pal.surface2.copy(alpha = .5f))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (fast.recommended) pal.good.copy(alpha = .16f) else pal.line.copy(alpha = .4f)),
                            contentAlignment = Alignment.Center) {
                            LineIcon(AppIcon.Crescent, if (fast.recommended) pal.good else pal.ink2, 20.dp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (fast.recommended) "صيام هذا اليوم مستحبّ" else "صيام اليوم",
                                color = if (fast.recommended) pal.good else MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(fast.reason, color = pal.ink2, fontSize = 12.sp, lineHeight = 18.sp, maxLines = 2)
                        }
                    }

                    // ===== الصلوات والنوافل اليومية — نُقلت من صفحة الأوقات إلى قلب التقويم =====
                    Spacer(Modifier.height(10.dp))
                    Text("الصلوات والنوافل اليومية — ٣٤ ركعة", fontWeight = FontWeight.ExtraBold, color = pal.emerald, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
                    NafilaRow("نافلة الفجر", "ركعتان قبل الفريضة", pal)
                    NafilaRow("نافلة الظهر", "٨ ركعات قبلها", pal)
                    NafilaRow("نافلة العصر", "٨ ركعات قبلها", pal)
                    NafilaRow("نافلة المغرب", "٤ ركعات بعدها", pal)
                    NafilaRow("الوتيرة (العشاء)", "ركعتان من جلوس بعدها", pal)
                    NafilaRow("صلاة الليل", "١١ ركعة: ٨ + الشفع ركعتان + الوتر ركعة", pal, last = true)
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.emerald.copy(alpha = .10f)).padding(12.dp)) {
                        Text(
                            "وقت صلاة الليل: من منتصف الليل الشرعي (${PrayerTimes.fmt(dayTimes.midnight)}) حتى أذان الفجر." +
                                if (wd == 5) "\nهذا اليوم جمعة — تُزاد ٤ ركعات على النوافل." else " ويُزاد يوم الجمعة ٤ ركعات على النوافل.",
                            color = pal.emerald, fontSize = 12.sp, lineHeight = 21.sp, fontWeight = FontWeight.Bold)
                    }

                    // ===== دمج المستحبّات: أعمال اليوم المختار من كتاب الأعمال =====
                    val dayWorks = Amaal.forDay(calM, selDay)
                    if (dayWorks.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        dayWorks.forEach { w -> WorkCard(w.title, w.body, pal, false) }
                    }

                    // رابط إلى شاشة الأعمال والمستحبّات الكاملة
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(pal.gold.copy(alpha = .10f))
                            .clickable { openScreen("amaal") }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("كلّ الأعمال والمستحبّات — تصفّح حسب الشهر", modifier = Modifier.weight(1f),
                            color = pal.gold, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                        LineIcon(AppIcon.ChevronStart, pal.gold, 16.dp)
                    }
                }
            }
        }
        // مفتاح الألوان
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            LegendDot("عيد", pal.good); Spacer(Modifier.width(14.dp))
            LegendDot("ولادة", pal.gold); Spacer(Modifier.width(14.dp))
            LegendDot("وفاة", pal.danger)
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable private fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color)); Spacer(Modifier.width(4.dp))
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun CalNavBtn(icon: AppIcon, pal: DuaaPalette, label: String, onClick: () -> Unit) {
    Box(Modifier.a11yIconButton(label, 38.dp, MaterialTheme.colorScheme.surface, onClick = onClick)
        .border(1.dp, pal.line, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
        LineIcon(icon, pal.emerald, 16.dp)
    }
}

// ============ المزيد ============
@Composable
fun MoreScreen(pal: DuaaPalette, openSheet: (String) -> Unit, openScreen: (String) -> Unit) {
    // بلاطاتٌ بلغة الرئيسية البصرية نفسها — بدل القوائم المزدحمة
    data class T(val ic: AppIcon, val label: String, val grad: List<Color>, val action: () -> Unit)

    val worship = listOf(
        T(AppIcon.StarFill, "رحلتي", categoryGradient("tarbiya")) { openScreen("journey") },
        T(AppIcon.Sparkle, "أسماء الله", categoryGradient("nawafil")) { openScreen("asma") },
        T(AppIcon.Dome, "المعصومون (ع)", categoryGradient("rajab")) { openScreen("masoom") },
        T(AppIcon.Book, "نقاط القرآن", categoryGradient("quran")) { openScreen("qpoints") },
        T(AppIcon.Beads, "تسبيح الزهراء (ع)", categoryGradient("munajat")) { openSheet("tasbih") },
        T(AppIcon.Moon2, "دليل صلاة الليل", categoryGradient("ramadan")) { openScreen("layl") },
        T(AppIcon.Flag, "زيارة عاشوراء", categoryGradient("ziyarat")) { openScreen("ashura") },
        T(AppIcon.Dome, "الحجّ والعمرة", categoryGradient("sahifa")) { openScreen("hajj") },
        T(AppIcon.Crescent, "المستحبّات", categoryGradient("jumaa")) { openScreen("amaal") }
    )
    val tools = listOf(
        T(AppIcon.Star8, "خِيرة القرآن", categoryGradient("hikam")) { openScreen("khira") },
        T(AppIcon.Book, "البرنامج الأسبوعي", categoryGradient("jumaa")) { openScreen("weekly") },
        T(AppIcon.Calc, "حاسبة الخُمس", categoryGradient("hajat")) { openScreen("khums") },
        T(AppIcon.Pin, "اتجاه القبلة", categoryGradient("salawat")) { openScreen("qibla") },
        T(AppIcon.Clock, "مواقيت الأسبوع", categoryGradient("osboo")) { openScreen("ptable") },
        T(AppIcon.Crescent, "محوّل التاريخ", categoryGradient("mashhura")) { openScreen("converter") },
        T(AppIcon.Clock, "عدّاد الركعات", categoryGradient("taqibat")) { openScreen("tracker") }
    )
    val tracking = listOf(
        T(AppIcon.StarFill, "محاسبة النفس", categoryGradient("tarbiya")) { openScreen("muhasaba") },
        T(AppIcon.Sparkle, "صفة الشهر", categoryGradient("akhlaq")) { openScreen("trait") },
        T(AppIcon.Copy, "قضاء الصلوات", categoryGradient("osboo")) { openScreen("qada") }
    )
    val saved = listOf(
        T(AppIcon.Star, "المفضلة", categoryGradient("mashhura")) { openSheet("fav") },
        T(AppIcon.Scroll, "العلامات المرجعية", categoryGradient("sahifa")) { openSheet("bookmarks") },
        T(AppIcon.Gear, "الإعدادات", categoryGradient("khutab")) { openSheet("settings") },
        T(AppIcon.Sparkle, "حول التطبيق", categoryGradient("hawaij")) { openSheet("about") }
    )

    @Composable
    fun TileGrid(items: List<T>) {
        items.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { q ->
                    Column(
                        Modifier.weight(1f).height(104.dp).paper(pal, 18).pressable(q.action).padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(q.grad)),
                            contentAlignment = Alignment.Center
                        ) { LineIcon(q.ic, Color.White, 20.dp) }
                        Spacer(Modifier.height(8.dp))
                        Text(q.label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center, lineHeight = 16.sp, maxLines = 2)
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        SectionTitle("العبادة والقراءة")
        TileGrid(worship)
        Spacer(Modifier.height(8.dp))

        SectionTitle("أدوات")
        TileGrid(tools)
        Spacer(Modifier.height(8.dp))

        SectionTitle("المتابعة والمحاسبة")
        TileGrid(tracking)
        Spacer(Modifier.height(8.dp))

        SectionTitle("المحفوظات والإعدادات")
        TileGrid(saved)
        Spacer(Modifier.height(90.dp))
    }
}

// ============ محوّل التاريخ الهجري ↔ الميلادي ============
@Composable
fun DateConverterScreen(settings: Settings, pal: DuaaPalette, onClose: () -> Unit) {
    val adj = settings.hijriAdj.value
    var mode by remember { mutableStateOf("h2g") } // h2g أو g2h
    val today = HijriCalendar.today(adj)
    val gToday = HijriCalendar.jdToGreg(HijriCalendar.hijriToJd(today.y, today.m, today.d, adj))

    // مدخلات هجرية
    var hY by remember { mutableStateOf(today.y) }
    var hM by remember { mutableStateOf(today.m) }
    var hD by remember { mutableStateOf(today.d) }
    // مدخلات ميلادية
    var gY by remember { mutableStateOf(gToday.y) }
    var gM by remember { mutableStateOf(gToday.m) }
    var gD by remember { mutableStateOf(gToday.d) }

    Column(Modifier.fillMaxSize().background(pal.bgBrush)) {
        ScreenTopBar("محوّل التاريخ", pal, onClose)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(pal.surface2).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("هجري ← ميلادي" to "h2g", "ميلادي ← هجري" to "g2h").forEach { (label, v) ->
                    val on = v == mode
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if (on) MaterialTheme.colorScheme.surface else Color.Transparent).clickable { mode = v }.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                        Text(label, color = if (on) pal.emerald else pal.ink2, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))

            if (mode == "h2g") {
                Text("التاريخ الهجري", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
                StepperRow("اليوم", hD, pal, { hD = (hD - 1).coerceAtLeast(1) }, { hD = (hD + 1).coerceAtMost(30) })
                StepperRowLabeled("الشهر", HijriCalendar.months[hM - 1], pal, { hM = if (hM <= 1) 12 else hM - 1 }, { hM = if (hM >= 12) 1 else hM + 1 })
                StepperRow("السنة", hY, pal, { hY-- }, { hY++ })
                Spacer(Modifier.height(16.dp))
                val g = HijriCalendar.jdToGreg(HijriCalendar.hijriToJd(hY, hM, hD, adj))
                val dow = run { val c = Calendar.getInstance(); c.set(g.y, g.m - 1, g.d); c.get(Calendar.DAY_OF_WEEK) - 1 }
                ResultCard(pal,
                    "$hD ${HijriCalendar.months[hM - 1]} $hY هـ",
                    "${g.d} / ${g.m} / ${g.y} م",
                    HijriCalendar.weekDays[dow])
            } else {
                Text("التاريخ الميلادي", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
                StepperRow("اليوم", gD, pal, { gD = (gD - 1).coerceAtLeast(1) }, { gD = (gD + 1).coerceAtMost(31) })
                StepperRowLabeled("الشهر", GREG_MONTHS[gM - 1], pal, { gM = if (gM <= 1) 12 else gM - 1 }, { gM = if (gM >= 12) 1 else gM + 1 })
                StepperRow("السنة", gY, pal, { gY-- }, { gY++ })
                Spacer(Modifier.height(16.dp))
                val jd = HijriCalendar.gToJd(gY, gM, gD)
                val h = HijriCalendar.jdToHijri(jd, adj)
                val dow = run { val c = Calendar.getInstance(); c.set(gY, gM - 1, gD); c.get(Calendar.DAY_OF_WEEK) - 1 }
                ResultCard(pal,
                    "${gD} / ${gM} / ${gY} م",
                    "${h.d} ${HijriCalendar.months[h.m - 1]} ${h.y} هـ",
                    HijriCalendar.weekDays[dow])
            }
            Spacer(Modifier.height(12.dp))
            Text("التحويل تقريبي حسابياً وقد يختلف يوماً عن الرؤية الهلالية المحلية.", color = pal.ink2, fontSize = 12.sp, lineHeight = 20.sp)
        }
    }
}

private val GREG_MONTHS = listOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")

@Composable
private fun StepperRow(label: String, value: Int, pal: DuaaPalette, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).paper(pal, 12).padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = pal.ink2, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
        StepBtn("−", pal, onMinus)
        Box(Modifier.widthIn(min = 56.dp).padding(horizontal = 8.dp), contentAlignment = Alignment.Center) {
            Text("$value", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
        }
        StepBtn("+", pal, onPlus)
    }
}

@Composable
private fun StepperRowLabeled(label: String, valueText: String, pal: DuaaPalette, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).paper(pal, 12).padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = pal.ink2, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
        StepBtn("−", pal, onMinus)
        Box(Modifier.widthIn(min = 92.dp).padding(horizontal = 8.dp), contentAlignment = Alignment.Center) {
            Text(valueText, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
        }
        StepBtn("+", pal, onPlus)
    }
}

@Composable
private fun StepBtn(s: String, pal: DuaaPalette, onClick: () -> Unit) {
    val label = when (s) { "+" -> "زيادة"; "−", "-" -> "إنقاص"; else -> s }
    Box(Modifier.a11yIconButton(label, 38.dp, pal.emerald.copy(alpha = .12f), radius = 10.dp, onClick = onClick), contentAlignment = Alignment.Center) {
        Text(s, color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
    }
}

@Composable
private fun ResultCard(pal: DuaaPalette, fromLine: String, toLine: String, weekday: String) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(pal.emerald, pal.emerald.copy(alpha = .82f)))).padding(20.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(weekday, color = Color.White.copy(alpha = .82f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(fromLine, color = Color.White.copy(alpha = .85f), fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            LineIcon(AppIcon.ChevronEnd, Color.White.copy(alpha = .6f), 18.dp)
            Spacer(Modifier.height(6.dp))
            Text(toLine, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

// ============ جدول مواقيت الأسبوع ============
@Composable
fun PrayerTableScreen(settings: Settings, pal: DuaaPalette, onClose: () -> Unit) {
    val loc = settings.location()
    val slots = listOf("fajr" to "الفجر", "sunrise" to "الشروق", "dhuhr" to "الظهر", "asr" to "العصر", "maghrib" to "المغرب", "isha" to "العشاء")
    Column(Modifier.fillMaxSize().background(pal.bgBrush)) {
        ScreenTopBar("مواقيت الأسبوع", pal, onClose)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text(loc.name, color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.padding(bottom = 12.dp))
            for (dayOffset in 0..6) {
                val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, dayOffset) }
                val t = PrayerTimes.compute(cal, loc.lat, loc.lng, loc.tz, settings.method.value)
                val wd = cal.get(Calendar.DAY_OF_WEEK) - 1
                val dayLabel = if (dayOffset == 0) "اليوم" else HijriCalendar.weekDays[wd]
                Box(Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, if (dayOffset == 0) pal.gold else pal.line, RoundedCornerShape(16.dp)).padding(14.dp)) {
                    Column {
                        Text(dayLabel, color = if (dayOffset == 0) pal.gold else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            slots.forEach { (key, name) ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                    Text(name, color = pal.ink2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(3.dp))
                                    Text(PrayerTimes.fmt(PrayerTimes.value(t, key)), color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                                }
                            }
                        }
                    }
                }
            }
            Text("الأوقات محسوبة فلكياً بحسب موقعك وتقريبية؛ يُحتاط في أوّل الوقت وآخره.", color = pal.ink2, fontSize = 12.sp, lineHeight = 20.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}

// ============ لوحة نقاط قراءة القرآن (تحفيز) ============
@Composable
fun QuranPointsScreen(settings: Settings, pal: DuaaPalette, onClose: () -> Unit, openReader: (String, String) -> Unit) {
    val points = settings.quranPoints.value
    val doneCount = settings.quranDoneCount.value
    val (levelName, levelNum) = settings.readerLevel()
    val quranCat = Data.categories.firstOrNull { it.id == "quran" }
    val total = quranCat?.items?.size ?: 114
    val khatmaFrac = (doneCount.toFloat() / total).coerceIn(0f, 1f)

    Column(Modifier.fillMaxSize().background(pal.bgBrush)) {
        ScreenTopBar("نقاط القرآن", pal, onClose)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            // البطاقة الرئيسية: المجموع + المستوى
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(pal.emerald, pal.emeraldDeep))).padding(24.dp)) {
                IslamicPattern(Color.White.copy(alpha = .06f), Modifier.matchParentSize(), cell = 70f)
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("مجموع نقاطك", color = Color.White.copy(alpha = .82f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("$points", color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.clip(RoundedCornerShape(99.dp)).background(pal.gold).padding(horizontal = 16.dp, vertical = 6.dp)) {
                        Text("المستوى $levelNum · $levelName", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))

            // تقدّم قراءة السور (تُحتسب آلياً عند إتمام كل سورة)
            PlainCard(pal) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("السور المقروءة", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Text("$doneCount / $total سورة", color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                }
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(99.dp)).background(pal.surface2)) {
                    Box(Modifier.fillMaxWidth(khatmaFrac).height(12.dp).clip(RoundedCornerShape(99.dp)).background(pal.emerald))
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    if (doneCount >= total) "أتممتَ قراءة سور القرآن كاملةً — جعلها الله في ميزان حسناتك."
                    else "تُحتسب السورة تلقائياً عند قراءتها حتّى النهاية، فتُضاف نقاطها.",
                    color = pal.ink2, fontSize = 12.sp, lineHeight = 20.sp
                )
            }
            Spacer(Modifier.height(14.dp))

            // ===== سلسلة القراءة وتقويمها =====
            run {
                val rStreak = settings.readingStreak()
                val rDays30 = settings.readDaysLast(30)
                PlainCard(pal) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(pal.gold.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                            LineIcon(AppIcon.StarFill, pal.gold, 22.dp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("سلسلة القراءة", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp)
                            Text(
                                if (rStreak > 0) "$rStreak ${if (rStreak == 1) "يوم" else "يوماً"} متتالية — لا تكسرها"
                                else "اقرأ اليوم لتبدأ سلسلتك",
                                color = pal.ink2, fontSize = 12.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    // تقويم آخر ٢١ يوماً (٣ أسابيع)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (week in 0..2) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                for (d in 0..6) {
                                    val offset = week * 7 + d
                                    val read = settings.readForOffset(offset) > 0
                                    Box(
                                        Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(8.dp))
                                            .background(if (read) pal.emerald.copy(alpha = .85f) else pal.surface2),
                                        contentAlignment = Alignment.Center
                                    ) {}
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("$rDays30 يوماً قرأتَ فيها خلال آخر ٣٠ يوماً.", color = pal.ink2, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            run {
                val todayEpoch = java.time.LocalDate.now().toEpochDay()
                PlainCard(pal) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        LineIcon(AppIcon.Book, pal.emerald, 20.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("مخطّط الختمة", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    if (!settings.khatmaActive.value) {
                        Text("حدّد مدّةً لختم القرآن، وسنوزّع الأجزاء على الأيام ونتابع وتيرتك.", color = pal.ink2, fontSize = 13.sp, lineHeight = 21.sp)
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(7, 30, 60).forEach { days ->
                                Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(pal.surface2).clickable { settings.startKhatma(days, todayEpoch) }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                                    Text(if (days == 7) "أسبوع" else "$days يوماً", color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                                }
                            }
                        }
                    } else {
                        val done = settings.khatmaJuzDone.value
                        val expected = settings.khatmaExpectedJuz(todayEpoch)
                        val perDay = 30.0 / settings.khatmaDays.value
                        val onTrack = done >= expected
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("$done / 30 جزءاً", color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            Box(Modifier.clip(RoundedCornerShape(99.dp)).background((if (onTrack) pal.good else pal.danger).copy(alpha = .16f)).padding(horizontal = 12.dp, vertical = 5.dp)) {
                                Text(if (onTrack) "في الموعد ✓" else "متأخّر قليلاً", color = if (onTrack) pal.good else pal.danger, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(99.dp)).background(pal.surface2)) {
                            Box(Modifier.fillMaxWidth((done / 30f).coerceIn(0f, 1f)).height(12.dp).clip(RoundedCornerShape(99.dp)).background(pal.emerald))
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("هدفك اليومي ${"%.1f".format(perDay)} جزء · المتوقّع حتى اليوم $expected جزءاً", color = pal.ink2, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { BigButton("− جزء", pal, false) { settings.setKhatmaJuz(done - 1) } }
                            Box(Modifier.weight(1f)) { BigButton("+ جزء", pal, true) { settings.setKhatmaJuz(done + 1) } }
                        }
                        Spacer(Modifier.height(8.dp))
                        Box(Modifier.fillMaxWidth().clickable { settings.cancelKhatma() }.padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
                            Text("إلغاء المخطّط", color = pal.danger, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
            }

            // كيف تُحتسب النقاط
            PlainCard(pal) {
                Text("كيف تُجمع النقاط", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp, modifier = Modifier.padding(bottom = 10.dp))
                PointRule(pal, "إتمام سورة عادية", "+10")
                PointRule(pal, "إتمام سورة مميّزة (الفاتحة، يس، الكهف، الملك، الرحمن...)", "+15")
                PointRule(pal, "ختم القرآن كاملاً", "+500")
            }
            Spacer(Modifier.height(14.dp))

            // متابعة القراءة — أوّل سورة غير مكتملة
            if (quranCat != null && doneCount < total) {
                val nextSurah = quranCat.items.firstOrNull { !settings.isSurahDone(it.id) }
                if (nextSurah != null) {
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(categoryGradient("quran"))).clickable { openReader("quran", nextSurah.id) }.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LineIcon(AppIcon.Book, Color.White, 24.dp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("تابع نحو الختمة", color = Color.White.copy(alpha = .82f), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                                Text(nextSurah.title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                            }
                            Text("+${settings.surahPoints(nextSurah.id)}", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                }
            }

            Text("التحفيز وسيلةٌ لا غاية؛ المقصود تدبّر كتاب الله والمداومة عليه.", color = pal.ink2, fontSize = 12.sp, lineHeight = 20.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun PointRule(pal: DuaaPalette, label: String, pts: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.clip(RoundedCornerShape(99.dp)).background(pal.gold.copy(alpha = .16f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
            Text(pts, color = pal.gold, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
        }
        Spacer(Modifier.width(12.dp))
        Text(label, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, modifier = Modifier.weight(1f), lineHeight = 19.sp)
    }
}
