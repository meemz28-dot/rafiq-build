package com.shirazi.duaa.ui

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

/**
 * ردود فعل لمسية لطيفة (haptics) للحظات التفاعل المهمّة:
 * نقرة التسبيح، إكمال الوِرد، إتمام السورة، حفظ علامة... إلخ.
 * تنحلّ بأمان على الأجهزة التي لا تدعم الاهتزاز.
 */
class Haptics(private val ctx: Context) {
    private val vibrator: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (e: Exception) { null }

    private fun buzz(ms: Long, amplitude: Int) {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val amp = if (v.hasAmplitudeControl()) amplitude else VibrationEffect.DEFAULT_AMPLITUDE
                v.vibrate(VibrationEffect.createOneShot(ms, amp))
            } else {
                @Suppress("DEPRECATION") v.vibrate(ms)
            }
        } catch (e: Exception) { /* تجاهل بهدوء */ }
    }

    /** نقرة خفيفة جداً — لكل حبّة تسبيح أو ضغطة عادية. */
    fun tick() = buzz(12, 60)

    /** نقرة متوسّطة — لتأكيد فعلٍ (حفظ علامة، تحديد عنصر). */
    fun confirm() = buzz(22, 130)

    /** نبضة احتفائية مزدوجة — لإكمال وِرد أو إتمام سورة. */
    fun celebrate() {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 28, 70, 45), -1))
            } else {
                @Suppress("DEPRECATION") v.vibrate(longArrayOf(0, 28, 70, 45), -1)
            }
        } catch (e: Exception) { }
    }
}

@Composable
fun rememberHaptics(): Haptics {
    val ctx = LocalContext.current
    return remember { Haptics(ctx) }
}
