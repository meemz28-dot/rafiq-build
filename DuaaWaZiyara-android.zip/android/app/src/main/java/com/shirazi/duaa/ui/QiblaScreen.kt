package com.shirazi.duaa.ui

import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Settings
import kotlin.math.*

/** بوصلة القبلة — تعتمد مُستشعِر الاتجاه + إحداثيات الموقع. تعمل دون إنترنت. */
@Composable
fun QiblaScreen(settings: Settings, pal: DuaaPalette, onClose: () -> Unit) {
    // إبقاء الشاشة مضاءة أثناء الاستعمال (العدّ أو توجيه البوصلة لا يُتابَع بالنظر دائماً)
    val awakeView = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(Unit) {
        val before = awakeView.keepScreenOn          // يُعاد كما كان، فلا يُطفئ إبقاءً تطلبه شاشةٌ أخرى تحته
        awakeView.keepScreenOn = true
        onDispose { awakeView.keepScreenOn = before }
    }
    val ctx = LocalContext.current
    val sm = remember { ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val hasCompass = remember { sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) != null }

    val loc = settings.location()
    // إحداثيات الكعبة المشرّفة
    val kaabaLat = 21.4225; val kaabaLng = 39.8262
    val qiblaBearing = remember(loc.lat, loc.lng) {
        val phiK = Math.toRadians(kaabaLat); val phi = Math.toRadians(loc.lat)
        val dL = Math.toRadians(kaabaLng - loc.lng)
        val y = sin(dL); val x = cos(phi) * tan(phiK) - sin(phi) * cos(dL)
        ((Math.toDegrees(atan2(y, x)) + 360) % 360).toFloat()
    }

    var azimuth by remember { mutableStateOf(0f) } // اتجاه الجهاز عن الشمال
    var sensorAccuracy by remember { mutableStateOf(SensorManager.SENSOR_STATUS_ACCURACY_HIGH) }

    DisposableEffect(hasCompass) {
        if (!hasCompass) return@DisposableEffect onDispose { }
        val rot = FloatArray(9); val orient = FloatArray(3)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                if (e.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
                SensorManager.getRotationMatrixFromVector(rot, e.values)
                // يعمل سواءٌ أُمسك الجهاز مسطّحاً أو قائماً:
                // rot[8] قريبٌ من ١ عند الاستلقاء، وقريبٌ من ٠ عند رفع الجهاز عمودياً
                val m = if (Math.abs(rot[8]) < 0.5f) {
                    val r2 = FloatArray(9)
                    SensorManager.remapCoordinateSystem(rot, SensorManager.AXIS_X, SensorManager.AXIS_Z, r2)
                    r2
                } else rot
                SensorManager.getOrientation(m, orient)
                var deg = Math.toDegrees(orient[0].toDouble()).toFloat()
                // تصحيح الانحراف المغناطيسي إلى الشمال الحقيقي
                val geo = GeomagneticField(loc.lat.toFloat(), loc.lng.toFloat(), 0f, System.currentTimeMillis())
                deg += geo.declination
                azimuth = (deg + 360) % 360
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {
                if (s?.type == Sensor.TYPE_ROTATION_VECTOR) sensorAccuracy = a
            }
        }
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(listener) }
    }

    // زاوية دوران مؤشر القبلة على القرص = اتجاه القبلة - اتجاه الجهاز
    val needle = (qiblaBearing - azimuth + 360) % 360
    val aligned = needle < 6f || needle > 354f

    val haptics = rememberHaptics()
    LaunchedEffect(aligned) { if (aligned) haptics.confirm() }
    val distanceKm = remember(loc.lat, loc.lng) {
        val dLat = Math.toRadians(kaabaLat - loc.lat)
        val dLng = Math.toRadians(kaabaLng - loc.lng)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(loc.lat)) * cos(Math.toRadians(kaabaLat)) * sin(dLng / 2).pow(2)
        (6371.0 * 2 * atan2(sqrt(a), sqrt(1 - a))).roundToInt()
    }

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
            Column(Modifier.fillMaxSize().padding(bottom = 12.dp)) {
                ScreenTopBar("اتجاه القبلة", pal, onClose)
                Column(
                    Modifier.fillMaxWidth().weight(1f).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (!hasCompass) {
                        Box(Modifier.fillMaxWidth().paper(pal, 20).padding(22.dp), contentAlignment = Alignment.Center) {
                            Text("جهازك لا يحتوي مُستشعِر البوصلة اللازم لتحديد القبلة.",
                                color = pal.ink2, textAlign = TextAlign.Center)
                        }
                        return@Column
                    }

                    Text("اتجاه القبلة من ${loc.name}: ${qiblaBearing.roundToInt()}°",
                        color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    if (sensorAccuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW) {
                        Spacer(Modifier.height(10.dp))
                        Box(Modifier.clip(RoundedCornerShape(12.dp)).background(pal.gold.copy(alpha = .18f)).padding(horizontal = 14.dp, vertical = 8.dp)) {
                            Text("⚠ البوصلة تحتاج معايرة — حرّك جهازك على شكل ٨ بعيداً عن المعادن والشواحن، وإلا فالاتجاه غير دقيق.",
                                color = pal.gold, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, lineHeight = 18.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    if (aligned) {
                        Box(Modifier.clip(RoundedCornerShape(99.dp)).background(pal.good.copy(alpha = .15f)).padding(horizontal = 16.dp, vertical = 6.dp)) {
                            Text("أنت موجَّه نحو القبلة الآن", color = pal.good, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                        }
                    } else {
                        Text("أدِر جهازك حتى تستقيم الكعبة لأعلى", color = pal.ink2, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(28.dp))

                    Box(Modifier.size(290.dp), contentAlignment = Alignment.Center) {
                        // القرص يدور عكس اتجاه الجهاز ليبقى الشمال صحيحاً
                        Canvas(Modifier.fillMaxSize().rotate(-azimuth)) {
                            val r = size.minDimension / 2
                            val c = Offset(size.width / 2, size.height / 2)
                            drawCircle(pal.line, r, c, style = Stroke(2f))
                            drawCircle(pal.line.copy(alpha = .5f), r * 0.72f, c, style = Stroke(1f))
                            for (i in 0 until 72) {
                                val a = Math.toRadians(i * 5.0)
                                val long = i % 6 == 0
                                val rO = r; val rI = r - (if (long) 18 else 9)
                                drawLine(
                                    if (long) pal.gold else pal.line,
                                    Offset(c.x + sin(a).toFloat() * rI, c.y - cos(a).toFloat() * rI),
                                    Offset(c.x + sin(a).toFloat() * rO, c.y - cos(a).toFloat() * rO),
                                    if (long) 2.5f else 1f
                                )
                            }
                        }
                        // خطٌّ رفيعٌ من مركزك (أنت) نحو القبلة
                        Canvas(Modifier.fillMaxSize().rotate(needle)) {
                            val c = Offset(size.width / 2, size.height / 2)
                            val r = size.minDimension / 2
                            val col = if (aligned) pal.good else pal.gold
                            drawLine(col.copy(alpha = .55f), Offset(c.x, c.y - r * 0.18f), Offset(c.x, c.y - r * 0.60f), 5f, cap = StrokeCap.Round)
                        }
                        // الكعبة المشرّفة عند اتجاه القبلة (تبقى قائمةً وتدور حول القرص)
                        run {
                            val rad = needle * Math.PI / 180.0
                            val rr = 104f
                            Box(Modifier.offset(x = (sin(rad).toFloat() * rr).dp, y = (-cos(rad).toFloat() * rr).dp)) {
                                KaabaGlyph(52.dp, if (aligned) pal.good else null)
                            }
                        }
                        // مركزك (أنت)
                        Box(Modifier.size(16.dp).clip(RoundedCornerShape(99.dp)).background(pal.emerald))
                        Box(Modifier.size(6.dp).clip(RoundedCornerShape(99.dp)).background(Color.White))
                    }

                    Spacer(Modifier.height(20.dp))
                    Text("الكعبة المشرّفة تبعد نحو ${"%,d".format(distanceKm)} كم", color = pal.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Spacer(Modifier.height(28.dp))
                    Text("${azimuth.roundToInt()}°", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = pal.emerald)
                    Text("اتجاه جهازك عن الشمال", color = pal.ink2, fontSize = 12.sp)
                }
                Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).navigationBarsPadding()) {
                    Box(Modifier.fillMaxWidth().paper(pal, 16).padding(12.dp)) {
                        Text("أمسك الجهاز مسطّحاً أو قائماً وابتعد عن المعادن والشواحن لدقّةٍ أعلى. إن بدا الاتجاه خاطئاً فعاير البوصلة بتحريك الجهاز على شكل ٨.",
                            color = pal.ink2, fontSize = 11.5.sp, lineHeight = 19.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun KaabaGlyph(sizeDp: Dp, highlight: Color?) {
    Canvas(Modifier.size(sizeDp)) {
        val s = size.minDimension
        val body = Color(0xFF141414)
        val gold = Color(0xFFC9A86A)
        val pad = s * 0.06f
        // جسم الكعبة (مكعّب أسود بكسوة)
        drawRect(body, topLeft = Offset(pad, pad), size = Size(s - 2 * pad, s - 2 * pad))
        // حزام الكسوة الذهبيّ
        drawRect(gold, topLeft = Offset(pad, s * 0.30f), size = Size(s - 2 * pad, s * 0.10f))
        // الباب
        drawRect(gold, topLeft = Offset(s * 0.42f, s * 0.56f), size = Size(s * 0.16f, s * 0.38f))
        // الإطار (يتحوّل أخضرَ عند المحاذاة)
        drawRect(highlight ?: gold, topLeft = Offset(pad, pad), size = Size(s - 2 * pad, s - 2 * pad), style = Stroke(width = s * 0.055f))
    }
}
