package com.shirazi.duaa.ui

import androidx.compose.ui.draw.clip
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Data
import com.shirazi.duaa.data.Settings

/**
 * تدفّق الترحيب لأوّل تشغيل: يهيّئ المستخدم في ثوانٍ (الموقع، طريقة الحساب، التذكيرات).
 * يكتب مباشرةً إلى الإعدادات الحقيقية، ثم يرفع علم الإكمال.
 */
@Composable
fun OnboardingScreen(settings: Settings, pal: DuaaPalette, onRequestNotifyPermission: () -> Unit, onDone: () -> Unit) {
    val haptics = rememberHaptics()
    var step by remember { mutableStateOf(0) }
    val total = 3

    Column(Modifier.fillMaxSize().background(pal.bgBrush).statusBarsPadding().navigationBarsPadding()) {
        // مؤشّر التقدّم
        Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(total) { i ->
                Box(
                    Modifier.weight(1f).height(5.dp).clip(RoundedCornerShape(99.dp))
                        .background(if (i <= step) pal.emerald else pal.surface2)
                )
            }
        }

        AnimatedContent(
            targetState = step,
            transitionSpec = {
                (slideInHorizontally(tween(300)) { it / 2 } + fadeIn(tween(300))) togetherWith
                    (slideOutHorizontally(tween(300)) { -it / 2 } + fadeOut(tween(200)))
            },
            modifier = Modifier.weight(1f), label = "onboard"
        ) { s ->
            when (s) {
                0 -> WelcomeStep(pal)
                1 -> LocationStep(settings, pal)
                else -> RemindersStep(settings, pal, onRequestNotifyPermission)
            }
        }

        // أزرار التنقّل
        Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (step > 0) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).border(1.5.dp, pal.line, RoundedCornerShape(16.dp))
                        .clickable { haptics.tick(); step-- }.padding(vertical = 15.dp),
                    contentAlignment = Alignment.Center
                ) { Text("السابق", color = pal.ink2, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
            }
            Box(
                Modifier.weight(if (step > 0) 2f else 1f).clip(RoundedCornerShape(16.dp)).background(pal.heroBrush)
                    .clickable {
                        haptics.tick()
                        if (step < total - 1) step++
                        else { settings.finishOnboarding(); onDone() }
                    }.padding(vertical = 15.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (step < total - 1) "التالي" else "ابدأ الآن",
                    color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp
                )
            }
        }
        if (step == 0) {
            Box(
                Modifier.fillMaxWidth().clickable { settings.finishOnboarding(); onDone() }.padding(bottom = 14.dp),
                contentAlignment = Alignment.Center
            ) { Text("تخطّي", color = pal.ink2, fontSize = 13.sp) }
        }
    }
}

@Composable
private fun StepShell(icon: AppIcon, title: String, subtitle: String, pal: DuaaPalette, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(20.dp))
        Box(
            Modifier.size(88.dp).clip(CircleShape).background(pal.emerald.copy(alpha = .12f)),
            contentAlignment = Alignment.Center
        ) { LineIcon(icon, pal.emerald, 44.dp) }
        Spacer(Modifier.height(20.dp))
        Text(title, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, color = pal.ink2, fontSize = 14.sp, lineHeight = 22.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        content()
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun WelcomeStep(pal: DuaaPalette) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        // بطاقة بطلٍ متدرّجة بمشهد الغروب — انطباعٌ أوّل فاخر
        Box(
            Modifier.fillMaxWidth().height(260.dp)
                .shadow(12.dp, RoundedCornerShape(28.dp), spotColor = pal.emerald.copy(alpha = .3f))
                .clip(RoundedCornerShape(28.dp))
                .background(pal.heroBrush)
        ) {
            DuskScene(Modifier.matchParentSize().clip(RoundedCornerShape(28.dp)))
            IslamicPattern(Color.White.copy(alpha = .08f), Modifier.matchParentSize(), cell = 56f)
            Box(
                Modifier.matchParentSize().clip(RoundedCornerShape(28.dp))
                    .background(androidx.compose.ui.graphics.Brush.verticalGradient(
                        listOf(Color.Transparent, Color(0xCC0E3A44))
                    ))
            )
            Column(
                Modifier.matchParentSize().padding(28.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("رفيق المؤمن", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
                Spacer(Modifier.height(6.dp))
                Text("رفيقك إلى ربّك كل يوم", color = Color.White.copy(alpha = .9f), fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.height(28.dp))
        // ثلاث قيمٍ سريعة (سطرٌ واحد لكلّ)
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickValue(AppIcon.Clock, "مواقيت الصلاة", "محسوبة فلكياً لموقعك بدقّة", pal)
            QuickValue(AppIcon.Book, "القرآن والأدعية", "المصحف كاملاً والأدعية والزيارات", pal)
            QuickValue(AppIcon.StarFill, "رحلتك الروحيّة", "تابِع وِردك ومحاسبتك وتقدّمك", pal)
        }
        Spacer(Modifier.height(20.dp))
        Text("لنهيّئ التطبيق لك في خطوتين سريعتين", color = pal.emerald, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun QuickValue(icon: AppIcon, title: String, sub: String, pal: DuaaPalette) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(pal.emerald.copy(alpha = if (pal.dark) .16f else .10f)), contentAlignment = Alignment.Center) {
            LineIcon(icon, pal.emerald, 23.dp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(sub, color = pal.ink2, fontSize = 12.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun LocationStep(settings: Settings, pal: DuaaPalette) {
    StepShell(AppIcon.Pin, "أين أنت؟", "نحتاج مدينتك لحساب مواقيت الصلاة بدقّة. اختر أقرب مدينة إليك.", pal) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Data.cities.forEachIndexed { i, c ->
                val on = settings.customLat.value == null && settings.cityIdx.value == i
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(if (on) pal.emerald.copy(alpha = .12f) else pal.surface2)
                        .border(if (on) 1.5.dp else 0.dp, if (on) pal.emerald else Color.Transparent, RoundedCornerShape(14.dp))
                        .clickable {
                            settings.cityIdx.value = i; settings.customLat.value = null
                            settings.customLng.value = null; settings.save()
                        }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(if (on) pal.emerald else pal.line))
                    Spacer(Modifier.width(12.dp))
                    Text(c.n, color = if (on) pal.emerald else MaterialTheme.colorScheme.onSurface,
                        fontWeight = if (on) FontWeight.ExtraBold else FontWeight.Medium, fontSize = 15.sp)
                }
            }
        }
    }
}

@Composable
private fun RemindersStep(settings: Settings, pal: DuaaPalette, onRequestNotifyPermission: () -> Unit) {
    StepShell(AppIcon.Sparkle, "تذكيرات تعينك", "نُنبّهك بأوقات الصلاة وما يعينك على المداومة. يمكنك ضبط التفاصيل لاحقاً من الإعدادات.", pal) {
        // خيارٌ رئيسيّ واحد: تفعيل التذكيرات
        val on = settings.notifyEnabled.value
        Column(
            Modifier.fillMaxWidth()
                .shadow(if (on) 6.dp else 2.dp, RoundedCornerShape(20.dp), spotColor = pal.emerald.copy(alpha = .2f))
                .clip(RoundedCornerShape(20.dp))
                .background(if (on) pal.emerald.copy(alpha = if (pal.dark) .16f else .10f) else MaterialTheme.colorScheme.surface)
                .border(1.5.dp, if (on) pal.emerald else pal.line, RoundedCornerShape(20.dp))
                .clickable {
                    val nv = !on
                    settings.notifyEnabled.value = nv; settings.save()
                    // تفعيل الحزمة المفيدة افتراضياً
                    settings.saveTaqibat(nv)
                    if (nv) onRequestNotifyPermission()
                }
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(64.dp).clip(CircleShape).background(if (on) pal.emerald else pal.surface2), contentAlignment = Alignment.Center) {
                LineIcon(if (on) AppIcon.StarFill else AppIcon.Clock, if (on) Color.White else pal.ink2, 32.dp)
            }
            Spacer(Modifier.height(14.dp))
            Text(if (on) "التذكيرات مفعّلة ✓" else "تفعيل التذكيرات", color = if (on) pal.emerald else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            Spacer(Modifier.height(6.dp))
            Text("تنبيهات أوقات الصلاة والتعقيبات بعد كلّ صلاة", color = pal.ink2, fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 18.sp)
        }
        Spacer(Modifier.height(14.dp))
        // خياران اختياريّان لطيفان
        ReminderToggle("تذكير صلاة الليل قبل الفجر", settings.laylEnabled.value, pal) { v ->
            settings.saveLayl(v); if (v) onRequestNotifyPermission()
        }
        Spacer(Modifier.height(8.dp))
        ReminderToggle("تذكير لطيف بالأذكار خلال اليوم", settings.dhikrEnabled.value, pal) { v ->
            settings.dhikrEnabled.value = v; settings.save()
            if (v) onRequestNotifyPermission()
        }
        Spacer(Modifier.height(18.dp))
        Text("تقبّل الله طاعاتك 🌙", color = pal.emerald, fontSize = 14.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

@Composable
private fun ReminderToggle(label: String, checked: Boolean, pal: DuaaPalette, onToggle: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.surface2).padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onToggle, colors = SwitchDefaults.colors(checkedTrackColor = pal.emerald))
    }
}
