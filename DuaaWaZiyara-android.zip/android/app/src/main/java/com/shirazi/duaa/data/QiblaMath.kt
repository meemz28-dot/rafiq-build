package com.shirazi.duaa.data

import kotlin.math.*

/**
 * اتجاه القبلة والمسافة والتحقّق بالشمس (دون بوصلة).
 * المعادلة وإحداثيات الكعبة مطابقة لمكتبة batoulapps/adhan-swift (MIT) ومُختبَرة على متجهات اختبارها.
 */
object QiblaMath {
    const val KAABA_LAT = 21.4225241
    const val KAABA_LNG = 39.8261818
    private const val RAD = PI / 180

    /** اتجاه القبلة من الشمال الحقيقي بالدرجات 0..360. */
    fun bearing(lat: Double, lng: Double): Double {
        val t1 = sin((KAABA_LNG - lng) * RAD)
        val t2 = cos(lat * RAD) * tan(KAABA_LAT * RAD)
        val t3 = sin(lat * RAD) * cos((KAABA_LNG - lng) * RAD)
        return (atan2(t1, t2 - t3) / RAD + 360) % 360
    }

    /** المسافة إلى الكعبة بالكيلومتر (هافرساين). */
    fun distanceKm(lat: Double, lng: Double): Double {
        val dLat = (KAABA_LAT - lat) * RAD; val dLng = (KAABA_LNG - lng) * RAD
        val a = sin(dLat / 2).pow(2) + cos(lat * RAD) * cos(KAABA_LAT * RAD) * sin(dLng / 2).pow(2)
        return 6371.0 * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    /** سمت الشمس (من الشمال الحقيقي) وارتفاعها بالدرجات (نموذج NOAA المبسّط، دقّة نحو ٠٫١°). */
    fun sun(epochMs: Long, lat: Double, lng: Double): Pair<Double, Double> {
        val jd = epochMs / 86400000.0 + 2440587.5
        val d = jd - 2451545.0
        val g = ((357.529 + 0.98560028 * d) % 360) * RAD
        val q = (280.459 + 0.98564736 * d) % 360
        val l = (q + 1.915 * sin(g) + 0.020 * sin(2 * g)) * RAD
        val e = (23.439 - 0.00000036 * d) * RAD
        val ra = (atan2(cos(e) * sin(l), cos(l)) / RAD / 15 + 24) % 24
        val dec = asin(sin(e) * sin(l))
        val eqt = (((q / 15 - ra + 12) % 24) + 24) % 24 - 12
        val ut = ((jd + 0.5) - floor(jd + 0.5)) * 24
        val h = 15 * (ut + lng / 15 + eqt - 12) * RAD
        val ph = lat * RAD
        val alt = asin(sin(ph) * sin(dec) + cos(ph) * cos(dec) * cos(h)) / RAD
        val az = atan2(-sin(h), tan(dec) * cos(ph) - sin(ph) * cos(h)) / RAD
        return Pair((az + 360) % 360, alt)
    }

    /** لحظةٌ تكون فيها الشمس في جهة القبلة تماماً (toward) أو خلفها تماماً (فيشير الظلّ إلى القبلة). */
    data class SunAlignment(val epochMs: Long, val toward: Boolean, val altitude: Double)

    private fun diff(a: Double, b: Double): Double = (((a - b + 540) % 360) + 360) % 360 - 180

    /** محاذيات اليوم المحلّي الذي يبدأ عند dayStartMs، والشمس فوق الأفق بثلاث درجات على الأقل. */
    fun sunAlignments(dayStartMs: Long, lat: Double, lng: Double, stepMinutes: Int = 1): List<SunAlignment> {
        val b = bearing(lat, lng)
        val targets = listOf(b to true, ((b + 180) % 360) to false)
        val out = mutableListOf<SunAlignment>()
        var prev: List<Double>? = null
        var m = 0
        while (m <= 1440) {
            val t = dayStartMs + m * 60000L
            val (az, alt) = sun(t, lat, lng)
            val cur = targets.map { diff(az, it.first) }
            val p = prev
            if (p != null && alt > 3) {
                for (k in 0..1) if (p[k] < 0 && cur[k] >= 0 && abs(cur[k] - p[k]) < 90) out += SunAlignment(t, targets[k].second, alt)
            }
            prev = cur
            m += stepMinutes
        }
        return out.sortedBy { it.epochMs }
    }

    /** أوّل يومٍ (من الغد، حتى سنة) فيه محاذاة؛ يُعيد بداية ذلك اليوم أو null. */
    fun nextAlignmentDay(dayStartMs: Long, lat: Double, lng: Double): Long? {
        for (i in 1..366) {
            val d = dayStartMs + i * 86400000L
            if (sunAlignments(d, lat, lng, 4).isNotEmpty()) return d
        }
        return null
    }
}
