package com.shirazi.duaa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Settings
import com.shirazi.duaa.data.traits
import kotlin.math.roundToInt

/** محاسبة النفس اليومية — عبادة مأثورة عن الإمام الكاظم (ع). */
private val muhasabaItems = listOf(
    "هل صلّيتُ الفرائض الخمس في أوقاتها؟",
    "هل ذكرتُ الله وسبّحتُ في يومي؟",
    "هل قرأتُ شيئاً من القرآن؟",
    "هل صنتُ لساني عن الغيبة والكذب؟",
    "هل أحسنتُ إلى والديّ أو أهلي؟",
    "هل نفعتُ أحداً أو قضيتُ حاجةً لمؤمن؟",
    "هل تجنّبتُ ما يُغضِب الله؟",
    "هل استغفرتُ وتُبتُ ممّا قصّرتُ فيه؟",
)

@Composable
fun MuhasabaScreen(settings: Settings, pal: DuaaPalette, onClose: () -> Unit) {
    val mask = settings.muhasabaMask.value
    val doneCount = (0 until muhasabaItems.size).count { mask and (1 shl it) != 0 }
    val pct = (doneCount * 100f / muhasabaItems.size).roundToInt()

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                ScreenTopBar("محاسبة النفس", pal, onClose)
                Column(Modifier.padding(18.dp)) {

                    // مقدّمة
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(RoundedCornerShape(16.dp))
                            .background(pal.emerald.copy(alpha = .10f)).padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        LineIcon(AppIcon.Scroll, pal.emerald, 18.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "قال الإمام الكاظم (ع): «لَيسَ مِنّا مَن لَم يُحاسِب نَفسَهُ في كُلِّ يَوم». راجِع يومك كل ليلة بصدق، واشكر الله على ما وُفِّقت، واستغفر لما قصّرت.",
                            color = pal.emerald, fontSize = 13.sp, lineHeight = 22.sp
                        )
                    }

                    // حلقة التقدّم
                    Column(
                        Modifier.fillMaxWidth().paper(pal, 20).padding(vertical = 22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("$pct%", color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 40.sp)
                        Text("$doneCount من ${muhasabaItems.size}", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Box(Modifier.fillMaxWidth().padding(horizontal = 24.dp).height(8.dp).clip(RoundedCornerShape(4.dp)).background(pal.line)) {
                            Box(Modifier.fillMaxWidth(doneCount.toFloat() / muhasabaItems.size).height(8.dp)
                                .clip(RoundedCornerShape(4.dp)).background(pal.gold))
                        }
                    }
                    Spacer(Modifier.height(16.dp))

                    // ===== اتّجاه المحاسبة عبر الزمن =====
                    run {
                        val days = settings.muhasabaDaysActive(30)
                        val avg = settings.muhasabaAvg(30)
                        val bestDow = settings.muhasabaBestWeekday()
                        val dowNames = listOf("الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
                        Column(Modifier.fillMaxWidth().paper(pal, 20).padding(18.dp)) {
                            Text("اتّجاهك (آخر ١٤ يوماً)", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                            Spacer(Modifier.height(14.dp))
                            // أعمدة آخر ١٤ يوماً (اليمين=الأقدم، اليسار=اليوم)
                            Row(Modifier.fillMaxWidth().height(70.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                for (offset in 13 downTo 0) {
                                    val v = settings.muhasabaForOffset(offset)
                                    val frac = (v / 8f).coerceIn(0f, 1f)
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.Bottom, horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(
                                            Modifier.fillMaxWidth().fillMaxHeight(if (frac == 0f) 0.04f else frac)
                                                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                                .background(if (v == 0) pal.line.copy(alpha = .5f) else pal.emerald.copy(alpha = 0.4f + frac * 0.6f))
                                        )
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("اليوم", color = pal.ink2, fontSize = 10.sp)
                                Text("قبل ١٤ يوماً", color = pal.ink2, fontSize = 10.sp)
                            }
                            Spacer(Modifier.height(14.dp))
                            // إحصاءات
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("$days", color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                                    Text("يوماً محاسَباً", color = pal.ink2, fontSize = 10.sp)
                                }
                                Box(Modifier.width(1.dp).height(36.dp).background(pal.line))
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(String.format("%.1f", avg), color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                                    Text("متوسّط ٨/يوم", color = pal.ink2, fontSize = 10.sp)
                                }
                            }
                            if (bestDow != null && days >= 3) {
                                Spacer(Modifier.height(14.dp))
                                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(pal.gold.copy(alpha = .12f)).padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        LineIcon(AppIcon.Sparkle, pal.gold, 16.dp)
                                        Spacer(Modifier.width(8.dp))
                                        Text("أكثر أيامك التزاماً: ${dowNames[bestDow]}", color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            } else if (days < 3) {
                                Spacer(Modifier.height(12.dp))
                                Text("تابِع المحاسبة أياماً لترى اتّجاهك ونمطك الأسبوعيّ.", color = pal.ink2, fontSize = 11.sp, lineHeight = 17.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))

                    // ===== سؤال صفة الشهر — يظهر أثناء رحلة تهذيبٍ جارية ويوثّق عمل اليوم بالضدّ =====
                    var traitRefresh by remember { mutableStateOf(0) }
                    val trTrait = traits.firstOrNull { it.id == settings.traitId.value }
                    if (settings.traitActive.value && trTrait != null) {
                        key(traitRefresh) {
                            val trDone = settings.traitDoneToday()
                            Row(
                                Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp))
                                    .background(if (trDone) pal.gold.copy(alpha = .14f) else pal.gold.copy(alpha = .07f))
                                    .border(1.dp, pal.gold.copy(alpha = if (trDone) .55f else .3f), RoundedCornerShape(16.dp))
                                    .clickable {
                                        if (trDone) settings.traitUntickToday() else settings.traitTickToday()
                                        traitRefresh++
                                    }.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier.size(28.dp).clip(CircleShape)
                                        .background(if (trDone) pal.gold else Color.Transparent)
                                        .border(1.5.dp, if (trDone) pal.gold else pal.gold.copy(alpha = .5f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) { if (trDone) Text("✓", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("سؤال صفة الشهر — تخلية «${trTrait.vice}»", color = pal.gold,
                                        fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                                    Spacer(Modifier.height(2.dp))
                                    Text("هل أتممتَ عملَ اليوم بالضدّ؟ ${trTrait.commitment}",
                                        fontSize = 14.sp, lineHeight = 23.sp, fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                    }

                    // القائمة
                    muhasabaItems.forEachIndexed { idx, q ->
                        val done = mask and (1 shl idx) != 0
                        Row(
                            Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp))
                                .background(if (done) pal.good.copy(alpha = .10f) else pal.cardFill)
                                .border(1.dp, if (done) pal.good.copy(alpha = .4f) else pal.cardBorder, RoundedCornerShape(16.dp))
                                .clickable { settings.toggleMuhasaba(idx) }.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(28.dp).clip(CircleShape)
                                    .background(if (done) pal.good else Color.Transparent)
                                    .border(1.5.dp, if (done) pal.good else pal.line, CircleShape),
                                contentAlignment = Alignment.Center
                            ) { if (done) Text("✓", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
                            Spacer(Modifier.width(14.dp))
                            Text(q, fontSize = 15.sp, lineHeight = 24.sp, fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    val msg = when {
                        pct == 100 -> "ما شاء الله، يومٌ مبارك. تقبّل الله وثبّتك."
                        pct >= 60 -> "خيرٌ كثير، أكمِل ما بقي واستغفر لما فات."
                        pct > 0 -> "بداية طيّبة، حاسِب نفسك بصدق وجدّد العزم غداً."
                        else -> "راجِع يومك بصدق؛ كل خطوة نحو الله مباركة."
                    }
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.gold.copy(alpha = .12f)).padding(14.dp)) {
                        Text(msg, color = pal.gold, fontSize = 14.sp, lineHeight = 23.sp, fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                    Spacer(Modifier.height(90.dp))
                }
            }
        }
    }
}
