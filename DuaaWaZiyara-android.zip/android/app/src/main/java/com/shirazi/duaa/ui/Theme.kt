package com.shirazi.duaa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

/* =====================================================================
 * هوية بصرية: "صفاء" — تيل هادئ + خلفية نعناعية فاتحة + أبيض واسع.
 * مستوحاة من تصميم Muslim Apps: بطاقات كبيرة الانحناء، ظلال ناعمة،
 * خطّ خفيف، مساحات بيضاء سخيّة. التوقيع: نجمة ثمانية زخرفية.
 * أسماء الحقول محفوظة كما هي حتى لا تنكسر بقية الشاشات؛
 * "gold" صار لكنة رمليّة دافئة، و"emerald" صار التيل الأساسي.
 * ===================================================================== */

// ---- التيل الأساسي ----
val Teal          = Color(0xFF3E94A6)   // التيل الرئيسي
val TealDeep      = Color(0xFF2C7C8E)
val TealDark      = Color(0xFF1F5E6E)
val TealLit       = Color(0xFF5FB3C4)
val TealSoft      = Color(0xFFBFE0E6)   // تيل فاتح للحوافّ والخلفيات

// ---- الخلفيات الفاتحة ----
val Mint          = Color(0xFFF1F7F8)   // خلفية نعناعية شديدة الفتح
val MintRaised    = Color(0xFFFFFFFF)   // البطاقات بيضاء
val InkTextC      = Color(0xFF1E3338)
val InkText2C     = Color(0xFF7B8C90)
val HairLine      = Color(0xFFE6EEF0)

// ---- لكنة رمليّة دافئة (بديل الذهب) ----
val Sand          = Color(0xFFC9A86A)
val SandSoft      = Color(0xFFEADFC8)
val Saffron       = Color(0xFFD89A57)

// ---- الوضع الليلي ----
val NightBg       = Color(0xFF0C1A1E)
val NightRaised   = Color(0xFF13262B)
val NightInk      = Color(0xFFE6F0F2)
val NightInk2     = Color(0xFF8AA3A8)
val NightLine     = Color(0xFF20383E)
val TealNight     = Color(0xFF54AEC0)
val SandNight     = Color(0xFFD9B978)

val Danger = Color(0xFFC4584A); val DangerD = Color(0xFFE08B7C)
val Good   = Color(0xFF2E9E84); val GoodD   = Color(0xFF5FC4A8)
val Mid    = Color(0xFFB9863A); val MidD    = Color(0xFFD9AE5E)

private val LightScheme = lightColorScheme(
    primary = Teal, onPrimary = Color.White, secondary = Sand, onSecondary = Color.White,
    background = Mint, onBackground = InkTextC, surface = MintRaised, onSurface = InkTextC,
    surfaceVariant = Color(0xFFE8F1F2), onSurfaceVariant = InkText2C, outline = HairLine, error = Danger
)
private val DarkScheme = darkColorScheme(
    primary = TealNight, onPrimary = Color(0xFF06140F), secondary = SandNight, onSecondary = Color(0xFF18120A),
    background = NightBg, onBackground = NightInk, surface = NightRaised, onSurface = NightInk,
    surfaceVariant = Color(0xFF17292F), onSurfaceVariant = NightInk2, outline = NightLine, error = DangerD
)

class DuaaPalette(
    val gold: Color, val goldSoft: Color, val emerald: Color, val emeraldDeep: Color,
    val ink2: Color, val line: Color, val surface2: Color,
    val danger: Color, val good: Color, val mid: Color, val dark: Boolean
) {
    val saffron get() = if (dark) Color(0xFFE0A463) else Saffron
    // الترويسة: تدرّج تيل ناعم (لا حبر داكن)
    // تدرّجات غنيّة تنتقل في الدرجة اللونية (لا اللمعان فقط) — عمقٌ جوهريّ كالتطبيقات الفاخرة
    val heroBrush get() = Brush.linearGradient(
        if (dark) listOf(Color(0xFF1A4A52), Color(0xFF123238), Color(0xFF0C1A1E))
        else listOf(Color(0xFF5FC4D0), Color(0xFF3E94A6), Color(0xFF2B6E84))  // سماوي → تيل → تيل عميق مائل للأزرق
    )
    val pillBrush get() = Brush.horizontalGradient(
        if (dark) listOf(Color(0xFF2C7C8E), Color(0xFF52B9C4)) else listOf(Color(0xFF2B7C8E), Color(0xFF5FC4D0))
    )
    // "goldBrush" صار تدرّج تيل للأزرار الأساسية (الاسم محفوظ)
    val goldBrush get() = Brush.horizontalGradient(
        if (dark) listOf(Color(0xFF2C7C8E), Color(0xFF54AEC0)) else listOf(Color(0xFF2B6E84), Color(0xFF3E94A6), Color(0xFF5FC4D0))
    )
    val cardFill get() = if (dark) NightRaised else MintRaised
    val cardBorder get() = if (dark) NightLine else HairLine
    val bgBrush get() = if (dark)
        Brush.verticalGradient(listOf(Color(0xFF0C1A1E), Color(0xFF0D1D21), Color(0xFF0C1A1E)))
    else Brush.verticalGradient(listOf(Color(0xFFF1F7F8), Color(0xFFEAF3F4), Color(0xFFF1F7F8)))
}
fun palette(dark: Boolean) = if (dark) DuaaPalette(
    SandNight, Color(0xFF5E5230), TealNight, Color(0xFF0F2A30), NightInk2, NightLine, Color(0xFF17292F),
    DangerD, GoodD, MidD, true
) else DuaaPalette(
    Sand, SandSoft, Teal, TealDark, InkText2C, HairLine, Color(0xFFE8F1F2),
    Danger, Good, Mid, false
)

// بطاقة ناعمة: ظلٌّ خفيفٌ محايدٌ ناعم (في الوضع الفاتح) + انحناء كبير + حدّ شعريّ
// الظلّ الآن مركزيّ في الرمز، فترتفع كلّ البطاقات بنعومةٍ متّسقة كتطبيقات Apple
/** استجابةٌ لمسيّة: تصغيرٌ لطيفٌ عند الضغط يمنح إحساساً ماديّاً بالتفاعل. */
fun Modifier.pressable(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.965f else 1f, label = "press")
    this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

/** بطاقة بطل: ظلّ ملوّن مضيء + زوايا ٢٨ — الخلفية (التدرّج) يوفّرها المستدعي. */
fun Modifier.heroCard(accent: Color, radius: Int = 28, elevation: Int = 12) = this
    .shadow(elevation.dp, RoundedCornerShape(radius.dp), spotColor = accent.copy(alpha = .30f))
    .clip(RoundedCornerShape(radius.dp))

/** بطاقة متدرّجة: ظلّ أسود خفيف + قصّ — للبطاقات ذات الخلفيات الملوّنة. */
fun Modifier.gradientCard(radius: Int = 20, elevation: Int = 4) = this
    .shadow(elevation.dp, RoundedCornerShape(radius.dp), spotColor = Color.Black.copy(alpha = .15f))
    .clip(RoundedCornerShape(radius.dp))

fun Modifier.paper(pal: DuaaPalette, radius: Int = 24) = this
    .shadow(
        elevation = if (pal.dark) 0.dp else 5.dp,
        shape = RoundedCornerShape(radius.dp),
        clip = false,
        spotColor = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.10f),
        ambientColor = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.05f)
    )
    .clip(RoundedCornerShape(radius.dp))
    .background(pal.cardFill)
    .border(1.dp, pal.cardBorder, RoundedCornerShape(radius.dp))

fun Modifier.glass(pal: DuaaPalette, radius: Int = 24) = paper(pal, radius)

@Composable
fun DuaaTheme(dark: Boolean, content: @Composable () -> Unit) {
    // جعل Cairo الخطّ الافتراضي لكلّ نصوص الواجهة عبر MaterialTheme،
    // فتنتقل الهوية للتطبيق كلّه دون تعديل كلّ عنصر نصّ على حدة.
    val base = androidx.compose.material3.Typography()
    val cairo = AppFonts.ui
    val typography = androidx.compose.material3.Typography(
        displayLarge = base.displayLarge.copy(fontFamily = cairo),
        displayMedium = base.displayMedium.copy(fontFamily = cairo),
        displaySmall = base.displaySmall.copy(fontFamily = cairo),
        headlineLarge = base.headlineLarge.copy(fontFamily = cairo),
        headlineMedium = base.headlineMedium.copy(fontFamily = cairo),
        headlineSmall = base.headlineSmall.copy(fontFamily = cairo),
        titleLarge = base.titleLarge.copy(fontFamily = cairo),
        titleMedium = base.titleMedium.copy(fontFamily = cairo),
        titleSmall = base.titleSmall.copy(fontFamily = cairo),
        bodyLarge = base.bodyLarge.copy(fontFamily = cairo),
        bodyMedium = base.bodyMedium.copy(fontFamily = cairo),
        bodySmall = base.bodySmall.copy(fontFamily = cairo),
        labelLarge = base.labelLarge.copy(fontFamily = cairo),
        labelMedium = base.labelMedium.copy(fontFamily = cairo),
        labelSmall = base.labelSmall.copy(fontFamily = cairo)
    )
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, typography = typography) {
        // ضمان أن حتى نصوص Text() التي تحدّد الحجم/الوزن فقط (بلا style) ترث خطّ Cairo
        androidx.compose.runtime.CompositionLocalProvider(
            androidx.compose.material3.LocalTextStyle provides androidx.compose.material3.LocalTextStyle.current.copy(fontFamily = AppFonts.ui),
            content = content
        )
    }
}
