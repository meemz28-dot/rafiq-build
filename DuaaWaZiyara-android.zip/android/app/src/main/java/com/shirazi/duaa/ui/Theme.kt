package com.shirazi.duaa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp

/* =====================================================================
 * هوية بصرية: "محراب" — زمرّديٌّ عميق + ورقٌ عاجيّ دافئ + لمسةُ ذهبٍ عتيق.
 * لونٌ أساسيٌّ واحد ولكنةٌ واحدة، بطاقات بيضاء هادئة، وعناوين صفحاتٍ كبيرة بدل الأشرطة الملوّنة.
 * التوقيع: نجمة ثمانية زخرفية.
 * أسماء الحقول محفوظة كما هي حتى لا تنكسر بقية الشاشات؛
 * "gold" صار لكنة رمليّة دافئة، و"emerald" صار التيل الأساسي.
 * ===================================================================== */

// ---- التيل الأساسي ----
val Teal          = Color(0xFF17695F)   // الزمرّدي الأساسي
val TealDeep      = Color(0xFF10574F)
val TealDark      = Color(0xFF0B4038)
val TealLit       = Color(0xFF3C8F84)
val TealSoft      = Color(0xFFCFE3DE)   // تيل فاتح للحوافّ والخلفيات

// ---- الخلفيات الفاتحة ----
val Mint          = Color(0xFFF5F2EA)   // خلفية نعناعية شديدة الفتح
val MintRaised    = Color(0xFFFFFFFF)   // البطاقات بيضاء
val InkTextC      = Color(0xFF17241F)
val InkText2C     = Color(0xFF66736E)
val HairLine      = Color(0xFFE6E0D2)

// ---- لكنة رمليّة دافئة (بديل الذهب) ----
val Sand          = Color(0xFFB08433)
val SandSoft      = Color(0xFFEEE2C8)
val Saffron       = Color(0xFFC98A3E)

// ---- الوضع الليلي ----
val NightBg       = Color(0xFF0C1412)
val NightRaised   = Color(0xFF141F1C)
val NightInk      = Color(0xFFECE8DE)
val NightInk2     = Color(0xFF93A19C)
val NightLine     = Color(0xFF22302C)
val TealNight     = Color(0xFF4DB39F)
val SandNight     = Color(0xFFD6B06A)

val Danger = Color(0xFFB9503F); val DangerD = Color(0xFFE08B7C)
val Good   = Color(0xFF2E8B6E); val GoodD   = Color(0xFF5FBF9F)
val Mid    = Color(0xFFB07D2E); val MidD    = Color(0xFFD9AE5E)

private val LightScheme = lightColorScheme(
    primary = Teal, onPrimary = Color.White, secondary = Sand, onSecondary = Color.White,
    background = Mint, onBackground = InkTextC, surface = MintRaised, onSurface = InkTextC,
    surfaceVariant = Color(0xFFEDE9DF), onSurfaceVariant = InkText2C, outline = HairLine, error = Danger
)
private val DarkScheme = darkColorScheme(
    primary = TealNight, onPrimary = Color(0xFF06140F), secondary = SandNight, onSecondary = Color(0xFF18120A),
    background = NightBg, onBackground = NightInk, surface = NightRaised, onSurface = NightInk,
    surfaceVariant = Color(0xFF1A2724), onSurfaceVariant = NightInk2, outline = NightLine, error = DangerD
)

class DuaaPalette(
    val gold: Color, val goldSoft: Color, val emerald: Color, val emeraldDeep: Color,
    val ink2: Color, val line: Color, val surface2: Color,
    val danger: Color, val good: Color, val mid: Color, val dark: Boolean
) {
    val saffron get() = if (dark) Color(0xFFE0A463) else Saffron
    // الترويسة: تدرّج تيل ناعم (لا حبر داكن)
    // تدرّجات غنيّة تنتقل في الدرجة اللونية (لا اللمعان فقط) — عمقٌ جوهريّ كالتطبيقات الفاخرة
    val heroBrush get() = Brush.linearGradient(
        if (dark) listOf(Color(0xFF1A4740), Color(0xFF11302B), Color(0xFF0C1412))
        else listOf(Color(0xFF1F7A6D), Color(0xFF135C52), Color(0xFF0C433B))  // زمرّدي → زمرّدي عميق
    )
    val pillBrush get() = Brush.horizontalGradient(
        if (dark) listOf(Color(0xFF1F7A6D), Color(0xFF2E9784)) else listOf(Color(0xFF135C52), Color(0xFF1F7A6D))
    )
    // "goldBrush" صار تدرّج تيل للأزرار الأساسية (الاسم محفوظ)
    val goldBrush get() = Brush.horizontalGradient(
        if (dark) listOf(Color(0xFF1F7A6D), Color(0xFF2E9784)) else listOf(Color(0xFF0F4F46), Color(0xFF17695F), Color(0xFF1F7A6D))
    )
    val cardFill get() = if (dark) NightRaised else MintRaised
    val cardBorder get() = if (dark) NightLine else HairLine
    val bgBrush get() = if (dark)
        Brush.verticalGradient(listOf(Color(0xFF0C1412), Color(0xFF0D1614), Color(0xFF0C1412)))
    else Brush.verticalGradient(listOf(Color(0xFFF7F4EC), Color(0xFFF3EFE6), Color(0xFFF5F2EA)))
}
fun palette(dark: Boolean) = if (dark) DuaaPalette(
    SandNight, Color(0xFF5E5230), TealNight, Color(0xFF0F2A26), NightInk2, NightLine, Color(0xFF1A2724),
    DangerD, GoodD, MidD, true
) else DuaaPalette(
    Sand, SandSoft, Teal, TealDark, InkText2C, HairLine, Color(0xFFEDE9DF),
    Danger, Good, Mid, false
)

// بطاقة ناعمة: ظلٌّ خفيفٌ محايدٌ ناعم (في الوضع الفاتح) + انحناء كبير + حدّ شعريّ
// الظلّ الآن مركزيّ في الرمز، فترتفع كلّ البطاقات بنعومةٍ متّسقة كتطبيقات Apple
/** استجابةٌ لمسيّة: تصغيرٌ لطيفٌ عند الضغط يمنح إحساساً ماديّاً بالتفاعل. */
fun Modifier.pressable(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.965f else 1f, label = "press")
    this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

/** بطاقة بطل: ظلّ ملوّن مضيء + زوايا ٢٨ — الخلفية (التدرّج) يوفّرها المستدعي. */
fun Modifier.heroCard(accent: Color, radius: Int = 28, elevation: Int = 12) = this
    .shadow(elevation.dp, RoundedCornerShape(radius.dp), spotColor = accent.copy(alpha = .30f))
    .clip(RoundedCornerShape(radius.dp))

/** بطاقة متدرّجة: ظلّ أسود خفيف + قصّ — للبطاقات ذات الخلفيات الملوّنة. */
fun Modifier.gradientCard(radius: Int = 20, elevation: Int = 4) = this
    .shadow(elevation.dp, RoundedCornerShape(radius.dp), spotColor = Color.Black.copy(alpha = .15f))
    .clip(RoundedCornerShape(radius.dp))

fun Modifier.paper(pal: DuaaPalette, radius: Int = 24) = this
    .shadow(
        elevation = if (pal.dark) 0.dp else 5.dp,
        shape = RoundedCornerShape(radius.dp),
        clip = false,
        spotColor = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.10f),
        ambientColor = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.05f)
    )
    .clip(RoundedCornerShape(radius.dp))
    .background(pal.cardFill)
    .border(1.dp, pal.cardBorder, RoundedCornerShape(radius.dp))

fun Modifier.glass(pal: DuaaPalette, radius: Int = 24) = paper(pal, radius)

@Composable
fun DuaaTheme(dark: Boolean, content: @Composable () -> Unit) {
    // جعل Cairo الخطّ الافتراضي لكلّ نصوص الواجهة عبر MaterialTheme،
    // فتنتقل الهوية للتطبيق كلّه دون تعديل كلّ عنصر نصّ على حدة.
    val base = androidx.compose.material3.Typography()
    val cairo = AppFonts.ui
    val typography = androidx.compose.material3.Typography(
        displayLarge = base.displayLarge.copy(fontFamily = cairo),
        displayMedium = base.displayMedium.copy(fontFamily = cairo),
        displaySmall = base.displaySmall.copy(fontFamily = cairo),
        headlineLarge = base.headlineLarge.copy(fontFamily = cairo),
        headlineMedium = base.headlineMedium.copy(fontFamily = cairo),
        headlineSmall = base.headlineSmall.copy(fontFamily = cairo),
        titleLarge = base.titleLarge.copy(fontFamily = cairo),
        titleMedium = base.titleMedium.copy(fontFamily = cairo),
        titleSmall = base.titleSmall.copy(fontFamily = cairo),
        bodyLarge = base.bodyLarge.copy(fontFamily = cairo),
        bodyMedium = base.bodyMedium.copy(fontFamily = cairo),
        bodySmall = base.bodySmall.copy(fontFamily = cairo),
        labelLarge = base.labelLarge.copy(fontFamily = cairo),
        labelMedium = base.labelMedium.copy(fontFamily = cairo),
        labelSmall = base.labelSmall.copy(fontFamily = cairo)
    )
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, typography = typography) {
        // ضمان أن حتى نصوص Text() التي تحدّد الحجم/الوزن فقط (بلا style) ترث خطّ Cairo
        androidx.compose.runtime.CompositionLocalProvider(
            androidx.compose.material3.LocalTextStyle provides androidx.compose.material3.LocalTextStyle.current.copy(fontFamily = AppFonts.ui),
            content = content
        )
    }
}


/**
 * زرّ أيقونةٍ بلا نصّ: مساحة لمسٍ لا تقلّ عن ٤٨dp (الحدّ الأدنى لإمكانية الوصول) مع إبقاء مظهره الأصغر كما هو،
 * واسمٌ يقرؤه قارئ الشاشة (TalkBack) بدل «زرّ» بلا معنى.
 */
fun Modifier.a11yIconButton(label: String, visual: Dp, bg: Color, radius: Dp = 12.dp, onClick: () -> Unit): Modifier {
    val pad = ((48.dp - visual) / 2).coerceAtLeast(0.dp)
    return this.size(maxOf(48.dp, visual))
        .clip(RoundedCornerShape(radius + pad))
        .clickable(onClick = onClick)
        .semantics { contentDescription = label; role = Role.Button }
        .padding(pad)
        .clip(RoundedCornerShape(radius))
        .background(bg)
}
