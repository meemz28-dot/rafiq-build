package com.shirazi.duaa.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.MasoomeenData

/** المعصومون الأربعة عشر عليهم السلام — قائمةٌ وصفحةُ سيرةٍ لكلّ معصوم. */
@Composable
fun MasoomeenScreen(pal: DuaaPalette, openReader: (String, String) -> Unit, onClose: () -> Unit) {
    var selected by remember { mutableStateOf<Int?>(null) }

    Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
        // القائمة
        AnimatedVisibility(visible = selected == null, enter = fadeIn(), exit = fadeOut()) {
            MasoomeenList(pal, onClose) { selected = it }
        }
        // صفحةُ التفاصيل
        AnimatedVisibility(
            visible = selected != null,
            enter = slideInHorizontally(initialOffsetX = { it / 3 }) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { it / 3 }) + fadeOut()
        ) {
            val idx = selected
            if (idx != null) {
                MasoomDetailPage(idx + 1, MasoomeenData.all[idx], ziyaraFor(idx), pal, openReader) { selected = null }
            }
        }
    }
}

/**
 * يربط كلَّ معصومٍ بزيارته في قسم الزيارات (المعرّف ضمن تصنيف "ziyarat").
 * أئمّةُ البقيع الأربعة (الحسن والسجّاد والباقر والصادق) يُزارون بالزيارة الجامعة لأئمّة البقيع.
 * الترتيب ثابتٌ مطابقٌ لقائمة MasoomeenData.all.
 */
private fun ziyaraFor(index: Int): String = when (index) {
    0 -> "z-nabi"       // النبيّ الأعظم ﷺ
    1 -> "z-zahra"      // فاطمة الزهراء (ع)
    2 -> "z-ali-najaf"  // أمير المؤمنين (ع)
    3 -> "z-baqi"       // الحسن المجتبى (ع) — أئمّة البقيع
    4 -> "z-warith"     // الحسين (ع) — زيارة وارث
    5 -> "z-baqi"       // زين العابدين (ع) — أئمّة البقيع
    6 -> "z-baqi"       // الباقر (ع) — أئمّة البقيع
    7 -> "z-baqi"       // الصادق (ع) — أئمّة البقيع
    8 -> "z-kadhim"     // الكاظم (ع)
    9 -> "z-redha"      // الرضا (ع)
    10 -> "z-jawad"     // الجواد (ع)
    11 -> "z-hadi"      // الهادي (ع)
    12 -> "z-askari"    // العسكريّ (ع)
    13 -> "z-yasin"     // المهديّ (عج) — زيارة آل ياسين
    else -> "z-jamia"   // افتراضي: الزيارة الجامعة الكبيرة
}

@Composable
private fun MasoomeenList(pal: DuaaPalette, onClose: () -> Unit, onSelect: (Int) -> Unit) {
    val haptics = rememberHaptics()
    val gemGrads = remember {
        listOf(
            categoryGradient("ziyarat"), categoryGradient("jumaa"), categoryGradient("munajat"),
            categoryGradient("rajab"), categoryGradient("hawaij"), categoryGradient("tarbiya"),
            categoryGradient("ramadan"), categoryGradient("sabah")
        )
    }
    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("المعصومون الأربعة عشر", pal, onClose)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            // بطاقةُ الصلاة على محمّدٍ وآله
            Box(
                Modifier.fillMaxWidth()
                    .heroCard(pal.emerald)
                    .background(pal.heroBrush)
            ) {
                IslamicPattern(Color.White.copy(alpha = .08f), Modifier.matchParentSize(), cell = 52f)
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 30.dp, horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("أهل بيت النبوّة ومعدن الرسالة", color = Color.White.copy(alpha = .82f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "اللّٰهُمَّ صَلِّ عَلىٰ مُحَمَّدٍ وَآلِ مُحَمَّد",
                        color = Color.White,
                        fontFamily = AppFonts.scripture,
                        fontWeight = FontWeight.Bold,
                        fontSize = 26.sp, lineHeight = 44.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(14.dp))
                    Text(
                        "الذين أذهب الله عنهم الرجس وطهّرهم تطهيراً",
                        color = Color.White.copy(alpha = .85f), fontSize = 13.sp, lineHeight = 22.sp, textAlign = TextAlign.Center
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("أهلُ الكساء وأئمّةُ الهدى", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))

            MasoomeenData.all.forEachIndexed { i, m ->
                MasoomCard(i + 1, m, gemGrads[i % gemGrads.size], pal) { haptics.tick(); onSelect(i) }
                Spacer(Modifier.height(12.dp))
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}

@Composable
private fun MasoomCard(num: Int, m: MasoomeenData.Masoom, grad: List<Color>, pal: DuaaPalette, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth()
            .gradientCard(20)
            .background(Brush.linearGradient(grad))
            .clickable(onClick = onClick)
    ) {
        IslamicPattern(Color.White.copy(alpha = .06f), Modifier.matchParentSize(), cell = 44f)
        Row(
            Modifier.fillMaxWidth().padding(vertical = 18.dp, horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                Text("$num", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(m.title, color = Color.White, fontFamily = AppFonts.scripture, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 32.sp)
                Spacer(Modifier.height(4.dp))
                Text(m.name, color = Color.White.copy(alpha = .85f), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(2.dp))
                Text(m.shrine, color = Color.White.copy(alpha = .7f), fontSize = 11.sp)
            }
            LineIcon(AppIcon.ChevronStart, Color.White.copy(alpha = .6f), 18.dp)
        }
    }
}

// ============ صفحةُ السيرة الكاملة ============
@Composable
private fun MasoomDetailPage(number: Int, m: MasoomeenData.Masoom, ziyaraId: String, pal: DuaaPalette, openReader: (String, String) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(pal.bgBrush)) {
        ScreenTopBar(m.title, pal, onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {

            // رأسٌ متدرّج: اللقب بخطّ النسخ + الاسم
            Box(
                Modifier.fillMaxWidth()
                    .heroCard(pal.emerald)
                    .background(pal.heroBrush)
            ) {
                IslamicPattern(Color.White.copy(alpha = .08f), Modifier.matchParentSize(), cell = 52f)
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 30.dp, horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(46.dp).clip(CircleShape).background(Color.White.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                        Text("$number", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(m.title, color = Color.White, fontFamily = AppFonts.scripture, fontWeight = FontWeight.Bold, fontSize = 36.sp, lineHeight = 52.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text(m.name, color = Color.White.copy(alpha = .9f), fontSize = 14.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(10.dp))
                    Text(m.rank, color = Color.White.copy(alpha = .82f), fontSize = 12.sp, lineHeight = 20.sp, textAlign = TextAlign.Center)
                }
            }
            Spacer(Modifier.height(16.dp))

            // بطاقةُ المعلومات الأساسيّة
            Column(Modifier.fillMaxWidth().paper(pal, 20).padding(18.dp)) {
                FactRow("الكنية", m.kunya, pal)
                FactDivider(pal)
                FactRow("المولد", m.birth, pal)
                FactDivider(pal)
                FactRow("الشهادة / الوفاة", m.passing, pal)
                FactDivider(pal)
                FactRow("المرقد الشريف", m.shrine, pal)
            }
            Spacer(Modifier.height(16.dp))

            // رابطُ الزيارة — يفتح زيارته في قسم الزيارات
            // أئمّةُ البقيع الأربعة (٤،٦،٧،٨) يُزارون بالزيارة الجامعة لأهل البقيع
            val isBaqi = (number - 1) in listOf(3, 5, 6, 7)
            val ziyaraTitle = if (isBaqi) "اقرأ زيارة أئمّة البقيع" else "اقرأ زيارته الشريفة"
            val ziyaraSub = if (isBaqi) "يُزارون جماعةً في البقيع" else "تفتحُ في قسم الزيارات"
            Box(
                Modifier.fillMaxWidth()
                    .heroCard(pal.gold, radius = 18, elevation = 8)
                    .background(Brush.linearGradient(categoryGradient("ziyarat")))
                    .clickable { openReader("ziyarat", ziyaraId) }
                    .padding(vertical = 16.dp, horizontal = 18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                        LineIcon(AppIcon.Book, Color.White, 21.dp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(ziyaraTitle, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(2.dp))
                        Text(ziyaraSub, color = Color.White.copy(alpha = .8f), fontSize = 11.sp)
                    }
                    LineIcon(AppIcon.ChevronStart, Color.White.copy(alpha = .7f), 18.dp)
                }
            }
            Spacer(Modifier.height(16.dp))

            // العصر
            SectionLabel("العصر والمعاصرون", pal)
            Box(Modifier.fillMaxWidth().paper(pal, 18).padding(16.dp)) {
                Text(m.era, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, lineHeight = 26.sp)
            }
            Spacer(Modifier.height(16.dp))

            // معالم السيرة
            SectionLabel("من معالم سيرته", pal)
            Column(Modifier.fillMaxWidth().paper(pal, 18).padding(vertical = 8.dp, horizontal = 16.dp)) {
                m.highlights.forEachIndexed { i, h ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.Top) {
                        Box(Modifier.padding(top = 6.dp).size(7.dp).clip(CircleShape).background(pal.gold))
                        Spacer(Modifier.width(12.dp))
                        Text(h, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, lineHeight = 24.sp, modifier = Modifier.weight(1f))
                    }
                    if (i < m.highlights.size - 1) FactDivider(pal)
                }
            }
            Spacer(Modifier.height(16.dp))

            // نبذةٌ جامعة
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                    .background(pal.emerald.copy(alpha = if (pal.dark) .14f else .08f)).padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Box(Modifier.width(3.dp).height(40.dp).clip(RoundedCornerShape(99.dp)).background(pal.emerald))
                    Spacer(Modifier.width(14.dp))
                    Text(m.note, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, lineHeight = 24.sp, fontWeight = FontWeight.Medium)
                }
            }
            Spacer(Modifier.height(14.dp))

            // عودة
            BigButton("العودة إلى القائمة", pal, false, onBack)
            Spacer(Modifier.height(30.dp))
        }
    }
}

@Composable
private fun SectionLabel(text: String, pal: DuaaPalette) {
    Text(text, color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
private fun FactRow(label: String, value: String, pal: DuaaPalette) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(label, color = pal.ink2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(3.dp))
        Text(value, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun FactDivider(pal: DuaaPalette) {
    Box(Modifier.fillMaxWidth().height(1.dp).background(pal.line.copy(alpha = .5f)))
}
