package com.shirazi.duaa

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.shirazi.duaa.data.Settings
import com.shirazi.duaa.ui.DuaaApp

class MainActivity : ComponentActivity() {

    private val notifyPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val settings = Settings(this)
        // لون خلفية النافذة يتبع ثيم التطبيق المحفوظ — فلا وميض عند الإقلاع مهما كان اختيار المستخدم
        val isDark = settings.theme.value == "dark"
        window.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(
                android.graphics.Color.parseColor(if (isDark) "#0C1A1E" else "#F1F7F8")
            )
        )
        // إعادة جدولة التنبيهات عند فتح التطبيق (تصحيح ذاتي إن سقطت المنبّهات)
        if (settings.notifyEnabled.value) {
            try { com.shirazi.duaa.notify.PrayerScheduler.reschedule(this) } catch (_: Exception) {}
        }
        if (settings.dhikrEnabled.value) {
            try { com.shirazi.duaa.notify.DhikrScheduler.reschedule(this) } catch (_: Exception) {}
        }
        setContent {
            DuaaApp(settings, onRequestNotifyPermission = { requestNotifyPermission() })
        }
    }

    override fun onResume() {
        super.onResume()
        // حدّث الودجت عند العودة للتطبيق (لتعكس أيّ تغيّر في الموقع أو الطريقة)
        try { com.shirazi.duaa.widget.PrayerWidget.updateAll(this) } catch (_: Exception) {}
    }

    private fun requestNotifyPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notifyPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
