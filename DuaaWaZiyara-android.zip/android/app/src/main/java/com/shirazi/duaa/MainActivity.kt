package com.shirazi.duaa

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.shirazi.duaa.data.Settings
import com.shirazi.duaa.ui.DuaaApp

class MainActivity : ComponentActivity() {

    private val notifyPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val settings = Settings(this)
        // لون خلفية النافذة يتبع ثيم التطبيق المحفوظ — فلا وميض عند الإقلاع مهما كان اختيار المستخدم
        val isDark = settings.theme.value == "dark"
        window.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(
                android.graphics.Color.parseColor(if (isDark) "#0C1412" else "#F5F2EA")
            )
        )
        // إعادة جدولة التنبيهات عند فتح التطبيق (تصحيح ذاتي إن سقطت المنبّهات)
        if (settings.notifyEnabled.value) {
            try { com.shirazi.duaa.notify.PrayerScheduler.reschedule(this) } catch (_: Exception) {}
        }
        if (settings.dhikrEnabled.value) {
            try { com.shirazi.duaa.notify.DhikrScheduler.reschedule(this) } catch (_: Exception) {}
        }
        // تذكيرات الروتين والمناسبات: تُعاد جدولتها عند كلّ فتح، لأنّها تُخطَّط ليومين فقط
        run {
            try { com.shirazi.duaa.notify.RoutineScheduler.reschedule(this) } catch (_: Exception) {}
        }
        // نسخة التطوير فقط: فتح صفحةٍ بعينها لالتقاط صور الشاشات آلياً (لا أثر له في نسخة المتجر)
        val debuggable = (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
        val start = if (debuggable) intent?.extras else null
        if (start?.getBoolean("skip_onboarding") == true && !settings.onboardingDone.value) settings.finishOnboarding()
        start?.getString("theme")?.let { settings.theme.value = it }
        setContent {
            DuaaApp(settings, onRequestNotifyPermission = { requestNotifyPermission() },
                startTab = start?.getString("tab"), startScreen = start?.getString("screen"),
                startSheet = start?.getString("sheet"),
                startReader = start?.getString("reader")?.split('/')?.takeIf { it.size == 2 }?.let { it[0] to it[1] })
        }
    }

    override fun onResume() {
        super.onResume()
        // حدّث الودجت عند العودة للتطبيق (لتعكس أيّ تغيّر في الموقع أو الطريقة)
        try { com.shirazi.duaa.widget.PrayerWidget.updateAll(this) } catch (_: Exception) {}
        // إن منح المستخدم «المنبّهات والتذكيرات» في الإعدادات ثم عاد: أعِد الجدولة بدقّة
        if (pendingExactAlarmCheck) {
            pendingExactAlarmCheck = false
            val s = Settings(this)
            if (s.notifyEnabled.value) try { com.shirazi.duaa.notify.PrayerScheduler.reschedule(this) } catch (_: Exception) {}
            try { com.shirazi.duaa.notify.RoutineScheduler.reschedule(this) } catch (_: Exception) {}
            if (s.dhikrEnabled.value) try { com.shirazi.duaa.notify.DhikrScheduler.reschedule(this) } catch (_: Exception) {}
        }
    }

    private var pendingExactAlarmCheck = false

    private fun requestNotifyPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notifyPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        // أندرويد ١٢ فما فوق: التنبيهات الدقيقة تحتاج إذن «المنبّهات والتذكيرات» (يُمنع افتراضياً في أندرويد ١٤ فما فوق).
        // بدونه تبقى التنبيهات تعمل لكن قد تتأخّر، فنشرح السبب ونفتح شاشة الإذن مرّةً عند تفعيل التنبيهات.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(android.app.AlarmManager::class.java)
            if (am != null && !am.canScheduleExactAlarms()) {
                android.widget.Toast.makeText(this, "لتصل تنبيهات الصلاة في وقتها بدقّة، فعّل «المنبّهات والتذكيرات» لتطبيق رفيق المؤمن", android.widget.Toast.LENGTH_LONG).show()
                try {
                    pendingExactAlarmCheck = true
                    startActivity(android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, android.net.Uri.parse("package:$packageName")))
                } catch (_: Exception) { pendingExactAlarmCheck = false }
            }
        }
    }
}
