package com.shirazi.duaa.logic

import com.shirazi.duaa.data.Data
import java.util.Calendar

/**
 * محرّك «ماذا أقرأ الآن؟» — يقترح المحتوى الأنسب للحظة الحالية
 * بحسب: المناسبة الهجرية الخاصّة، ثمّ ليلة/يوم الأسبوع، ثمّ وقت اليوم.
 */
object Recommend {

    data class Suggestion(
        val catId: String,
        val itemId: String,
        val reason: String,   // لماذا اقتُرح (يظهر للمستخدم)
        val label: String     // وصف قصير للزرّ
    )

    /** يتحقّق أن العنصر موجود فعلاً قبل اقتراحه (حتى لا يقترح معرّفاً محذوفاً). */
    private fun exists(catId: String, itemId: String): Boolean =
        Data.categories.firstOrNull { it.id == catId }?.items?.any { it.id == itemId } == true

    private fun sug(catId: String, itemId: String, reason: String, label: String): Suggestion? =
        if (exists(catId, itemId)) Suggestion(catId, itemId, reason, label) else null

    /**
     * يعيد أفضل اقتراحٍ متاح بحسب التاريخ الهجري (hMonth/hDay)، واليوم الميلادي للأسبوع،
     * والساعة. weekday: 0=الأحد .. 6=السبت (كما في تقويم أندرويد - 1).
     */
    fun now(hMonth: Int, hDay: Int, weekday: Int, hour: Int): Suggestion {
        // ١) مناسبات خاصّة ذات أعمال معروفة
        specialOccasion(hMonth, hDay)?.let { return it }

        // ٢) ليالي وأيام الأسبوع ذات الفضل
        weekdaySpecial(weekday, hour)?.let { return it }

        // ٣) وقت اليوم العام
        return timeOfDay(hour)
    }

    private fun specialOccasion(m: Int, d: Int): Suggestion? {
        // شهر رمضان: دعاء الافتتاح / الجوشن الكبير ليلاً
        if (m == 9) {
            sug("mashhura", "m-iftitah", "في شهر رمضان المبارك", "دعاء الافتتاح")?.let { return it }
        }
        // عاشوراء ومحرّم: زيارة عاشوراء
        if (m == 1 && d in 1..12) {
            sug("ziyarat", "z-ashura", "في أيام عاشوراء", "زيارة عاشوراء")?.let { return it }
        }
        // ليالي القدر التقريبية (١٩، ٢١، ٢٣ رمضان): الجوشن الكبير
        if (m == 9 && d in listOf(19, 21, 23)) {
            sug("ramadan", "r-jawshan", "من أعمال ليالي القدر", "الجوشن الكبير")?.let { return it }
        }
        // النصف من شعبان: دعاء كميل / الندبة (مولد صاحب الزمان عج)
        if (m == 8 && d == 15) {
            sug("mashhura", "m-nudba", "في ليلة النصف من شعبان", "دعاء الندبة")?.let { return it }
        }
        return null
    }

    private fun weekdaySpecial(weekday: Int, hour: Int): Suggestion? {
        // ليلة الجمعة (مساء الخميس بعد المغرب ~18) ويوم الجمعة: دعاء كميل ليلاً، الندبة صباحاً
        // الخميس = 4، الجمعة = 5
        if (weekday == 4 && hour >= 18) {
            sug("mashhura", "m-kumayl", "ليلة الجمعة", "دعاء كميل")?.let { return it }
        }
        if (weekday == 5) {
            if (hour < 10) sug("mashhura", "m-nudba", "صباح الجمعة", "دعاء الندبة")?.let { return it }
            sug("jumaa", "j-samat", "يوم الجمعة", "دعاء السمات")?.let { return it }
            // احتياطاً: زيارة آل ياسين أو دعاء الجمعة إن لم يوجد السمات
            sug("mashhura", "m-tawassul", "يوم الجمعة", "دعاء التوسّل")?.let { return it }
        }
        return null
    }

    private fun timeOfDay(hour: Int): Suggestion {
        // الفجر/الصباح: تعقيب الصباح أو آية الكرسي
        // المساء: تسبيح، أو سورة الملك قبل النوم
        return when (hour) {
            in 4..10 -> sug("sabah", firstId("sabah"), "أذكار الصباح", "تعقيبات الصباح")
                ?: fallback()
            in 20..23, in 0..3 -> sug("quran", "q-067", "قبل النوم", "سورة الملك")
                ?: fallback()
            else -> sug("quran", "q-018", "تلاوة اليوم", "سورة الكهف")
                ?: fallback()
        }
    }

    private fun firstId(catId: String): String =
        Data.categories.firstOrNull { it.id == catId }?.items?.firstOrNull()?.id ?: ""

    // اقتراح أخير مضمون الوجود: الفاتحة
    private fun fallback() = Suggestion("quran", "q-001", "تلاوة", "سورة الفاتحة")
}
