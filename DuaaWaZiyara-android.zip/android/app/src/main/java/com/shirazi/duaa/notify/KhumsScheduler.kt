package com.shirazi.duaa.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.shirazi.duaa.data.Settings
import com.shirazi.duaa.logic.HijriCalendar
import java.util.Calendar

/**
 * تذكير السنة الخمسية: يُنبّه المستخدم قبل موعد سنته الخمسية بأيّام،
 * ثمّ في يومها، لحساب خمس أرباحه. مرتبطٌ بتاريخٍ هجريّ يحدّده المستخدم.
 */
object KhumsScheduler {

    private const val REQ = 910

    fun reschedule(context: Context) {
        val settings = Settings(context)
        cancel(context)
        if (!settings.khumsDateSet.value) return

        val adj = settings.hijriAdj.value
        val today = HijriCalendar.today(adj)
        val targetM = settings.khumsHMonth.value
        val targetD = settings.khumsHDay.value

        // عدد الأيّام حتى الموعد القادم (تقريب هجريّ 354 يوماً/سنة)
        fun doy(m: Int, d: Int) = (m - 1) * 30 + d
        val todayDoy = doy(today.m, today.d)
        val targetDoy = doy(targetM, targetD)
        val daysUntil = if (targetDoy >= todayDoy) targetDoy - todayDoy else (354 - todayDoy) + targetDoy

        // ننبّه في يوم الموعد صباحاً (٩ ص). نحوّل أيّام هجريّة ≈ ميلاديّة (نفس عدد الأيّام).
        val fire = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, daysUntil)
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }

        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(context)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setWindow(AlarmManager.RTC_WAKEUP, fire.timeInMillis, 3_600_000L, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fire.timeInMillis, pi)
            }
        } catch (e: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, fire.timeInMillis, pi)
        }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context))
    }

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, DhikrReceiver::class.java).apply {
            action = "com.shirazi.duaa.KHUMS"
            putExtra("routineTitle", "موعد سنتك الخمسية")
            putExtra("routineBody", "حان وقت حساب خمس أرباحك. افتح الحاسبة لتطمئنّ ذمّتك.")
        }
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags = flags or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, REQ, intent, flags)
    }
}
