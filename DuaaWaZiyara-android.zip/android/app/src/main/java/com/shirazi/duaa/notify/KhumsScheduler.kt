package com.shirazi.duaa.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.shirazi.duaa.data.Settings
import java.util.Calendar

/**
 * تذكير السنة الخمسية: يُنبّه المستخدم قبل موعد سنته الخمسية بأيّام،
 * ثمّ في يومها، لحساب خمس أرباحه. مرتبطٌ بتاريخٍ هجريّ يحدّده المستخدم.
 */
object KhumsScheduler {

    private const val REQ = 910
    private const val REQ_WEEK = 911

    fun reschedule(context: Context) {
        val settings = Settings(context)
        cancel(context)
        if (!settings.khumsDateSet.value) return

        val adj = settings.hijriAdj.value
        val targetM = settings.khumsHMonth.value
        val targetD = settings.khumsHDay.value

        // عدد الأيّام حتى الموعد القادم: بالتقويم الهجريّ الفعليّ (كان تقديراً بثلاثين يوماً للشهر فيخطئ بأيّام)
        var daysUntil = com.shirazi.duaa.logic.Khums.daysUntilKhumsDay(targetM, targetD, adj)
        fun at9(days: Int) = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, days)
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        // إن فات موعد اليوم (بعد التنبيه نفسه) فالموعد القادم في السنة التالية، وإلّا تكرّر التنبيه بلا نهاية
        if (at9(daysUntil).timeInMillis <= System.currentTimeMillis())
            daysUntil = com.shirazi.duaa.logic.Khums.daysUntilKhumsDay(targetM, targetD, adj, from = 1)
        val fire = at9(daysUntil)
        val weekBefore = if (daysUntil >= 7) at9(daysUntil - 7) else null

        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        arm(am, fire.timeInMillis, pendingIntent(context, REQ, "موعد سنتك الخمسية", "حان وقت حساب خمس أرباحك. افتح الحاسبة لتطمئنّ ذمّتك."))
        if (weekBefore != null && weekBefore.timeInMillis > System.currentTimeMillis())
            arm(am, weekBefore.timeInMillis, pendingIntent(context, REQ_WEEK, "رأس سنتك الخمسية بعد أسبوع", "هيّئ حساباتك: النقد والبضائع وما فضل عن مؤونتك."))
    }

    private fun arm(am: AlarmManager, at: Long, pi: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setWindow(AlarmManager.RTC_WAKEUP, at, 3_600_000L, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context, REQ, "", ""))
        am.cancel(pendingIntent(context, REQ_WEEK, "", ""))
    }

    private fun pendingIntent(context: Context, req: Int, title: String, body: String): PendingIntent {
        val intent = Intent(context, DhikrReceiver::class.java).apply {
            action = "com.shirazi.duaa.KHUMS"   // يعيد المستقبِلُ الجدولةَ عند هذا الاسم بعينه
            putExtra("routineTitle", title)
            putExtra("routineBody", body)
        }
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags = flags or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, req, intent, flags)
    }
}
