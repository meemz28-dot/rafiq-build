package com.shirazi.duaa.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf

/** حفظ الإعدادات والمفضلة محلياً على الجهاز. */
class Settings(context: Context) {
    private val sp = context.getSharedPreferences("duaa_prefs", Context.MODE_PRIVATE)

    // ===== النسخ الاحتياطي: تصدير/استيراد كامل التفضيلات والتقدّم كملفّ JSON =====
    fun exportJson(): String {
        val root = org.json.JSONObject()
        val types = org.json.JSONObject()
        for ((k, v) in sp.all) {
            when (v) {
                is Boolean -> { root.put(k, v); types.put(k, "b") }
                is Int -> { root.put(k, v); types.put(k, "i") }
                is Long -> { root.put(k, v); types.put(k, "l") }
                is Float -> { root.put(k, v.toDouble()); types.put(k, "f") }
                is String -> { root.put(k, v); types.put(k, "s") }
                is Set<*> -> { root.put(k, org.json.JSONArray(v.toList())); types.put(k, "set") }
            }
        }
        root.put("__types", types)
        root.put("__app", "rafiq-almumin")
        root.put("__exported", System.currentTimeMillis())
        return root.toString(2)
    }

    /** يعيد true عند نجاح الاستيراد. لا يكتب شيئاً إن لم يكن الملفّ نسخةً صالحة من التطبيق. */
    fun importJson(json: String): Boolean {
        return try {
            val root = org.json.JSONObject(json)
            if (root.optString("__app") != "rafiq-almumin") return false
            val types = root.getJSONObject("__types")
            val ed = sp.edit()
            for (k in types.keys()) {
                when (types.getString(k)) {
                    "b" -> ed.putBoolean(k, root.getBoolean(k))
                    "i" -> ed.putInt(k, root.getInt(k))
                    "l" -> ed.putLong(k, root.getLong(k))
                    "f" -> ed.putFloat(k, root.getDouble(k).toFloat())
                    "s" -> ed.putString(k, root.getString(k))
                    "set" -> {
                        val arr = root.getJSONArray(k)
                        ed.putStringSet(k, (0 until arr.length()).map { arr.getString(it) }.toSet())
                    }
                }
            }
            ed.commit()
            true
        } catch (e: Exception) { false }
    }

    var theme = mutableStateOf(sp.getString("theme", "light") ?: "light")
    var fontSize = mutableStateOf(sp.getFloat("fontSize", 21f))
    var hijriAdj = mutableStateOf(sp.getInt("hijriAdj", 0))
    var method = mutableStateOf(sp.getString("method", "jafari") ?: "jafari")
    var cityIdx = mutableStateOf(sp.getInt("cityIdx", 0))
    var customLat = mutableStateOf<Double?>(if (sp.contains("lat")) sp.getFloat("lat", 0f).toDouble() else null)
    var customLng = mutableStateOf<Double?>(if (sp.contains("lng")) sp.getFloat("lng", 0f).toDouble() else null)
    var customTz = mutableStateOf(sp.getFloat("tz", 0f).toDouble())
    var customName = mutableStateOf<String?>(sp.getString("cityName", null))
    var notifyEnabled = mutableStateOf(sp.getBoolean("notify", false))
    // هل أكمل المستخدم خطوات الترحيب الأولى؟
    var onboardingDone = mutableStateOf(sp.getBoolean("onboarded", false))
    fun finishOnboarding() { onboardingDone.value = true; sp.edit().putBoolean("onboarded", true).apply() }
    fun resetOnboarding() { onboardingDone.value = false; sp.edit().putBoolean("onboarded", false).apply() }
    // تذكير الأذكار العشوائي (صلوات / استغفار ...)
    var dhikrEnabled = mutableStateOf(sp.getBoolean("dhikrOn", false))
    var dhikrCount = mutableStateOf(sp.getInt("dhikrCount", 5))

    // تذكير التعقيبات بعد كل صلاة (يُربط بأوقات الصلاة الفعلية)
    var taqibatEnabled = mutableStateOf(sp.getBoolean("taqibOn", false))
    // تذكير صلاة الليل قبل الفجر (بعدد الدقائق المختارة)
    var laylEnabled = mutableStateOf(sp.getBoolean("laylOn", false))
    var laylBeforeFajr = mutableStateOf(sp.getInt("laylBefore", 60))
    fun saveTaqibat(on: Boolean) { taqibatEnabled.value = on; sp.edit().putBoolean("taqibOn", on).apply() }
    // تنبيهات المناسبات: عشيّة الليالي ذات الأعمال (القدر، أوّل رمضان...) وصباح الأيّام الكبرى
    var occasionEnabled = mutableStateOf(sp.getBoolean("occasionOn", true))
    // إبقاء الشاشة مضاءة أثناء القراءة (الأدعية الطويلة تتجاوز مهلة إطفاء الشاشة)
    var keepAwake = mutableStateOf(sp.getBoolean("keepAwake", true))
    fun saveKeepAwake(on: Boolean) { keepAwake.value = on; sp.edit().putBoolean("keepAwake", on).apply() }
    fun saveOccasion(on: Boolean) { occasionEnabled.value = on; sp.edit().putBoolean("occasionOn", on).apply() }
    fun saveLayl(on: Boolean) { laylEnabled.value = on; sp.edit().putBoolean("laylOn", on).apply() }
    // تذكير الصدقة اليومي (بساعة محدّدة) مع بيان فضلها
    var sadaqaEnabled = mutableStateOf(sp.getBoolean("sadaqaOn", false))
    var sadaqaHour = mutableStateOf(sp.getInt("sadaqaHour", 9))
    fun saveSadaqa(on: Boolean) { sadaqaEnabled.value = on; sp.edit().putBoolean("sadaqaOn", on).apply() }
    fun saveSadaqaHour(h: Int) { sadaqaHour.value = h.coerceIn(5, 22); sp.edit().putInt("sadaqaHour", sadaqaHour.value).apply() }
    fun saveLaylBefore(min: Int) { laylBeforeFajr.value = min.coerceIn(15, 120); sp.edit().putInt("laylBefore", laylBeforeFajr.value).apply() }

    // favorites stored as "catId|itemId" lines
    val favorites = mutableStateListOf<Pair<String, String>>().also { list ->
        sp.getString("fav", "")?.split("\n")?.forEach { line ->
            val p = line.split("|")
            if (p.size == 2 && p[0].isNotEmpty()) list.add(p[0] to p[1])
        }
    }

    fun save() {
        sp.edit().apply {
            putString("theme", theme.value)
            putFloat("fontSize", fontSize.value)
            putInt("hijriAdj", hijriAdj.value)
            putString("method", method.value)
            putInt("cityIdx", cityIdx.value)
            val lat = customLat.value; val lng = customLng.value
            if (lat != null && lng != null) {
                putFloat("lat", lat.toFloat()); putFloat("lng", lng.toFloat())
            } else { remove("lat"); remove("lng") }
            putFloat("tz", customTz.value.toFloat())
            putString("cityName", customName.value)
            putBoolean("notify", notifyEnabled.value)
            putBoolean("dhikrOn", dhikrEnabled.value)
            putInt("dhikrCount", dhikrCount.value)
            apply()
        }
    }

    fun saveFav() {
        sp.edit().putString("fav", favorites.joinToString("\n") { "${it.first}|${it.second}" }).apply()
    }

    fun isFav(c: String, i: String) = favorites.any { it.first == c && it.second == i }
    fun toggleFav(c: String, i: String) {
        val idx = favorites.indexOfFirst { it.first == c && it.second == i }
        if (idx >= 0) favorites.removeAt(idx) else favorites.add(c to i)
        saveFav()
    }

    // ===== الختمة: خطّة ختم القرآن بالتزامٍ يوميّ =====
    // خطّة نشطة تُخزَّن كـ: نوعها، تاريخ البدء (يوم ميلادي مطلق)، وعدد السور المنجزة
    var khatmaPlan = mutableStateOf(sp.getString("khatmaPlan", "") ?: "")          // "" | "30" | "40" | "90"
    var khatmaStart = mutableStateOf(sp.getInt("khatmaStart", 0))                   // epochDay
    val khatmaDone = mutableStateListOf<String>().also { list ->
        (sp.getString("khatmaDone", "") ?: "").split(",").filter { it.isNotEmpty() }.forEach { list.add(it) }
    }

    fun startKhatma(plan: String, epochDay: Int) {
        khatmaPlan.value = plan
        khatmaStart.value = epochDay
        khatmaDone.clear()
        sp.edit().putString("khatmaPlan", plan).putInt("khatmaStart", epochDay).putString("khatmaDone", "").apply()
    }

    fun endKhatma() {
        khatmaPlan.value = ""
        khatmaDone.clear()
        sp.edit().putString("khatmaPlan", "").putString("khatmaDone", "").apply()
    }

    fun isKhatmaDone(suraId: String) = khatmaDone.contains(suraId)

    fun toggleKhatma(suraId: String) {
        if (khatmaDone.contains(suraId)) khatmaDone.remove(suraId) else khatmaDone.add(suraId)
        sp.edit().putString("khatmaDone", khatmaDone.joinToString(",")).apply()
    }

    // ===== الحجّ والعمرة: المرجع المُختار + تتبّع إتمام المناسك =====
    var hajjMarja = mutableStateOf(sp.getString("hajjMarja", "shirazi") ?: "shirazi")
    fun setHajjMarja(m: String) { hajjMarja.value = m; sp.edit().putString("hajjMarja", m).apply() }

    val hajjDone = mutableStateListOf<String>().also { list ->
        (sp.getString("hajjDone", "") ?: "").split(",").filter { it.isNotEmpty() }.forEach { list.add(it) }
    }
    fun isHajjDone(id: String) = hajjDone.contains(id)
    fun toggleHajjStep(id: String) {
        if (hajjDone.contains(id)) hajjDone.remove(id) else hajjDone.add(id)
        sp.edit().putString("hajjDone", hajjDone.joinToString(",")).apply()
    }
    fun hajjDoneCount(prefix: String) = hajjDone.count { it.startsWith(prefix) }
    fun resetHajj(prefix: String) {
        hajjDone.removeAll { it.startsWith(prefix) }
        sp.edit().putString("hajjDone", hajjDone.joinToString(",")).apply()
    }


    // ===== المواظبة اليومية (Streak) والوِرد اليومي =====
    var streak = mutableStateOf(sp.getInt("streak", 0))
    var bestStreak = mutableStateOf(sp.getInt("bestStreak", 0))
    private var lastOpenDay = sp.getLong("lastOpenDay", 0L)

    private fun todayNumber(): Long = (System.currentTimeMillis() + java.util.TimeZone.getDefault().getOffset(System.currentTimeMillis())) / 86400000L

    /** يُستدعى عند فتح التطبيق: يحدّث سلسلة الأيام المتتالية. */
    fun touchStreak() {
        val today = todayNumber()
        if (today == lastOpenDay) return
        streak.value = if (today == lastOpenDay + 1) streak.value + 1 else 1
        if (streak.value > bestStreak.value) bestStreak.value = streak.value
        lastOpenDay = today
        sp.edit().putInt("streak", streak.value).putInt("bestStreak", bestStreak.value)
            .putLong("lastOpenDay", today).apply()
    }

    // ===== سجلّ النشاط اليومي (لرحلتي) =====
    // نخزّن لكلّ يومٍ نشطٍ درجةً 0..4 (الوِرد + المحاسبة + القراءة)، كخريطة "يوم:درجة".
    // نُبقي آخر 60 يوماً فقط لتبقى خفيفة.
    fun logActivity(score: Int) {
        val today = todayNumber()
        val raw = sp.getString("activityLog", "") ?: ""
        val map = parseActivity(raw).toMutableMap()
        val prev = map[today] ?: 0
        if (score > prev) map[today] = score   // نحتفظ بأعلى درجةٍ في اليوم
        else if (today !in map) map[today] = score
        // أبقِ آخر 60 يوماً
        val cutoff = today - 60
        val trimmed = map.filterKeys { it >= cutoff }
        val encoded = trimmed.entries.joinToString(",") { "${it.key}:${it.value}" }
        sp.edit().putString("activityLog", encoded).apply()
    }

    private fun parseActivity(raw: String): Map<Long, Int> {
        if (raw.isBlank()) return emptyMap()
        return raw.split(",").mapNotNull {
            val p = it.split(":")
            if (p.size == 2) p[0].toLongOrNull()?.let { d -> d to (p[1].toIntOrNull() ?: 0) } else null
        }.toMap()
    }

    /** درجة يومٍ معيّن (الإزاحة عن اليوم: 0=اليوم، 1=أمس...). */
    fun activityForDayOffset(offset: Int): Int {
        val day = todayNumber() - offset
        return parseActivity(sp.getString("activityLog", "") ?: "")[day] ?: 0
    }

    /** عدد الأيام النشطة في آخر 30 يوماً. */
    fun activeDaysLast30(): Int {
        val today = todayNumber()
        return parseActivity(sp.getString("activityLog", "") ?: "").count { it.key > today - 30 && it.value > 0 }
    }

    // ===== مخزن سلاسل زمنية عامّ (يوم:قيمة) لأيّ أداة، آخر 90 يوماً =====
    private fun logSeries(key: String, value: Int, keepDays: Long = 90) {
        val today = todayNumber()
        val map = parseActivity(sp.getString(key, "") ?: "").toMutableMap()
        map[today] = value
        val cutoff = today - keepDays
        val encoded = map.filterKeys { it >= cutoff }.entries.joinToString(",") { "${it.key}:${it.value}" }
        sp.edit().putString(key, encoded).apply()
    }
    private fun seriesForOffset(key: String, offset: Int): Int =
        parseActivity(sp.getString(key, "") ?: "")[todayNumber() - offset] ?: 0
    private fun seriesMap(key: String): Map<Long, Int> = parseActivity(sp.getString(key, "") ?: "")

    // ===== تاريخ المحاسبة: درجة 0..8 لكلّ يوم =====
    fun muhasabaForOffset(offset: Int): Int = seriesForOffset("muhHist", offset)
    fun muhasabaDaysActive(window: Int): Int {
        val today = todayNumber()
        return seriesMap("muhHist").count { it.key > today - window && it.value > 0 }
    }
    fun muhasabaAvg(window: Int): Float {
        val today = todayNumber()
        val vals = seriesMap("muhHist").filterKeys { it > today - window }.values
        return if (vals.isEmpty()) 0f else vals.sum().toFloat() / vals.size
    }
    /** أكثر أيام الأسبوع التزاماً (0=الأحد..6=السبت) من تاريخ المحاسبة. */
    fun muhasabaBestWeekday(): Int? {
        val map = seriesMap("muhHist")
        if (map.isEmpty()) return null
        val byDow = IntArray(7); val cnt = IntArray(7)
        for ((day, v) in map) {
            // اليوم 0 (epochDay) كان الخميس؛ نحسب يوم الأسبوع: (day+4)%7 → 0=الأحد
            val dow = ((day + 4) % 7).toInt()
            byDow[dow] += v; cnt[dow]++
        }
        var best = -1; var bestAvg = -1f
        for (i in 0..6) if (cnt[i] > 0) { val a = byDow[i].toFloat() / cnt[i]; if (a > bestAvg) { bestAvg = a; best = i } }
        return if (best >= 0) best else null
    }

    /** حساب درجة اليوم الحالية من الوِرد والمحاسبة (0..4) وتسجيلها. */
    fun refreshTodayActivity() {
        var score = 0
        val w = wirdMask.value
        if (w and 0b1111 == 0b1111) score += 2          // الوِرد مكتمل = نقطتان
        else if (w != 0) score += 1                      // وِردٌ جزئيّ = نقطة
        val m = muhasabaMask.value
        val muhCount = (0 until 8).count { m and (1 shl it) != 0 }
        if (muhCount >= 6) score += 2                    // محاسبة شبه كاملة = نقطتان
        else if (muhCount > 0) score += 1                // محاسبة جزئية = نقطة
        logActivity(score.coerceIn(0, 4))
    }

    /** الوِرد اليومي: قناع بتات لثلاث مهام (دعاء اليوم، التسبيح، ذكر اليوم). */
    var wirdMask = mutableStateOf(loadWird())
    private fun loadWird(): Int {
        val day = todayNumber()
        return if (sp.getLong("wirdDay", -1L) == day) sp.getInt("wirdMask", 0) else 0
    }
    fun toggleWird(bit: Int) {
        val day = todayNumber()
        val cur = if (sp.getLong("wirdDay", -1L) == day) sp.getInt("wirdMask", 0) else 0
        val next = cur xor (1 shl bit)
        wirdMask.value = next
        sp.edit().putLong("wirdDay", day).putInt("wirdMask", next).apply()
        refreshTodayActivity()
    }
    fun markWird(bit: Int) { if (wirdMask.value and (1 shl bit) == 0) toggleWird(bit) }
    fun dayOfYearIndex(): Int = (todayNumber() % 366L).toInt()

    // ===== محاسبة النفس اليومية =====
    var muhasabaMask = mutableStateOf(loadMuhasaba())
    private fun loadMuhasaba(): Int {
        val day = todayNumber()
        return if (sp.getLong("muhDay", -1L) == day) sp.getInt("muhMask", 0) else 0
    }

    // ===== تتبّع القضاء (صلوات وصيام فائتة) =====
    var qadaFajr = mutableStateOf(sp.getInt("qFajr", 0))
    var qadaDhuhr = mutableStateOf(sp.getInt("qDhuhr", 0))
    var qadaAsr = mutableStateOf(sp.getInt("qAsr", 0))
    var qadaMaghrib = mutableStateOf(sp.getInt("qMaghrib", 0))
    var qadaIsha = mutableStateOf(sp.getInt("qIsha", 0))
    var qadaFast = mutableStateOf(sp.getInt("qFast", 0))
    // المقضيّ (المُنجَز) — للوحة المقارنة
    var qadaDoneFajr = mutableStateOf(sp.getInt("qdFajr", 0))
    var qadaDoneDhuhr = mutableStateOf(sp.getInt("qdDhuhr", 0))
    var qadaDoneAsr = mutableStateOf(sp.getInt("qdAsr", 0))
    var qadaDoneMaghrib = mutableStateOf(sp.getInt("qdMaghrib", 0))
    var qadaDoneIsha = mutableStateOf(sp.getInt("qdIsha", 0))
    var qadaDoneFast = mutableStateOf(sp.getInt("qdFast", 0))
    fun qadaDone(key: String): MutableState<Int> = when (key) {
        "fajr" -> qadaDoneFajr; "dhuhr" -> qadaDoneDhuhr; "asr" -> qadaDoneAsr
        "maghrib" -> qadaDoneMaghrib; "isha" -> qadaDoneIsha; else -> qadaDoneFast
    }
    // قضى صلاة/صوماً: ينقص المتبقّي ويزيد المُنجَز
    fun completeQada(key: String) {
        val rem = qadaState(key)
        if (rem.value <= 0) return
        setQada(key, rem.value - 1)
        val done = qadaDone(key); val nv = done.value + 1
        done.value = nv
        sp.edit().putInt("qd" + key.replaceFirstChar { it.uppercase() }, nv).apply()
        // سجّل إنجاز اليوم (عدد ما قُضي اليوم) للمخطّط والإسقاط
        val today = todayNumber()
        val map = parseActivity(sp.getString("qadaHist", "") ?: "").toMutableMap()
        map[today] = (map[today] ?: 0) + 1
        val encoded = map.filterKeys { it >= today - 90 }.entries.joinToString(",") { "${it.key}:${it.value}" }
        sp.edit().putString("qadaHist", encoded).apply()
    }
    /** إجمالي ما قُضي في آخر N يوماً (لحساب المعدّل). */
    fun qadaCompletedLast(window: Int): Int {
        val today = todayNumber()
        return seriesMap("qadaHist").filterKeys { it > today - window }.values.sum()
    }
    /** عدد ما قُضي في يومٍ بإزاحة معيّنة. */
    fun qadaCompletedForOffset(offset: Int): Int = seriesForOffset("qadaHist", offset)
    /** المعدّل اليوميّ للقضاء (من آخر 30 يوماً) — لإسقاط تاريخ الانتهاء. */
    fun qadaDailyRate(): Float {
        val total = qadaCompletedLast(30)
        return total / 30f
    }

    // ===== تاريخ القراءة =====
    fun readForOffset(offset: Int): Int = seriesForOffset("readHist", offset)
    fun readDaysLast(window: Int): Int {
        val today = todayNumber()
        return seriesMap("readHist").count { it.key > today - window && it.value > 0 }
    }
    /** سلسلة أيام القراءة المتتالية المنتهية اليوم أو أمس. */
    fun readingStreak(): Int {
        val map = seriesMap("readHist")
        if (map.isEmpty()) return 0
        val today = todayNumber()
        // ابدأ من اليوم إن قرأ، وإلا من أمس (لا نكسر السلسلة قبل انتهاء اليوم)
        var cursor = if ((map[today] ?: 0) > 0) today else today - 1
        var count = 0
        while ((map[cursor] ?: 0) > 0) { count++; cursor-- }
        return count
    }
    fun qadaState(key: String): MutableState<Int> = when (key) {
        "fajr" -> qadaFajr; "dhuhr" -> qadaDhuhr; "asr" -> qadaAsr
        "maghrib" -> qadaMaghrib; "isha" -> qadaIsha; else -> qadaFast
    }
    fun setQada(key: String, v: Int) {
        val nv = v.coerceAtLeast(0)
        when (key) {
            "fajr" -> { qadaFajr.value = nv; sp.edit().putInt("qFajr", nv).apply() }
            "dhuhr" -> { qadaDhuhr.value = nv; sp.edit().putInt("qDhuhr", nv).apply() }
            "asr" -> { qadaAsr.value = nv; sp.edit().putInt("qAsr", nv).apply() }
            "maghrib" -> { qadaMaghrib.value = nv; sp.edit().putInt("qMaghrib", nv).apply() }
            "isha" -> { qadaIsha.value = nv; sp.edit().putInt("qIsha", nv).apply() }
            "fast" -> { qadaFast.value = nv; sp.edit().putInt("qFast", nv).apply() }
        }
    }

    fun toggleMuhasaba(bit: Int) {
        val day = todayNumber()
        val cur = if (sp.getLong("muhDay", -1L) == day) sp.getInt("muhMask", 0) else 0
        val next = cur xor (1 shl bit)
        muhasabaMask.value = next
        sp.edit().putLong("muhDay", day).putInt("muhMask", next).apply()
        val count = (0 until 8).count { next and (1 shl it) != 0 }
        logSeries("muhHist", count)
        refreshTodayActivity()
    }


    // ========== سجلّ القراءة: المتابعة + المقروء حديثاً + الأكثر قراءة ==========
    // آخر نص مقروء (للمتابعة من حيث توقّفت)
    var lastReadCat = mutableStateOf<String?>(sp.getString("lrCat", null))
    var lastReadId = mutableStateOf<String?>(sp.getString("lrId", null))

    /** يسجّل فتح نصٍّ: يحدّث "المتابعة"، ويضيفه لقائمة المقروء حديثاً، ويزيد عدّاد قراءته. */
    fun recordRead(catId: String, itemId: String) {
        val key = "$catId|$itemId"
        lastReadCat.value = catId; lastReadId.value = itemId
        // سجّل أنّ اليوم يومُ قراءة (لتقويم القراءة والسلسلة)
        val today = todayNumber()
        val rmap = parseActivity(sp.getString("readHist", "") ?: "").toMutableMap()
        rmap[today] = (rmap[today] ?: 0) + 1
        val rEncoded = rmap.filterKeys { it >= today - 90 }.entries.joinToString(",") { "${it.key}:${it.value}" }
        sp.edit().putString("readHist", rEncoded).apply()
        // قائمة حلقية: أحدث 20، بلا تكرار
        val cur = (sp.getString("recent", "") ?: "").split("¦").filter { it.isNotEmpty() && it != key }
        val next = (listOf(key) + cur).take(20)
        // عدّاد القراءة
        val counts = loadCounts().toMutableMap()
        counts[key] = (counts[key] ?: 0) + 1
        val countsStr = counts.entries.joinToString("¦") { "${it.key}=${it.value}" }
        sp.edit()
            .putString("lrCat", catId).putString("lrId", itemId)
            .putString("recent", next.joinToString("¦"))
            .putString("counts", countsStr)
            .apply()
    }

    /** قائمة المقروء حديثاً (أحدث أولاً) كأزواج (catId, itemId). */
    fun recentReads(): List<Pair<String, String>> =
        (sp.getString("recent", "") ?: "").split("¦")
            .filter { it.contains("|") }
            .map { val p = it.split("|"); p[0] to p[1] }

    private fun loadCounts(): Map<String, Int> =
        (sp.getString("counts", "") ?: "").split("¦")
            .filter { it.contains("=") }
            .associate { val p = it.split("="); p[0] to (p[1].toIntOrNull() ?: 0) }

    /** مفاتيح كلّ النصوص المقروءة "catId|itemId" — لعرض مؤشّر القراءة في القوائم. */
    fun readKeys(): Set<String> = loadCounts().keys

    /** الأكثر قراءةً (الأعلى عدّاداً أولاً) كأزواج (catId,itemId) مع العدد. */
    fun mostRead(limit: Int = 6): List<Triple<String, String, Int>> =
        loadCounts().entries
            .filter { it.key.contains("|") }
            .sortedByDescending { it.value }
            .take(limit)
            .map { val p = it.key.split("|"); Triple(p[0], p[1], it.value) }

    fun clearHistory() {
        lastReadCat.value = null; lastReadId.value = null
        sp.edit().remove("lrCat").remove("lrId").remove("recent").remove("counts").apply()
    }

    // موضع التمرير لكل نص (للمتابعة من نفس المكان داخل النص الطويل)
    fun saveScroll(catId: String, itemId: String, value: Int) {
        sp.edit().putInt("scroll_${catId}_$itemId", value).apply()
    }
    fun loadScroll(catId: String, itemId: String): Int =
        sp.getInt("scroll_${catId}_$itemId", 0)

    // ========== إعدادات عرض القارئ ==========
    var readerSepia = mutableStateOf(sp.getBoolean("rSepia", false))
    var lineHeight = mutableStateOf(sp.getFloat("rLine", 2.0f))
    var tashkeelOn = mutableStateOf(sp.getBoolean("rTashkeel", true))
    fun saveReaderPrefs() {
        sp.edit()
            .putBoolean("rSepia", readerSepia.value)
            .putFloat("rLine", lineHeight.value)
            .putBoolean("rTashkeel", tashkeelOn.value)
            .apply()
    }

    // ========== نقاط قراءة القرآن (تحفيز) ==========
    // السور المميّزة (لها فضل خاصّ / مرتبطة بأحاديث) — تُمنح ١٥ نقطة بدل ١٠
    val featuredSurahs = setOf(
        "q-001", // الفاتحة
        "q-002", // البقرة
        "q-018", // الكهف
        "q-036", // يس
        "q-048", // الفتح
        "q-055", // الرحمن
        "q-056", // الواقعة
        "q-067", // الملك
        "q-044", // الدخان
        "q-076", // الإنسان (الدهر)
        "q-062", // الجمعة
        "q-112", // الإخلاص
        "q-113", // الفلق
        "q-114"  // الناس
    )

    /** نقاط سورة معيّنة: مميّزة ١٥، عادية ١٠. */
    fun surahPoints(itemId: String): Int = if (itemId in featuredSurahs) 15 else 10

    /** هل أُكملت هذه السورة من قبل؟ */
    fun isSurahDone(itemId: String): Boolean =
        (sp.getString("quranDone", "") ?: "").split(",").contains(itemId)

    private fun doneSet(): Set<String> =
        (sp.getString("quranDone", "") ?: "").split(",").filter { it.isNotEmpty() }.toSet()

    var quranPoints = mutableStateOf(sp.getInt("quranPoints", 0))
    var quranDoneCount = mutableStateOf(doneSet().size)

    /**
     * يسجّل إكمال قراءة سورة. يمنح النقاط مرّة واحدة فقط لكلّ سورة.
     * يعيد عدد النقاط الممنوحة (٠ إن كانت مُكملة سابقاً)، أو -1 لا شيء.
     * عند إكمال جميع السور الـ١١٤ تُضاف مكافأة ٥٠٠ نقطة ختمة.
     */
    fun completeSurah(itemId: String): Int {
        if (!itemId.startsWith("q-")) return -1
        val done = doneSet().toMutableSet()
        if (itemId in done) return 0
        val pts = surahPoints(itemId)
        done.add(itemId)
        var total = sp.getInt("quranPoints", 0) + pts
        var bonus = 0
        val khatmaAwarded = sp.getBoolean("khatmaAwarded", false)
        if (done.size >= 114 && !khatmaAwarded) { bonus = 500; total += bonus }
        sp.edit()
            .putString("quranDone", done.joinToString(","))
            .putInt("quranPoints", total)
            .apply { if (bonus > 0) putBoolean("khatmaAwarded", true) }
            .apply()
        quranPoints.value = total
        quranDoneCount.value = done.size
        return pts + bonus
    }

    /** مستوى القارئ بحسب النقاط (للوحة التحفيز). */
    fun readerLevel(): Pair<String, Int> {
        val p = quranPoints.value
        return when {
            p >= 1140 -> "حافظ مثابر" to 5
            p >= 600 -> "قارئ متقدّم" to 4
            p >= 300 -> "قارئ مواظب" to 3
            p >= 100 -> "قارئ ناشئ" to 2
            else -> "مبتدئ" to 1
        }
    }

    fun resetQuranPoints() {
        sp.edit().remove("quranDone").remove("quranPoints").remove("khatmaAwarded").apply()
        quranPoints.value = 0; quranDoneCount.value = 0
    }

    // ========== مخطّط الختمة ==========
    // هدف يومي بعدد الأجزاء، تاريخ البدء، والأجزاء المقروءة
    var khatmaActive = mutableStateOf(sp.getBoolean("khActive", false))
    var khatmaDays = mutableStateOf(sp.getInt("khDays", 30))
    var khatmaStartDay = mutableStateOf(sp.getLong("khStart", 0L))   // epochDay للبدء
    var khatmaJuzDone = mutableStateOf(sp.getInt("khJuz", 0))         // عدد الأجزاء المقروءة (0..30)

    fun startKhatma(days: Int, todayEpochDay: Long) {
        khatmaActive.value = true; khatmaDays.value = days.coerceIn(1, 365)
        khatmaStartDay.value = todayEpochDay; khatmaJuzDone.value = 0
        sp.edit().putBoolean("khActive", true).putInt("khDays", khatmaDays.value)
            .putLong("khStart", todayEpochDay).putInt("khJuz", 0).apply()
    }
    fun setKhatmaJuz(n: Int) {
        khatmaJuzDone.value = n.coerceIn(0, 30)
        sp.edit().putInt("khJuz", khatmaJuzDone.value).apply()
        if (khatmaJuzDone.value >= 30) { khatmaActive.value = false; sp.edit().putBoolean("khActive", false).apply() }
    }
    fun cancelKhatma() {
        khatmaActive.value = false
        sp.edit().putBoolean("khActive", false).apply()
    }

    /** الأجزاء المتوقّع إنجازها حتى اليوم (للمقارنة بالوتيرة الفعلية). */
    // ===== رحلة تهذيب الصفات (صفة الشهر) — على نمط الختمة: حالة + سجلّ يومي =====
    var traitActive = mutableStateOf(sp.getBoolean("trActive", false))
    var traitId = mutableStateOf(sp.getString("trId", "") ?: "")
    var traitStart = mutableStateOf(sp.getLong("trStart", 0L))
    var traitTarget = mutableStateOf(sp.getInt("trTarget", 30))

    fun todayEpochDay(): Long = todayNumber()

    fun startTrait(id: String, days: Int) {
        traitActive.value = true; traitId.value = id
        traitStart.value = todayNumber(); traitTarget.value = days.coerceIn(7, 60)
        sp.edit().putBoolean("trActive", true).putString("trId", id)
            .putLong("trStart", traitStart.value).putInt("trTarget", traitTarget.value)
            .putString("trLog", "").apply()
    }
    fun traitTickToday() { logSeries("trLog", 1, keepDays = 70L) }
    fun traitUntickToday() { logSeries("trLog", 0, keepDays = 70L) }
    fun traitDoneToday(): Boolean = (seriesMap("trLog")[todayNumber()] ?: 0) > 0
    fun traitDoneCount(): Int = seriesMap("trLog").count { it.key >= traitStart.value && it.value > 0 }
    fun traitDayNumber(): Int = ((todayNumber() - traitStart.value).toInt() + 1).coerceAtLeast(1)
    fun traitHistory(): Set<String> = sp.getStringSet("trHist", emptySet()) ?: emptySet()
    fun completeTrait() {
        val h = traitHistory().toMutableSet()
        h.add(traitId.value + "|" + traitTarget.value + "|" + todayNumber())
        traitActive.value = false
        sp.edit().putStringSet("trHist", h).putBoolean("trActive", false).apply()
    }
    fun abandonTrait() {
        traitActive.value = false
        sp.edit().putBoolean("trActive", false).putString("trLog", "").apply()
    }

    fun khatmaExpectedJuz(todayEpochDay: Long): Int {
        if (!khatmaActive.value || khatmaDays.value <= 0) return 0
        val elapsed = (todayEpochDay - khatmaStartDay.value).toInt() + 1
        val perDay = 30.0 / khatmaDays.value
        return (elapsed * perDay).toInt().coerceIn(0, 30)
    }

    // ========== هدف الذِّكر اليومي (تسبيح) ==========
    var dhikrGoal = mutableStateOf(sp.getInt("dhikrGoal", 100))
    private fun todayKey() = java.time.LocalDate.now().toEpochDay()
    var dhikrTodayCount = mutableStateOf(
        if (sp.getLong("dhikrDay", -1L) == java.time.LocalDate.now().toEpochDay()) sp.getInt("dhikrToday", 0) else 0
    )
    /** يضيف عدداً من التسبيحات المكتملة لعدّاد اليوم (يصفّر تلقائياً عند تغيّر اليوم). */
    fun addDhikr(n: Int) {
        val today = todayKey()
        val savedDay = sp.getLong("dhikrDay", -1L)
        val base = if (savedDay == today) sp.getInt("dhikrToday", 0) else 0
        val total = base + n
        dhikrTodayCount.value = total
        sp.edit().putLong("dhikrDay", today).putInt("dhikrToday", total).apply()
    }
    fun setDhikrGoal(n: Int) {
        dhikrGoal.value = n.coerceIn(33, 1000)
        sp.edit().putInt("dhikrGoal", dhikrGoal.value).apply()
    }

    // ========== العلامات المرجعية داخل النصوص الطويلة ==========
    // مفتاح كلّ علامة: "catId|itemId|scroll" ⇐ يخزّن موضعاً مسمّى داخل نصّ
    data class Bookmark(val catId: String, val itemId: String, val scroll: Int, val title: String)

    fun bookmarks(): List<Bookmark> =
        (sp.getString("bookmarks", "") ?: "").split("§")
            .filter { it.contains("|") }
            .mapNotNull {
                val p = it.split("|")
                if (p.size >= 4) Bookmark(p[0], p[1], p[2].toIntOrNull() ?: 0, p.drop(3).joinToString("|")) else null
            }

    fun addBookmark(catId: String, itemId: String, scroll: Int, title: String) {
        val cur = bookmarks().toMutableList()
        cur.add(0, Bookmark(catId, itemId, scroll, title))
        val capped = cur.take(50)
        sp.edit().putString("bookmarks", capped.joinToString("§") { "${it.catId}|${it.itemId}|${it.scroll}|${it.title}" }).apply()
    }

    fun removeBookmark(b: Bookmark) {
        val cur = bookmarks().filterNot { it.catId == b.catId && it.itemId == b.itemId && it.scroll == b.scroll }
        sp.edit().putString("bookmarks", cur.joinToString("§") { "${it.catId}|${it.itemId}|${it.scroll}|${it.title}" }).apply()
    }

    // ========== حاسبة الخُمس (native) ==========
    var khumsMarja = mutableStateOf(sp.getString("khMarja", "shirazi") ?: "shirazi")
    var khumsCurrency = mutableStateOf(sp.getString("khCur", "د.إ") ?: "د.إ")
    fun saveKhumsMarja(k: String) { khumsMarja.value = k; sp.edit().putString("khMarja", k).apply() }
    fun saveKhumsCurrency(c: String) { khumsCurrency.value = c; sp.edit().putString("khCur", c).apply() }
    fun khumsField(id: String): String = sp.getString("khf_$id", "") ?: ""
    fun saveKhumsField(id: String, v: String) { sp.edit().putString("khf_$id", v).apply() }
    // السنة الخمسية: تاريخ هجريّ (شهر/يوم) تُحسب عنده زكاة الأرباح سنوياً
    var khumsDateSet = mutableStateOf(sp.getBoolean("khDateSet", false))
    var khumsHMonth = mutableStateOf(sp.getInt("khHMonth", 1))
    var khumsHDay = mutableStateOf(sp.getInt("khHDay", 1))
    var khumsLastPaid = mutableStateOf(sp.getString("khLastPaid", "") ?: "")  // "سنة هجرية" آخر إخراج
    fun saveKhumsDate(m: Int, d: Int) {
        khumsHMonth.value = m; khumsHDay.value = d; khumsDateSet.value = true
        sp.edit().putInt("khHMonth", m).putInt("khHDay", d).putBoolean("khDateSet", true).apply()
    }
    fun clearKhumsDate() {
        khumsDateSet.value = false
        sp.edit().putBoolean("khDateSet", false).apply()
    }
    fun markKhumsPaid(hijriYear: Int) {
        khumsLastPaid.value = hijriYear.toString()
        sp.edit().putString("khLastPaid", hijriYear.toString()).apply()
    }
    fun clearKhumsFields() {
        val e = sp.edit()
        listOf("cash","goods","trade","metals","receivables","other","khumsed","loans","debts","mixed").forEach { e.remove("khf_$it") }
        e.apply()
    }

    /** الموقع الفعّال: مخصّص أو مدينة مختارة. */
    fun location(): City {
        val lat = customLat.value; val lng = customLng.value
        return if (lat != null && lng != null)
            City(customName.value ?: "موقع مخصّص", lat, lng, customTz.value)
        else Data.cities[cityIdx.value.coerceIn(0, Data.cities.size - 1)]
    }

    // ===================================================================
    // النسخ الاحتياطي والاستعادة — يحفظ كلّ التفضيلات (التقدّم، المفضّلة،
    // الإعدادات...) في ملفّ JSON يمكن للمستخدم حفظه أو نقله لجهازٍ آخر.
    // ===================================================================
    fun exportBackupJson(): String {
        val all = sp.all
        val obj = org.json.JSONObject()
        obj.put("_app", "rafiq_almumin")
        obj.put("_version", 1)
        obj.put("_date", System.currentTimeMillis())
        val data = org.json.JSONObject()
        for ((k, v) in all) {
            when (v) {
                is String -> data.put(k, org.json.JSONObject().put("t", "s").put("v", v))
                is Int -> data.put(k, org.json.JSONObject().put("t", "i").put("v", v))
                is Long -> data.put(k, org.json.JSONObject().put("t", "l").put("v", v))
                is Boolean -> data.put(k, org.json.JSONObject().put("t", "b").put("v", v))
                is Float -> data.put(k, org.json.JSONObject().put("t", "f").put("v", v.toDouble()))
            }
        }
        obj.put("data", data)
        return obj.toString(2)
    }

    /** يستعيد نسخةً احتياطية. يُرجِع true عند النجاح. */
    fun importBackupJson(json: String): Boolean {
        return try {
            val obj = org.json.JSONObject(json)
            if (obj.optString("_app") != "rafiq_almumin") return false
            val data = obj.getJSONObject("data")
            val e = sp.edit()
            e.clear()
            val keys = data.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val entry = data.getJSONObject(k)
                when (entry.getString("t")) {
                    "s" -> e.putString(k, entry.getString("v"))
                    "i" -> e.putInt(k, entry.getInt("v"))
                    "l" -> e.putLong(k, entry.getLong("v"))
                    "b" -> e.putBoolean(k, entry.getBoolean("v"))
                    "f" -> e.putFloat(k, entry.getDouble("v").toFloat())
                }
            }
            e.apply()
            true
        } catch (ex: Exception) {
            false
        }
    }
}
