package com.shirazi.duaa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Settings
import kotlin.math.roundToInt

/** تتبّع القضاء مع لوحة مقارنة بين المُنجَز والمتبقّي. */
@Composable
fun QadaScreen(settings: Settings, pal: DuaaPalette, onClose: () -> Unit) {
    data class Row(val key: String, val label: String)
    val rows = listOf(
        Row("fajr", "صلاة الصبح"), Row("dhuhr", "صلاة الظهر"), Row("asr", "صلاة العصر"),
        Row("maghrib", "صلاة المغرب"), Row("isha", "صلاة العشاء"),
    )
    val remSalat: Int = rows.sumOf { settings.qadaState(it.key).value.toInt() }
    val doneSalat: Int = rows.sumOf { settings.qadaDone(it.key).value.toInt() }
    val remFast = settings.qadaFast.value
    val doneFast = settings.qadaDoneFast.value

    val totalSalat = remSalat + doneSalat
    val totalFast = remFast + doneFast
    val totalAll = totalSalat + totalFast
    val doneAll = doneSalat + doneFast
    val pctAll = if (totalAll > 0) (doneAll * 100f / totalAll).roundToInt() else 0

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(pal.bgBrush)) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                ScreenTopBar("تتبّع القضاء", pal, onClose)
                Column(Modifier.padding(18.dp)) {

                    // ===== لوحة الإنجاز =====
                    if (totalAll == 0) {
                        Column(
                            Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(RoundedCornerShape(20.dp))
                                .background(pal.heroBrush).padding(vertical = 28.dp, horizontal = 20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("لا قضاء عليك", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("الحمد لله على العافية. وإن كان عليك فوائتُ صلاةٍ أو صيام، أضِفها من البطاقات أدناه لتتابع قضاءها بيُسر.",
                                color = Color.White.copy(alpha = .88f), fontSize = 13.sp, textAlign = TextAlign.Center, lineHeight = 21.sp)
                        }
                    } else {
                    Column(
                        Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(RoundedCornerShape(20.dp))
                            .background(pal.heroBrush).padding(20.dp)
                    ) {
                        Text("لوحة القضاء", color = Color.White.copy(alpha = .85f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text("$pctAll%", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 44.sp)
                            Spacer(Modifier.width(10.dp))
                            Text("مُنجَز من إجمالي القضاء", color = Color.White.copy(alpha = .8f), fontSize = 13.sp,
                                modifier = Modifier.padding(bottom = 10.dp))
                        }
                        Spacer(Modifier.height(12.dp))
                        // شريط تقدّم إجمالي
                        Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = .2f))) {
                            if (totalAll > 0)
                                Box(Modifier.fillMaxWidth(doneAll.toFloat() / totalAll).height(10.dp)
                                    .clip(RoundedCornerShape(4.dp)).background(pal.gold))
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MiniStat("مُنجَز", doneAll, pal.gold, Modifier.weight(1f))
                            MiniStat("متبقٍّ", remSalat + remFast, Color.White, Modifier.weight(1f))
                            MiniStat("الإجمالي", totalAll, Color.White.copy(alpha = .7f), Modifier.weight(1f))
                        }
                    }
                    }

                    // ===== الإسقاط والوتيرة: متى تنتهي بهذا المعدّل؟ =====
                    run {
                        val remTotal = remSalat + remFast
                        val rate = settings.qadaDailyRate()
                        val last7 = settings.qadaCompletedLast(7)
                        val last30 = settings.qadaCompletedLast(30)
                        if (remTotal > 0) {
                            Column(Modifier.fillMaxWidth().paper(pal, 20).padding(18.dp)) {
                                Text("وتيرتك والإسقاط", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                Spacer(Modifier.height(14.dp))
                                if (rate > 0.01f) {
                                    val daysLeft = kotlin.math.ceil(remTotal / rate).toInt()
                                    val months = daysLeft / 30; val daysRem = daysLeft % 30
                                    val etaText = when {
                                        daysLeft <= 30 -> "خلال ${daysLeft} يوماً تقريباً"
                                        months < 12 -> "خلال ${months} ${if (months == 1) "شهر" else "أشهر"}${if (daysRem > 5) " و${daysRem} يوماً" else ""} تقريباً"
                                        else -> "خلال ${months / 12} ${if (months / 12 == 1) "سنة" else "سنوات"} تقريباً"
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(pal.emerald.copy(alpha = .12f)), contentAlignment = Alignment.Center) {
                                            LineIcon(AppIcon.StarFill, pal.emerald, 22.dp)
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text("تنتهي $etaText", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                            Text("بمعدّلك الحاليّ: ${String.format("%.1f", rate)} فريضة/يوم", color = pal.ink2, fontSize = 12.sp)
                                        }
                                    }
                                } else {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(pal.gold.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                                            LineIcon(AppIcon.Clock, pal.gold, 22.dp)
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text("ابدأ القضاء لترى إسقاط الانتهاء", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Text("كلّ فريضةٍ تُسجّلها تقرّبك من الهدف", color = pal.ink2, fontSize = 12.sp)
                                        }
                                    }
                                }
                                Spacer(Modifier.height(14.dp))
                                // أعمدة إنجاز آخر ١٤ يوماً
                                val maxDay = (0..13).maxOf { settings.qadaCompletedForOffset(it) }.coerceAtLeast(1)
                                Row(Modifier.fillMaxWidth().height(50.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    for (offset in 13 downTo 0) {
                                        val v = settings.qadaCompletedForOffset(offset)
                                        val frac = (v.toFloat() / maxDay).coerceIn(0f, 1f)
                                        Box(Modifier.weight(1f).fillMaxHeight(if (frac == 0f) 0.05f else frac)
                                            .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                            .background(if (v == 0) pal.line.copy(alpha = .5f) else pal.emerald))
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("هذا الأسبوع: $last7 فريضة", color = pal.ink2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("آخر ٣٠ يوماً: $last30", color = pal.ink2, fontSize = 11.sp)
                                }
                            }
                            Spacer(Modifier.height(16.dp))
                        }
                    }

                    // ===== تفصيل الصلوات: شريط مُنجَز/متبقٍّ لكل صلاة =====
                    SectionTitle("الصلوات")
                    rows.forEach { r ->
                        val rem = settings.qadaState(r.key).value
                        val done = settings.qadaDone(r.key).value
                        QadaBar(r.label, done, rem, pal,
                            onComplete = { settings.completeQada(r.key) },
                            onPlus = { settings.setQada(r.key, settings.qadaState(r.key).value + 1) },
                            onMinus = { settings.setQada(r.key, settings.qadaState(r.key).value - 1) })
                    }

                    SectionTitle("الصيام")
                    QadaBar("أيام الصيام", doneFast, remFast, pal,
                        onComplete = { settings.completeQada("fast") },
                        onPlus = { settings.setQada("fast", settings.qadaFast.value + 1) },
                        onMinus = { settings.setQada("fast", settings.qadaFast.value - 1) })

                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.emerald.copy(alpha = .10f)).padding(14.dp)) {
                        Text("استخدم ﹣ ＋ لضبط ما عليك من فوائت، واضغط «قضيت» كلّما أدّيت واحدة لتنتقل إلى المُنجَز. اجعل لك ورداً يومياً ولو صلاةً واحدة حتى تبرأ ذمّتك.",
                            color = pal.emerald, fontSize = 12.5.sp, lineHeight = 21.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                    Spacer(Modifier.height(90.dp))
                }
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: Int, color: Color, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .12f)).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$value", color = color, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        Text(label, color = Color.White.copy(alpha = .75f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun QadaBar(label: String, done: Int, rem: Int, pal: DuaaPalette,
                    onComplete: () -> Unit, onPlus: () -> Unit, onMinus: () -> Unit) {
    val total = done + rem
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).paper(pal, 16).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
            Text("$done / $total", color = pal.ink2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        // شريط مُنجَز (ذهبي) مقابل متبقٍّ (رمادي)
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(pal.line)) {
            if (total > 0)
                Box(Modifier.fillMaxWidth(done.toFloat() / total).height(8.dp).clip(RoundedCornerShape(4.dp)).background(pal.good))
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            // قضيت
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                    .background(if (rem > 0) pal.pillBrush else androidx.compose.ui.graphics.SolidColor(pal.surface2))
                    .clickable(enabled = rem > 0, onClick = onComplete).padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("✓", color = if (rem > 0) Color.White else pal.ink2, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                    Spacer(Modifier.width(6.dp))
                    Text("قضيت", color = if (rem > 0) Color.White else pal.ink2, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.width(10.dp))
            StepBtn("﹣", pal, onMinus)
            Box(Modifier.widthIn(min = 40.dp), contentAlignment = Alignment.Center) {
                Text("$rem", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = pal.emerald)
            }
            StepBtn("＋", pal, onPlus)
        }
    }
}

@Composable
private fun StepBtn(sym: String, pal: DuaaPalette, onClick: () -> Unit) {
    val label = when (sym) { "+" -> "زيادة"; "−", "-" -> "إنقاص"; else -> sym }
    Box(Modifier.a11yIconButton(label, 36.dp, pal.emerald.copy(alpha = .12f), radius = 18.dp, onClick = onClick),
        contentAlignment = Alignment.Center) {
        Text(sym, color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
    }
}
