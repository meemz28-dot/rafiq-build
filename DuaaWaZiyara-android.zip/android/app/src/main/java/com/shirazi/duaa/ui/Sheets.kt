package com.shirazi.duaa.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shirazi.duaa.data.Data
import com.shirazi.duaa.data.Settings
import com.shirazi.duaa.logic.PrayerTimes
import com.shirazi.duaa.notify.PrayerScheduler
import com.shirazi.duaa.notify.DhikrScheduler
import com.shirazi.duaa.notify.RoutineScheduler
import com.shirazi.duaa.notify.SadaqaScheduler
import kotlin.math.min
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Sheet(title: String, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    ModalBottomSheet(onDismissRequest = onClose, containerColor = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 30.dp).verticalScroll(rememberScrollState())) {
            Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(bottom = 14.dp))
            content()
        }
    }
}

// ============ التسبيح ============
@Composable
fun TasbihSheet(settings: Settings, pal: DuaaPalette, onClose: () -> Unit) {
    val haptics = rememberHaptics()
    data class Mode(val key: String, val label: String, val phrase: String, val target: Int, val stages: List<Pair<String, Int>>?)
    val modes = listOf(
        Mode("zahra", "تسبيح الزهراء", "", 100, listOf("اللّٰه أكبر" to 34, "الحمد لله" to 33, "سبحان الله" to 33)),
        Mode("istighfar", "الاستغفار", "أستَغفِرُ اللهَ وأتوبُ إلَيه", 100, null),
        Mode("salawat", "الصلوات", "اللّٰهُمَّ صَلِّ عَلى مُحَمَّدٍ وآلِ مُحَمَّد", 100, null),
        Mode("tahlil", "التهليل", "لا إلٰهَ إلّا الله", 100, null),
        Mode("hawqala", "الحوقلة", "لا حَولَ ولا قُوَّةَ إلّا بِالله", 100, null),
        Mode("free", "عدّاد حر", "", 33, null),
    )
    var modeIdx by remember { mutableStateOf(0) }
    var count by remember { mutableStateOf(0) }
    var stage by remember { mutableStateOf(0) }
    val mode = modes[modeIdx]
    val staged = mode.stages != null

    Sheet("التسبيح والذكر", onClose) {
        // اختيار نوع الذكر
        androidx.compose.foundation.lazy.LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
        ) {
            items(modes.size) { idx ->
                val on = idx == modeIdx
                Box(
                    Modifier.clip(RoundedCornerShape(99.dp))
                        .background(if (on) pal.pillBrush else androidx.compose.ui.graphics.SolidColor(pal.surface2))
                        .clickable { modeIdx = idx; count = 0; stage = 0 }
                        .padding(horizontal = 16.dp, vertical = 9.dp)
                ) {
                    Text(modes[idx].label, color = if (on) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        val done = staged && stage >= mode.stages!!.size
        val target = when { staged && !done -> mode.stages!![stage].second; else -> mode.target }
        val curLabel = when {
            staged && done -> "تمّ تسبيح الزهراء (ع)"
            staged -> mode.stages!![stage].first
            else -> mode.phrase
        }
        val frac = if (target > 0) min(1f, count.toFloat() / target) else 0f

        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(228.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 20f; val d = min(size.width, size.height) - sw
                    val topLeft = Offset((size.width - d) / 2, (size.height - d) / 2)
                    drawArc(pal.line, -90f, 360f, false, topLeft = topLeft, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                    drawArc(pal.gold, -90f, 360f * frac, false, topLeft = topLeft, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 30.dp)) {
                    Text("$count", fontSize = 50.sp, fontWeight = FontWeight.ExtraBold, color = pal.emerald)
                    Text(curLabel, fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onBackground, lineHeight = 22.sp)
                    if (!done && mode.key != "free") Text("$count / $target", color = pal.ink2, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier.size(128.dp).clip(CircleShape).background(pal.heroBrush)
                    .clickable {
                        count++
                        settings.addDhikr(1)
                        if (staged && stage in mode.stages!!.indices && count >= mode.stages[stage].second) { stage++; count = 0; haptics.celebrate() }
                        else haptics.tick()
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    LineIcon(AppIcon.Beads, Color.White, 30.dp)
                    Spacer(Modifier.height(3.dp))
                    Text("سبِّح", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth()) { BigButton("تصفير", pal, false) { count = 0; stage = 0 } }

            // ===== هدف الذِّكر اليومي =====
            Spacer(Modifier.height(18.dp))
            val today = settings.dhikrTodayCount.value
            val goal = settings.dhikrGoal.value
            val gfrac = if (goal > 0) min(1f, today.toFloat() / goal) else 0f
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(pal.surface2).padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("ذِكر اليوم", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text("$today / $goal", color = pal.emerald, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(99.dp)).background(MaterialTheme.colorScheme.surface)) {
                    Box(Modifier.fillMaxWidth(gfrac).height(10.dp).clip(RoundedCornerShape(99.dp)).background(if (today >= goal) pal.good else pal.gold))
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(33, 100, 313, 1000).forEach { g ->
                        val on = goal == g
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if (on) pal.emerald else MaterialTheme.colorScheme.surface).clickable { settings.setDhikrGoal(g) }.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                            Text("$g", color = if (on) Color.White else pal.ink2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
                if (today >= goal && goal > 0) {
                    Spacer(Modifier.height(8.dp))
                    Text("بلغتَ هدفك اليوم — أحسنت 🌿", color = pal.good, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}


@Composable
fun EmptyState(icon: AppIcon, title: String, subtitle: String, pal: DuaaPalette) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 36.dp, horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(66.dp).clip(CircleShape).background(pal.emerald.copy(alpha = .10f)),
            contentAlignment = Alignment.Center
        ) { LineIcon(icon, pal.emerald, 30.dp) }
        Spacer(Modifier.height(16.dp))
        Text(title, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(subtitle, color = pal.ink2, fontSize = 13.sp, textAlign = TextAlign.Center, lineHeight = 21.sp)
    }
}

@Composable
fun BookmarksSheet(settings: Settings, pal: DuaaPalette, onClose: () -> Unit, openReader: (String, String) -> Unit) {
    var items by remember { mutableStateOf(settings.bookmarks()) }
    Sheet("العلامات المرجعية", onClose) {
        if (items.isEmpty()) {
            EmptyState(AppIcon.Scroll, "لا علامات بعد", "أثناء القراءة اضغط «ضع علامة» لحفظ موضعك في النصوص الطويلة والرجوع إليه لاحقاً.", pal)
        } else {
            items.forEach { b ->
                val cat = Data.categories.firstOrNull { it.id == b.catId }
                if (cat != null) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) {
                            ItemRow(b.title, "${cat.name} · علامة محفوظة", pal) {
                                settings.saveScroll(b.catId, b.itemId, b.scroll)
                                openReader(b.catId, b.itemId)
                            }
                        }
                        Box(Modifier.clip(RoundedCornerShape(10.dp)).clickable {
                            settings.removeBookmark(b); items = settings.bookmarks()
                        }.padding(8.dp)) {
                            LineIcon(AppIcon.ChevronEnd, pal.danger, 16.dp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FavSheet(settings: Settings, pal: DuaaPalette, onClose: () -> Unit, openReader: (String, String) -> Unit) {
    Sheet("المفضلة", onClose) {
        if (settings.favorites.isEmpty()) {
            EmptyState(AppIcon.Star, "لا مفضّلات بعد", "افتح أيّ دعاءٍ واضغط نجمة الحفظ لإضافته هنا والرجوع إليه بسرعة.", pal)
        } else {
            settings.favorites.toList().forEach { (cId, iId) ->
                val cat = Data.categories.firstOrNull { it.id == cId }
                val item = cat?.items?.firstOrNull { it.id == iId }
                if (cat != null && item != null) ItemRow(item.title, cat.name, pal) { openReader(cId, iId) }
            }
        }
    }
}

// ============ الإعدادات ============
@Composable
fun SettingsSheet(settings: Settings, pal: DuaaPalette, onClose: () -> Unit, openSheet: (String) -> Unit, onRequestNotifyPermission: () -> Unit) {
    val ctx = LocalContext.current
    Sheet("الإعدادات", onClose) {
        Text("المظهر", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        Segmented(listOf("فاتح" to "light", "داكن" to "dark"), settings.theme.value, pal) { settings.theme.value = it; settings.save() }
        Spacer(Modifier.height(14.dp))

        // ===== النسخ الاحتياطي: صيانة تقدّمك (سلاسل، قضاء، ختمة، مفضّلة) عبر ملفّ =====
        Text("النسخ الاحتياطي", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        var restoreMsg by remember { mutableStateOf<String?>(null) }
        val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) {
                try {
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(settings.exportJson().toByteArray(Charsets.UTF_8)) }
                    restoreMsg = "تمّ حفظ النسخة الاحتياطية ✓"
                } catch (e: Exception) { restoreMsg = "تعذّر الحفظ" }
            }
        }
        val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    val txt = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                    restoreMsg = if (settings.importJson(txt)) "استُعيدت النسخة ✓ — أعد فتح التطبيق لتطبيقها كاملةً" else "الملفّ ليس نسخةً صالحة من رفيق المؤمن"
                } catch (e: Exception) { restoreMsg = "تعذّرت الاستعادة" }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) { BigButton("تصدير نسخة", pal, true) { exporter.launch("rafiq-backup.json") } }
            Box(Modifier.weight(1f)) { BigButton("استعادة نسخة", pal, false) { importer.launch(arrayOf("application/json", "text/*", "application/octet-stream")) } }
        }
        restoreMsg?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = pal.emerald, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(14.dp))

        Text("حجم خط الأدعية: ${settings.fontSize.value.toInt()}", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) { BigButton("A −", pal, true) { settings.fontSize.value = (settings.fontSize.value - 1).coerceAtLeast(15f); settings.save() } }
            Box(Modifier.weight(1f)) { BigButton("A +", pal, true) { settings.fontSize.value = (settings.fontSize.value + 1).coerceAtMost(40f); settings.save() } }
        }
        Spacer(Modifier.height(8.dp))
        // معاينة حيّة بحجم الخط الحالي — يظهر أثر التغيير فوراً
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface)
                .border(1.dp, pal.line, RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            val sample = "بِسْمِ اللهِ الرَّحْمنِ الرَّحِيمِ"
            Text(
                if (settings.tashkeelOn.value) sample else com.shirazi.duaa.logic.ArabicSearch.stripTashkeel(sample),
                fontFamily = AppFonts.scripture, fontSize = settings.fontSize.value.sp,
                lineHeight = (settings.fontSize.value * 1.7f).sp,
                color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(14.dp))

        Text("التشكيل في النصوص", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, pal.line, RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (settings.tashkeelOn.value) "ظاهر" else "مخفيّ", modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
            Switch(checked = settings.tashkeelOn.value, onCheckedChange = { on ->
                settings.tashkeelOn.value = on; settings.saveReaderPrefs()
            }, colors = SwitchDefaults.colors(checkedTrackColor = pal.emerald))
        }
        Spacer(Modifier.height(14.dp))

        Text("تنبيهات أوقات الصلاة", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, pal.line, RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (settings.notifyEnabled.value) "مفعّلة" else "متوقّفة", modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
            Switch(checked = settings.notifyEnabled.value, onCheckedChange = { on ->
                settings.notifyEnabled.value = on; settings.save()
                if (on) { onRequestNotifyPermission(); PrayerScheduler.reschedule(ctx) } else PrayerScheduler.cancelAll(ctx)
            }, colors = SwitchDefaults.colors(checkedTrackColor = pal.emerald))
        }
        Spacer(Modifier.height(14.dp))

        Text("تذكير بالأذكار (صلوات / استغفار)", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, pal.line, RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (settings.dhikrEnabled.value) "مفعّلة" else "متوقّفة", modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
            Switch(checked = settings.dhikrEnabled.value, onCheckedChange = { on ->
                settings.dhikrEnabled.value = on; settings.save()
                if (on) { onRequestNotifyPermission(); DhikrScheduler.reschedule(ctx) } else DhikrScheduler.cancelAll(ctx)
            }, colors = SwitchDefaults.colors(checkedTrackColor = pal.emerald))
        }
        if (settings.dhikrEnabled.value) {
            Spacer(Modifier.height(8.dp))
            Text("عدد التذكيرات يومياً: ${settings.dhikrCount.value}", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)) { BigButton("− أقلّ", pal, true) {
                    settings.dhikrCount.value = (settings.dhikrCount.value - 1).coerceAtLeast(1); settings.save(); DhikrScheduler.reschedule(ctx)
                } }
                Box(Modifier.weight(1f)) { BigButton("+ أكثر", pal, true) {
                    settings.dhikrCount.value = (settings.dhikrCount.value + 1).coerceAtMost(12); settings.save(); DhikrScheduler.reschedule(ctx)
                } }
            }
            Spacer(Modifier.height(8.dp))
            Text("تُوزَّع بأوقات عشوائية بين الـ${DhikrScheduler.START_HOUR} صباحاً والـ${DhikrScheduler.END_HOUR - 12} مساءً، بذِكرٍ مختلف في كلّ مرّة.", color = pal.ink2, fontSize = 12.sp, lineHeight = 20.sp)
        }
        Spacer(Modifier.height(14.dp))

        // ===== تذكير التعقيبات بعد كل صلاة =====
        Text("تذكير التعقيبات بعد كل صلاة", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, pal.line, RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (settings.taqibatEnabled.value) "مفعّل" else "متوقّف", modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
            Switch(checked = settings.taqibatEnabled.value, onCheckedChange = { on ->
                settings.saveTaqibat(on)
                if (on) { onRequestNotifyPermission(); RoutineScheduler.reschedule(ctx) } else RoutineScheduler.reschedule(ctx)
            }, colors = SwitchDefaults.colors(checkedTrackColor = pal.emerald))
        }
        if (settings.taqibatEnabled.value) {
            Spacer(Modifier.height(8.dp))
            Text("تذكير لطيف بعد كل فريضة بدقائق، بتسبيح الزهراء (ع) والتعقيب — مرتبط بمواقيت صلاتك الفعلية.", color = pal.ink2, fontSize = 12.sp, lineHeight = 20.sp)
        }
        Spacer(Modifier.height(14.dp))

        // ===== تذكير صلاة الليل قبل الفجر =====
        Text("تذكير صلاة الليل قبل الفجر", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, pal.line, RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (settings.laylEnabled.value) "مفعّل" else "متوقّف", modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
            Switch(checked = settings.laylEnabled.value, onCheckedChange = { on ->
                settings.saveLayl(on)
                if (on) { onRequestNotifyPermission(); RoutineScheduler.reschedule(ctx) } else RoutineScheduler.reschedule(ctx)
            }, colors = SwitchDefaults.colors(checkedTrackColor = pal.emerald))
        }
        if (settings.laylEnabled.value) {
            Spacer(Modifier.height(8.dp))
            Text("قبل الفجر بـ ${settings.laylBeforeFajr.value} دقيقة", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)) { BigButton("− أقرب", pal, true) {
                    settings.saveLaylBefore(settings.laylBeforeFajr.value - 15); RoutineScheduler.reschedule(ctx)
                } }
                Box(Modifier.weight(1f)) { BigButton("+ أبكر", pal, true) {
                    settings.saveLaylBefore(settings.laylBeforeFajr.value + 15); RoutineScheduler.reschedule(ctx)
                } }
            }
            Spacer(Modifier.height(8.dp))
            Text("ينبّهك قبيل الفجر لإحياء ليلك بصلاة الليل ولو ركعة الوتر — مرتبط بوقت الفجر الفعلي لموقعك.", color = pal.ink2, fontSize = 12.sp, lineHeight = 20.sp)
        }
        Spacer(Modifier.height(14.dp))

        // ===== تذكير الصدقة اليومي =====
        Text("تذكير الصدقة اليومي", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, pal.line, RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (settings.sadaqaEnabled.value) "مفعّل" else "متوقّف", modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
            Switch(checked = settings.sadaqaEnabled.value, onCheckedChange = { on ->
                settings.saveSadaqa(on)
                if (on) { onRequestNotifyPermission(); SadaqaScheduler.reschedule(ctx) } else SadaqaScheduler.cancel(ctx)
            }, colors = SwitchDefaults.colors(checkedTrackColor = pal.emerald))
        }
        if (settings.sadaqaEnabled.value) {
            Spacer(Modifier.height(8.dp))
            Text("الساعة ${settings.sadaqaHour.value}:00", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)) { BigButton("− أبكر", pal, true) {
                    settings.saveSadaqaHour(settings.sadaqaHour.value - 1); SadaqaScheduler.reschedule(ctx)
                } }
                Box(Modifier.weight(1f)) { BigButton("+ أمتأخّر", pal, true) {
                    settings.saveSadaqaHour(settings.sadaqaHour.value + 1); SadaqaScheduler.reschedule(ctx)
                } }
            }
            Spacer(Modifier.height(8.dp))
            Text("يذكّرك يومياً بالصدقة ولو يسيرة، مع بيان فضلها. «الصدقة تدفع البلاء وتزيد في الرزق».", color = pal.ink2, fontSize = 12.sp, lineHeight = 20.sp)
        }
        Spacer(Modifier.height(14.dp))

        BigButton(PrayerTimes.methodByKey(settings.method.value).name, pal, true) { openSheet("method") }
        Spacer(Modifier.height(14.dp))

        Text("الموقع", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        BigButton(settings.location().name, pal, true) { openSheet("loc") }
        Spacer(Modifier.height(14.dp))

        Text("تعديل التقويم الهجري (${if (settings.hijriAdj.value > 0) "+" else ""}${settings.hijriAdj.value} يوم)", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) { BigButton("− يوم", pal, true) { settings.hijriAdj.value = (settings.hijriAdj.value - 1).coerceAtLeast(-2); settings.save() } }
            Box(Modifier.weight(1f)) { BigButton("+ يوم", pal, true) { settings.hijriAdj.value = (settings.hijriAdj.value + 1).coerceAtMost(2); settings.save() } }
        }
        Spacer(Modifier.height(10.dp))
        Text("عدّل التقويم ±يوم أو يومين عند اختلاف رؤية الهلال محلياً.", color = pal.ink2, fontSize = 12.sp)

        Spacer(Modifier.height(20.dp))

        // ===== النسخ الاحتياطي والاستعادة =====
        Text("النسخ الاحتياطي", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        var importMsg by remember { mutableStateOf<String?>(null) }
        // مُلتقط ملفّ الاستعادة
        val importLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.GetContent()
        ) { uri ->
            if (uri != null) {
                try {
                    val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    importMsg = if (settings.importBackupJson(text)) "تمّت الاستعادة بنجاح. أعد فتح التطبيق لتطبيق كلّ التغييرات." else "تعذّرت الاستعادة — تأكّد أنّ الملفّ نسخةٌ صحيحة."
                } catch (e: Exception) {
                    importMsg = "تعذّرت قراءة الملفّ."
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) {
                BigButton("تصدير نسخة", pal, true) {
                    try {
                        val json = settings.exportBackupJson()
                        val file = java.io.File(ctx.cacheDir, "rafiq_backup.json")
                        file.writeText(json)
                        val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
                        val share = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "application/json"
                            putExtra(android.content.Intent.EXTRA_STREAM, uri)
                            putExtra(android.content.Intent.EXTRA_SUBJECT, "نسخة رفيق المؤمن الاحتياطية")
                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(android.content.Intent.createChooser(share, "حفظ النسخة الاحتياطية"))
                    } catch (e: Exception) {
                        importMsg = "تعذّر التصدير."
                    }
                }
            }
            Box(Modifier.weight(1f)) {
                BigButton("استعادة نسخة", pal, true) { importLauncher.launch("application/json") }
            }
        }
        if (importMsg != null) {
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(pal.emerald.copy(alpha = .10f)).padding(12.dp)) {
                Text(importMsg!!, color = pal.emerald, fontSize = 12.sp, lineHeight = 19.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("احفظ نسخةً من تقدّمك ومفضّلتك وإعداداتك، واستعدها عند تغيير الهاتف. النسخة ملفٌّ تحفظه أو ترسله لنفسك.", color = pal.ink2, fontSize = 12.sp, lineHeight = 19.sp)

        // ===== إعادة مشاهدة الترحيب =====
        Spacer(Modifier.height(20.dp))
        Text("عن التطبيق", color = pal.ink2, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(pal.surface2)
                .clickable { settings.resetOnboarding(); onClose() }
                .padding(16.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LineIcon(AppIcon.Sparkle, pal.emerald, 20.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("إعادة مشاهدة الترحيب", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("اعرض شاشات البداية من جديد", color = pal.ink2, fontSize = 11.sp)
                }
                LineIcon(AppIcon.ChevronStart, pal.ink2, 16.dp)
            }
        }
    }
}

@Composable
private fun Segmented(options: List<Pair<String, String>>, selected: String, pal: DuaaPalette, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(pal.surface2).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { (label, value) ->
            val on = value == selected
            Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if (on) MaterialTheme.colorScheme.surface else Color.Transparent).clickable { onSelect(value) }.padding(vertical = 9.dp), contentAlignment = Alignment.Center) {
                Text(label, color = if (on) pal.emerald else pal.ink2, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

// ============ حول ============
@Composable
fun AboutSheet(pal: DuaaPalette, onClose: () -> Unit) {
    Sheet("حول التطبيق", onClose) {
        val p = MaterialTheme.colorScheme.onBackground
        Text("رفيق المؤمن — رفيق المسلم الشيعي اليومي", fontWeight = FontWeight.ExtraBold, color = p, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))
        Text("تطبيق جامع للصلاة والدعاء والزيارة وفق مذهب أهل البيت (ع): مواقيت الصلاة المحسوبة فلكياً مع تنبيهاتها، التعقيبات المشتركة والمختصة بكل صلاة، أدعية الأيام والمناسبات، الأدعية المشهورة والزيارات، خِيرة القرآن، حاسبة الخُمس، دليل صلاة الليل التفاعلي، اتجاه القبلة، متتبّع حركات الصلاة، التقويم الهجري بمناسباته، التسبيح متعدّد الأذكار، أدعية الحاجات، النصائح التربوية، محاسبة النفس، الأعمال والمستحبّات بحسب التقويم، تتبّع القضاء، أوقات الفضيلة، والوِرد اليومي.", color = p, lineHeight = 26.sp)
        Spacer(Modifier.height(10.dp))
        Text("النصوص منتقاة من كتب الأدعية والزيارات المعتبرة المتداولة، وفي مقدّمتها مفاتيح الجنان.", color = p, lineHeight = 26.sp)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(pal.surface2).padding(12.dp)) {
            Text("تنبيه: النصوص بنُسخها المتداولة المعروفة وقد تختلف يسيراً عن الطبعات الورقية؛ يُرجى مراجعة المطبوع عند الحاجة للدقّة. المواقيت وبدايات الأشهر تقريبية فيُحتاط في العبادات.", color = pal.ink2, fontSize = 13.sp, lineHeight = 22.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text("نسخة 18.6.2 — يعمل دون اتصال — بياناتك محفوظة على جهازك فقط.", color = pal.ink2, fontSize = 12.sp)
    }
}

// ============ الموقع ============
@Composable
fun LocationSheet(settings: Settings, pal: DuaaPalette, onClose: () -> Unit) {
    val ctx = LocalContext.current
    Sheet("اختر الموقع", onClose) {
        Data.cities.forEachIndexed { i, c ->
            val on = settings.customLat.value == null && settings.cityIdx.value == i
            Row(Modifier.fillMaxWidth().clickable {
                settings.cityIdx.value = i; settings.customLat.value = null; settings.customLng.value = null
                settings.customTz.value = c.tz; settings.customName.value = null; settings.save()
                PrayerScheduler.reschedule(ctx); onClose()
            }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (on) "✓ ${c.n}" else c.n, fontWeight = if (on) FontWeight.ExtraBold else FontWeight.Normal, color = if (on) pal.emerald else MaterialTheme.colorScheme.onSurface)
            }
            Divider(color = pal.line)
        }
    }
}

// ============ طريقة الحساب ============
@Composable
fun MethodSheet(settings: Settings, pal: DuaaPalette, onClose: () -> Unit) {
    val ctx = LocalContext.current
    Sheet("طريقة حساب المواقيت", onClose) {
        PrayerTimes.methods.forEach { m ->
            val on = m.key == settings.method.value
            Row(Modifier.fillMaxWidth().clickable {
                settings.method.value = m.key; settings.save(); PrayerScheduler.reschedule(ctx); onClose()
            }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (on) "✓ ${m.name}" else m.name, fontWeight = if (on) FontWeight.ExtraBold else FontWeight.Normal, color = if (on) pal.emerald else MaterialTheme.colorScheme.onSurface)
            }
            Divider(color = pal.line)
        }
    }
}
