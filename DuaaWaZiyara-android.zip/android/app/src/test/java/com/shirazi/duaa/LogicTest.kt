package com.shirazi.duaa

import com.shirazi.duaa.data.Data
import com.shirazi.duaa.data.DailyContent
import com.shirazi.duaa.data.KhiraPages
import com.shirazi.duaa.data.QuranJuz
import com.shirazi.duaa.data.KhiraVerdicts
import com.shirazi.duaa.data.sahifaOrder
import com.shirazi.duaa.logic.ArabicSearch
import com.shirazi.duaa.logic.HijriCalendar
import com.shirazi.duaa.logic.Khums
import com.shirazi.duaa.logic.PrayerTimes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

/** اختبارات وحدة للمنطق الخالص: التقويم الهجريّ، والخمس، والمواقيت، وبيانات الخيرة. تعمل على JVM دون جهاز. */
class LogicTest {

    @Test fun hijri_round_trip_is_exact_for_fifty_years() {
        val start = HijriCalendar.gToJd(2000, 1, 1); val end = HijriCalendar.gToJd(2050, 1, 1)
        var jd = start
        while (jd < end) {
            val h = HijriCalendar.jdToHijri(jd)
            assertEquals("jd $jd -> $h", jd, HijriCalendar.hijriToJd(h.y, h.m, h.d))
            assertTrue(h.m in 1..12 && h.d in 1..30)
            jd += 1
        }
    }

    @Test fun hijri_month_lengths_and_year_length_are_plausible() {
        for (y in 1440..1460) {
            var days = 0
            for (m in 1..12) { val len = HijriCalendar.monthLength(y, m); assertTrue("$y/$m len $len", len == 29 || len == 30); days += len }
            assertTrue("year $y has $days days", days == 354 || days == 355)
        }
    }

    @Test fun khums_date_matches_last_day_when_month_is_short() {
        // a 30th set as the date must fall on the 29th in a 29-day month, and must not fire twice
        for (y in 1446..1450) for (m in 1..12) {
            val len = HijriCalendar.monthLength(y, m)
            val hits = (1..len).count { d -> Khums.isKhumsDay(HijriCalendar.HDate(y, m, d), m, 30, 0) }
            assertEquals("$y/$m", 1, hits)
            assertTrue(Khums.isKhumsDay(HijriCalendar.HDate(y, m, len), m, 30, 0))
        }
    }

    @Test fun days_until_khums_day_is_never_negative_and_within_a_year() {
        for (m in 1..12) for (d in listOf(1, 15, 29, 30)) {
            val n = Khums.daysUntilKhumsDay(m, d, 0)
            assertTrue("$m/$d -> $n", n in 0..385)
            val next = Khums.daysUntilKhumsDay(m, d, 0, from = n + 1)
            assertTrue("next occurrence $m/$d -> $next", next in (n + 353)..(n + 386))
        }
    }

    @Test fun khums_calculation_matches_the_published_rule() {
        val marja = Khums.maraji.first()
        val r = Khums.calc(Khums.Inputs(cash = 100_000.0, goods = 20_000.0, khumsed = 30_000.0, debts = 10_000.0), marja)
        assertEquals(80_000.0, r.base, 1e-6)          // (100k + 20k) - (30k + 10k)
        assertEquals(16_000.0, r.khums, 1e-6)         // 20 %
        assertEquals(8_000.0, r.imam, 1e-6); assertEquals(8_000.0, r.sada, 1e-6)
        assertEquals(64_000.0, r.keep, 1e-6)
        val neg = Khums.calc(Khums.Inputs(cash = 1_000.0, debts = 5_000.0), marja)
        assertEquals(0.0, neg.khums, 1e-9)            // never negative
        val mixed = Khums.calc(Khums.Inputs(mixed = 10_000.0, mixedSeparate = true), marja)
        assertEquals(2_000.0, mixed.khums, 1e-6)      // one fifth of the mixed wealth, separately
    }

    @Test fun prayer_times_are_ordered_for_dubai_on_a_summer_day() {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dubai")).apply { set(2026, Calendar.JUNE, 21, 12, 0, 0) }
        val t = PrayerTimes.compute(cal, 25.2048, 55.2708, 4.0, "jafari")
        val seq = listOf(t.fajr, t.sunrise, t.dhuhr, t.asr, t.maghrib, t.isha)
        assertTrue("ordered $seq", seq.zipWithNext().all { (a, b) -> a < b })
        assertTrue("fajr around 4am: ${t.fajr}", t.fajr in 3.5..4.8)
        assertTrue("maghrib after sunset: ${t.maghrib}", t.maghrib in 19.0..19.8)
        assertEquals(0.5, PrayerTimes.norm(24.5), 1e-9); assertEquals(23.0, PrayerTimes.norm(-1.0), 1e-9)
    }

    @Test fun khira_verdicts_cover_every_verse_with_valid_codes() {
        assertEquals(6236, KhiraVerdicts.COUNT)
        assertEquals(KhiraVerdicts.COUNT, KhiraVerdicts.VERDICT.length)
        assertEquals(KhiraVerdicts.COUNT, KhiraVerdicts.THEME_A.length)
        assertEquals(KhiraVerdicts.COUNT, KhiraVerdicts.THEME_B.length)
        assertTrue(KhiraVerdicts.VERDICT.all { it in "gmb" })
        val codes = (KhiraVerdicts.THEME_A + KhiraVerdicts.THEME_B).toSet() - '-'
        assertTrue("unknown theme codes: ${codes - KhiraVerdicts.LABELS.keys}", codes.all { it in KhiraVerdicts.LABELS })
    }

    @Test fun sahifa_order_maps_special_ids_to_their_numbers() {
        assertEquals(7, sahifaOrder("saj-mohimmat"))
        assertEquals(20, sahifaOrder("mu-makarim"))
        assertEquals(45, sahifaOrder("saj-45"))
        assertEquals(999, sahifaOrder("unrelated"))
    }

    @Test fun search_uses_the_index_and_normalises_arabic() {
        assertEquals(ArabicSearch.normalize("الحمد لله"), ArabicSearch.normalize("أَلْحَمْدُ لِلّٰهِ"))
        val hits = ArabicSearch.search("دعاء كميل")
        assertTrue("no hits", hits.isNotEmpty())
        assertTrue("first hit: ${hits.first().item.title}", hits.first().item.title.contains("كميل"))
        assertTrue(ArabicSearch.search("   ").isEmpty())
    }

    @Test fun khira_pages_cover_the_mushaf_in_order() {
        assertEquals(604, KhiraPages.START.size)
        assertEquals(0, KhiraPages.START[0])                 // الفاتحة ١ في الصفحة ١
        for (p in 1 until 604) assertTrue("page ${p + 1} not after page $p", KhiraPages.START[p] > KhiraPages.START[p - 1])
        assertEquals(1, KhiraPages.pageOf(0))
        assertEquals(2, KhiraPages.pageOf(KhiraPages.START[1]))
        assertEquals(604, KhiraPages.pageOf(6235))
        assertEquals(0..6, KhiraPages.versesOf(1, 6236))      // الفاتحة كاملةً في الصفحة الأولى
        assertEquals(KhiraPages.START[603]..6235, KhiraPages.versesOf(604, 6236))
        assertEquals(KhiraVerdicts.COUNT, 6236)
    }

    @Test fun kafi_hadith_are_graded_and_referenced() {
        val ids = listOf("ahadith", "kafi-dua", "kafi-quran", "kafi-ishra")
        val cats = Data.categories.filter { it.id in ids }
        assertEquals(4, cats.size)
        for (c in cats) for (item in c.items) {
            assertTrue(item.id, item.src?.contains("الكافي") == true)
            for (h in item.text.split("\n\n")) assertTrue("${item.id} ungraded", h.trimEnd().endsWith("]"))
        }
        assertTrue(DailyContent.hikam.size > 100)
        assertTrue(DailyContent.hikmaOfDay(0).who.contains("الكافي"))
    }

    @Test fun juz_starts_are_ordered() {
        assertEquals(30, QuranJuz.SURA.size)
        assertEquals(1, QuranJuz.SURA[0]); assertEquals(1, QuranJuz.AYA[0])
        for (j in 1 until 30) assertTrue(QuranJuz.SURA[j] >= QuranJuz.SURA[j - 1])
    }
}
