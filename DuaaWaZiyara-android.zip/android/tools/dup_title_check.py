#!/usr/bin/env python3
"""No two items in the same category may share a title (users see the name twice in a list).
Cross-listing one item, or the same title in different categories, is allowed."""
import re, glob, sys
from collections import defaultdict
def span(t, i):
    d, j = 0, i
    while j < len(t):
        if t.startswith('"""', j): j = t.find('"""', j + 3) + 3; continue
        c = t[j]
        if c == '"':
            k = j + 1
            while t[k] != '"': k += 2 if t[k] == '\\' else 1
            j = k + 1; continue
        if c == '(': d += 1
        elif c == ')':
            d -= 1
            if d == 0: return j + 1
        j += 1
D = 'app/src/main/java/com/shirazi/duaa/data/'
alld = '\n'.join(open(f, encoding='utf-8').read() for f in glob.glob(D + 'Data*.kt') if 'Withdrawn' not in f)
lists = {}
for m in re.finditer(r'internal val (\w+)\s*:\s*List<DuaaItem>\s*=\s*', alld):
    r = alld[m.end():]; lists[m.group(1)] = r[:span(r, 6)] if r.startswith('listOf(') else r.split('\n')[0]
def ids_of(expr, seen=()):
    if expr.startswith('listOf('): return re.findall(r'DuaaItem\("([a-z0-9-]+)"', expr[:span(expr, 6)])
    return [i for w in re.findall(r'\w+', expr) if w in lists and w not in seen for i in ids_of(lists[w], seen + (w,))]
titles = {m.group(1): m.group(2).strip() for m in re.finditer(r'DuaaItem\("([a-z0-9-]+)", """([^"]*)"""', alld)}
bad = []
for m in re.finditer(r'internal val cat_([a-z]+): Category = Category\(', alld):
    call = alld[m.end() - 1: span(alld, m.end() - 1)][1:-1]; depth = last = j = 0
    while j < len(call):
        if call.startswith('"""', j): j = call.find('"""', j + 3) + 3; continue
        ch = call[j]
        if ch == '"':
            k = j + 1
            while call[k] != '"': k += 2 if call[k] == '\\' else 1
            j = k + 1; continue
        depth += (ch == '(') - (ch == ')')
        if ch == ',' and depth == 0: last = j + 1
        j += 1
    seen = defaultdict(list)
    for i in dict.fromkeys(ids_of(call[last:].strip())): seen[titles.get(i, '')].append(i)
    bad += [(m.group(1), ti, v) for ti, v in seen.items() if len(v) > 1]
for b in bad: print('DUPLICATE TITLE', b)
print('TITLES: ALL OK' if not bad else f'TITLES: {len(bad)} DUPLICATES')
sys.exit(1 if bad else 0)
