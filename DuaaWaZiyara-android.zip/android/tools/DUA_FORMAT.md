# Dua text-file format — رفيق المؤمن

Send a plain `.txt` file (UTF-8) in this shape and I ingest it in one command. Your file is the trusted source; nothing is pulled from Wikipedia.

## Minimal example

```
# category: mashhura

@@@
title: دعاء العهد
src: مفاتيح الجنان
intro: يُقرأ صباح كل يوم لتجديد العهد مع الإمام (عج)
text:
اللّهُمَّ رَبَّ النُّورِ الْعَظِيمِ ...

[continue the full text; leave a blank line between paragraphs]
```

## Rules (short)

1. **First line(s):** `# category: <id>` — where to file the duas. Use an existing id
   (e.g. `sahifa`, `mashhura`, `ziyarat`, `munajat`, `taqibat` …) or a brand-new one.
2. **`@@@`** on its own line separates one dua from the next. One file can hold many.
3. **Per dua:**
   - `title:` — required (the display name)
   - `src:` — recommended (e.g. "الصحيفة السجّادية — الدعاء ٤٧" or "إقبال الأعمال")
   - `intro:` — optional one-line description
   - `id:` — optional; I auto-generate a safe one if you omit it
   - `text:` — required; everything after this line (until the next `@@@`) is the body.
     Blank lines become paragraph breaks.

## New category (optional header lines)

Only needed if `category:` is an id that doesn't exist yet:

```
# category: iqbal
# category_name: إقبال الأعمال
# category_desc: من أدعية السيّد ابن طاووس (ره)
# category_icon: Scroll
```

## What the tool does automatically

- Strips stray verse-number markers, brackets, and double spaces.
- Rejects any entry with Persian letters (چ پ ژ گ) or a `"""` that would break the build.
- Skips duplicates (same title already in that category).
- Runs a brace / paren / quote balance check before writing — refuses to write if unbalanced.
- Prints exactly what was added and skipped.

## To run

```
python3 tools/ingest_duas.py my_duas.txt --dry-run   # preview
python3 tools/ingest_duas.py my_duas.txt             # apply
```

Then I bump the version and build. Provenance stays clean: whatever source you paste
(al-Kafeel, Al-Seraj, a printed manasik you typed up) is what ships — no wiki sources.
