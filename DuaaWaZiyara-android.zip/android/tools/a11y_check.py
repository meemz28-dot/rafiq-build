#!/usr/bin/env python3
"""Accessibility regression gate.
1) No Text() below 11sp (Arabic at 10sp is hard to read; allowlisted: the Khatma day grid).
2) Small icon chips (38-40dp) must not be made clickable directly; use Modifier.a11yIconButton(),
   which gives a 48dp touch area and a spoken label."""
import re, glob, sys
ALLOW_SMALL_TEXT = {('KhatmaScreen.kt', 'fontSize = 9.sp')}
bad = []
for f in glob.glob('app/src/main/java/**/ui/*.kt', recursive=True):
    name = f.split('/')[-1]
    for n, l in enumerate(open(f, encoding='utf-8').read().split('\n'), 1):
        m = re.search(r'Text\([^\n]*(fontSize = (?:[5-9]|10)(?:\.\d)?\.sp)', l)
        if m and (name, m.group(1)) not in ALLOW_SMALL_TEXT: bad.append((name, n, 'text < 11sp'))
        if re.search(r'\.size\((?:3[6-9]|40)\.dp\)[^\n]*\.clickable', l) and 'a11yIconButton' not in l:
            bad.append((name, n, 'small icon chip clickable without a11yIconButton'))
for b in bad: print('A11Y', b)
print('A11Y: ALL OK' if not bad else f'A11Y: {len(bad)} ISSUES')
sys.exit(1 if bad else 0)
