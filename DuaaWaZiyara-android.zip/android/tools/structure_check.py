#!/usr/bin/env python3
"""Structural gate: manifest classes exist, referenced resources exist, raw strings balanced,
and every capitalised call resolves to a project definition, an import, or a known library symbol."""
import re, glob, os, sys
S = 'app/src/main/'
kt = {f: open(f, encoding='utf-8').read() for f in glob.glob(S + 'java/**/*.kt', recursive=True)}
allkt = '\n'.join(kt.values()); man = open(S + 'AndroidManifest.xml', encoding='utf-8').read()
bad = []
defined_types = set(re.findall(r'\b(?:class|object) (\w+)', allkt))
for c in re.findall(r'android:name="(\.[\w.]+)"', man):
    if c.split('.')[-1] not in defined_types: bad.append(f'manifest class missing: {c}')
res = {k: {os.path.splitext(os.path.basename(f))[0] for d in glob.glob(S + f'res/{k}*') for f in glob.glob(d + '/*')} for k in ('font', 'drawable', 'mipmap', 'raw', 'xml')}
for k in res:
    for n in set(re.findall(r'R\.' + k + r'\.(\w+)', allkt)):
        if n not in res[k]: bad.append(f'missing resource R.{k}.{n}')
for k, n in set(re.findall(r'@(drawable|mipmap|xml|font)/(\w+)', man)):
    if n not in res[k]: bad.append(f'manifest resource missing @{k}/{n}')
for f, t in kt.items():
    if t.count('"""') % 2: bad.append(f'unbalanced raw string in {os.path.basename(f)}')
# strings first (a MIME string like "*/*" would otherwise open a fake block comment), then comments
code = re.sub(r'"""(?:.|\n)*?"""', '""', allkt); code = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', code)
code = re.sub(r'/\*(?:.|\n)*?\*/', '', code); code = re.sub(r'//[^\n]*', '', code)
defined = set(re.findall(r'\bfun (?:[\w.<>]+\.)?([A-Z]\w*)\s*\(', code)) | defined_types
imported = set(re.findall(r'^import [\w.]+\.([A-Z]\w*)$', allkt, re.M))
known = set(open(os.path.join(os.path.dirname(__file__), 'known_symbols.txt')).read().split())
for c in set(re.findall(r'(?<![\w.])([A-Z]\w*)\s*\(', code)):
    if c not in defined and c not in imported and c not in known: bad.append(f'unresolved symbol {c}(')
for b in bad: print('STRUCTURE', b)
print('STRUCTURE: ALL OK' if not bad else f'STRUCTURE: {len(bad)} ISSUES'); sys.exit(1 if bad else 0)
