import re, json
from collections import Counter
def norm(s):
    s = re.sub(r'[\u064B-\u0652\u0670\u0640\u06E1-\u06ED]', '', s)
    for a, b in (('أ','ا'),('إ','ا'),('آ','ا'),('ٱ','ا'),('ى','ي'),('ة','ه'),('ؤ','و'),('ئ','ي')):
        s = s.replace(a, b)
    return ' ' + re.sub(r'[^\u0621-\u064A]+', ' ', s) + ' '
P = r'(?:\s)(?:و|ف)?(?:ب|ل|ك)?(?:ال|لل)?'           # word start + common Arabic prefixes
# code: (label, polarity +1 good / -1 bad, weight, stems)
THEMES = {
 'J': ('الجنّة ونعيمها', +1, 3, ['جنات', 'جنه', 'الجنه', 'فردوس', 'نعيم', 'سندس', 'استبرق', 'حور', 'قوارير', 'ارايك', 'عطاونا', 'يعصمك']),
 'R': ('الرحمة والمغفرة', +1, 2, ['رحمه', 'رحمت', 'يغفر', 'اغفر', 'مغفره', 'غفور', 'غفار', 'التواب', 'يتوب', 'تاب']),
 'B': ('البشارة', +1, 2, ['بشري', 'يبشر', 'بشرهم', 'بشره', 'بشرناه', 'مبشر']),
 'N': ('النصر والفتح', +1, 3, ['نصر', 'ينصر', 'ننصر', 'فتحا', 'فتحنا', 'الفتح', 'الغالبون', 'غالبون']),
 'H': ('الهداية', +1, 1, ['هدي', 'يهدي', 'يهديهم', 'المهتدين', 'مهتدون', 'رشدا', 'الرشد']),
 'F': ('الفلاح والفوز', +1, 3, ['فوز', 'الفوز', 'فازوا', 'الفايزون', 'فايزون', 'المفلحون', 'مفلحون', 'تفلحون', 'افلح']),
 'Z': ('الرزق والفضل والبركة', +1, 2, ['رزق', 'يرزق', 'رزقا', 'فضله', 'فضلا', 'بركات', 'مبارك', 'مباركا', 'نعمه', 'نعمت']),
 'X': ('التسبيح والحمد', +1, 2, ['سبحان', 'الحمد لله', 'فسبحان', 'يسبح', 'سبح']),
 'O': ('النجاة والإنقاذ', +1, 3, ['انقذكم', 'نجيناه', 'نجيناهم', 'فنجيناه', 'ننجي', 'ينجي', 'نجاه']),
 'V': ('إجابة الدعاء والاصطفاء', +1, 3, ['استجب', 'استجاب', 'يستجيب', 'فاستجبنا', 'اجيب', 'المصطفين', 'الاخيار', 'المخلصين', 'مشكورا', 'يبدلنا خيرا']),
 'U': ('محبّة الله', +1, 3, ['يحب المحسنين', 'يحب المتقين', 'يحب الذين', 'يحب الصابرين', 'يحب التوابين', 'يحبهم']),
 'Y': ('اليسر والفرج', +1, 3, ['يسر', 'يسرا', 'اليسري', 'مخرجا', 'فرج']),
 'T': ('الطمأنينة والأمن', +1, 3, ['تطمين', 'يطمين', 'مطمينه', 'سكينه', 'امنين', 'امنه', 'روح الله']),
 'E': ('الأجر والرضوان', +1, 2, ['اجر', 'اجرا', 'اجرهم', 'رضوان', 'رضي الله', 'الحسني', 'حسنا']),
 'S': ('صفات أهل الإيمان', +1, 1, ['المتقين', 'للمتقين', 'المحسنين', 'الصالحين', 'الصالحات', 'الصابرين', 'المومنين', 'الشاكرين']),
 'A': ('العذاب', -1, 3, ['عذاب', 'عذابا', 'العذاب', 'يعذب', 'يعذبهم']),
 'Q': ('النار وجهنّم', -1, 3, ['النار', 'جهنم', 'ضريع', 'زقوم', 'الزقوم', 'الحميم', 'حميما', 'غسلين', 'صديد', 'الجحيم', 'جحيم', 'سعير', 'سقر', 'الحطمه', 'لظي']),
 'L': ('اللعن والويل', -1, 3, ['لعن', 'لعنه', 'لعنهم', 'ويل']),
 'K': ('الخسران والهلاك', -1, 3, ['مهلك', 'خسر', 'الخاسرين', 'خاسرين', 'الاخسرين', 'اهلكنا', 'دمرنا', 'اغرقنا', 'هلك', 'المهلكين', 'فاخذهم', 'اخذناهم', 'فاخذناهم', 'اخذته', 'الصيحه', 'الرجفه']),
 'G': ('الغضب والمقت والمعصية', -1, 3, ['غضب', 'مقتا', 'سخط', 'سواتهما', 'وعصي']),
 'W': ('ذكر أهل الضلال', -1, 1, ['الظالمين', 'الكافرين', 'الفاسقين', 'المنافقين', 'المجرمين', 'المكذبين', 'المشركين', 'الضالين', 'كفروا', 'يضل']),
}
COMFORT = ['لا تحزن', 'لا تخف', 'لا تخافوا', 'لا تحزنوا', 'لا تقنطوا', 'لا تياسوا', 'لا خوف عليهم', 'لا تهنوا']
_LAST = {}
def theme_hits(text):
    classify(text); return dict(_LAST)
def classify(text):
    t = norm(text); hits = Counter()
    for code, (_, pol, w, stems) in THEMES.items():
        for st in stems:
            n = len(re.findall(P + re.escape(st), t))
            if n: hits[code] += w * min(n, 2)
    # indefinite «نار» counts only in an eschatological setting (not «من نار السموم», not a lit fire)
    if re.search(P + 'نارا?\\s', t) and re.search(r'خالد|جهنم|عذاب|اصحاب|يصلي|سيصلي|وقود|حطب', t): hits['Q'] += 3
    # rescue FROM the Fire is a blessing, not a threat
    if re.search(r'انقذكم منها|نجاكم|زحزح عن النار|تاكله النار|نارا فلما|انست نارا|اوقد', t): hits['Q'] = 0
    # «أجر» meaning a fee the Prophet does not ask for is not a reward
    if re.search(r'(اسالكم|تسالهم|يسالكم|نسالك)\s+(عليه\s+)?(من\s+)?اجر', t): hits['E'] = max(0, hits['E'] - 4)
    # a single passing mention of disbelievers etc. must not tip a verdict by itself
    if hits['W'] > 1: hits['W'] = 1
    if re.search(r'ورق الجنه', t): hits['J'] = max(0, hits['J'] - 3)          # the leaves of paradise in Adam's fall are not a promise
    comfort = sum(1 for c in COMFORT if (' ' + c) in t)
    if comfort: hits['T'] += 3 * comfort
    proh = len(re.findall(r'\s(?:و|ف)?لا ت\w+وا\s', t)) + len(re.findall(r'\s(?:و|ف)?لا تقرب', t))
    proh -= sum(1 for c in COMFORT if (' ' + c) in t and c.endswith('وا'))
    if proh > 0: hits['P'] = 2 * proh
    _LAST.clear(); _LAST.update(hits)
    good = sum(v for k, v in hits.items() if k in THEMES and THEMES[k][1] > 0)
    bad = sum(v for k, v in hits.items() if (k in THEMES and THEMES[k][1] < 0) or k == 'P')
    if bad >= 3 and bad > good: verdict = 'b'
    elif good >= 3 and good > bad: verdict = 'g'
    else: verdict = 'm'
    pol = {'g': +1, 'b': -1}.get(verdict)
    themes = [k for k, _ in hits.most_common() if pol and ((k == 'P' and pol < 0) or (k in THEMES and THEMES[k][1] == pol))][:2]
    return verdict, themes, good, bad
if __name__ == '__main__':
    V = json.load(open('verses.json', encoding='utf-8')); res = [classify(v['t']) for v in V]
    c = Counter(r[0] for r in res); n = len(res)
    print({k: f"{c[k]} ({100*c[k]/n:.0f}%)" for k in 'gmb'})
    json.dump([[r[0], ''.join(r[1])] for r in res], open('verdicts.json', 'w'), ensure_ascii=False)
