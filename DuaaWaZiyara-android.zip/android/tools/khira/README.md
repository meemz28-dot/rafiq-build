# Khira verdicts generator

Regenerates `app/src/main/java/com/shirazi/duaa/data/KhiraVerdicts.kt` (one verdict per Quran verse).

1. `python3 build_verses.py`  (extracts all 6,236 verses in the app's order)
2. `python3 final.py`         (classifies; writes verdicts.json)
3. Re-run the generation step from the release session to write KhiraVerdicts.kt

Rule: mercy, good news, paradise, victory, ease, forgiveness, guidance → good; punishment, Fire, destruction,
curse, prohibition → not good; stories, rulings, reports → middle. The drawn verse's own clear, one-sided meaning
decides; the previous and next verse are consulted only when the verse is silent or mixed.
Validation (Sep 2026): 24/24 on a regression set; about 83% agreement on unseen random samples, with the rare
misses mostly erring toward "middle". Scholar review of the rule is recommended.
