#!/usr/bin/env python3
"""Generates KhiraPages.kt: the first verse of each of the 604 pages of the Madina Mushaf.
Source: Tanzil Quran metadata (tanzil-quran-data.js, CC BY 3.0, tanzil.net). Run from tools/khira/."""
import re, json, os
here = os.path.dirname(os.path.abspath(__file__))
s = open(os.path.join(here, 'tanzil-quran-data.js'), encoding='utf-8').read()
i = s.index('QuranData.Page'); seg = s[i:s.index('];', i)]
P = [(int(a), int(b)) for a, b in re.findall(r'\[(\d+),\s*(\d+)\]', seg)][:604]
assert len(P) == 604 and P[0] == (1, 1) and P[1] == (2, 1)
V = json.load(open(os.path.join(here, 'verses.json'), encoding='utf-8'))
key = {(v['s'], v['n']): k for k, v in enumerate(V)}
idx = [key[p] for p in P]
assert idx == sorted(idx) and len(set(idx)) == 604
out = os.path.join(here, '..', '..', 'app/src/main/java/com/shirazi/duaa/data/KhiraPages.kt')
body = ','.join(str(x) for x in idx)
open(out, 'w', encoding='utf-8').write(
'''package com.shirazi.duaa.data

// فهرس أوّل آيةٍ في كلّ صفحةٍ من صفحات مصحف المدينة (٦٠٤ صفحات)، بترقيم الآيات في التطبيق (٠..٦٢٣٥).
// مولَّدٌ من tools/khira/pages.py عن بيانات مشروع تنزيل (tanzil.net، رخصة CC BY 3.0)، ولا يُعدَّل يدوياً.
// الصفحة اليمنى في المصحف هي الصفحة الفرديّة (١، ٣، ٥ ...)، وعددها ٣٠٢ صفحة.
internal object KhiraPages {
    const val COUNT = 604
    val START: IntArray = intArrayOf(''' + body + ''')
    /** رقم الصفحة (١..٦٠٤) التي تقع فيها الآية ذات الفهرس المعطى */
    fun pageOf(verseIndex: Int): Int {
        var lo = 0; var hi = COUNT - 1
        while (lo < hi) { val mid = (lo + hi + 1) / 2; if (START[mid] <= verseIndex) lo = mid else hi = mid - 1 }
        return lo + 1
    }
    /** فهارس آيات الصفحة (١..٦٠٤) */
    fun versesOf(page: Int, total: Int): IntRange {
        val p = page.coerceIn(1, COUNT)
        val end = if (p == COUNT) total - 1 else START[p] - 1
        return START[p - 1]..end
    }
}
''')
print('pages ok', len(idx))
