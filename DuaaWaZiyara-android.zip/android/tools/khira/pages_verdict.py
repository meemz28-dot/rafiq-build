#!/usr/bin/env python3
"""Page-level khira verdicts (the method in the app): the first verse of the right-hand page decides by its own
clear meaning; when it is silent or mixed, the lines that follow it ON THE SAME PAGE are read with it
(never the previous page). Writes PAGE_VERDICT / PAGE_THEMES into KhiraPages.kt. Run after pages.py."""
import json, re, os
from collections import Counter
import classify as C
here = os.path.dirname(os.path.abspath(__file__))
V = json.load(open(os.path.join(here, 'verses.json'), encoding='utf-8'))
kt_path = os.path.join(here, '..', '..', 'app/src/main/java/com/shirazi/duaa/data/KhiraPages.kt')
kt = open(kt_path, encoding='utf-8').read()
S = [int(x) for x in re.search(r'intArrayOf\(([^)]*)\)', kt).group(1).split(',')]
def gb(t): _, _, g, b = C.classify(t); return g, b
def page_verdict(p):                       # p: 0-based page index
    i = S[p]; end = S[p + 1] if p + 1 < len(S) else len(V)
    follow = [j for j in range(i + 1, min(i + 3, end)) if V[j]['s'] == V[i]['s']]   # next two verses on this page
    g0, b0 = gb(V[i]['t'])
    if b0 >= 2 and g0 == 0: verdict = 'b'
    elif g0 >= 2 and b0 == 0: verdict = 'g'
    else:
        g, b = 2 * g0, 2 * b0
        for j in follow: gj, bj = gb(V[j]['t']); g += gj; b += bj
        verdict = 'b' if (b >= 4 and b > g * 1.25) else 'g' if (g >= 4 and g > b * 1.25) else 'm'
    themes = ''
    pol = {'g': 1, 'b': -1}.get(verdict)
    if pol:
        tot = Counter()
        for w, j in [(2, i)] + [(1, j) for j in follow]:
            for k, c in C.theme_hits(V[j]['t']).items(): tot[k] += w * c
        themes = ''.join([k for k, _ in tot.most_common() if (k == 'P' and pol < 0) or (k in C.THEMES and C.THEMES[k][1] == pol)][:2])
    return verdict, themes
R = [page_verdict(p) for p in range(len(S))]
# reviewed readings of the right-hand pages override the keyword classifier (themes kept only when polarity agrees)
REV = json.load(open(os.path.join(here, 'page_review.json'), encoding='utf-8'))
for v in 'gbm':
    for page in REV[v]:
        old = R[page - 1]
        R[page - 1] = (v, old[1] if old[0] == v else '')
pv = ''.join(r[0] for r in R)
pa = ''.join((r[1] + '--')[0] for r in R); pb = ''.join((r[1] + '--')[1] for r in R)
block = (f'    /** حكم كلّ صفحة: أوّل آيةٍ فيها، وما يليها في الصفحة نفسها عند خلوّها من دلالة (tools/khira/pages_verdict.py) */\n'
         f'    const val PAGE_VERDICT = "{pv}"\n    const val PAGE_THEME_A = "{pa}"\n    const val PAGE_THEME_B = "{pb}"\n')
kt = re.sub(r'    /\*\* حكم كلّ صفحة.*?const val PAGE_THEME_B = "[^"]*"\n', '', kt, flags=re.S)
kt = kt.replace('    val START: IntArray', block + '    val START: IntArray', 1)
open(kt_path, 'w', encoding='utf-8').write(kt)
odd = Counter(pv[p] for p in range(0, 604, 2))
print('right-hand pages:', dict(odd))
if __name__ == '__main__':
    for p in [71, 133, 191, 235, 253, 291, 315, 365, 369, 371, 377, 405, 511, 543, 563, 565, 571, 589]:
        i = S[p - 1]; print(p, V[i]['name'], V[i]['n'], pv[p - 1], gb(V[i]['t']), V[i]['t'][:60])
