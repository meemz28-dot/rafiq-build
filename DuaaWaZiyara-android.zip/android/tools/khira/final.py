import json, random
import classify as C
V = json.load(open('verses.json', encoding='utf-8'))
def gb(t): _, _, g, b = C.classify(t); return g, b
def run():
    out = []
    for i, v in enumerate(V):
        g0, b0 = gb(v['t']); g, b = 2 * g0, 2 * b0                     # the drawn verse counts double
        for j in (i - 1, i + 1):                                         # neighbours in the same surah as context
            if 0 <= j < len(V) and V[j]['s'] == v['s']:
                gj, bj = gb(V[j]['t']); g += gj; b += bj
        # the drawn verse's own clear, one-sided meaning decides; neighbours decide only when it is silent or mixed
        if b0 >= 3 and g0 == 0: verdict = 'b'
        elif g0 >= 3 and b0 == 0: verdict = 'g'
        else: verdict = 'b' if (b >= 4 and b > g * 1.25) else 'g' if (g >= 4 and g > b * 1.25) else 'm'
        # themes to explain the verdict: from the drawn verse first, else from its neighbours
        pol = {'g': 1, 'b': -1}.get(verdict); themes = []
        if pol:
            for src in [v['t']] + [V[j]['t'] for j in (i - 1, i + 1) if 0 <= j < len(V) and V[j]['s'] == v['s']]:
                _, th, _, _ = C.classify(src)
                for k in C.classify(src)[1] if False else sorted(set(th), key=th.index):
                    pass
                hits = C.classify(src)
            # recompute theme hits properly
            from collections import Counter
            tot = Counter()
            for w, src in [(2, v['t'])] + [(1, V[j]['t']) for j in (i - 1, i + 1) if 0 <= j < len(V) and V[j]['s'] == v['s']]:
                for k in C.theme_hits(src): tot[k] += w * C.theme_hits(src)[k]
            themes = [k for k, _ in tot.most_common() if (k == 'P' and pol < 0) or (k in C.THEMES and C.THEMES[k][1] == pol)][:2]
        out.append((verdict, ''.join(themes)))
    return out
if __name__ == '__main__':
    from collections import Counter
    R = run(); c = Counter(r[0] for r in R); n = len(R)
    print('  '.join(f"{k}={100*c[k]/n:.0f}%" for k in 'gmb'))
    random.seed(7)
    for i in sorted(random.sample(range(len(V)), 30)):
        print(f"{V[i]['name']}:{V[i]['n']:<3d} [{R[i][0]}] {R[i][1]:2s} | {V[i]['t'][:80]}")
    json.dump(R, open('verdicts.json', 'w'))
