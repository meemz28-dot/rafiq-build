import re, glob, json
def span(t, i):
    d, j = 0, i
    while j < len(t):
        if t.startswith('"""', j): j = t.find('"""', j + 3) + 3; continue
        c = t[j]
        if c == '"':
            k = j + 1
            while t[k] != '"': k += 2 if t[k] == '\\' else 1
            j = k + 1; continue
        if c == '(': d += 1
        elif c == ')':
            d -= 1
            if d == 0: return j + 1
        j += 1
import os
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'app', 'src', 'main', 'java', 'com', 'shirazi', 'duaa', 'data') + os.sep
alld = '\n'.join(open(f, encoding='utf-8').read() for f in sorted(glob.glob(D + 'DataQuran*.kt')))
# follow the CATEGORY's own item order (this is the order the app's QuranIndex iterates)
allsrc = '\n'.join(open(f, encoding='utf-8').read() for f in glob.glob(D + '*.kt'))
m = re.search(r'internal val cat_quran: Category = Category\(', allsrc)
call = allsrc[m.end() - 1: span(allsrc, m.end() - 1)]
defs = {}
for mm in re.finditer(r'internal val (quranItems\w*)\s*:\s*List<DuaaItem>\s*=\s*', allsrc):
    rest = allsrc[mm.end():]
    defs[mm.group(1)] = ('list', re.findall(r'DuaaItem\("(q-\d{3})"', rest[:span(rest, 6)])) if rest.startswith('listOf(') \
        else ('expr', re.findall(r'quranItems\w*', rest.split('\n')[0]))
def resolve(name):
    kind, v = defs[name]
    return v if kind == 'list' else [i for n in v for i in resolve(n)]
top = re.findall(r'quranItems\w*', call)
ids = [i for n in top for i in resolve(n)]
assert ids == [f'q-{k:03d}' for k in range(1, 115)], ids[:5]
rx = re.compile(r'([^()]+?)\s*\((\d+)\)', re.S)
verses = []
for iid in ids:
    s = int(iid[2:]); k = alld.find(f'DuaaItem("{iid}"'); c = alld[k:span(alld, k + 8)]
    lits = re.findall(r'"""(.*?)"""', c, re.S); title = lits[0].replace('سورة ', '').strip()
    text = (lits[3] + '\n' + ' '.join(lits[4:])) if 'joinToString' in c else ''.join(lits[3:])
    for seg, n in rx.findall(text):
        seg = seg.strip()
        if s not in (1, 9) and int(n) == 1 and '\n' in seg: seg = seg[seg.rfind('\n') + 1:].strip()
        verses.append({'s': s, 'name': title, 'n': int(n), 't': seg})
json.dump(verses, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'verses.json'), 'w', encoding='utf-8'), ensure_ascii=False)
print("category order starts:", ids[:3], "... ends:", ids[-2:], "| verses:", len(verses))
