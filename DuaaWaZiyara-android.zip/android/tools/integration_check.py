#!/usr/bin/env python3
# فحص تكامل الواجهات — يتحقق أن كل تبويب/شاشة/ورقة/رابط قارئ موصول ومعرّف.
# التشغيل من جذر المشروع: python3 tools/integration_check.py
import glob, re, sys, os
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app/src/main/java/com/shirazi/duaa'))
ui = {f: open(f, encoding='utf-8').read() for f in glob.glob('ui/*.kt')}
data = {f: open(f, encoding='utf-8').read() for f in glob.glob('data/*.kt')}
app = ui['ui/DuaaApp.kt']; allui = '\n'.join(ui.values()); alldata = '\n'.join(data.values())
fails = 0
def check(label, bad):
    global fails
    ok = not bad
    print(('  OK  ' if ok else '  FAIL') + ' ' + label + ('' if ok else f' -> {bad}'))
    if not ok: fails += 1

tabs = set(re.findall(r'Tab\("([a-z]+)"', app))
routed = set(re.findall(r'"([a-z]+)" -> \w+Screen\(', app))
called = set(re.findall(r'openScreen\("([a-z]+)"\)', allui))
check('all openScreen targets routed', sorted(called - routed))
check('all tabs routed', sorted(t for t in tabs if f'"{t}" ->' not in app))
sheets_r = set(re.findall(r'"([a-z]+)" -> \w+Sheet\(', app))
sheets_c = set(re.findall(r'openSheet\("([a-z]+)"\)', allui))
check('all openSheet targets routed', sorted(sheets_c - sheets_r))
defs = set(re.findall(r'fun (\w+(?:Screen|Sheet))\(', allui))
used = set(re.findall(r'-> (\w+(?:Screen|Sheet))\(', app))
check('routed composables defined', sorted(used - defs))
ids = set(re.findall(r'DuaaItem\("([a-z0-9-]+)"', alldata))
cats = set(re.findall(r'Category\("([a-z]+)"', alldata))
links = set(re.findall(r'openReader\("([a-z]+)",\s*"([a-z0-9-]+)"\)', allui))
check('reader deep links valid', [(c,i) for c,i in links if c not in cats or i not in ids])
reg = re.findall(r'cat_([a-z]+)', re.search(r'val categories: List<Category> = listOf\((.*?)\)', data['data/AppRegistry.kt'], re.DOTALL).group(1))
dcats = set(re.findall(r'internal val cat_([a-z]+): Category', alldata))
check('categories registered==defined', sorted(set(reg) ^ dcats))
gbody = ui['ui/Icons.kt'].split('fun categoryGradient')[1].split('}')[0]
gcases = set(re.findall(r'"([a-z]+)"\s*->', gbody))
check('every category has a gradient', sorted(set(reg) - gcases) if 'else ->' not in gbody else [])
st_defs = set(re.findall(r'fun (\w+)\(', data['data/Settings.kt'])) | set(re.findall(r'va[lr] (\w+)\s*=', data['data/Settings.kt']))
st_calls = set(re.findall(r'settings\.(\w+)\b', allui))
check('settings API complete', sorted(c for c in st_calls if c not in st_defs and c != 'value'))
check('central BackHandler present', [] if 'BackHandler(enabled = reader != null' in app else ['missing'])
print(('\nINTEGRATION: ALL CHECKS PASSED' if fails == 0 else f'\nINTEGRATION: {fails} FAILURES'))
sys.exit(1 if fails else 0)
