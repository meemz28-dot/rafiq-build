#!/usr/bin/env python3
"""Brace/paren balance across all Kotlin sources. Strips strings BEFORE comments,
so '//' inside URLs (https://, market://) is never mistaken for a comment."""
import re, glob, sys
def balance(t):
    c = re.sub(r'"""(?:.|\n)*?"""', '""', t)
    c = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', c)
    c = re.sub(r'//[^\n]*', '', c)
    c = re.sub(r'/\*(?:.|\n)*?\*/', '', c)
    return c.count('{') - c.count('}'), c.count('(') - c.count(')')
bad = []
for f in glob.glob('app/src/main/java/**/*.kt', recursive=True):
    b = balance(open(f, encoding='utf-8').read())
    if b != (0, 0): bad.append((f, b))
for f, b in bad: print('UNBALANCED', f, b)
# CEILINGS: long string lines and oversized files destabilise the Kotlin compiler
for f in glob.glob('app/src/main/java/**/*.kt', recursive=True):
    import os
    if os.path.getsize(f) > 166000: bad.append((f, 'file > 166000 bytes (largest historical data file: 165,798)'))
    for n, line in enumerate(open(f, encoding='utf-8').read().split('\n'), 1):
        if len(line.encode()) > 6657: bad.append((f, f'line {n} > 6657 bytes'))
# MISSING COMMAS between list items: `""")` then a new `DuaaItem(` with no comma (broke the CI build, Sep 2026)
import re as _re
for f in glob.glob('app/src/main/java/**/*.kt', recursive=True):
    t = open(f, encoding='utf-8').read()
    for m in _re.finditer(r'(?:\"\"\"|\bnull|\))\)[ \t]*\n(?:[ \t]*\n)*[ \t]*(DuaaItem|Category|KhiraStep)\(', t):
        bad.append((f, f'missing comma before line {t.count(chr(10), 0, m.start(1)) + 1}'))
for f, b in bad: print('LIMIT', f, b) if isinstance(b, str) else None
print('BALANCE: ALL OK' if not bad else f'BALANCE: {len(bad)} FILES')
sys.exit(1 if bad else 0)
