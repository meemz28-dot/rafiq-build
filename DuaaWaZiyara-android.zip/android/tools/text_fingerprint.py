#!/usr/bin/env python3
"""Sacred-text regression guard. Fingerprints every DuaaItem (its whole call: title, source,
intro and text, including multi-segment texts) and compares with tools/TEXT_BASELINE.txt.
Prints ADDED / CHANGED / REMOVED ids so no edit to an existing text passes unnoticed.
--update rewrites the baseline after a reviewed change."""
import re, glob, hashlib, sys, os
def span(t, i):                      # t[i] == '('  -> index after the matching ')'
    d, j = 0, i
    while j < len(t):
        if t.startswith('"""', j): j = t.find('"""', j + 3) + 3; continue
        c = t[j]
        if c == '"':
            k = j + 1
            while t[k] != '"': k += 2 if t[k] == '\\' else 1
            j = k + 1; continue
        if c == '(': d += 1
        elif c == ')':
            d -= 1
            if d == 0: return j + 1
        j += 1
    raise ValueError('unbalanced')
items = {}
for f in sorted(glob.glob('app/src/main/java/com/shirazi/duaa/data/Data*.kt')):
    t = open(f, encoding='utf-8').read()
    for m in re.finditer(r'DuaaItem\("([a-z0-9-]+)"', t):
        body = t[m.start():span(t, m.start() + 8)]
        items[m.group(1)] = hashlib.sha256(body.encode()).hexdigest()[:16]
base_f = 'tools/TEXT_BASELINE.txt'
base = dict(l.split() for l in open(base_f)) if os.path.exists(base_f) else {}
added = sorted(set(items) - set(base)); removed = sorted(set(base) - set(items))
changed = sorted(k for k in items if k in base and items[k] != base[k])
if '--update' in sys.argv:
    open(base_f, 'w').write(''.join(f'{k} {v}\n' for k, v in sorted(items.items())))
print(f"TEXTS: {len(items)} | added {len(added)} | changed {len(changed)} | removed {len(removed)}" + (" | baseline updated" if '--update' in sys.argv else ""))
for tag, ids in (('CHANGED', changed), ('REMOVED', removed)):
    for i in ids: print(f"  {tag:8s} {i}")
if len(added) <= 20:
    for i in added: print(f"  ADDED    {i}")
