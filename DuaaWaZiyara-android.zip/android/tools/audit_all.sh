#!/usr/bin/env bash
# Runs every gate. Exit code is non-zero if any fails.
cd "$(dirname "$0")/.." || exit 1
fail=0
for g in balance_check structure_check import_check a11y_check dup_title_check khira_check source_check reachability_check integration_check; do
  out=$(python3 tools/$g.py 2>&1); rc=$?; echo "$out" | tail -1; [ $rc -ne 0 ] && fail=1
done
out=$(bash tools/kotlin_syntax_check.sh 2>&1); rc=$?; echo "$out" | tail -1; [ $rc -ne 0 ] && fail=1
python3 tools/text_fingerprint.py 2>/dev/null | head -1
bash tools/verify.sh | tail -1
[ $fail -eq 0 ] && echo "AUDIT: ALL GATES GREEN" || { echo "AUDIT: FAILURES ABOVE"; exit 1; }
