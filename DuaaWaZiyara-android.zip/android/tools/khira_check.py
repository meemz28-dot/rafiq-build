#!/usr/bin/env python3
"""Khira verdicts must stay aligned with the Quran text they were generated from (position-matched)."""
import re, sys, subprocess, json, os, hashlib
here = os.path.dirname(os.path.abspath(__file__))
subprocess.run([sys.executable, 'build_verses.py'], cwd=os.path.join(here, 'khira'), check=True, capture_output=True)
V = json.load(open(os.path.join(here, 'khira', 'verses.json'), encoding='utf-8'))
kt = open(os.path.join(here, '..', 'app/src/main/java/com/shirazi/duaa/data/KhiraVerdicts.kt'), encoding='utf-8').read()
get = lambda n: re.search(n + r' = "([^"]*)"', kt).group(1)
verdict, ta, tb = get('VERDICT'), get('THEME_A'), get('THEME_B')
sig_now = hashlib.sha256(''.join(v['t'] for v in V).encode()).hexdigest()[:16]
sig_saved = re.search(r'VERSES_SIG = "([0-9a-f]+)"', kt)
problems = []
if not (len(V) == len(verdict) == len(ta) == len(tb) == 6236): problems.append(f'length mismatch: verses {len(V)}, verdicts {len(verdict)}')
if set(verdict) - set('gmb'): problems.append('invalid verdict codes')
if sig_saved and sig_saved.group(1) != sig_now: problems.append('Quran text changed since verdicts were generated: regenerate tools/khira')
# صفحات المصحف: أوّل آية في كلّ صفحة يجب أن تطابق بيانات تنزيل على نصّ الآيات الحالي
pk = open(os.path.join(here, '..', 'app/src/main/java/com/shirazi/duaa/data/KhiraPages.kt'), encoding='utf-8').read()
start = [int(x) for x in re.search(r'intArrayOf\(([^)]*)\)', pk).group(1).split(',')]
tz = open(os.path.join(here, 'khira', 'tanzil-quran-data.js'), encoding='utf-8').read()
seg = tz[tz.index('QuranData.Page'):]; seg = seg[:seg.index('];')]
P = [(int(a), int(b)) for a, b in re.findall(r'\[(\d+),\s*(\d+)\]', seg)][:604]
key = {(v['s'], v['n']): k for k, v in enumerate(V)}
if len(start) != 604 or start != [key.get(x, -1) for x in P]: problems.append('KhiraPages out of date: run tools/khira/pages.py')
pvd = re.search(r'PAGE_VERDICT = "([^"]*)"', pk); pta = re.search(r'PAGE_THEME_A = "([^"]*)"', pk); ptb = re.search(r'PAGE_THEME_B = "([^"]*)"', pk)
if not (pvd and pta and ptb) or not (len(pvd.group(1)) == len(pta.group(1)) == len(ptb.group(1)) == 604) or set(pvd.group(1)) - set('gmb'):
    problems.append('page verdicts missing or malformed: run tools/khira/pages_verdict.py')
else:
    rev = json.load(open(os.path.join(here, 'khira', 'page_review.json'), encoding='utf-8'))
    bad = [p for v in 'gbm' for p in rev[v] if pvd.group(1)[p - 1] != v]
    if bad: problems.append(f'reviewed pages not applied: {bad[:5]}')
print('KHIRA: ALL OK' if not problems else 'KHIRA: ' + '; '.join(problems))
sys.exit(1 if problems else 0)
