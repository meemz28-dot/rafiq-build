#!/usr/bin/env python3
"""Every DuaaItem must be reachable from a registered category (or deliberately quarantined in
DataWithdrawn.kt). Catches items spliced outside any list, e.g. between Category definitions,
which stay brace-balanced but fail to compile or silently vanish from the app."""
import re, glob, sys
def span(t, i):
    d, j = 0, i
    while j < len(t):
        if t.startswith('"""', j): j = t.find('"""', j + 3) + 3; continue
        c = t[j]
        if c == '"':
            k = j + 1
            while t[k] != '"': k += 2 if t[k] == '\\' else 1
            j = k + 1; continue
        if c == '(': d += 1
        elif c == ')':
            d -= 1
            if d == 0: return j + 1
        j += 1
D = 'app/src/main/java/com/shirazi/duaa/data/'
files = {f: open(f, encoding='utf-8').read() for f in glob.glob(D + 'Data*.kt')}
alld = '\n'.join(t for f, t in files.items() if not f.endswith('DataWithdrawn.kt'))
lists = {}
for m in re.finditer(r'internal val (\w+)\s*:\s*List<DuaaItem>\s*=\s*', alld):
    rest = alld[m.end():]
    lists[m.group(1)] = rest[:span(rest, 6)] if rest.startswith('listOf(') else rest.split('\n')[0]
def resolve(expr, seen=()):
    ids = []
    for lo in re.finditer(r'listOf\(', expr):
        pass
    if expr.startswith('listOf('):
        body = expr[:span(expr, 6)]
        return re.findall(r'DuaaItem\("([a-z0-9-]+)"', body)
    for ident in re.findall(r'\w+', expr):
        if ident in lists and ident not in seen: ids += resolve(lists[ident], seen + (ident,))
    return ids
reg = open(D + 'AppRegistry.kt', encoding='utf-8').read()
cats = re.findall(r'cat_([a-z]+)', re.search(r'val categories: List<Category> = listOf\((.*?)\)', reg, re.DOTALL).group(1))
reach = set()
for c in cats:
    m = re.search(r'internal val cat_' + c + r': Category = Category\(', alld)
    call = alld[m.end() - 1: span(alld, m.end() - 1)][1:-1]
    depth = 0; last = 0; j = 0
    while j < len(call):
        if call.startswith('"""', j): j = call.find('"""', j + 3) + 3; continue
        ch = call[j]
        if ch == '"':
            k = j + 1
            while call[k] != '"': k += 2 if call[k] == '\\' else 1
            j = k + 1; continue
        if ch == '(': depth += 1
        elif ch == ')': depth -= 1
        elif ch == ',' and depth == 0: last = j + 1
        j += 1
    expr = call[last:].strip()
    reach |= set(resolve(expr)) if expr.startswith('listOf(') else set(i for ident in re.findall(r'\w+', expr) if ident in lists for i in resolve(lists[ident]))
defined = set(re.findall(r'DuaaItem\("([a-z0-9-]+)"', alld))
orphans = sorted(defined - reach)
print(f"REACHABILITY: {len(reach)} reachable of {len(defined)} defined" + (f" | ORPHANS: {orphans}" if orphans else " | ALL OK"))
sys.exit(1 if orphans else 0)
