#!/usr/bin/env python3
"""Imports graded hadith from Usul al-Kafi, volume 2, out of ThaqalaynData (CC0, github.com/narmafraz/ThaqalaynData).
Only narrations that al-Majlisi (Mir'at al-'Uqul) grades sahih, hasan, muwaththaq or mu'tabar are kept; weak,
unknown (majhul) and mursal ones are left out. Each item is one chapter (bab), with every kept hadith numbered
as in al-Kafi and its grading shown. Usage: python3 import_kafi.py /path/to/ThaqalaynData"""
import json, os, re, sys, glob
SRC = sys.argv[1]
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', '..', 'app/src/main/java/com/shirazi/duaa/data')
AR = '٠١٢٣٤٥٦٧٨٩'
ar = lambda n: ''.join(AR[int(c)] for c in str(n))
BOOKS = [  # (kafi book index, category id, name, desc, kotlin val)
    (1, 'ahadith', 'الكافي: الإيمان والكفر', 'أحاديث أصول الكافي في الإيمان والأخلاق وآفات النفس، ممّا صحّحه العلامة المجلسي', 'cat_ahadith'),
    (2, 'kafi-dua', 'الكافي: كتاب الدعاء', 'فضل الدعاء وآدابه وأوقاته وما ورد فيه من أصول الكافي', 'cat_kafidua'),
    (3, 'kafi-quran', 'الكافي: فضل القرآن', 'فضل القرآن وحَمَلته وتلاوته من أصول الكافي', 'cat_kafiquran'),
    (4, 'kafi-ishra', 'الكافي: العِشرة', 'آداب المعاشرة والصحبة والجوار من أصول الكافي', 'cat_kafiishra'),
]
BOOK_TITLE = {1: 'كتاب الإيمان والكفر', 2: 'كتاب الدعاء', 3: 'كتاب فضل القرآن', 4: 'كتاب العشرة'}
GOOD = ['صحيح', 'حسن', 'موثق', 'معتبر', 'موثّق', 'كالصحيح']
BAD = ['ضعيف', 'مجهول', 'مرسل', 'مرفوع', 'مختلف']
MARK = re.compile(r'\(\s*(عليه السلام|عليها السلام|صلى الله عليه وآله(?: وسلم)?|عليهم السلام)\s*\)')

def grade(gr):
    """Majlisi's grading of the hadith (first grader), normalised; None if not acceptable."""
    for g in gr or []:
        if 'Majlisi' not in g: continue
        word = re.sub(r'<[^>]+>', '', g.split(':', 1)[1].split(' - ')[0]).strip()
        word = re.sub(r'\s+', ' ', word)
        if any(b in word for b in BAD): return None
        if any(k in word for k in GOOD): return word
        return None
    return None

def matn(text):
    """The narration from its immediate attribution onwards: 'عن أبي عبد الله (عليه السلام) قال …'."""
    t = re.sub(r'\s+', ' ', ' '.join(text)).strip()
    m = MARK.search(t)
    if not m: return None
    head = t[:m.start()]
    k = max(head.rfind(' عَنْ '), head.rfind(' عَنِ '))      # the narrator who heard it from the Infallible
    if k < 0: k = max(head.rfind(' قَالَ '), head.rfind(' سَمِعْتُ '), head.rfind(' سَأَلْتُ '))
    start = k + 1 if k >= 0 else 0
    s = t[start:]
    s = MARK.sub(lambda x: '(' + x.group(1) + ')', s)
    s = s.replace(' و ', ' وَ ') if False else s
    return s.strip()

def clean_title(t):
    t = re.sub(r'\s+', ' ', t.replace('‏', '')).strip()
    return MARK.sub(lambda x: '(' + x.group(1) + ')', t)

kafi = json.load(open(os.path.join(SRC, 'books/complete/al-kafi.json')))
vol2 = kafi['chapters'][1]
cats = {}
stats = {'kept': 0, 'seen': 0}
for bi, cid, name, desc, val in BOOKS:
    book = vol2['chapters'][bi - 1]
    items = []; prev_title = None; seen_titles = set()
    for ch in book['chapters']:
        ci = int(ch['path'].rsplit(':', 1)[1])
        title = clean_title(ch['titles'].get('ar', '')) or 'بابٌ في فضل القرآن'
        if re.match(r'^بَابٌ آخَرُ', title) and prev_title: shown = prev_title + ' (بابٌ آخر)'
        else: shown = title; prev_title = title
        while shown in seen_titles: shown += ' ـ'
        hs = []
        for f in sorted(glob.glob(os.path.join(SRC, f'books/al-kafi/2/{bi}/{ci}/*.json')), key=lambda p: int(re.sub(r'\D', '', os.path.basename(p)) or 0)):
            if re.search(r'\.[a-z]{2}\.json$', f): continue
            v = json.load(open(f, encoding='utf-8'))['data']['verse']
            stats['seen'] += 1
            g = grade(v.get('gradings'))
            if not g: continue
            chain = ''.join(p.get('text', '') for p in (v.get('narrator_chain') or {}).get('parts', []))
            body = matn([chain] + list(v.get('text', [])))
            if not body or len(body) > 1800 or '"""' in body or '$' in body: continue
            hs.append((v['local_index'], body, g))
        if not hs: continue
        seen_titles.add(shown)
        stats['kept'] += len(hs)
        text = '\n\n'.join(f'{ar(n)}. {b}\n[{g}]' for n, b, g in hs)
        nums = '، '.join(ar(n) for n, _, _ in hs)
        src = f'الكافي للكليني، ج٢، {BOOK_TITLE[bi]}، الباب {ar(ci)} — الأحاديث: {nums}. التصحيح للعلامة المجلسي في مرآة العقول (عن بيانات مشروع ثقلين)'
        items.append((f'kf{bi}-{ci}', shown, src, text))
    cats[val] = (cid, name, desc, items)

# write files under the size ceilings (≤ 150 KB per file)
for f in glob.glob(os.path.join(OUT, 'DataKafi*.kt')): os.remove(f)
files = []; cur = []; size = 0; cat_parts = {}
def flush():
    global cur, size
    if cur: files.append(cur); cur = []; size = 0
for val, (cid, name, desc, items) in cats.items():
    for it in items:
        b = len(('\n'.join(it)).encode())
        if size + b > 140000: flush()
        cur.append((val, it)); size += b
flush()
for n, chunk in enumerate(files, 1):
    vals = []
    for val, it in chunk:
        if val not in vals: vals.append(val)
    body = ['package com.shirazi.duaa.data', '',
            '// مولَّدٌ من tools/hadith/import_kafi.py عن بيانات مشروع ثقلين (ThaqalaynData، رخصة CC0). لا يُعدَّل يدوياً.', '']
    for val in vals:
        part = f'kafi{n}{val.replace("cat_", "").capitalize()}'
        cat_parts.setdefault(val, []).append(part)
        rows = []
        for v2, (i, t, s, x) in chunk:
            if v2 != val: continue
            rows.append(f'      DuaaItem("{i}", """{t}""", """{s}""", null, """{x}""")')
        body.append(f'internal val {part}: List<DuaaItem> = listOf(\n' + ',\n'.join(rows) + '\n)\n')
    open(os.path.join(OUT, f'DataKafi{n:02d}.kt'), 'w', encoding='utf-8').write('\n'.join(body))
# categories file
body = ['package com.shirazi.duaa.data', '', '// أبواب أصول الكافي (ج٢) — مولَّدٌ من tools/hadith/import_kafi.py', '']
for val, (cid, name, desc, items) in cats.items():
    if val == 'cat_ahadith': continue  # defined in DataPart12 (existing id), filled below
    body.append(f'internal val {val}: Category = Category("{cid}", "📜", """{name}""", """{desc}""", ' + ' + '.join(cat_parts.get(val, ['emptyList()'])) + ')')
body.append('internal val kafiIman: List<DuaaItem> = ' + ' + '.join(cat_parts.get('cat_ahadith', ['emptyList()'])))
open(os.path.join(OUT, 'DataKafiIndex.kt'), 'w', encoding='utf-8').write('\n'.join(body) + '\n')
print(f"seen {stats['seen']} hadith, kept {stats['kept']} graded, {sum(len(c[3]) for c in cats.values())} chapters, {len(files)} data files")
for val, (cid, name, desc, items) in cats.items(): print(' ', cid, len(items), 'chapters')

# ===== حكمة اليوم: أقوالٌ قصيرة صحيحة السند من الكافي، مع القائل والمرجع =====
SPEAKERS = [('رَسُولُ اللَّهِ', 'النبي الأعظم (ص)'), ('رَسُولِ اللَّهِ', 'النبي الأعظم (ص)'), ('النَّبِيُّ', 'النبي الأعظم (ص)'),
            ('أَمِيرُ الْمُؤْمِنِينَ', 'أمير المؤمنين (ع)'), ('أَمِيرِ الْمُؤْمِنِينَ', 'أمير المؤمنين (ع)'),
            ('عَلِيُّ بْنُ الْحُسَيْنِ', 'الإمام السجّاد (ع)'), ('عَلِيِّ بْنِ الْحُسَيْنِ', 'الإمام السجّاد (ع)'),
            ('أَبِي جَعْفَرٍ', 'الإمام الباقر (ع)'), ('أَبَا جَعْفَرٍ', 'الإمام الباقر (ع)'), ('أَبُو جَعْفَرٍ', 'الإمام الباقر (ع)'),
            ('أَبِي عَبْدِ اللَّهِ', 'الإمام الصادق (ع)'), ('أَبَا عَبْدِ اللَّهِ', 'الإمام الصادق (ع)'), ('أَبُو عَبْدِ اللَّهِ', 'الإمام الصادق (ع)'),
            ('الرِّضَا', 'الإمام الرضا (ع)'), ('أَبِي الْحَسَنِ', 'أبو الحسن (ع)'), ('أَبَا الْحَسَنِ', 'أبو الحسن (ع)')]
import unicodedata
def bare(t):
    t = ''.join(c for c in unicodedata.normalize('NFKD', t) if not unicodedata.combining(c))
    return t.replace('ی', 'ي').replace('ک', 'ك').replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('\u200c', '')
hikam = []
for bi, cid, name, desc, val in BOOKS:
    for it in cats[val][3]:
        ch = it[0]
        for block in it[3].split('\n\n'):
            body, g = block.rsplit('\n[', 1); g = g.rstrip(']')
            num, body = body.split('. ', 1)
            marks = list(MARK.finditer(body))
            if not marks: continue
            last = marks[-1]
            before = body[:last.start()]
            who = None
            nb = bare(before)
            for k, lab in SPEAKERS:
                p = nb.rfind(bare(k))
                if p >= 0 and (who is None or p > who[0]): who = (p, lab)
            if not who: continue
            after = body[last.end():]
            m2 = re.match(r'\s*(?:أَنَّهُ\s+)?(?:قَالَ|يَقُولُ)\s+(.*)$', after)
            if not m2: continue
            saying = m2.group(1).strip().rstrip(' .').strip()
            if any(w in bare(saying) for w in ['سمعته', 'التقية', 'الفروج', 'الدم']) or bare(saying).startswith('قل '): continue
            if not (25 <= len(saying) <= 180) or 'قُلْتُ' in saying or 'فَقَالَ' in saying or 'سَأَلْتُ' in saying: continue
            ci = int(ch.split('-')[1])
            hikam.append((saying, f'{who[1]} · الكافي ج٢، {BOOK_TITLE[bi]}، باب {ar(ci)} ح{num} ({g})'))
rows = ',\n'.join(f'        DailyContent.Hikma("""{s}""", """{w}""")' for s, w in hikam)
open(os.path.join(OUT, 'DailyKafi.kt'), 'w', encoding='utf-8').write(
    'package com.shirazi.duaa.data\n\n// حكمة اليوم: أقوالٌ قصيرة صحيحة السند من أصول الكافي (تصحيح المجلسي) — مولَّدٌ من tools/hadith/import_kafi.py\n'
    'internal object DailyKafi {\n    val hikam: List<DailyContent.Hikma> = listOf(\n' + rows + '\n    )\n}\n')
print('daily hikam:', len(hikam))
