#!/usr/bin/env python3
"""Cross-package top-level function references must be imported. Kotlin can't be compiled in this
environment, so this catches the common 'Unresolved reference' error: a top-level fun defined in one
package (e.g. data.sahifaOrder) called from a file in another package without importing it."""
import re, glob, sys
root = 'app/src/main/java/'
files = {f: open(f, encoding='utf-8').read() for f in glob.glob(root + '**/*.kt', recursive=True)}
pkg = {f: re.search(r'^package ([\w.]+)', t, re.M).group(1) for f, t in files.items()}
defs = {}   # name -> package
for f, t in files.items():
    for m in re.finditer(r'^(?:internal |public |private )?fun ([a-z]\w*)\(', t, re.M):
        if not re.match(r'^private ', t[m.start():m.start() + 8]): defs.setdefault(m.group(1), set()).add(pkg[f])
bad = []
for f, t in files.items():
    code = re.sub(r'"""(?:.|\n)*?"""', '""', t); code = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', code); code = re.sub(r'//[^\n]*', '', code)
    for name, pkgs in defs.items():
        if pkg[f] in pkgs: continue
        if not re.search(r'(?<![\w.])' + name + r'\(', code): continue
        if any(re.search(rf'^import {re.escape(p)}\.({re.escape(name)}|\*)$', t, re.M) for p in pkgs): continue
        if re.search(rf'fun {name}\(', code): continue   # shadowed by a local definition
        bad.append((f.split('/')[-1], name, sorted(pkgs)))
for b in bad: print('MISSING IMPORT', b)
print('IMPORTS: ALL OK' if not bad else f'IMPORTS: {len(bad)} MISSING')
sys.exit(1 if bad else 0)
