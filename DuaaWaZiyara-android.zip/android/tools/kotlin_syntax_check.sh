#!/usr/bin/env bash
# Real Kotlin parser pass over every source file (syntax only). Uses a kotlin-compiler-embeddable jar if one
# is found locally (e.g. bundled with a Gradle install); skips cleanly when none is available.
cd "$(dirname "$0")/.." || exit 1
JAR=$(ls /opt/gradle*/lib/kotlin-compiler-embeddable-*.jar ~/.gradle/wrapper/dists/*/*/*/lib/kotlin-compiler-embeddable-*.jar 2>/dev/null | head -1)
[ -z "$JAR" ] && { echo "KOTLIN SYNTAX: SKIPPED (no local compiler)"; exit 0; }
L=$(dirname "$JAR"); CP=$JAR
for j in kotlin-stdlib kotlin-script-runtime kotlin-reflect trove4j annotations kotlinx-coroutines-core-jvm kotlin-daemon-embeddable; do
  CP=$CP:$(ls $L/$j-*.jar 2>/dev/null | head -1); done
OUT=$(mktemp -d)
ERR=$(java -Xmx4g -cp "$CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -d "$OUT" $(find app/src/main/java -name '*.kt') 2>&1 | grep -i "syntax error")
rm -rf "$OUT"
if [ -n "$ERR" ]; then echo "$ERR" | head -20; echo "KOTLIN SYNTAX: $(echo "$ERR" | wc -l) ERRORS"; exit 1; fi
echo "KOTLIN SYNTAX: ALL OK"
