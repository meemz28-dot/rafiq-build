#!/usr/bin/env bash
# Run from the project root BEFORE building: bash tools/verify.sh
# Confirms the source tree survived transfer intact (catches unzip/encoding corruption).
set -e
echo "== file count =="
n=$(find app/src -name "*.kt" | wc -l); echo "kotlin files: $n (expected: 95)"
echo "== checksums =="
if sha256sum -c tools/CHECKSUMS.txt --quiet; then
  echo "ALL FILES INTACT ✓ — safe to build"
else
  echo "!! CORRUPTED/MODIFIED FILES DETECTED — re-extract the zip freshly (do NOT merge over an old folder)"
  exit 1
fi
