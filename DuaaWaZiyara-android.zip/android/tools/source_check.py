#!/usr/bin/env python3
"""Every text shown in the app must cite a named Shia book (or be a disclosed explanation, not a narration)."""
import re, glob, sys
SHIA = ['مفاتيح','الصحيفة','المناجاة','نهج البلاغة','القرآن','رسالة الحقوق','مناسك','تحف العقول','مكارم الأخلاق','بحار','الكافي','كامل الزيارات','حديث الكساء',
        'مصباح','مزار','أمالي','الاحتجاج','عيون أخبار','الخصال','التوحيد','من لا يحضره','تهذيب','الإرشاد','جامع السعادات','كمال الدين','الإقبال','إقبال','مستدرك','دعوات الراوندي','الشيرازي','السيستاني']
AUTH = ['بيانٌ فقهيّ', 'إعدادٌ تربويّ', 'ملخّصٌ', 'ملخّص']
t = ''.join(open(f, encoding='utf-8').read() for f in glob.glob('app/src/main/java/com/shirazi/duaa/data/Data*.kt') if 'Withdrawn' not in f)
bad = []
for m in re.finditer(r'DuaaItem\("([a-z0-9-]+)", """([^"]*)""", (?:"""([^"]*)"""|null)', t):
    i, ti, src = m.group(1), m.group(2), m.group(3) or ''
    if i.startswith('q-'): continue
    if not (any(k in src for k in SHIA) or any(k in src for k in AUTH)): bad.append((i, ti[:30], src[:30]))
for b in bad: print('UNSOURCED', b)
print('SOURCES: ALL OK' if not bad else f'SOURCES: {len(bad)} UNSOURCED'); sys.exit(1 if bad else 0)
