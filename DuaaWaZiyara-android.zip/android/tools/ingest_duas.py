#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ingest_duas.py — load duas from a plain-text file into Data.kt, safely.

USAGE
  python3 tools/ingest_duas.py <file.txt>            # ingest
  python3 tools/ingest_duas.py <file.txt> --dry-run  # preview only

FILE FORMAT  (see tools/DUA_FORMAT.md for the full spec)
  # category: sahifa                         <- required: target category id
  # category_name: الصحيفة السجّادية          <- only used if the category is new
  # category_desc: من أدعية الإمام السجّاد (ع)
  # category_icon: Scroll

  @@@
  title: دعاء ختم القرآن
  src: الصحيفة السجّادية — الدعاء الثاني والأربعون
  intro: من دعائه (ع) عند ختم القرآن
  id: saj-42                                 <- optional; auto-generated if omitted
  text:
  بِسْمِ اللهِ الرَّحْمَنِ الرَّحِيمِ

  اللّهُمَّ ...
  @@@
  title: ...
  text:
  ...

RULES
  - '#' header lines set the target category (id required).
  - '@@@' on its own line separates entries.
  - Per entry: title + text are required; src/intro/id are optional.
  - Everything after 'text:' until the next '@@@' is the body (blank lines = paragraph breaks).
"""
import sys, re, os

DATA_DIR = "app/src/main/java/com/shirazi/duaa/data"

def data_file_for(cat_id):
    """في البنية المقسّمة: يحدّد الملف الحاوي للتصنيف؛ وإلا فملفّ المسجّل."""
    import glob as _g
    for f in sorted(_g.glob(DATA_DIR + "/*.kt")):
        if 'Category("%s"' % cat_id in open(f, encoding="utf-8").read():
            return f
    return DATA_DIR + "/AppRegistry.kt"
ICONS = "app/src/main/java/com/shirazi/duaa/ui/Icons.kt"

def clean_text(t):
    t = re.sub(r'\s*\d+\)\s*', ' ', t)          # stray passage-number markers  e.g. "31)"
    t = t.replace('[', ' ').replace(']', ' ')    # stray bracket artifacts
    t = re.sub(r'[ \t]+', ' ', t)                # collapse spaces
    t = re.sub(r'\n{3,}', '\n\n', t)             # max one blank line between paragraphs
    t = re.sub(r' *\n *', '\n', t)
    return t.strip()

def parse(path):
    raw = open(path, encoding="utf-8").read()
    cat = {"id": None, "name": None, "desc": None, "icon": "Scroll"}
    body_lines = []
    for line in raw.splitlines():
        m = re.match(r'\s*#\s*category(?:_(\w+))?\s*:\s*(.+)', line)
        if m:
            key = m.group(1) or "id"
            cat[key] = m.group(2).strip()
        else:
            body_lines.append(line)
    if not cat["id"]:
        sys.exit("ERROR: file must start with '# category: <id>'")

    entries = []
    for chunk in re.split(r'^\s*@@@\s*$', "\n".join(body_lines), flags=re.M):
        if not chunk.strip():
            continue
        e = {"id": None, "title": None, "src": "", "intro": "", "text": ""}
        lines = chunk.splitlines()
        i, in_text = 0, False
        text_buf = []
        while i < len(lines):
            ln = lines[i]
            if not in_text:
                fm = re.match(r'\s*(title|src|intro|id)\s*:\s*(.*)', ln)
                if re.match(r'\s*text\s*:\s*$', ln):
                    in_text = True
                elif fm:
                    e[fm.group(1)] = fm.group(2).strip()
                elif ln.strip():
                    # loose line before text: -> treat as title if none yet
                    if not e["title"]:
                        e["title"] = ln.strip()
            else:
                text_buf.append(ln)
            i += 1
        e["text"] = clean_text("\n".join(text_buf))
        if e["title"] and e["text"]:
            entries.append(e)
    return cat, entries

def existing_ids(s):
    return set(re.findall(r'DuaaItem\("([^"]+)"', s))

def gen_id(cat, existing):
    n = 1
    while f"{cat}-{n}" in existing:
        n += 1
    return f"{cat}-{n}"

def main():
    if len(sys.argv) < 2:
        sys.exit("usage: ingest_duas.py <file.txt> [--dry-run]")
    path, dry = sys.argv[1], "--dry-run" in sys.argv
    cat, entries = parse(path)
    DATA = data_file_for(cat["id"])
    s = open(DATA, encoding="utf-8").read()
    ids = existing_ids(s)

    # existing titles in the target category (for dedup)
    seg_m = re.search(r'Category\("' + re.escape(cat["id"]) + r'".*?\n[ \t]*\)\),?', s, re.DOTALL)
    seg = seg_m.group(0) if seg_m else ""
    existing_titles = set(re.findall(r'DuaaItem\("[^"]+", """([^"]+)"""', seg))

    added, skipped, blocks = [], [], ""
    for e in entries:
        if e["title"] in existing_titles:
            skipped.append((e["title"], "duplicate title")); continue
        if '"""' in e["text"] or '"""' in e["title"]:
            skipped.append((e["title"], "contains triple-quote")); continue
        persian = re.findall('[چپژگ]', e["text"])
        if persian:
            skipped.append((e["title"], f"persian chars {set(persian)}")); continue
        iid = e["id"] or gen_id(cat["id"], ids)
        if iid in ids:
            skipped.append((e["title"], f"id '{iid}' exists")); continue
        ids.add(iid)
        blocks += (f'      DuaaItem("{iid}", """{e["title"]}""", """{e["src"]}""", '
                   f'"""{e["intro"]}""", """{e["text"]}"""),\n')
        added.append((iid, e["title"]))

    if not blocks:
        print("Nothing to add.")
        for t, r in skipped: print(f"  skip: {t}  ({r})")
        return

    if seg_m:  # append into existing category, at the END (preserves order)
        hdr = re.search(r'    Category\("' + re.escape(cat["id"]) + r'".*?listOf\(\n', s, re.DOTALL)
        mclose = re.search(r'\n[ \t]*\)\),?', s[hdr.end():])   # category-close: ')),' in monolith, '))' in split files
        close = hdr.end() + mclose.start()
        new_s = s[:close + 1] + blocks + s[close + 1:]
    else:
        sys.exit("ERROR: category '%s' not found — create it manually in the split data files." % cat["id"])

    # validate
    c = re.sub(r'//[^\n]*', '', new_s)
    c = re.sub(r'"""(?:.|\n)*?"""', '""', c)
    c = re.sub(r'"[^"\n]*"', '""', c)
    ok = (c.count('{') == c.count('}') and c.count('(') == c.count(')')
          and new_s.count('"""') % 2 == 0)

    print(f"category: {cat['id']} | added: {len(added)} | skipped: {len(skipped)} | balanced: {ok}")
    for iid, t in added:   print(f"  + {iid}: {t}")
    for t, r in skipped:   print(f"  - skip {t}  ({r})")
    if not ok:
        sys.exit("VALIDATION FAILED — not written.")
    if dry:
        print("(dry-run — nothing written)")
    else:
        open(DATA, "w", encoding="utf-8").write(new_s)
        print("written to Data.kt ✓  (bump version + build next)")

if __name__ == "__main__":
    main()
