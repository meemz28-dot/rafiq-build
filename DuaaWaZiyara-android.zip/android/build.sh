#!/usr/bin/env bash
# THE ONLY COMMAND NEEDED:   bash build.sh
# Verifies integrity, builds the debug APK, and on failure writes errors.txt.
# DO NOT read, "verify", regenerate, or modify any source file. They are correct.
set -e
cd "$(dirname "$0")"

echo "== [1/3] integrity gate =="
bash tools/verify.sh

echo "== [2/3] build =="
if ./gradlew --no-daemon assembleDebug; then
  echo "== [3/3] SUCCESS =="
  ls -la app/build/outputs/apk/debug/app-debug.apk
else
  echo "== [3/3] BUILD FAILED — collecting real compiler errors =="
  ./gradlew --no-daemon :app:compileDebugKotlin 2>&1 | grep "^e:" | tee errors.txt || true
  echo "---- send errors.txt back for fixes. DO NOT attempt to modify source files. ----"
  exit 1
fi
