# Third-party data used in رفيق المؤمن

| Data | Source | Licence | Where in the app |
| --- | --- | --- | --- |
| Usul al-Kafi vol. 2 hadith text and al-Majlisi gradings | ThaqalaynData, github.com/narmafraz/ThaqalaynData (thaqalayn.net) | CC0 1.0 (public domain dedication) | DataKafi*.kt, categories «الكافي: …» |
| Mushaf page and juz boundaries | Tanzil Quran metadata, tanzil.net (via github.com/Yunesk/metadata) | CC BY 3.0, © Tanzil Project | KhiraPages.kt, QuranJuz.kt |
| Shia Hijri event dates (cross-check of the calendar) | ShiaCompanion, github.com/saeedjassani/ShiaCompanion | MIT, © Saeed Jassani | AppRegistry.kt occasions |

Attribution for all three is also shown in the app's About sheet.

The ShiaCompanion data is used under the MIT licence: "Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files ... The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software."

## Shia Companion (adhan notification sounds)
- Source: https://github.com/saeedjassani/ShiaCompanion (MIT License, Copyright (c) 2020 Saeed Jassani)
- Used: `assets/sounds/takbir.mp3` and the first 29.5 s of `assets/sounds/full_azan.mp3`, converted to `ios/Rafiq/Resources/Sounds/*.caf`.
- Note: the repository does not credit the reciter. Confirm recording rights before any store release.

## adhan-swift (Qibla formula and Kaaba coordinates)
- Source: https://github.com/batoulapps/adhan-swift (MIT License, Copyright (c) 2018 Batoul Apps)
- Used: the Qibla bearing equation, Kaaba coordinates 21.4225241, 39.8261818, and its Qibla test vectors.

## quran-ios (Apache-2.0)
Arabic search letter-variant mapping in `ArabicSearch.normalize` follows the approach of
quran/quran-ios `SearchTerm.swift` (https://github.com/quran/quran-ios), licensed under the Apache License 2.0.

## ShiaCompanion (MIT)
Reader auto-scroll pacing and the occasion-ranked "Today" ordering were inspired by
saeedjassani/ShiaCompanion (https://github.com/saeedjassani/ShiaCompanion), MIT License.
