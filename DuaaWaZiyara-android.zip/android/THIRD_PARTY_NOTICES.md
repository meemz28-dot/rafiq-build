# Third-party data used in رفيق المؤمن

| Data | Source | Licence | Where in the app |
| --- | --- | --- | --- |
| Usul al-Kafi vol. 2 hadith text and al-Majlisi gradings | ThaqalaynData, github.com/narmafraz/ThaqalaynData (thaqalayn.net) | CC0 1.0 (public domain dedication) | DataKafi*.kt, categories «الكافي: …» |
| Mushaf page and juz boundaries | Tanzil Quran metadata, tanzil.net (via github.com/Yunesk/metadata) | CC BY 3.0, © Tanzil Project | KhiraPages.kt, QuranJuz.kt |
| Shia Hijri event dates (cross-check of the calendar) | ShiaCompanion, github.com/saeedjassani/ShiaCompanion | MIT, © Saeed Jassani | AppRegistry.kt occasions |

Attribution for all three is also shown in the app's About sheet.

The ShiaCompanion data is used under the MIT licence: "Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files ... The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software."
