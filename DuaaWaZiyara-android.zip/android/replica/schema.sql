-- Room (SQLite) schema for on-device personal state. No server database.
-- Times stored as INTEGER epoch milliseconds UTC. No money columns (free app).
CREATE TABLE favourite (
  id         TEXT PRIMARY KEY,            -- UUID
  text_id    TEXT NOT NULL,               -- DuaaItem.id (content is in code, so no FK)
  folder     TEXT NOT NULL DEFAULT 'default',
  position   INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  UNIQUE (text_id, folder)
);
CREATE INDEX idx_fav_folder ON favourite (folder, position);

CREATE TABLE reading_state (
  text_id      TEXT PRIMARY KEY,
  paragraph    INTEGER NOT NULL DEFAULT 0,
  scroll_px    INTEGER NOT NULL DEFAULT 0,
  audio_ms     INTEGER NOT NULL DEFAULT 0,
  opened_at    INTEGER NOT NULL,
  open_count   INTEGER NOT NULL DEFAULT 1,
  updated_at   INTEGER NOT NULL
);
CREATE INDEX idx_reading_opened ON reading_state (opened_at DESC);

CREATE TABLE audio_download (
  pack_id     TEXT PRIMARY KEY,
  reciter     TEXT NOT NULL,
  bytes_total INTEGER NOT NULL,
  bytes_done  INTEGER NOT NULL DEFAULT 0,
  sha256      TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'queued'
              CHECK (status IN ('queued','downloading','verifying','ready','failed')),
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL,
  CHECK (bytes_done <= bytes_total)
);
CREATE INDEX idx_audio_status ON audio_download (status);

CREATE TABLE occasion_override (
  occasion_id TEXT PRIMARY KEY,
  muted       INTEGER NOT NULL DEFAULT 0 CHECK (muted IN (0,1)),
  remind_min  INTEGER,                    -- minutes before window start, NULL = default
  updated_at  INTEGER NOT NULL
);

CREATE TABLE app_meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
