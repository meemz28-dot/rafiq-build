# Open-source sources on GitHub for رفيق المؤمن

Searched 2026-11-05. The licence decides what we can do with each source: CC0 and MIT can be bundled with credit; GPL and AGPL code cannot be copied into the app (it would force the app open-source under the same licence), but we can study it. Repos with no licence are "all rights reserved", so we only read them.

## Tier 1: use now

| Repo | Licence | What it gives us | Use |
| --- | --- | --- | --- |
| narmafraz/ThaqalaynData | CC0 1.0 | Arabic hadith with exact book/volume/chapter/number refs from 26 Shia books: al-Kafi, Man La Yahduruhu al-Faqih, Tahdhib, Istibsar, Amali (Saduq, Mufid), Khisal, Tawhid, Uyun Akhbar al-Rida, Thawab al-Amal, Kamil al-Ziyarat, Kamal al-Din, Ghayba (Tusi, Nu'mani), Nahj al-Balagha, Risalat al-Huquq, Sifat al-Shia, Fadail al-Shia, Mu'jam al-Ahadith al-Mu'tabara | Bring back the quarantined hadith section, and source the uncited Home cards (daily hikma and dhikr), with every narration citing its book and number. Passes our "named Shia book" gate |
| Tanzil metadata (via Yunesk/metadata) | CC BY 3.0 | Mushaf page, juz, hizb and sajda boundaries | Already used: khira page table (604 pages). Next: juz/hizb navigation in the Quran reader |
| saeedjassani/ShiaCompanion | MIT | Active Flutter app (updated Nov 2026). `assets/events.json` + `events_i18n/ar.json`: 86 Shia Hijri events with Arabic titles | Cross-check our calendar occasions; study its "Today's Recitations" and Zikr reminders design |
| batoulapps/adhan-kotlin | MIT | High-precision prayer-time library (Kotlin) | Optional: cross-validate our Jafari/Leva times in unit tests |

## Tier 2: study the design, do not copy code

| Repo | Licence | Why look |
| --- | --- | --- |
| quran/quran_android | GPL-3.0 | The reference Quran reader on Android: page mode, audio follow-along, gapless playback (2.4K stars) |
| meypod/al-azan-compose | AGPL-3.0 | Privacy-first adhan + qibla app in Jetpack Compose (our stack): notifications, widgets |
| AlfaazPlus/QuranApp | GPL-3.0 | Ad-free Kotlin Quran app; good reading UX and settings patterns |
| LhacenMed/khatmah | Unspecified | Khatma planner UX, close to our Khatma screen |
| alialrikabi313/shia_hijri_calendar | MIT (Dart) | Takes the Hijri date from the Sistani office site. The idea is useful for a "marja-adjusted date" option; needs network, so opt-in only |

## Tier 3: read only (no licence or narrow fit)

- duas-pro/shia-duas-api, Anquuni/duas-pro-frontend: 80+ duas in 8 languages, no licence; translations are copyrighted.
- IslamShia-project/shia-hadith: ~35K hadith of the 14 Infallibles, no licence.
- jaafar56-cloud/al-sahifa-al-sajjadiyah (MIT, JSON): we already ship all 54 duas from our own sources; useful only as a cross-check.
- aminpaydar/Mafatih (Apache-2.0, 2018, inactive).

## Recommended next step

Import a curated hadith set from ThaqalaynData into a new `DataHadith.kt`: Arabic text only, plus "book, volume, chapter, number". Start with 300 short narrations on akhlaq, du'a and ziyara. Run it through source_check and add a per-hadith reference gate. This unlocks the hidden «الأحاديث والروايات» category and fully sources the Home cards.
