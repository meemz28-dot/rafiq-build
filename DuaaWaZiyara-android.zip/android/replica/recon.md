# Recon map: Leading Shia devotional apps (Android + iOS)

Scope: the devotional core loop of the category leaders (find the right text for today, read it, come back tomorrow), benchmarked against رفيق المؤمن to find what to build next. Not a full clone of any single app.
For: رفيق المؤمن (com.shirazi.duaa), Munther's own free, offline, Arabic-first app.
Date: 2026-11-04
Method: public store listings and data aggregators only. No accounts, no binaries, no APIs, no scraping.

## Sources

| # | app | source | URL | key data |
| --- | --- | --- | --- | --- |
| 1 | Shia Toolkit (Amber Rajani) | App Store | https://apps.apple.com/app/id702458202 | 4.8 (398), free, no IAP, 10 languages, hyder.ai |
| 2 | Shia Toolkit | AppGoblin (Android) | https://appgoblin.info/apps/anywheresoftware.b4a.SIAToolKit | 1.5M+ installs, 4.71 (25K), updated 5 Oct 2026 |
| 3 | Shia Muslim (Yasin.ai) | App Store | https://apps.apple.com/us/app/id1613187510 | 4.8 (781), freemium $1.99 to $14.99 |
| 4 | Shia Muslim | AppGoblin (Android) | https://appgoblin.info/apps/com.shiamuslimproject.main | 1.2M+ installs, 4.82 (19K), ~40K MAU, under $10K/month |
| 5 | Nafilah (M. M. Qazwini) | App Store | https://apps.apple.com/app/id1510691403 | 4.5 (469), free, Hijri-date recommendations, lock-screen widgets |
| 6 | Habib (Shia AI) | mwm.ai | https://mwm.ai/apps/habib-shia-ai-quran-dua-azan/1658719511 | 4.8 (3.9K), 1,000+ duas with audio, AI voice nav, live rooms |
| 7 | مفاتيح الجنان (فريق مساحة حرة) | App Store | https://apps.apple.com/us/app/id689778571 | 4.6 (550), free, text checked vs lifetime print edition, audio up to 2.5x |
| 8 | نفحات - مفاتيح الجنان | App Store | https://apps.apple.com/us/app/id1417391691 | 4.6 (37), suggestions by weekday/month/prayer, search jumps to line |

## Core loop

Open the app, see what is recommended for today (Hijri date, weekday, prayer time), open the text, read or listen, and return the next day through a reminder or widget.

## Market structure

| tier | apps | model | moat |
| --- | --- | --- | --- |
| Super-apps (English/Urdu diaspora) | Shia Toolkit, Shia Muslim, Habib | free or freemium, 1M+ installs | breadth: library, AI, audio, 10 to 20 languages |
| Focused readers | Nafilah, Mafatih (masaha), Nafahat | free, no IAP | text fidelity, audio, clean reading |
| رفيق المؤمن | | free, offline, no ads, no tracking | Arabic-first, verified sources, khira, khums, guided programmes |

Read: the super-apps win on breadth and audio; the focused readers win on trust and calm. رفيق المؤمن sits with the focused readers but has more tools than any of them. The gap is audio and "today" intelligence, not text volume.

## Screens (category-standard set, mapped to our app)

| ID | screen | purpose | key components | seen in | ours |
| --- | --- | --- | --- | --- | --- |
| S01 | Home / Today | what to read now | Hijri date, next prayer, recommended cards, daily quote | 1,3,5,6,8 | yes (home): partial recommendations |
| S02 | Category index | browse Mafatih by section | grid, counts | all | yes |
| S03 | Text reader | read a dua or ziyara | Arabic, translation, transliteration, font, night mode, audio bar | all | yes, no audio, no translation |
| S04 | Audio player | listen, speed, background | play/seek, speed 0.5 to 2.5x, line sync | 1,3,6,7 | no |
| S05 | Search | find a text | title + full-text, jump to line, recent | 5,7,8 | yes (normalised), no jump-to-line |
| S06 | Favourites | personal Mafatih | list, folders | all | yes |
| S07 | Quran reader | read surah/juz | juz/hizb nav, translation, reciters, khatm | 1,3,5,6 | yes (text, khatma), no audio |
| S08 | Prayer times | daily times + adhan | method (Jafari/Leva), offsets, adhan voice | 1,3,5 | yes, no adhan audio choice check |
| S09 | Qibla | direction | compass, map | 3,6 | yes |
| S10 | Calendar | Hijri events | adjustable Hijri, events, a'mal per day | 1,3,6 | yes |
| S11 | Tasbih | dhikr counter | ring, haptics, presets | 1,3,7 | yes |
| S12 | Qadha tracker | missed prayers/fasts | counters | 3 | yes |
| S13 | Library | books | 1,200 to 13,000 books | 1,3,6 | partial (Nahj, Sahifa, Huquq, hikam) |
| S14 | Hadith | narrations | daily hadith, categories | 1,3,6 | quarantined (unsourced) |
| S15 | AI assistant | ask questions | chat, voice | 1,3,6 | no |
| S16 | Istikhara | guidance | 3: scholar on request; ours: automatic Quran khira | 3 | yes (better: offline, instant) |
| S17 | Widgets | glanceable | prayer, Hijri, favourites, lock screen | 1,3,5 | prayer widget only |
| S18 | Settings | personalise | font, theme, language, app icon, Hijri offset | all | yes |
| S19 | Hajj & ziyarat guide | step-by-step rites | steps, duas | 1,3,5 | yes |
| S20 | Live/virtual ziyarah | shrine streams | video | 3 | no |
| S21 | Radio / podcasts | lectures | stream | 3,6 | no |
| S22 | Quiz | daily learning | question, leaderboard | 1 | no |

## Flows

```
F01 Read today's recommended dua
    S01 -> tap card -> S03
    happy path clicks: 1 (Nafilah, Nafahat). Ours: 2 to 3 unless it is on Home.
    edge: Hijri date offset by country, night of an occasion starts at maghrib, user travels

F02 Listen while doing something else
    S03 -> play -> lock phone (background audio, follow-along line highlight)
    happy path clicks: 1. Ours: not possible.
    edge: no network (downloaded audio), headphones disconnect, speed change

F03 Find a dua by a remembered phrase
    S05 -> type phrase -> S03 scrolled to the line, highlighted
    happy path clicks: 2. Ours: 2, but lands at the top of the text, not the line.

F04 Get reminded at the right time
    notification (Thursday night: Kumayl; 13 to 15 Rajab: Umm Dawud) -> S03
    happy path clicks: 1. Ours: routine reminders exist; occasion-linked deep links partial.

F05 Make istikhara
    Shia Muslim: form -> wait for scholar -> result. Ours: S16 4 steps -> instant verdict.
```

## Components

| component | variants | states | used on |
| --- | --- | --- | --- |
| Recommendation card | occasion, weekday, after-prayer | today, tonight, upcoming | S01, S10 |
| Reader paragraph | Arabic, translation, transliteration | default, highlighted (search hit / audio sync) | S03, S07 |
| Audio bar | mini, expanded | idle, buffering, playing, downloaded | S03, S04, S07 |
| Hijri date chip | with offset | normal, occasion | S01, S10, S17 |
| Widget | prayer, Hijri, favourites, lock screen | | S17 |
| Counter ring | tasbih, qadha | | S11, S12 |

## Inferred data model (category-standard)

```
Text        id, title, category, source_book, source_ref, arabic[], translation[lang][], translit[], occasions[]
            evidence: S03 readers, Mafatih (7) "checked vs print edition"; confidence: high
Occasion    id, hijri_month, hijri_day | weekday | prayer, time_window (night/day), text_ids[]
            evidence: Nafilah/Nafahat recommendations, calendars; confidence: high
AudioTrack  id, text_id, reciter, url, duration, line_timings[] (for sync)
            evidence: Shia Muslim "text-to-audio matching", Habib per-excerpt audio; confidence: medium
Favourite   text_id, folder, added_at; confidence: high
ReadingHist text_id, last_position, opened_at; confidence: high (Nafilah v3.3)
```

Relationships: Occasion n-n Text, Text 1-n AudioTrack, Text 1-n Favourite.

## Feature matrix

See `features.csv`. Must: 6, should: 9, could: 7, skip: 6. Rows marked clone=yes already exist in رفيق المؤمن.

## Out of scope (cannot or should not be cloned)

- Recitation audio recorded by others: licensed per reciter. Needs our own recordings or written permission.
- English/Urdu translations owned by publishers (e.g. Mafatih translations): licence or use public-domain/permissive ones only.
- 1,200 to 13,000 book libraries: copyrighted; also breaks the "verified Shia source" standard.
- AI assistant trained on Shia sources: fatwa risk, needs backend and a scholar-review loop; conflicts with offline and no-data positioning.
- Online istikhara by scholars in Qom/Najaf: partner network.
- Live shrine streams, radio, TV: partner content and backend.

## Size

Screens 22 (17 already built), flows 5, entities 5. Hard parts: offline audio with line sync, licensed audio sourcing, a correct occasion engine (Hijri offset plus maghrib night rule), lock-screen widgets. Size: M (a few weeks) for the must + should rows that are not yet built.
