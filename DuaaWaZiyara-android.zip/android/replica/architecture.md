# Architecture: closing the gap with the Shia category leaders

Input: recon.md + features.csv (2026-11-04). Target: رفيق المؤمن, not a new app.

## Executive summary

| item | decision |
| --- | --- |
| Stack | Keep: Kotlin 2.1 + Compose (Android), WKWebView web-core (iOS), offline, no accounts, no backend |
| New infra | One static file host for downloadable audio packs (Cloudflare R2 public bucket, or GitHub Releases). No user data leaves the phone |
| Local tables | 5 (SQLite via Room, replacing ad-hoc SharedPreferences for personal state) |
| Internal routes | 9 module APIs, 4 background jobs |
| Riskiest parts | 1. Audio licensing. 2. Occasion engine correctness (Hijri offset + maghrib night rule). 3. Line-sync timing data |
| Size | M: about 4 to 6 weeks part-time across 4 milestones |

## 1. Stack

| layer | choice | why |
| --- | --- | --- |
| Android UI | Kotlin + Jetpack Compose (existing) | already shipping, 10 gates + unit tests + CI in place |
| iOS | Swift shell + web-core (existing) | one JS content export, sideload today, App Store later |
| Content | Kotlin data files (existing), exported to content.js for iOS | compile-time checked, gated by source_check |
| Personal state | Room (SQLite) | favourites, history, positions, downloads need queries and migrations; prefs do not scale |
| Audio playback | AndroidX Media3 (ExoPlayer + MediaSession) | background play, lock-screen controls, speed 0.5 to 2.5x, Bluetooth, all first-party |
| Audio delivery | Static packs on Cloudflare R2 (or GitHub Releases), SHA-256 manifest | zero cost at our scale, no server code, works with the no-tracking promise |
| Widgets | Jetpack Glance | Compose-style widgets for Hijri, favourites, next occasion |
| Jobs | AlarmManager (existing) + WorkManager for downloads | exact alarms for occasions, resumable downloads |
| Payments / auth / email | none | free app, no accounts; keeps the Data Safety form at "no data collected" |

Explicitly not adopted from the leaders: AI assistant, book library, live streams, scholar istikhara (see recon "Out of scope").

## 2. Schema

No server database. User-owned state lives on device in Room; content stays in Kotlin. Full DDL in `schema.sql`.

| table | purpose | key constraints |
| --- | --- | --- |
| favourite | personal Mafatih with folders | unique (text_id, folder) |
| reading_state | resume position + history | text_id primary key, index on opened_at |
| audio_download | which packs are on disk | status check, sha256 not null |
| occasion_override | user mutes/edits a recommendation | unique (occasion_id) |
| app_meta | schema version, migration flags | key primary key |

Content-side additions (Kotlin, compile-time, gated):

```
Occasion   id, kind (hijri | weekday | prayer | span), hijri_month?, hijri_day?, weekday?,
           prayer?, window (night | day | after_prayer), text_ids, src
           rule: a "night of X" starts at maghrib of the previous Gregorian day
AudioTrack id, text_id, reciter, pack_id, file, duration_ms, licence, line_ms[] (optional)
```

Access rule: single user, single device; no RLS needed. Personal data never synced; backup via Android Auto Backup only if the user enables it (excluded by default to match the privacy policy).

Hard constraints: `occasion_check` gate (new) fails the build if two Occasions claim the same slot for different "primary" texts, or if any text_id is unknown. Audio manifest SHA-256 must match before a pack is marked `ready`.

## 3. Module APIs (in place of HTTP routes)

| module call | does | flow | input | output |
| --- | --- | --- | --- | --- |
| OccasionEngine.today(now, loc, hijriAdj) | ranked recommendations for now | F01 | time, location, offset | List<Recommendation> |
| OccasionEngine.upcoming(days) | next N occasions | F04 | days | List<Occasion+date> |
| Search.query(q) | full-text hits with paragraph index + char range | F03 | string | List<Hit(textId, para, range)> |
| Reader.open(textId, para?, range?) | open and scroll to hit, highlight | F03 | ids | screen state |
| Audio.play(textId, reciter) | start Media3 session | F02 | ids | PlayerState flow |
| Audio.setSpeed(x) | 0.5 to 2.5 | F02 | float | |
| Downloads.enqueue(packId) | WorkManager download + verify | F02 | pack id | DownloadState flow |
| Favourites.add/remove/move | personal list | - | text, folder | |
| Widgets.refresh() | push today/hijri/favourites to Glance | F01 | | |

Background jobs:

| job | schedule | notes |
| --- | --- | --- |
| Occasion reminders | exact alarm, maghrib-anchored for nights | deep link `rafiq://text/{id}`; reschedule on boot, time-zone change, offset change |
| Widget refresh | at maghrib and midnight | Hijri day flips at maghrib for "tonight" cards |
| Audio pack download | on demand, unmetered by default | resumable, checksum, retry x3 |
| Orphan cleanup | weekly | delete partial files and packs not in manifest |

External calls: only a GET of the static audio manifest and packs, on user action. No analytics, no private endpoints of any competitor.

## 4. The parts that bite

| risk | handling |
| --- | --- |
| Audio licensing | Only reciters who give written permission, or recordings we commission. `licence` field is mandatory and gated. Ship M3 without audio if permissions lag |
| Hijri offset and the maghrib night rule | One function `effectiveHijri(now, maghrib, adj)` used by Home, widgets, reminders; unit tests for month ends, 29/30 days, travel |
| Time zones / DST | Store alarms as local wall time + zone; reschedule on ACTION_TIMEZONE_CHANGED |
| Line sync | `line_ms` optional; reader degrades to plain playback without it. Never guess timings |
| Storage | Packs per reciter (est. 150 to 400 MB each); show size before download, allow delete |
| Search jump | Index stores paragraph + normalised offset; map back to the diacritised string via a char map built once |
| Offline promise | Everything except audio download works with INTERNET permission absent; adding INTERNET requires a Data Safety update and privacy-policy line |
| iOS parity | Audio via AVAudioPlayer in the Swift shell, exposed on the existing `native` bridge |

## 5. Build order

| milestone | features (features.csv) | screens | tables / modules | exit test |
| --- | --- | --- | --- | --- |
| M1 Today engine (vertical slice) | Today recommendations, occasion-linked notifications | S01, S10 | Occasion data, OccasionEngine, reminders | Thursday 20:00 Dubai shows Kumayl as card 1; 13 Rajab shows Umm Dawud; unit tests green |
| M2 Search to line + personal state | search jump, favourites folders, history | S03, S05, S06 | Room: favourite, reading_state, app_meta | query "يا من أرجوه" lands on the highlighted line |
| M3 Audio | audio, background, speed, offline packs | S03, S04, S07 | audio_download, Media3, Downloads | lock phone mid-Kumayl, audio continues, 2.0x works offline |
| M4 Widgets + polish | lock-screen/Hijri widget, favourites widget, share-as-image, themes | S17, S18 | Glance widgets | widget flips to tonight's card at maghrib |
| Later, gated | English translation, line sync, hadith (sourced) | S03, S14 | content | only with permissive licences and named sources |

Next step: `/replica-design` (component specs for Recommendation card, Audio bar, highlighted paragraph, widgets).
