import SwiftUI
import WidgetKit

// MARK: - Shared look of all widgets (matches the Widgets mockup)

enum WS {
    static let ink = Color(red: 0x10 / 255, green: 0x32 / 255, blue: 0x2D / 255)
    static let deep = Color(red: 0x1E / 255, green: 0x5C / 255, blue: 0x54 / 255)
    static let deeper = Color(red: 0x17 / 255, green: 0x5A / 255, blue: 0x50 / 255)
    static let deepest = Color(red: 0x0F / 255, green: 0x3B / 255, blue: 0x35 / 255)
    static let emerald = Color(red: 0x2A / 255, green: 0x80 / 255, blue: 0x73 / 255)
    static let night = Color(red: 0x12 / 255, green: 0x3F / 255, blue: 0x3A / 255)
    static let gold = Color(red: 0xF2 / 255, green: 0xD5 / 255, blue: 0x92 / 255)
    static let goldDeep = Color(red: 0xB8 / 255, green: 0x86 / 255, blue: 0x2E / 255)
    static let paperTop = Color(red: 0xF7 / 255, green: 0xF0 / 255, blue: 0xE1 / 255)
    static let paperBottom = Color(red: 0xEA / 255, green: 0xD9 / 255, blue: 0xB4 / 255)
    static let beadOff = Color(red: 0xD9 / 255, green: 0xC9 / 255, blue: 0xA3 / 255)
    static let muted = Color(red: 0x6E / 255, green: 0x60 / 255, blue: 0x46 / 255)

    static var prayerBG: some View {
        ZStack {
            LinearGradient(colors: [deep, deepest], startPoint: .topTrailing, endPoint: .bottomLeading)
            WidgetGirih().opacity(0.07)
        }
    }
    static var greenBG: some View {
        ZStack {
            LinearGradient(colors: [emerald, deeper], startPoint: .topTrailing, endPoint: .bottomLeading)
            WidgetGirih().opacity(0.06)
        }
    }
    static var paperGradient: LinearGradient {
        LinearGradient(colors: [paperTop, paperBottom], startPoint: .topTrailing, endPoint: .bottomLeading)
    }
    static var paperBG: some View { paperGradient }

    static func ui(_ size: CGFloat, _ w: Font.Weight = .regular) -> Font {
        switch w {
        case .bold, .heavy, .black: return .custom("IBMPlexSansArabic-Bold", size: size)
        case .semibold: return .custom("IBMPlexSansArabic-SemiBold", size: size)
        case .medium: return .custom("IBMPlexSansArabic-Medium", size: size)
        default: return .custom("IBMPlexSansArabic-Regular", size: size)
        }
    }
    static func kufi(_ size: CGFloat) -> Font { .custom("ReemKufi-Bold", size: size) }
    static func amiri(_ size: CGFloat) -> Font { .custom("Amiri", size: size) }

    /// "٥:٢٠" without the ص/م suffix, as in the mockup pills.
    static func short(_ t: String) -> String {
        t.replacingOccurrences(of: " ص", with: "").replacingOccurrences(of: " م", with: "")
    }
}

/// Faint eight-point star lattice behind the green widgets.
struct WidgetGirih: View {
    var body: some View {
        Canvas { ctx, size in
            let step: CGFloat = 46
            var y: CGFloat = -step / 2
            var row = 0
            while y < size.height + step {
                var x: CGFloat = (row % 2 == 0 ? 0 : step / 2) - step / 2
                while x < size.width + step {
                    ctx.stroke(star(CGPoint(x: x, y: y), r: step * 0.42), with: .color(.white), lineWidth: 0.8)
                    x += step
                }
                y += step * 0.86
                row += 1
            }
        }
    }

    private func star(_ c: CGPoint, r: CGFloat) -> Path {
        var p = Path()
        for i in 0..<16 {
            let a = Double(i) * .pi / 8 - .pi / 2
            let rr = i % 2 == 0 ? r : r * 0.62
            let pt = CGPoint(x: c.x + CGFloat(cos(a)) * rr, y: c.y + CGFloat(sin(a)) * rr)
            if i == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
        }
        p.closeSubpath()
        return p
    }
}

/// The ring of beads used by the tasbih widget (mockup: 33 beads, gold when counted).
struct BeadRing: View {
    let done: Int
    let total: Int
    var beads: Int = 33

    var body: some View {
        GeometryReader { g in
            let d = min(g.size.width, g.size.height)
            let r = d / 2 - d * 0.045
            let filled = total > 0 ? Int((Double(done) / Double(total) * Double(beads)).rounded()) : 0
            ZStack {
                ForEach(0..<beads, id: \.self) { i in
                    let a = Double(i) / Double(beads) * 2 * .pi - .pi / 2
                    Circle()
                        .fill(i < filled ? WS.goldDeep : WS.beadOff)
                        .frame(width: d * 0.075, height: d * 0.075)
                        .position(x: d / 2 + CGFloat(cos(a)) * r, y: d / 2 + CGFloat(sin(a)) * r)
                }
            }
            .frame(width: d, height: d)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}
