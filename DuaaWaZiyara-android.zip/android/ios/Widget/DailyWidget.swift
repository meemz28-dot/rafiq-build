import WidgetKit
import SwiftUI

// MARK: - «اليوم»: Hijri date, the coming occasion, and a saying of the day

struct DailyEntry: TimelineEntry {
    let date: Date
    let hijri: String
    let weekday: String
    let occasion: WidgetContent.Upcoming?
    let saying: WidgetContent.Saying?
    let dhikr: WidgetContent.Dhikr?
}

struct DailyProvider: TimelineProvider {
    func placeholder(in context: Context) -> DailyEntry { entry(Date()) }
    func getSnapshot(in context: Context, completion: @escaping (DailyEntry) -> Void) { completion(entry(Date())) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<DailyEntry>) -> Void) {
        let now = Date()
        let midnight = Calendar.current.startOfDay(for: now).addingTimeInterval(86400 + 5)
        completion(Timeline(entries: [entry(now), entry(midnight)],
                            policy: .after(midnight.addingTimeInterval(86400))))
    }

    private func entry(_ d: Date) -> DailyEntry { DailyEntry.make(d) }
}

extension DailyEntry {
    static func make(_ d: Date) -> DailyEntry {
        let wd = Calendar(identifier: .gregorian).component(.weekday, from: d) - 1
        let days = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"]
        return DailyEntry(date: d, hijri: WS.plain(Hijri.format(Hijri.jdToHijri(Hijri.jd(of: d)))),
                          weekday: days[max(0, min(6, wd))],
                          occasion: WidgetContent.nextOccasion(from: d),
                          saying: WidgetContent.saying(for: d),
                          dhikr: WidgetContent.dhikr(for: d))
    }
}

struct DailyWidgetView: View {
    @Environment(\.widgetFamily) private var envFamily
    var forced: WidgetFamily? = nil
    private var family: WidgetFamily { forced ?? envFamily }
    init(entry: DailyEntry, forced: WidgetFamily? = nil) { self.entry = entry; self.forced = forced }
    let entry: DailyEntry

    var body: some View {
        content
            .environment(\.layoutDirection, .rightToLeft)
            .widgetURL(URL(string: "rafiq://calendar"))
            .containerBackground(for: .widget) { WS.greenBG }
    }

    @ViewBuilder private var content: some View {
        switch family {
        case .accessoryInline:
            Text(entry.hijri)
        case .accessoryRectangular:
            HStack(spacing: 8) {
                Image(systemName: "moon.fill").font(.system(size: 20, weight: .medium)).widgetAccentable()
                VStack(alignment: .leading, spacing: 0) {
                    Text(entry.hijri.components(separatedBy: " ").prefix(3).joined(separator: " "))
                        .font(WS.kufi(15)).lineLimit(1).minimumScaleFactor(0.7).widgetAccentable()
                    if let o = entry.occasion {
                        Text(verbatim: o.days == 0 ? "اليوم: \(o.title)" : "بعد \(o.days.ar) \(o.days == 1 ? "يوم" : "أيام"): \(o.title)")
                            .font(WS.ui(10)).lineLimit(2)
                    }
                }
                Spacer(minLength: 0)
            }
        case .systemMedium:
            HStack(alignment: .top, spacing: 14) {
                DailyDateBlock(entry: entry, showSaying: false).frame(width: 128)
                Rectangle().fill(.white.opacity(0.15)).frame(width: 1)
                DailySayingBlock(entry: entry)
            }
        case .systemLarge:
            VStack(alignment: .leading, spacing: 12) {
                DailyDateBlock(entry: entry, showSaying: false).frame(height: 110)
                DailySayingBlock(entry: entry)
                if let d = entry.dhikr { DailyDhikrBlock(dhikr: d) }
                Spacer(minLength: 0)
            }
        default:
            DailyDateBlock(entry: entry, showSaying: true)
        }
    }
}

enum DailyText {
    static func occasionLine(_ o: WidgetContent.Upcoming?) -> String? {
        guard let o else { return nil }
        if o.days == 0 { return "اليوم: \(o.title)" }
        return "\(o.title) · بعد \(o.days.ar) \(o.days == 1 ? "يوم" : (o.days <= 10 ? "أيام" : "يوماً"))"
    }
}

/// Mockup «اليوم · صغير»: weekday, the Hijri date in Kufi, the coming occasion, a short saying.
struct DailyDateBlock: View {
    let entry: DailyEntry
    let showSaying: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(entry.weekday).font(WS.ui(11, .medium)).foregroundStyle(.white.opacity(0.8))
            Text(entry.hijri.replacingOccurrences(of: " هـ", with: ""))
                .font(WS.kufi(17)).foregroundStyle(.white).lineSpacing(2)
                .lineLimit(2).minimumScaleFactor(0.75)
            Spacer(minLength: 4)
            if let o = entry.occasion, let l = DailyText.occasionLine(o) {
                HStack(spacing: 5) {
                    Image(systemName: o.symbol).font(.system(size: 9, weight: .semibold)).foregroundStyle(WS.gold)
                    Text(l).font(WS.ui(10, .semibold)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.8)
                }
            }
            if showSaying, let s = entry.saying {
                Text(verbatim: "«\(s.text)»").font(WS.amiri(12)).foregroundStyle(.white.opacity(0.9))
                    .lineLimit(2).minimumScaleFactor(0.8)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }
}

struct DailySayingBlock: View {
    let entry: DailyEntry
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("حكمة اليوم").font(WS.ui(11, .bold)).foregroundStyle(WS.gold)
            if let s = entry.saying {
                Text(verbatim: "«\(s.text)»").font(WS.amiri(15)).foregroundStyle(.white)
                    .lineLimit(4).minimumScaleFactor(0.8)
                Text(s.who.components(separatedBy: " · ").first ?? s.who)
                    .font(WS.ui(10)).foregroundStyle(.white.opacity(0.7)).lineLimit(1)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }
}

struct DailyDhikrBlock: View {
    let dhikr: WidgetContent.Dhikr
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("ذكر اليوم").font(WS.ui(11, .bold)).foregroundStyle(WS.gold)
            Text(dhikr.text).font(WS.amiri(17)).foregroundStyle(.white).lineLimit(3).minimumScaleFactor(0.8)
            Text(dhikr.src).font(WS.ui(10)).foregroundStyle(.white.opacity(0.7)).lineLimit(1)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(.white.opacity(0.08)))
    }
}

struct DailyWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "RafiqDailyWidget", provider: DailyProvider()) { entry in
            DailyWidgetView(entry: entry)
        }
        .configurationDisplayName("اليوم")
        .description("التاريخ الهجري، المناسبة القادمة، وحكمة اليوم من أهل البيت (ع).")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular, .accessoryInline])
    }
}
