import WidgetKit
import SwiftUI

// MARK: - «اليوم»: Hijri date, the coming occasion, and a saying of the day

struct DailyEntry: TimelineEntry {
    let date: Date
    let hijri: String
    let weekday: String
    let occasion: WidgetContent.Upcoming?
    let saying: WidgetContent.Saying?
    let dhikr: WidgetContent.Dhikr?
}

struct DailyProvider: TimelineProvider {
    func placeholder(in context: Context) -> DailyEntry { entry(Date()) }
    func getSnapshot(in context: Context, completion: @escaping (DailyEntry) -> Void) { completion(entry(Date())) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<DailyEntry>) -> Void) {
        let now = Date()
        let midnight = Calendar.current.startOfDay(for: now).addingTimeInterval(86400 + 5)
        completion(Timeline(entries: [entry(now), entry(midnight)],
                            policy: .after(midnight.addingTimeInterval(86400))))
    }

    private func entry(_ d: Date) -> DailyEntry {
        let wd = Calendar(identifier: .gregorian).component(.weekday, from: d) - 1
        let days = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"]
        return DailyEntry(date: d, hijri: Hijri.format(Hijri.jdToHijri(Hijri.jd(of: d))),
                          weekday: days[max(0, min(6, wd))],
                          occasion: WidgetContent.nextOccasion(from: d),
                          saying: WidgetContent.saying(for: d),
                          dhikr: WidgetContent.dhikr(for: d))
    }
}

private let dTeal = Color(red: 0x17 / 255, green: 0x5A / 255, blue: 0x50 / 255)
private let dEmerald = Color(red: 0x2A / 255, green: 0x80 / 255, blue: 0x73 / 255)
private let dGold = Color(red: 0xD9 / 255, green: 0xB0 / 255, blue: 0x5C / 255)

struct DailyWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: DailyEntry

    var body: some View {
        content
            .environment(\.layoutDirection, .rightToLeft)
            .widgetURL(URL(string: "rafiq://home"))
            .containerBackground(for: .widget) {
                LinearGradient(colors: [dEmerald, dTeal], startPoint: .topLeading, endPoint: .bottomTrailing)
            }
    }

    private var occasionLine: String? {
        guard let o = entry.occasion else { return nil }
        if o.days == 0 { return "اليوم: \(o.title)" }
        return "بعد \(o.days.ar) \(o.days == 1 ? "يوم" : (o.days <= 10 ? "أيام" : "يوماً")): \(o.title)"
    }

    @ViewBuilder private var content: some View {
        switch family {
        case .accessoryInline:
            Text(entry.hijri)
        case .accessoryRectangular:
            VStack(alignment: .leading, spacing: 1) {
                Text(entry.hijri).font(.headline).widgetAccentable()
                if let l = occasionLine { Text(l).font(.caption).lineLimit(2) }
            }
        case .systemMedium:
            HStack(alignment: .top, spacing: 12) {
                dateBlock.frame(width: 104)
                VStack(alignment: .leading, spacing: 6) {
                    if let s = entry.saying {
                        Text(s.text).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white)
                            .lineLimit(4).minimumScaleFactor(0.8)
                        Text(s.who.components(separatedBy: " · ").first ?? s.who)
                            .font(.caption2).foregroundStyle(dGold).lineLimit(1)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            }
        case .systemLarge:
            VStack(alignment: .leading, spacing: 12) {
                dateBlock
                if let s = entry.saying {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("حكمة اليوم").font(.caption.weight(.bold)).foregroundStyle(dGold)
                        Text(s.text).font(.system(size: 17, weight: .semibold)).foregroundStyle(.white).lineLimit(5)
                        Text(s.who).font(.caption2).foregroundStyle(.white.opacity(0.7)).lineLimit(2)
                    }
                    .padding(12).frame(maxWidth: .infinity, alignment: .leading)
                    .background(RoundedRectangle(cornerRadius: 14).fill(.white.opacity(0.1)))
                }
                if let d = entry.dhikr {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("ذكر اليوم").font(.caption.weight(.bold)).foregroundStyle(dGold)
                        Text(d.text).font(.system(size: 16, weight: .bold)).foregroundStyle(.white).lineLimit(2)
                        Text(d.src).font(.caption2).foregroundStyle(.white.opacity(0.7)).lineLimit(1)
                    }
                }
                Spacer(minLength: 0)
            }
        default:
            dateBlock.frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
    }

    private var dateBlock: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(entry.weekday).font(.caption.weight(.bold)).foregroundStyle(.white.opacity(0.75))
            Text(entry.hijri).font(.system(size: 17, weight: .heavy)).foregroundStyle(.white)
                .lineLimit(2).minimumScaleFactor(0.7)
            Spacer(minLength: 2)
            if let o = entry.occasion, let l = occasionLine {
                HStack(alignment: .top, spacing: 4) {
                    Image(systemName: o.symbol).font(.caption2).foregroundStyle(dGold)
                    Text(l).font(.caption2.weight(.semibold)).foregroundStyle(.white).lineLimit(3)
                }
            }
        }
    }
}

struct DailyWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "RafiqDailyWidget", provider: DailyProvider()) { entry in
            DailyWidgetView(entry: entry)
        }
        .configurationDisplayName("اليوم")
        .description("التاريخ الهجري، المناسبة القادمة، وحكمة اليوم من أهل البيت (ع).")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular, .accessoryInline])
    }
}
