import WidgetKit
import SwiftUI

@main
struct RafiqWidgets: WidgetBundle {
    var body: some Widget {
        HubWidget()
        PrayerWidget()
        DailyWidget()
        TasbihWidget()
        PrayerLiveActivity()
        TasbihControl()
        QiblaControl()
        PrayerControl()
    }
}
