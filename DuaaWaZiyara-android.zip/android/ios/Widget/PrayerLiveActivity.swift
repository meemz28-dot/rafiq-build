import WidgetKit
import SwiftUI
import ActivityKit

private let liveGold = Color(red: 0xE3 / 255, green: 0xA3 / 255, blue: 0x3B / 255)
private let liveTeal = Color(red: 0x22 / 255, green: 0x6E / 255, blue: 0x62 / 255)

struct PrayerLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: PrayerActivityAttributes.self) { context in
            PrayerLiveLockView(city: context.attributes.city, state: context.state)
                .environment(\.layoutDirection, .rightToLeft)
                .activityBackgroundTint(liveTeal)
                .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(context.state.prayer).font(.headline).foregroundStyle(liveGold)
                        Text(context.state.time).font(.caption)
                    }
                }
                DynamicIslandExpandedRegion(.trailing) {
                    PrayerLiveTimer(target: context.state.target).font(.title3.weight(.bold))
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text("الصلاة القادمة · \(context.attributes.city)").font(.caption2).foregroundStyle(.secondary)
                }
            } compactLeading: {
                Image(systemName: "moon.stars.fill").foregroundStyle(liveGold)
            } compactTrailing: {
                PrayerLiveTimer(target: context.state.target).frame(maxWidth: 56).font(.caption.weight(.bold))
            } minimal: {
                Image(systemName: "moon.stars.fill").foregroundStyle(liveGold)
            }
            .widgetURL(URL(string: "rafiq://prayer"))
        }
    }
}

/// Counts down to the prayer, then shows that it is due.
struct PrayerLiveTimer: View {
    let target: Date
    var body: some View {
        if target > Date() {
            Text(timerInterval: Date()...target, countsDown: true)
                .monospacedDigit()
                .multilineTextAlignment(.trailing)
        } else {
            Text("حان الوقت")
        }
    }
}

private struct PrayerLiveLockView: View {
    let city: String
    let state: PrayerActivityAttributes.ContentState

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: "moon.stars.fill").font(.title2).foregroundStyle(liveGold)
            VStack(alignment: .leading, spacing: 2) {
                Text("الصلاة القادمة · \(city)").font(.caption).foregroundStyle(.white.opacity(0.75))
                Text("\(state.prayer)  \(state.time)").font(.title3.weight(.heavy)).foregroundStyle(.white)
            }
            Spacer()
            PrayerLiveTimer(target: state.target)
                .font(.title2.weight(.bold))
                .foregroundStyle(liveGold)
        }
        .padding(16)
    }
}
