import WidgetKit
import SwiftUI
import ActivityKit


struct PrayerLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: PrayerActivityAttributes.self) { context in
            PrayerLiveLockView(city: context.attributes.city, state: context.state)
                .environment(\.layoutDirection, .rightToLeft)
                .activityBackgroundTint(WS.deepest.opacity(0.92))
                .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(context.state.prayer).font(WS.ui(16, .bold)).foregroundStyle(WS.gold)
                        Text(context.state.time).font(.caption)
                    }
                }
                DynamicIslandExpandedRegion(.trailing) {
                    PrayerLiveTimer(target: context.state.target).font(WS.kufi(20)).foregroundStyle(WS.gold)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text("الصلاة القادمة · \(context.attributes.city)").font(.caption2).foregroundStyle(.secondary)
                }
            } compactLeading: {
                Image(systemName: "moon.stars.fill").foregroundStyle(WS.gold)
            } compactTrailing: {
                PrayerLiveTimer(target: context.state.target).frame(maxWidth: 56).font(.caption.weight(.bold))
            } minimal: {
                Image(systemName: "moon.stars.fill").foregroundStyle(WS.gold)
            }
            .widgetURL(URL(string: "rafiq://prayer"))
        }
    }
}

/// Counts down to the prayer, then shows that it is due.
struct PrayerLiveTimer: View {
    let target: Date
    var body: some View {
        if target > Date() {
            Text(timerInterval: Date()...target, countsDown: true)
                .monospacedDigit()
                .multilineTextAlignment(.trailing)
        } else {
            Text("حان الوقت")
        }
    }
}

private struct PrayerLiveLockView: View {
    let city: String
    let state: PrayerActivityAttributes.ContentState

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: "moon.fill").font(.system(size: 11, weight: .semibold)).foregroundStyle(WS.gold)
                    .frame(width: 24, height: 24)
                    .background(RoundedRectangle(cornerRadius: 7, style: .continuous).fill(WS.emerald))
                Text("رفيق المؤمن · نشاط مباشر").font(WS.ui(12, .bold)).foregroundStyle(.white)
                Spacer()
                Text("الآن").font(WS.ui(11)).foregroundStyle(.white.opacity(0.6))
            }
            HStack(alignment: .lastTextBaseline) {
                VStack(alignment: .leading, spacing: 0) {
                    Text(verbatim: "الصلاة القادمة · \(city)").font(WS.ui(11)).foregroundStyle(.white.opacity(0.75))
                    Text(verbatim: "\(state.prayer) \(WS.short(state.time))").font(WS.kufi(28)).foregroundStyle(.white)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 0) {
                    Text("بعد").font(WS.ui(11)).foregroundStyle(.white.opacity(0.75))
                    PrayerLiveTimer(target: state.target).font(WS.kufi(24)).foregroundStyle(WS.gold)
                }
            }
            if let since = state.since, since < state.target {
                ProgressView(timerInterval: since...state.target, countsDown: false) {
                    EmptyView()
                } currentValueLabel: { EmptyView() }
                .tint(WS.gold)
            }
            if let after = state.after {
                HStack {
                    Text("تنبيه عند دخول الوقت").font(WS.ui(10)).foregroundStyle(.white.opacity(0.6))
                    Spacer()
                    Text(verbatim: "ثم \(WS.short(after))").font(WS.ui(10, .medium)).foregroundStyle(.white.opacity(0.75))
                }
            }
        }
        .padding(16)
        .environment(\.locale, widgetArabicLocale)
    }
}
