import WidgetKit
import SwiftUI
import AppIntents

// MARK: - Interactive tasbih on the Home Screen: tap the widget, no need to open the app.
// Counts تسبيحة الزهراء (ع): الله أكبر ٣٤، الحمد لله ٣٣، سبحان الله ٣٣.

enum WidgetTasbih {
    static let countKey = "widgetTasbihCount"
    static let roundsKey = "widgetTasbihRounds"
    static let total = 100
    static let phases: [(text: String, size: Int)] = [("الله أكبر", 34), ("الحمد لله", 33), ("سبحان الله", 33)]

    static var count: Int { UserDefaults.standard.integer(forKey: countKey) }
    static var rounds: Int { UserDefaults.standard.integer(forKey: roundsKey) }

    static func tap() {
        var c = count + 1
        if c >= total {
            c = 0
            UserDefaults.standard.set(rounds + 1, forKey: roundsKey)
        }
        UserDefaults.standard.set(c, forKey: countKey)
    }

    static func reset() {
        UserDefaults.standard.set(0, forKey: countKey)
        UserDefaults.standard.set(0, forKey: roundsKey)
    }

    /// Current phase text, the count inside it, and its size.
    static func phase(_ c: Int) -> (text: String, done: Int, size: Int) {
        var start = 0
        for p in phases {
            if c < start + p.size { return (p.text, c - start, p.size) }
            start += p.size
        }
        return (phases[0].text, 0, phases[0].size)
    }
}

struct WidgetTasbihTap: AppIntent {
    static var title: LocalizedStringResource = "تسبيحة"
    static var isDiscoverable: Bool = false
    func perform() async throws -> some IntentResult {
        WidgetTasbih.tap()
        return .result()
    }
}

struct WidgetTasbihReset: AppIntent {
    static var title: LocalizedStringResource = "إعادة التسبيح"
    static var isDiscoverable: Bool = false
    func perform() async throws -> some IntentResult {
        WidgetTasbih.reset()
        return .result()
    }
}

struct TasbihEntry: TimelineEntry {
    let date: Date
    let count: Int
    let rounds: Int
}

struct TasbihProvider: TimelineProvider {
    func placeholder(in context: Context) -> TasbihEntry { TasbihEntry(date: Date(), count: 12, rounds: 0) }
    func getSnapshot(in context: Context, completion: @escaping (TasbihEntry) -> Void) {
        completion(TasbihEntry(date: Date(), count: WidgetTasbih.count, rounds: WidgetTasbih.rounds))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<TasbihEntry>) -> Void) {
        completion(Timeline(entries: [TasbihEntry(date: Date(), count: WidgetTasbih.count, rounds: WidgetTasbih.rounds)],
                            policy: .never))
    }
}

private let tTeal = Color(red: 0x17 / 255, green: 0x5A / 255, blue: 0x50 / 255)
private let tEmerald = Color(red: 0x2A / 255, green: 0x80 / 255, blue: 0x73 / 255)
private let tGold = Color(red: 0xD9 / 255, green: 0xB0 / 255, blue: 0x5C / 255)

struct TasbihWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: TasbihEntry

    var body: some View {
        let p = WidgetTasbih.phase(entry.count)
        content(p)
            .environment(\.layoutDirection, .rightToLeft)
            .containerBackground(for: .widget) {
                LinearGradient(colors: [tEmerald, tTeal], startPoint: .topLeading, endPoint: .bottomTrailing)
            }
    }

    @ViewBuilder private func content(_ p: (text: String, done: Int, size: Int)) -> some View {
        if family == .systemMedium {
            HStack(spacing: 14) {
                tapButton(p, ring: 104)
                VStack(alignment: .leading, spacing: 6) {
                    Text("تسبيحة الزهراء (ع)").font(.caption.weight(.bold)).foregroundStyle(tGold)
                    Text(p.text).font(.title2.weight(.heavy)).foregroundStyle(.white)
                    Text("\(entry.count.ar) من ١٠٠").font(.caption).foregroundStyle(.white.opacity(0.8))
                    if entry.rounds > 0 {
                        Text("أتممتها \(entry.rounds.ar) \(entry.rounds == 1 ? "مرة" : "مرات")")
                            .font(.caption2).foregroundStyle(.white.opacity(0.7))
                    }
                    Spacer(minLength: 0)
                    resetButton
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        } else {
            VStack(spacing: 6) {
                tapButton(p, ring: 108)
                Text(p.text).font(.caption.weight(.heavy)).foregroundStyle(.white).lineLimit(1)
            }
        }
    }

    /// The whole ring is the button: each tap counts one.
    private func tapButton(_ p: (text: String, done: Int, size: Int), ring: CGFloat) -> some View {
        Button(intent: WidgetTasbihTap()) {
            ZStack {
                Circle().stroke(.white.opacity(0.15), lineWidth: 8)
                Circle()
                    .trim(from: 0, to: CGFloat(p.done) / CGFloat(max(1, p.size)))
                    .stroke(tGold, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                VStack(spacing: 0) {
                    Text(p.done.ar).font(.system(size: ring * 0.32, weight: .heavy)).foregroundStyle(.white)
                        .contentTransition(.numericText())
                    Text("/ \(p.size.ar)").font(.caption2).foregroundStyle(.white.opacity(0.7))
                }
            }
            .frame(width: ring, height: ring)
            .contentShape(Circle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel("سبّح: \(p.text)")
    }

    private var resetButton: some View {
        Button(intent: WidgetTasbihReset()) {
            Label("من جديد", systemImage: "arrow.counterclockwise").font(.caption2.weight(.bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 10).padding(.vertical, 5)
                .background(Capsule().fill(.white.opacity(0.15)))
        }
        .buttonStyle(.plain)
    }
}

struct TasbihWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "RafiqTasbihWidget", provider: TasbihProvider()) { entry in
            TasbihWidgetView(entry: entry)
        }
        .configurationDisplayName("السبحة")
        .description("سبّح من الشاشة الرئيسية مباشرة: اضغط الحلقة لكلّ تسبيحة.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}
