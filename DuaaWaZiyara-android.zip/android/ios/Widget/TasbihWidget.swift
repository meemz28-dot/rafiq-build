import WidgetKit
import SwiftUI
import AppIntents

// MARK: - Interactive tasbih on the Home Screen: tap the widget, no need to open the app.
// Counts تسبيحة الزهراء (ع): الله أكبر ٣٤، الحمد لله ٣٣، سبحان الله ٣٣.

enum WidgetTasbih {
    static let countKey = "widgetTasbihCount"
    static let roundsKey = "widgetTasbihRounds"
    static let total = 100
    static let phases: [(text: String, size: Int)] = [("الله أكبر", 34), ("الحمد لله", 33), ("سبحان الله", 33)]

    static var count: Int { UserDefaults.standard.integer(forKey: countKey) }
    static var rounds: Int { UserDefaults.standard.integer(forKey: roundsKey) }

    static func tap() {
        var c = count + 1
        if c >= total {
            c = 0
            UserDefaults.standard.set(rounds + 1, forKey: roundsKey)
        }
        UserDefaults.standard.set(c, forKey: countKey)
    }

    static func reset() {
        UserDefaults.standard.set(0, forKey: countKey)
        UserDefaults.standard.set(0, forKey: roundsKey)
    }

    /// Current phase text, the count inside it, and its size.
    static func phase(_ c: Int) -> (text: String, done: Int, size: Int) {
        var start = 0
        for p in phases {
            if c < start + p.size { return (p.text, c - start, p.size) }
            start += p.size
        }
        return (phases[0].text, 0, phases[0].size)
    }
}

struct WidgetTasbihTap: AppIntent {
    static var title: LocalizedStringResource = "تسبيحة"
    static var isDiscoverable: Bool = false
    func perform() async throws -> some IntentResult {
        WidgetTasbih.tap()
        return .result()
    }
}

struct WidgetTasbihReset: AppIntent {
    static var title: LocalizedStringResource = "إعادة التسبيح"
    static var isDiscoverable: Bool = false
    func perform() async throws -> some IntentResult {
        WidgetTasbih.reset()
        return .result()
    }
}

struct TasbihEntry: TimelineEntry {
    let date: Date
    let count: Int
    let rounds: Int
}

struct TasbihProvider: TimelineProvider {
    func placeholder(in context: Context) -> TasbihEntry { TasbihEntry(date: Date(), count: 12, rounds: 0) }
    func getSnapshot(in context: Context, completion: @escaping (TasbihEntry) -> Void) {
        completion(TasbihEntry(date: Date(), count: WidgetTasbih.count, rounds: WidgetTasbih.rounds))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<TasbihEntry>) -> Void) {
        completion(Timeline(entries: [TasbihEntry(date: Date(), count: WidgetTasbih.count, rounds: WidgetTasbih.rounds)],
                            policy: .never))
    }
}

struct TasbihWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: TasbihEntry

    var body: some View {
        let p = WidgetTasbih.phase(entry.count)
        content(p)
            .environment(\.layoutDirection, .rightToLeft)
            .containerBackground(for: .widget) { WS.paperBG }
    }

    @ViewBuilder private func content(_ p: (text: String, done: Int, size: Int)) -> some View {
        if family == .systemMedium {
            HStack(spacing: 14) {
                TasbihRingButton(phase: p, size: 118)
                VStack(alignment: .leading, spacing: 4) {
                    Text("تسبيحة الزهراء (ع)").font(WS.ui(12, .bold)).foregroundStyle(WS.goldDeep)
                    Text(p.text).font(WS.kufi(24)).foregroundStyle(WS.ink)
                    Text(verbatim: "\(entry.count.ar) من ١٠٠").font(WS.ui(12)).foregroundStyle(WS.muted)
                    if entry.rounds > 0 {
                        Text(verbatim: "أتممتها \(entry.rounds.ar) \(entry.rounds == 1 ? "مرة" : "مرات")")
                            .font(WS.ui(11)).foregroundStyle(WS.muted)
                    }
                    Spacer(minLength: 0)
                    TasbihResetButton()
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        } else {
            TasbihRingButton(phase: p, size: 132)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}

/// The bead ring is the button: each tap counts one (mockup: count, "من ٣٣", the phrase).
struct TasbihRingButton: View {
    let phase: (text: String, done: Int, size: Int)
    let size: CGFloat

    var body: some View {
        Button(intent: WidgetTasbihTap()) {
            ZStack {
                BeadRing(done: phase.done, total: phase.size)
                VStack(spacing: 0) {
                    Text(phase.done.ar).font(WS.kufi(size * 0.27)).foregroundStyle(WS.ink)
                        .contentTransition(.numericText())
                    Text(verbatim: "من \(phase.size.ar)").font(WS.ui(size * 0.085)).foregroundStyle(WS.muted)
                    Text(phase.text).font(WS.amiri(size * 0.11)).foregroundStyle(WS.deeper).padding(.top, 2)
                }
            }
            .frame(width: size, height: size)
            .contentShape(Circle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel("سبّح: \(phase.text)")
    }
}

struct TasbihResetButton: View {
    var dark = true
    var body: some View {
        Button(intent: WidgetTasbihReset()) {
            Label("من جديد", systemImage: "arrow.counterclockwise").font(WS.ui(11, .bold))
                .foregroundStyle(dark ? WS.ink : .white)
                .padding(.horizontal, 10).padding(.vertical, 5)
                .background(Capsule().fill((dark ? WS.ink : Color.white).opacity(0.1)))
        }
        .buttonStyle(.plain)
    }
}

struct TasbihWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "RafiqTasbihWidget", provider: TasbihProvider()) { entry in
            TasbihWidgetView(entry: entry)
        }
        .configurationDisplayName("السبحة")
        .description("سبّح من الشاشة الرئيسية مباشرة: اضغط الحلقة لكلّ تسبيحة.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}
