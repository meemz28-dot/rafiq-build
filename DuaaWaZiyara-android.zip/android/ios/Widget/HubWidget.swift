import WidgetKit
import SwiftUI
import AppIntents

// MARK: - «رفيق المؤمن»: one widget for prayer times, the day's calendar, and the dhikr of the day.
// Medium rotates between three pages every 20 minutes; tap the dots (or the arrow) to switch.
// Large shows everything at once with a tappable tasbih.

enum HubPager {
    static let pages = 3
    static let slotSeconds: TimeInterval = 1200
    private static let offsetKey = "hubPageOffset"

    static func slot(_ d: Date) -> Int { Int(d.timeIntervalSince1970 / slotSeconds) }

    static func page(at d: Date) -> Int {
        let off = UserDefaults.standard.integer(forKey: offsetKey)
        return ((slot(d) + off) % pages + pages) % pages
    }

    /// Show page `p` now; rotation then continues from it.
    static func show(_ p: Int) {
        let off = ((p - slot(Date())) % pages + pages) % pages
        UserDefaults.standard.set(off, forKey: offsetKey)
    }
}

struct HubShowPage: AppIntent {
    static var title: LocalizedStringResource = "عرض صفحة"
    static var isDiscoverable: Bool = false
    @Parameter(title: "الصفحة") var page: Int
    init() {}
    init(page: Int) { self.page = page }
    func perform() async throws -> some IntentResult {
        HubPager.show(page)
        return .result()
    }
}

struct HubEntry: TimelineEntry {
    let date: Date
    let prayer: PrayerEntry
    let daily: DailyEntry
    let page: Int
    let tasbih: Int
}

struct HubProvider: AppIntentTimelineProvider {
    private let prayer = PrayerProvider()

    func placeholder(in context: Context) -> HubEntry {
        make(Date(), city: WidgetLocator.cached ?? WidgetCity.all[0], method: "jafari")
    }

    func snapshot(for configuration: PrayerWidgetIntent, in context: Context) async -> HubEntry {
        make(Date(), city: await prayer.resolve(configuration), method: configuration.method.rawValue)
    }

    func timeline(for configuration: PrayerWidgetIntent, in context: Context) async -> Timeline<HubEntry> {
        let c = await prayer.resolve(configuration), m = configuration.method.rawValue
        let now = Date()
        var stamps: [Date] = [now]
        // Each page change (every 20 minutes, on the slot boundary) and each prayer time, for 6 hours.
        var t = Date(timeIntervalSince1970: Double(HubPager.slot(now) + 1) * HubPager.slotSeconds)
        while t.timeIntervalSince(now) <= 21600 { stamps.append(t); t = t.addingTimeInterval(HubPager.slotSeconds) }
        var cursor = now
        for _ in 0..<4 {
            let at = prayer.entry(at: cursor, city: c, method: m).nextDate.addingTimeInterval(1)
            if at.timeIntervalSince(now) > 21600 { break }
            stamps.append(at)
            cursor = at
        }
        stamps.sort()
        return Timeline(entries: stamps.map { make($0, city: c, method: m) },
                        policy: .after(stamps.last ?? now.addingTimeInterval(3600)))
    }

    private func make(_ d: Date, city: WidgetCity, method: String) -> HubEntry {
        HubEntry(date: d, prayer: prayer.entry(at: d, city: city, method: method), daily: DailyEntry.make(d),
                 page: HubPager.page(at: d), tasbih: WidgetTasbih.count)
    }
}

struct HubWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: HubEntry

    var body: some View {
        Group {
            if family == .systemLarge { large } else { medium }
        }
        .environment(\.layoutDirection, .rightToLeft)
        .environment(\.locale, widgetArabicLocale)
        .widgetURL(URL(string: entry.page == 0 ? "rafiq://prayer" : (entry.page == 1 ? "rafiq://calendar" : "rafiq://tasbih")))
        .containerBackground(for: .widget) {
            if family == .systemLarge || entry.page == 0 { WS.prayerBG } else if entry.page == 1 { WS.greenBG } else { WS.paperBG }
        }
    }

    // MARK: Medium (rotating)

    private var medium: some View {
        VStack(spacing: 0) {
            Group {
                switch entry.page {
                case 0: PrayerMediumCard(entry: entry.prayer)
                case 1: todayPage
                default: dhikrPage
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .transition(.push(from: .leading))
            pager(dark: entry.page == 2).padding(.top, 6)
        }
    }

    private var todayPage: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(entry.daily.weekday).font(WS.ui(11, .medium)).foregroundStyle(.white.opacity(0.8))
                Text(entry.daily.hijri.replacingOccurrences(of: " هـ", with: ""))
                    .font(WS.kufi(19)).foregroundStyle(.white).lineLimit(2).minimumScaleFactor(0.75)
                Spacer(minLength: 2)
                if let o = entry.daily.occasion, let l = DailyText.occasionLine(o) {
                    HStack(spacing: 5) {
                        Image(systemName: o.symbol).font(.system(size: 9, weight: .semibold)).foregroundStyle(WS.gold)
                        Text(l).font(WS.ui(10, .semibold)).foregroundStyle(.white).lineLimit(2)
                    }
                }
            }
            .frame(width: 136, alignment: .leading)
            Rectangle().fill(.white.opacity(0.15)).frame(width: 1)
            VStack(alignment: .leading, spacing: 3) {
                Text("حكمة اليوم").font(WS.ui(10, .bold)).foregroundStyle(WS.gold)
                if let s = entry.daily.saying {
                    Text(verbatim: "«\(s.text)»").font(WS.amiri(14)).foregroundStyle(.white)
                        .lineLimit(4).minimumScaleFactor(0.75)
                    Text(s.who.components(separatedBy: " · ").first ?? s.who)
                        .font(WS.ui(9)).foregroundStyle(.white.opacity(0.7)).lineLimit(1)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var dhikrPage: some View {
        let p = WidgetTasbih.phase(entry.tasbih)
        return HStack(spacing: 12) {
            TasbihRingButton(phase: p, size: 96)
            VStack(alignment: .leading, spacing: 3) {
                Text("ذكر اليوم").font(WS.ui(10, .bold)).foregroundStyle(WS.goldDeep)
                if let d = entry.daily.dhikr {
                    Text(d.text).font(WS.amiri(16)).foregroundStyle(WS.ink).lineLimit(3).minimumScaleFactor(0.75)
                    Text(d.src).font(WS.ui(9)).foregroundStyle(WS.muted).lineLimit(1)
                }
                Spacer(minLength: 0)
                Text("اضغط الحلقة لتسبيحة الزهراء (ع)").font(WS.ui(9)).foregroundStyle(WS.muted).lineLimit(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    /// Three tappable dots plus a next arrow.
    private func pager(dark: Bool) -> some View {
        let on: Color = dark ? WS.deeper : WS.gold
        let off: Color = (dark ? WS.ink : Color.white).opacity(0.25)
        let names = ["الصلاة", "اليوم", "الذكر"]
        return HStack(spacing: 6) {
            ForEach(0..<HubPager.pages, id: \.self) { i in
                Button(intent: HubShowPage(page: i)) {
                    if i == entry.page {
                        Text(names[i]).font(WS.ui(9, .bold)).foregroundStyle(dark ? .white : WS.ink)
                            .padding(.horizontal, 8).padding(.vertical, 2)
                            .background(Capsule().fill(on))
                    } else {
                        Circle().fill(off).frame(width: 6, height: 6).padding(5)
                    }
                }
                .buttonStyle(.plain)
            }
            Spacer(minLength: 0)
            Button(intent: HubShowPage(page: (entry.page + 1) % HubPager.pages)) {
                Image(systemName: "chevron.left").font(.system(size: 11, weight: .bold))
                    .foregroundStyle(dark ? WS.ink : .white)
                    .frame(width: 26, height: 20)
                    .background(Capsule().fill((dark ? WS.ink : Color.white).opacity(0.12)))
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: Large (everything)

    private var large: some View {
        VStack(alignment: .leading, spacing: 10) {
            PrayerHeader(entry: entry.prayer, big: 32)
            PrayerProgress(entry: entry.prayer)
            PrayerPills(entry: entry.prayer)
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(entry.daily.weekday).font(WS.ui(10, .medium)).foregroundStyle(.white.opacity(0.8))
                    Text(entry.daily.hijri.replacingOccurrences(of: " هـ", with: ""))
                        .font(WS.kufi(15)).foregroundStyle(.white).lineLimit(2).minimumScaleFactor(0.75)
                    Spacer(minLength: 2)
                    if let o = entry.daily.occasion, let l = DailyText.occasionLine(o) {
                        HStack(alignment: .top, spacing: 4) {
                            Image(systemName: o.symbol).font(.system(size: 9, weight: .semibold)).foregroundStyle(WS.gold)
                            Text(l).font(WS.ui(10, .semibold)).foregroundStyle(.white).lineLimit(2)
                        }
                    }
                    if let s = entry.daily.saying {
                        Text(verbatim: "«\(s.text)»").font(WS.amiri(12)).foregroundStyle(.white.opacity(0.9)).lineLimit(2)
                    }
                }
                .padding(12)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                .background(RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(LinearGradient(colors: [WS.emerald, WS.deeper], startPoint: .topTrailing, endPoint: .bottomLeading)))
                TasbihRingButton(phase: WidgetTasbih.phase(entry.tasbih), size: 112)
                    .padding(10)
                    .frame(maxHeight: .infinity)
                    .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(WS.paperGradient))
            }
            if let d = entry.daily.dhikr {
                HStack(spacing: 8) {
                    Text("ذكر اليوم").font(WS.ui(10, .bold)).foregroundStyle(WS.gold)
                    Text(d.text).font(WS.amiri(14)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.7)
                }
            }
        }
    }
}

struct HubWidget: Widget {
    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: "RafiqHubWidget", intent: PrayerWidgetIntent.self, provider: HubProvider()) { entry in
            HubWidgetView(entry: entry)
        }
        .configurationDisplayName("رفيق المؤمن")
        .description("الصلاة والتقويم وذكر اليوم في ويدجت واحد يتبدّل تلقائياً، واضغط النقاط للتنقّل.")
        .supportedFamilies([.systemMedium, .systemLarge])
    }
}
