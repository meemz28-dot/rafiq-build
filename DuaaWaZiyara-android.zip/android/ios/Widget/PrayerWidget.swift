import WidgetKit
import SwiftUI
import AppIntents
import CoreLocation

// MARK: - Configuration (the widget cannot read the app's settings without an App Group, so the user picks here)

struct WidgetCityEntity: AppEntity {
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "المدينة"
    static var defaultQuery = WidgetCityQuery()
    let id: String
    let name: String
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(name)") }

    static let gps = WidgetCityEntity(id: "gps", name: "موقعي الحالي (GPS)")

    static func from(index i: Int) -> WidgetCityEntity {
        let list = WidgetCity.all
        let k = max(0, min(list.count - 1, i))
        return WidgetCityEntity(id: String(k), name: list[k].n)
    }
}

struct WidgetCityQuery: EntityQuery {
    func entities(for identifiers: [String]) async throws -> [WidgetCityEntity] {
        identifiers.map { $0 == "gps" ? .gps : WidgetCityEntity.from(index: Int($0) ?? 0) }
    }
    func suggestedEntities() async throws -> [WidgetCityEntity] {
        [.gps] + WidgetCity.all.indices.map { WidgetCityEntity.from(index: $0) }
    }
    func defaultResult() async -> WidgetCityEntity? { .gps }
}

enum WidgetMethod: String, AppEnum {
    case jafari, hadi, tehran, karachi, mwl, makkah
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "طريقة الحساب"
    static var caseDisplayRepresentations: [WidgetMethod: DisplayRepresentation] = [
        .jafari: "الجعفري (ليفا - قم)",
        .hadi: "الهادي (البوعلي)",
        .tehran: "طهران",
        .karachi: "كراتشي",
        .mwl: "رابطة العالم الإسلامي",
        .makkah: "أم القرى (مكة)"
    ]
}

struct PrayerWidgetIntent: WidgetConfigurationIntent {
    static var title: LocalizedStringResource = "مواقيت الصلاة"
    static var description = IntentDescription("الصلاة القادمة ومواقيت اليوم")
    @Parameter(title: "المدينة") var city: WidgetCityEntity?
    @Parameter(title: "طريقة الحساب", default: .jafari) var method: WidgetMethod
}

// MARK: - Timeline

struct PrayerEntry: TimelineEntry {
    let date: Date
    let city: String
    let times: PrayerTimes.Times
    let nextKey: String
    let nextDate: Date
    /// Previous prayer (start of the current interval), for the progress bar and ring.
    let prevDate: Date
    let hijri: String

    var fraction: Double {
        let total = nextDate.timeIntervalSince(prevDate)
        guard total > 0 else { return 0 }
        return min(1, max(0, date.timeIntervalSince(prevDate) / total))
    }
}

/// The device's location for the widget (uses the app's location permission; NSWidgetWantsLocation).
enum WidgetLocator {
    private static let ud = UserDefaults.standard

    static var cached: WidgetCity? {
        guard ud.object(forKey: "gpsLat") != nil else { return nil }
        return WidgetCity(n: ud.string(forKey: "gpsName") ?? "موقعي", lat: ud.double(forKey: "gpsLat"),
                          lng: ud.double(forKey: "gpsLng"), tz: tzNow)
    }

    static var tzNow: Double { Double(TimeZone.current.secondsFromGMT()) / 3600 }

    static func current() async -> WidgetCity? {
        let m = CLLocationManager()
        guard [.authorizedWhenInUse, .authorizedAlways].contains(m.authorizationStatus) else { return cached }
        var loc = m.location
        if loc == nil || (loc?.timestamp.timeIntervalSinceNow ?? -9999) < -1800 {
            loc = await fresh() ?? loc
        }
        guard let l = loc else { return cached }
        var name = ud.string(forKey: "gpsName") ?? "موقعي"
        let old = cached.map { CLLocation(latitude: $0.lat, longitude: $0.lng) }
        if old == nil || old!.distance(from: l) > 3000 || ud.string(forKey: "gpsName") == nil {
            if let p = try? await CLGeocoder().reverseGeocodeLocation(l, preferredLocale: Locale(identifier: "ar")).first {
                name = p.locality ?? p.subAdministrativeArea ?? p.administrativeArea ?? name
            }
        }
        ud.set(l.coordinate.latitude, forKey: "gpsLat"); ud.set(l.coordinate.longitude, forKey: "gpsLng"); ud.set(name, forKey: "gpsName")
        return WidgetCity(n: name, lat: l.coordinate.latitude, lng: l.coordinate.longitude, tz: tzNow)
    }

    private static func fresh() async -> CLLocation? {
        await withTaskGroup(of: CLLocation?.self) { g in
            g.addTask {
                do { for try await u in CLLocationUpdate.liveUpdates() { if let l = u.location { return l } } } catch {}
                return nil
            }
            g.addTask { try? await Task.sleep(nanoseconds: 8_000_000_000); return nil }
            let first = await g.next() ?? nil
            g.cancelAll()
            return first
        }
    }
}

struct PrayerProvider: AppIntentTimelineProvider {
    func placeholder(in context: Context) -> PrayerEntry {
        entry(at: Date(), city: WidgetLocator.cached ?? WidgetCity.all[0], method: "jafari")
    }

    func snapshot(for configuration: PrayerWidgetIntent, in context: Context) async -> PrayerEntry {
        entry(at: Date(), city: await resolve(configuration), method: configuration.method.rawValue)
    }

    func timeline(for configuration: PrayerWidgetIntent, in context: Context) async -> Timeline<PrayerEntry> {
        let c = await resolve(configuration), m = configuration.method.rawValue
        let now = Date()
        // An entry at each prayer (the highlight moves on time) and every 20 minutes
        // (the lock-screen ring fills smoothly), for the next 12 hours.
        var stamps: [Date] = [now]
        var cursor = now
        for _ in 0..<6 {
            let at = entry(at: cursor, city: c, method: m).nextDate.addingTimeInterval(1)
            if at.timeIntervalSince(now) > 43200 { break }
            stamps.append(at)
            cursor = at
        }
        var t = now.addingTimeInterval(1200)
        while t.timeIntervalSince(now) <= 43200 { stamps.append(t); t = t.addingTimeInterval(1200) }
        stamps.sort()
        let entries = stamps.map { entry(at: $0, city: c, method: m) }
        // GPS widgets refresh hourly so a new city is picked up when travelling.
        let gps = (configuration.city?.id ?? "gps") == "gps"
        let refresh = gps ? now.addingTimeInterval(3600) : (stamps.last ?? now.addingTimeInterval(3600))
        return Timeline(entries: entries, policy: .after(refresh))
    }

    func resolve(_ c: PrayerWidgetIntent) async -> WidgetCity {
        let id = c.city?.id ?? "gps"
        if id == "gps" { return await WidgetLocator.current() ?? WidgetCity.all[0] }
        let list = WidgetCity.all
        return list[max(0, min(list.count - 1, Int(id) ?? 0))]
    }

    func entry(at date: Date, city c: WidgetCity, method: String) -> PrayerEntry {
        let t = PrayerTimes.compute(date: date, lat: c.lat, lng: c.lng, tz: c.tz, methodKey: method)
        let nowH = PrayerTimes.nowHours(date)
        let nx = PrayerTimes.next(t, nowHours: nowH)
        let nextDate = date.addingTimeInterval(nx.hours * 3600)
        var since = 24.0
        for k in PrayerTimes.prayerKeys {
            var dt = nowH - PrayerTimes.norm(PrayerTimes.value(t, k))
            if dt < 0 { dt += 24 }
            if dt < since { since = dt }
        }
        return PrayerEntry(date: date, city: c.n, times: t, nextKey: nx.key, nextDate: nextDate,
                           prevDate: date.addingTimeInterval(-since * 3600),
                           hijri: Hijri.format(Hijri.jdToHijri(Hijri.jd(of: date))))
    }
}

// MARK: - Views

extension PrayerEntry {
    var hDate: Hijri.HDate { Hijri.jdToHijri(Hijri.jd(of: date)) }
    var dayMonth: String { "\(hDate.d.ar) \(Hijri.months[max(0, min(11, hDate.m - 1))])" }
    var weekday: String {
        let wd = Calendar(identifier: .gregorian).component(.weekday, from: date) - 1
        return Hijri.weekDays[max(0, min(6, wd))]
    }
}

/// Arabic-Indic digits for the system timer texts.
let widgetArabicLocale = Locale(identifier: "ar_SA@numbers=arab")

struct PrayerWidgetView: View {
    @Environment(\.widgetFamily) private var envFamily
    var forced: WidgetFamily? = nil
    private var family: WidgetFamily { forced ?? envFamily }
    init(entry: PrayerEntry, forced: WidgetFamily? = nil) { self.entry = entry; self.forced = forced }
    let entry: PrayerEntry

    var body: some View {
        content
            .environment(\.layoutDirection, .rightToLeft)
            .environment(\.locale, widgetArabicLocale)
            .widgetURL(URL(string: "rafiq://prayer"))
            .containerBackground(for: .widget) { WS.prayerBG }
    }

    @ViewBuilder private var content: some View {
        switch family {
        case .accessoryInline:
            Text(verbatim: "\(PrayerTimes.name(entry.nextKey)) \(PrayerTimes.fmt(PrayerTimes.value(entry.times, entry.nextKey)))")
        case .accessoryCircular:
            Gauge(value: entry.fraction) {
                Image(systemName: "moon.stars.fill")
            } currentValueLabel: {
                VStack(spacing: 0) {
                    Text(PrayerTimes.name(entry.nextKey)).font(WS.ui(10, .bold)).minimumScaleFactor(0.6)
                    Text(WS.short(PrayerTimes.fmt(PrayerTimes.value(entry.times, entry.nextKey))))
                        .font(WS.ui(9)).minimumScaleFactor(0.6)
                }
            }
            .gaugeStyle(.accessoryCircularCapacity)
            .widgetAccentable()
        case .accessoryRectangular:
            HStack(spacing: 8) {
                ZStack {
                    ProgressView(timerInterval: entry.prevDate...entry.nextDate, countsDown: false) {
                        EmptyView()
                    } currentValueLabel: { EmptyView() }
                    .progressViewStyle(.circular)
                    .widgetAccentable()
                    Text(PrayerTimes.name(entry.nextKey)).font(WS.ui(10, .bold)).minimumScaleFactor(0.6).lineLimit(1)
                        .padding(4)
                }
                .frame(width: 46, height: 46)
                VStack(alignment: .leading, spacing: 0) {
                    Text(WS.short(PrayerTimes.fmt(PrayerTimes.value(entry.times, entry.nextKey))))
                        .font(WS.kufi(20)).lineLimit(1).minimumScaleFactor(0.7)
                    HStack(spacing: 3) {
                        Text("بعد").font(WS.ui(11))
                        Text(timerInterval: entry.date...entry.nextDate, countsDown: true)
                            .font(WS.ui(11, .medium)).lineLimit(1)
                    }
                }
                Spacer(minLength: 0)
            }
        case .systemMedium:
            PrayerMediumCard(entry: entry)
        case .systemLarge:
            large
        default:
            small
        }
    }

    private var small: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack {
                Text(entry.city).font(WS.ui(11, .medium)).foregroundStyle(.white.opacity(0.8)).lineLimit(1)
                Spacer(minLength: 0)
                Text(entry.weekday).font(WS.ui(11, .bold)).foregroundStyle(WS.gold)
            }
            Spacer(minLength: 0)
            Text(verbatim: "\(PrayerTimes.name(entry.nextKey)) بعد").font(WS.ui(11)).foregroundStyle(.white.opacity(0.8))
            Text(timerInterval: entry.date...entry.nextDate, countsDown: true)
                .font(WS.kufi(26)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.6)
            PrayerProgress(entry: entry).padding(.vertical, 3)
            Text(verbatim: "\(PrayerTimes.name(entry.nextKey)) · \(WS.short(PrayerTimes.fmt(PrayerTimes.value(entry.times, entry.nextKey))))")
                .font(WS.ui(12, .bold)).foregroundStyle(WS.gold)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
    }

    private var large: some View {
        VStack(alignment: .leading, spacing: 10) {
            PrayerHeader(entry: entry)
            PrayerProgress(entry: entry)
            VStack(spacing: 5) {
                ForEach(PrayerTimes.slots, id: \.key) { slot in
                    let isNext = slot.key == entry.nextKey
                    HStack {
                        Image(systemName: slot.symbol).font(.system(size: 13, weight: .medium)).frame(width: 22)
                        Text(slot.name).font(WS.ui(14, isNext ? .bold : .medium))
                        Spacer()
                        Text(WS.short(PrayerTimes.fmt(PrayerTimes.value(entry.times, slot.key))))
                            .font(WS.ui(14, isNext ? .bold : .medium))
                    }
                    .foregroundStyle(isNext ? WS.ink : .white.opacity(slot.key == "sunrise" || slot.key == "midnight" ? 0.65 : 0.95))
                    .padding(.horizontal, 12).padding(.vertical, 5)
                    .background(RoundedRectangle(cornerRadius: 11, style: .continuous).fill(isNext ? WS.gold : Color.white.opacity(0.08)))
                }
            }
            Spacer(minLength: 0)
            if let o = WidgetContent.nextOccasion(from: entry.date) {
                HStack(spacing: 6) {
                    Image(systemName: o.symbol).font(.system(size: 11)).foregroundStyle(WS.gold)
                    Text(verbatim: o.days == 0 ? "اليوم: \(o.title)" : "\(o.title) · بعد \(o.days.ar) \(o.days == 1 ? "يوم" : "أيام")")
                        .font(WS.ui(12, .semibold)).foregroundStyle(.white).lineLimit(1)
                }
            }
        }
    }
}

/// "دبي · الظهر بعد  ٢:٣٧:١٤"  |  "٢٤ جمادى الأولى / الخميس"
struct PrayerHeader: View {
    let entry: PrayerEntry
    var big: CGFloat = 30

    var body: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 0) {
                Text(verbatim: "\(entry.city) · \(PrayerTimes.name(entry.nextKey)) بعد")
                    .font(WS.ui(11, .medium)).foregroundStyle(.white.opacity(0.8)).lineLimit(1)
                Text(timerInterval: entry.date...entry.nextDate, countsDown: true)
                    .font(WS.kufi(big)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.6)
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 1) {
                Text(entry.dayMonth).font(WS.ui(11, .medium)).foregroundStyle(.white.opacity(0.8)).lineLimit(1)
                Text(entry.weekday).font(WS.ui(13, .bold)).foregroundStyle(WS.gold)
            }
        }
    }
}

/// Thin gold bar from the previous prayer to the next, animated by the system.
struct PrayerProgress: View {
    let entry: PrayerEntry
    var body: some View {
        ProgressView(timerInterval: entry.prevDate...entry.nextDate, countsDown: false) {
            EmptyView()
        } currentValueLabel: { EmptyView() }
        .progressViewStyle(.linear)
        .tint(WS.gold)
        .scaleEffect(x: 1, y: 1.2)
    }
}

/// Five pills, the next prayer filled gold.
struct PrayerPills: View {
    let entry: PrayerEntry
    var body: some View {
        HStack(spacing: 4) {
            ForEach(PrayerTimes.prayerKeys, id: \.self) { k in
                let isNext = k == entry.nextKey
                VStack(spacing: 1) {
                    Text(PrayerTimes.name(k)).font(WS.ui(10, isNext ? .bold : .regular))
                    Text(WS.short(PrayerTimes.fmt(PrayerTimes.value(entry.times, k))))
                        .font(WS.ui(11, .bold)).lineLimit(1).minimumScaleFactor(0.7)
                }
                .foregroundStyle(isNext ? WS.ink : .white.opacity(0.9))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 6)
                .background(RoundedRectangle(cornerRadius: 10, style: .continuous).fill(isNext ? WS.gold : Color.white.opacity(0.08)))
            }
        }
    }
}

struct PrayerMediumCard: View {
    let entry: PrayerEntry
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            PrayerHeader(entry: entry)
            Spacer(minLength: 4)
            PrayerProgress(entry: entry)
            Spacer(minLength: 6)
            PrayerPills(entry: entry)
        }
    }
}

struct PrayerWidget: Widget {
    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: "RafiqPrayerWidget", intent: PrayerWidgetIntent.self, provider: PrayerProvider()) { entry in
            PrayerWidgetView(entry: entry)
        }
        .configurationDisplayName("مواقيت الصلاة")
        .description("الصلاة القادمة ومواقيت اليوم. اضغط مطوّلاً لاختيار المدينة وطريقة الحساب.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular, .accessoryCircular, .accessoryInline])
    }
}

