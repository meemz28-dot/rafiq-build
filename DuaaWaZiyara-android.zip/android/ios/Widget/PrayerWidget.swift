import WidgetKit
import SwiftUI
import AppIntents
import CoreLocation

// MARK: - Configuration (the widget cannot read the app's settings without an App Group, so the user picks here)

struct WidgetCityEntity: AppEntity {
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "المدينة"
    static var defaultQuery = WidgetCityQuery()
    let id: String
    let name: String
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(name)") }

    static let gps = WidgetCityEntity(id: "gps", name: "موقعي الحالي (GPS)")

    static func from(index i: Int) -> WidgetCityEntity {
        let list = WidgetCity.all
        let k = max(0, min(list.count - 1, i))
        return WidgetCityEntity(id: String(k), name: list[k].n)
    }
}

struct WidgetCityQuery: EntityQuery {
    func entities(for identifiers: [String]) async throws -> [WidgetCityEntity] {
        identifiers.map { $0 == "gps" ? .gps : WidgetCityEntity.from(index: Int($0) ?? 0) }
    }
    func suggestedEntities() async throws -> [WidgetCityEntity] {
        [.gps] + WidgetCity.all.indices.map { WidgetCityEntity.from(index: $0) }
    }
    func defaultResult() async -> WidgetCityEntity? { .gps }
}

enum WidgetMethod: String, AppEnum {
    case jafari, hadi, tehran, karachi, mwl, makkah
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "طريقة الحساب"
    static var caseDisplayRepresentations: [WidgetMethod: DisplayRepresentation] = [
        .jafari: "الجعفري (ليفا - قم)",
        .hadi: "الهادي (البوعلي)",
        .tehran: "طهران",
        .karachi: "كراتشي",
        .mwl: "رابطة العالم الإسلامي",
        .makkah: "أم القرى (مكة)"
    ]
}

struct PrayerWidgetIntent: WidgetConfigurationIntent {
    static var title: LocalizedStringResource = "مواقيت الصلاة"
    static var description = IntentDescription("الصلاة القادمة ومواقيت اليوم")
    @Parameter(title: "المدينة") var city: WidgetCityEntity?
    @Parameter(title: "طريقة الحساب", default: .jafari) var method: WidgetMethod
}

// MARK: - Timeline

struct PrayerEntry: TimelineEntry {
    let date: Date
    let city: String
    let times: PrayerTimes.Times
    let nextKey: String
    let nextDate: Date
    /// Previous prayer (start of the current interval), for the progress bar and ring.
    let prevDate: Date
    let hijri: String

    var fraction: Double {
        let total = nextDate.timeIntervalSince(prevDate)
        guard total > 0 else { return 0 }
        return min(1, max(0, date.timeIntervalSince(prevDate) / total))
    }
}

/// The device's location for the widget (uses the app's location permission; NSWidgetWantsLocation).
enum WidgetLocator {
    private static let ud = UserDefaults.standard

    static var cached: WidgetCity? {
        guard ud.object(forKey: "gpsLat") != nil else { return nil }
        return WidgetCity(n: ud.string(forKey: "gpsName") ?? "موقعي", lat: ud.double(forKey: "gpsLat"),
                          lng: ud.double(forKey: "gpsLng"), tz: tzNow)
    }

    static var tzNow: Double { Double(TimeZone.current.secondsFromGMT()) / 3600 }

    static func current() async -> WidgetCity? {
        let m = CLLocationManager()
        guard [.authorizedWhenInUse, .authorizedAlways].contains(m.authorizationStatus) else { return cached }
        var loc = m.location
        if loc == nil || (loc?.timestamp.timeIntervalSinceNow ?? -9999) < -1800 {
            loc = await fresh() ?? loc
        }
        guard let l = loc else { return cached }
        var name = ud.string(forKey: "gpsName") ?? "موقعي"
        let old = cached.map { CLLocation(latitude: $0.lat, longitude: $0.lng) }
        if old == nil || old!.distance(from: l) > 3000 || ud.string(forKey: "gpsName") == nil {
            if let p = try? await CLGeocoder().reverseGeocodeLocation(l, preferredLocale: Locale(identifier: "ar")).first {
                name = p.locality ?? p.subAdministrativeArea ?? p.administrativeArea ?? name
            }
        }
        ud.set(l.coordinate.latitude, forKey: "gpsLat"); ud.set(l.coordinate.longitude, forKey: "gpsLng"); ud.set(name, forKey: "gpsName")
        return WidgetCity(n: name, lat: l.coordinate.latitude, lng: l.coordinate.longitude, tz: tzNow)
    }

    private static func fresh() async -> CLLocation? {
        await withTaskGroup(of: CLLocation?.self) { g in
            g.addTask {
                do { for try await u in CLLocationUpdate.liveUpdates() { if let l = u.location { return l } } } catch {}
                return nil
            }
            g.addTask { try? await Task.sleep(nanoseconds: 8_000_000_000); return nil }
            let first = await g.next() ?? nil
            g.cancelAll()
            return first
        }
    }
}

struct PrayerProvider: AppIntentTimelineProvider {
    func placeholder(in context: Context) -> PrayerEntry {
        entry(at: Date(), city: WidgetLocator.cached ?? WidgetCity.all[0], method: "jafari")
    }

    func snapshot(for configuration: PrayerWidgetIntent, in context: Context) async -> PrayerEntry {
        entry(at: Date(), city: await resolve(configuration), method: configuration.method.rawValue)
    }

    func timeline(for configuration: PrayerWidgetIntent, in context: Context) async -> Timeline<PrayerEntry> {
        let c = await resolve(configuration), m = configuration.method.rawValue
        let now = Date()
        // An entry at each prayer (the highlight moves on time) and every 20 minutes
        // (the lock-screen ring fills smoothly), for the next 12 hours.
        var stamps: [Date] = [now]
        var cursor = now
        for _ in 0..<6 {
            let at = entry(at: cursor, city: c, method: m).nextDate.addingTimeInterval(1)
            if at.timeIntervalSince(now) > 43200 { break }
            stamps.append(at)
            cursor = at
        }
        var t = now.addingTimeInterval(1200)
        while t.timeIntervalSince(now) <= 43200 { stamps.append(t); t = t.addingTimeInterval(1200) }
        stamps.sort()
        let entries = stamps.map { entry(at: $0, city: c, method: m) }
        // GPS widgets refresh hourly so a new city is picked up when travelling.
        let gps = (configuration.city?.id ?? "gps") == "gps"
        let refresh = gps ? now.addingTimeInterval(3600) : (stamps.last ?? now.addingTimeInterval(3600))
        return Timeline(entries: entries, policy: .after(refresh))
    }

    private func resolve(_ c: PrayerWidgetIntent) async -> WidgetCity {
        let id = c.city?.id ?? "gps"
        if id == "gps" { return await WidgetLocator.current() ?? WidgetCity.all[0] }
        let list = WidgetCity.all
        return list[max(0, min(list.count - 1, Int(id) ?? 0))]
    }

    private func entry(at date: Date, city c: WidgetCity, method: String) -> PrayerEntry {
        let t = PrayerTimes.compute(date: date, lat: c.lat, lng: c.lng, tz: c.tz, methodKey: method)
        let nowH = PrayerTimes.nowHours(date)
        let nx = PrayerTimes.next(t, nowHours: nowH)
        let nextDate = date.addingTimeInterval(nx.hours * 3600)
        var since = 24.0
        for k in PrayerTimes.prayerKeys {
            var dt = nowH - PrayerTimes.norm(PrayerTimes.value(t, k))
            if dt < 0 { dt += 24 }
            if dt < since { since = dt }
        }
        return PrayerEntry(date: date, city: c.n, times: t, nextKey: nx.key, nextDate: nextDate,
                           prevDate: date.addingTimeInterval(-since * 3600),
                           hijri: Hijri.format(Hijri.jdToHijri(Hijri.jd(of: date))))
    }
}

// MARK: - Views

private let widgetTeal = Color(red: 0x17 / 255, green: 0x5A / 255, blue: 0x50 / 255)
private let widgetEmerald = Color(red: 0x2A / 255, green: 0x80 / 255, blue: 0x73 / 255)
private let widgetGold = Color(red: 0xD9 / 255, green: 0xB0 / 255, blue: 0x5C / 255)

struct PrayerWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: PrayerEntry

    var body: some View {
        content
            .environment(\.layoutDirection, .rightToLeft)
            .widgetURL(URL(string: "rafiq://prayer"))
            .containerBackground(for: .widget) {
                LinearGradient(colors: [widgetEmerald, widgetTeal], startPoint: .topLeading, endPoint: .bottomTrailing)
            }
    }

    @ViewBuilder private var content: some View {
        switch family {
        case .accessoryInline:
            Text(verbatim: "\(PrayerTimes.name(entry.nextKey)) \(PrayerTimes.fmt(PrayerTimes.value(entry.times, entry.nextKey)))")
        case .accessoryCircular:
            Gauge(value: entry.fraction) {
                Image(systemName: "moon.stars.fill")
            } currentValueLabel: {
                VStack(spacing: 0) {
                    Text(PrayerTimes.name(entry.nextKey)).font(.system(size: 10, weight: .bold)).minimumScaleFactor(0.6)
                    Text(PrayerTimes.fmt(PrayerTimes.value(entry.times, entry.nextKey))
                        .replacingOccurrences(of: " ص", with: "").replacingOccurrences(of: " م", with: ""))
                        .font(.system(size: 9)).minimumScaleFactor(0.6)
                }
            }
            .gaugeStyle(.accessoryCircularCapacity)
            .widgetAccentable()
        case .accessoryRectangular:
            VStack(alignment: .leading, spacing: 1) {
                Text(verbatim: "\(PrayerTimes.name(entry.nextKey)) · \(PrayerTimes.fmt(PrayerTimes.value(entry.times, entry.nextKey)))")
                    .font(.headline)
                Text(timerInterval: entry.date...entry.nextDate, countsDown: true)
                    .font(.caption.monospacedDigit())
                ProgressView(timerInterval: entry.prevDate...entry.nextDate, countsDown: false) {
                    EmptyView()
                } currentValueLabel: {
                    EmptyView()
                }
                .widgetAccentable()
            }
        case .systemMedium:
            medium
        case .systemLarge:
            large
        default:
            small
        }
    }

    private var small: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(entry.city).font(.caption2.weight(.bold)).foregroundStyle(.white.opacity(0.75))
            Spacer(minLength: 0)
            Text("الصلاة القادمة").font(.caption2).foregroundStyle(.white.opacity(0.75))
            Text(PrayerTimes.name(entry.nextKey)).font(.title2.weight(.heavy)).foregroundStyle(.white)
            Text(PrayerTimes.fmt(PrayerTimes.value(entry.times, entry.nextKey)))
                .font(.headline.weight(.bold)).foregroundStyle(widgetGold)
            countdown(.caption.weight(.bold))
            progressBar
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
    }

    /// Live countdown ("١:٢٣:٠٥") that ticks without timeline reloads.
    private func countdown(_ font: Font) -> some View {
        Text(timerInterval: entry.date...entry.nextDate, countsDown: true)
            .font(font.monospacedDigit())
            .foregroundStyle(.white.opacity(0.9))
    }

    /// Fills from the previous prayer to the next one, animated by the system.
    private var progressBar: some View {
        ProgressView(timerInterval: entry.prevDate...entry.nextDate, countsDown: false) {
            EmptyView()
        } currentValueLabel: {
            EmptyView()
        }
        .tint(widgetGold)
    }

    private var large: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(entry.city).font(.subheadline.weight(.heavy)).foregroundStyle(.white)
                    Text(entry.hijri).font(.caption).foregroundStyle(.white.opacity(0.75))
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text(verbatim: "\(PrayerTimes.name(entry.nextKey)) بعد").font(.caption2).foregroundStyle(.white.opacity(0.75))
                    countdown(.title3.weight(.heavy))
                }
            }
            progressBar
            VStack(spacing: 4) {
                ForEach(PrayerTimes.slots, id: \.key) { slot in
                    let isNext = slot.key == entry.nextKey
                    HStack {
                        Image(systemName: slot.symbol).frame(width: 22)
                        Text(slot.name).font(.subheadline.weight(isNext ? .heavy : .semibold))
                        Spacer()
                        Text(PrayerTimes.fmt(PrayerTimes.value(entry.times, slot.key)))
                            .font(.subheadline.weight(isNext ? .heavy : .medium)).monospacedDigit()
                    }
                    .foregroundStyle(isNext ? widgetTeal : .white.opacity(slot.key == "sunrise" || slot.key == "midnight" ? 0.7 : 1))
                    .padding(.horizontal, 10).padding(.vertical, 5)
                    .background(RoundedRectangle(cornerRadius: 10).fill(isNext ? widgetGold : Color.white.opacity(0.08)))
                }
            }
            if let o = WidgetContent.nextOccasion(from: entry.date) {
                HStack(spacing: 6) {
                    Image(systemName: o.symbol).foregroundStyle(widgetGold)
                    Text(o.days == 0 ? "اليوم: \(o.title)" : "بعد \(o.days.ar) \(o.days == 1 ? "يوم" : "أيام"): \(o.title)")
                        .font(.caption.weight(.semibold)).foregroundStyle(.white).lineLimit(1)
                }
            }
        }
    }

    private var medium: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(entry.city).font(.caption.weight(.heavy)).foregroundStyle(.white)
                Spacer()
                Text(entry.hijri).font(.caption2).foregroundStyle(.white.opacity(0.75))
            }
            HStack(spacing: 4) {
                ForEach(PrayerTimes.prayerKeys, id: \.self) { k in
                    let isNext = k == entry.nextKey
                    VStack(spacing: 3) {
                        Text(PrayerTimes.name(k)).font(.system(size: 11, weight: .bold))
                        Text(PrayerTimes.fmt(PrayerTimes.value(entry.times, k)))
                            .font(.system(size: 11, weight: .semibold)).minimumScaleFactor(0.7).lineLimit(1)
                    }
                    .foregroundStyle(isNext ? widgetTeal : .white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(RoundedRectangle(cornerRadius: 10).fill(isNext ? widgetGold : Color.white.opacity(0.12)))
                }
            }
            HStack(spacing: 4) {
                Text(verbatim: "\(PrayerTimes.name(entry.nextKey)) بعد").font(.caption2).foregroundStyle(.white.opacity(0.8))
                Text(timerInterval: entry.date...entry.nextDate, countsDown: true)
                    .font(.caption2.weight(.bold).monospacedDigit()).foregroundStyle(widgetGold)
            }
            progressBar
        }
    }
}

struct PrayerWidget: Widget {
    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: "RafiqPrayerWidget", intent: PrayerWidgetIntent.self, provider: PrayerProvider()) { entry in
            PrayerWidgetView(entry: entry)
        }
        .configurationDisplayName("مواقيت الصلاة")
        .description("الصلاة القادمة ومواقيت اليوم. اضغط مطوّلاً لاختيار المدينة وطريقة الحساب.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular, .accessoryCircular, .accessoryInline])
    }
}

@main
struct RafiqWidgets: WidgetBundle {
    var body: some Widget {
        PrayerWidget()
        DailyWidget()
        TasbihWidget()
        PrayerLiveActivity()
        TasbihControl()
        QiblaControl()
        PrayerControl()
    }
}
