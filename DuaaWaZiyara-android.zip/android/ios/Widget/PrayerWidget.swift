import WidgetKit
import SwiftUI
import AppIntents

// MARK: - Configuration (the widget cannot read the app's settings without an App Group, so the user picks here)

struct WidgetCityEntity: AppEntity {
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "المدينة"
    static var defaultQuery = WidgetCityQuery()
    let id: String
    let name: String
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(name)") }

    static func from(index i: Int) -> WidgetCityEntity {
        let list = WidgetCity.all
        let k = max(0, min(list.count - 1, i))
        return WidgetCityEntity(id: String(k), name: list[k].n)
    }
}

struct WidgetCityQuery: EntityQuery {
    func entities(for identifiers: [String]) async throws -> [WidgetCityEntity] {
        identifiers.compactMap { Int($0) }.map { WidgetCityEntity.from(index: $0) }
    }
    func suggestedEntities() async throws -> [WidgetCityEntity] {
        WidgetCity.all.indices.map { WidgetCityEntity.from(index: $0) }
    }
    func defaultResult() async -> WidgetCityEntity? { WidgetCityEntity.from(index: 0) }
}

enum WidgetMethod: String, AppEnum {
    case jafari, hadi, tehran, karachi, mwl, makkah
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "طريقة الحساب"
    static var caseDisplayRepresentations: [WidgetMethod: DisplayRepresentation] = [
        .jafari: "الجعفري (ليفا - قم)",
        .hadi: "الهادي (البوعلي)",
        .tehran: "طهران",
        .karachi: "كراتشي",
        .mwl: "رابطة العالم الإسلامي",
        .makkah: "أم القرى (مكة)"
    ]
}

struct PrayerWidgetIntent: WidgetConfigurationIntent {
    static var title: LocalizedStringResource = "مواقيت الصلاة"
    static var description = IntentDescription("الصلاة القادمة ومواقيت اليوم")
    @Parameter(title: "المدينة") var city: WidgetCityEntity?
    @Parameter(title: "طريقة الحساب", default: .jafari) var method: WidgetMethod
}

// MARK: - Timeline

struct PrayerEntry: TimelineEntry {
    let date: Date
    let city: String
    let times: PrayerTimes.Times
    let nextKey: String
    let nextDate: Date
    let hijri: String
}

struct PrayerProvider: AppIntentTimelineProvider {
    func placeholder(in context: Context) -> PrayerEntry { entry(at: Date(), cityIndex: 0, method: "jafari") }

    func snapshot(for configuration: PrayerWidgetIntent, in context: Context) async -> PrayerEntry {
        entry(at: Date(), cityIndex: index(configuration), method: configuration.method.rawValue)
    }

    func timeline(for configuration: PrayerWidgetIntent, in context: Context) async -> Timeline<PrayerEntry> {
        let idx = index(configuration), m = configuration.method.rawValue
        let now = Date()
        var entries = [entry(at: now, cityIndex: idx, method: m)]
        // A new entry at each prayer so the highlight moves on time, for the next 24 hours.
        var cursor = now
        for _ in 0..<8 {
            let e = entry(at: cursor, cityIndex: idx, method: m)
            let at = e.nextDate.addingTimeInterval(1)
            if at.timeIntervalSince(now) > 86400 { break }
            entries.append(entry(at: at, cityIndex: idx, method: m))
            cursor = at
        }
        return Timeline(entries: entries, policy: .after(cursor.addingTimeInterval(60)))
    }

    private func index(_ c: PrayerWidgetIntent) -> Int { Int(c.city?.id ?? "0") ?? 0 }

    private func entry(at date: Date, cityIndex: Int, method: String) -> PrayerEntry {
        let list = WidgetCity.all
        let c = list[max(0, min(list.count - 1, cityIndex))]
        let t = PrayerTimes.compute(date: date, lat: c.lat, lng: c.lng, tz: c.tz, methodKey: method)
        let nowH = PrayerTimes.nowHours(date)
        let nx = PrayerTimes.next(t, nowHours: nowH)
        let nextDate = date.addingTimeInterval(nx.hours * 3600)
        return PrayerEntry(date: date, city: c.n, times: t, nextKey: nx.key, nextDate: nextDate,
                           hijri: Hijri.format(Hijri.jdToHijri(Hijri.jd(of: date))))
    }
}

// MARK: - Views

private let widgetTeal = Color(red: 0x22 / 255, green: 0x6E / 255, blue: 0x62 / 255)
private let widgetEmerald = Color(red: 0x3E / 255, green: 0x9E / 255, blue: 0x8E / 255)
private let widgetGold = Color(red: 0xD9 / 255, green: 0xB0 / 255, blue: 0x5C / 255)

struct PrayerWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: PrayerEntry

    var body: some View {
        content
            .environment(\.layoutDirection, .rightToLeft)
            .widgetURL(URL(string: "rafiq://prayer"))
            .containerBackground(for: .widget) {
                LinearGradient(colors: [widgetEmerald, widgetTeal], startPoint: .topLeading, endPoint: .bottomTrailing)
            }
    }

    @ViewBuilder private var content: some View {
        switch family {
        case .accessoryInline:
            Text("\(PrayerTimes.name(entry.nextKey)) \(PrayerTimes.fmt(PrayerTimes.value(entry.times, entry.nextKey)))")
        case .accessoryCircular:
            VStack(spacing: 0) {
                Text(PrayerTimes.name(entry.nextKey)).font(.system(size: 11, weight: .bold))
                Text(PrayerTimes.fmt(PrayerTimes.value(entry.times, entry.nextKey))).font(.system(size: 10)).minimumScaleFactor(0.6)
            }
        case .accessoryRectangular:
            VStack(alignment: .leading, spacing: 1) {
                Text("\(PrayerTimes.name(entry.nextKey)) · \(PrayerTimes.fmt(PrayerTimes.value(entry.times, entry.nextKey)))")
                    .font(.headline)
                Text(entry.nextDate, style: .relative).font(.caption)
                Text(entry.city).font(.caption2).foregroundStyle(.secondary)
            }
        case .systemMedium:
            medium
        default:
            small
        }
    }

    private var small: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(entry.city).font(.caption2.weight(.bold)).foregroundStyle(.white.opacity(0.75))
            Spacer(minLength: 0)
            Text("الصلاة القادمة").font(.caption2).foregroundStyle(.white.opacity(0.75))
            Text(PrayerTimes.name(entry.nextKey)).font(.title2.weight(.heavy)).foregroundStyle(.white)
            Text(PrayerTimes.fmt(PrayerTimes.value(entry.times, entry.nextKey)))
                .font(.headline.weight(.bold)).foregroundStyle(widgetGold)
            Text(entry.nextDate, style: .relative).font(.caption2).foregroundStyle(.white.opacity(0.8))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
    }

    private var medium: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(entry.city).font(.caption.weight(.heavy)).foregroundStyle(.white)
                Spacer()
                Text(entry.hijri).font(.caption2).foregroundStyle(.white.opacity(0.75))
            }
            HStack(spacing: 4) {
                ForEach(PrayerTimes.prayerKeys, id: \.self) { k in
                    let isNext = k == entry.nextKey
                    VStack(spacing: 3) {
                        Text(PrayerTimes.name(k)).font(.system(size: 11, weight: .bold))
                        Text(PrayerTimes.fmt(PrayerTimes.value(entry.times, k)))
                            .font(.system(size: 11, weight: .semibold)).minimumScaleFactor(0.7).lineLimit(1)
                    }
                    .foregroundStyle(isNext ? widgetTeal : .white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(RoundedRectangle(cornerRadius: 10).fill(isNext ? widgetGold : Color.white.opacity(0.12)))
                }
            }
            HStack(spacing: 4) {
                Text("\(PrayerTimes.name(entry.nextKey)) بعد").font(.caption2).foregroundStyle(.white.opacity(0.8))
                Text(entry.nextDate, style: .relative).font(.caption2.weight(.bold)).foregroundStyle(widgetGold)
            }
        }
    }
}

struct PrayerWidget: Widget {
    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: "RafiqPrayerWidget", intent: PrayerWidgetIntent.self, provider: PrayerProvider()) { entry in
            PrayerWidgetView(entry: entry)
        }
        .configurationDisplayName("مواقيت الصلاة")
        .description("الصلاة القادمة ومواقيت اليوم. اضغط مطوّلاً لاختيار المدينة وطريقة الحساب.")
        .supportedFamilies([.systemSmall, .systemMedium, .accessoryRectangular, .accessoryCircular, .accessoryInline])
    }
}

@main
struct RafiqWidgets: WidgetBundle {
    var body: some Widget {
        PrayerWidget()
        PrayerLiveActivity()
        TasbihControl()
        QiblaControl()
        PrayerControl()
    }
}
