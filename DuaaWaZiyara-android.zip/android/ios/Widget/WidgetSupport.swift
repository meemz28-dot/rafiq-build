import Foundation

// Small copies of the app's digit helpers (the widget is a separate module and does not compile Models.swift).
private let widgetArabicDigits: [Character] = ["٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩"]

extension Int {
    var ar: String {
        String(String(self).map { c -> Character in
            if let v = c.wholeNumberValue, v >= 0, v < 10 { return widgetArabicDigits[v] }
            return c
        })
    }
}

extension String {
    var arabicDigits: String {
        String(map { c -> Character in
            if c.isASCII, let v = c.wholeNumberValue { return widgetArabicDigits[v] }
            return c
        })
    }
}

/// One city from cities.json (same list as the app).
struct WidgetCity: Decodable, Hashable {
    let n: String
    let lat: Double
    let lng: Double
    let tz: Double

    static let all: [WidgetCity] = {
        guard let url = Bundle.main.url(forResource: "cities", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let list = try? JSONDecoder().decode([WidgetCity].self, from: data), !list.isEmpty else {
            return [WidgetCity(n: "دبي", lat: 25.2048, lng: 55.2708, tz: 4)]
        }
        return list
    }()
}

/// Occasions, sayings and adhkar exported from the app's content (widget-content.json).
enum WidgetContent {
    struct Occ: Decodable { let m: Int; let d: Int; let t: String; let k: String }
    struct Saying: Decodable { let text: String; let who: String }
    struct Dhikr: Decodable { let text: String; let src: String }
    private struct File: Decodable { let occasions: [Occ]; let hikam: [Saying]; let adhkar: [Dhikr] }

    private static let file: File? = {
        guard let url = Bundle.main.url(forResource: "widget-content", withExtension: "json"),
              let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(File.self, from: data)
    }()

    struct Upcoming { let title: String; let days: Int; let kind: String
        var symbol: String {
            switch kind {
            case "birth": return "sparkles"
            case "death": return "moon.fill"
            case "eid": return "star.fill"
            default: return "calendar"
            }
        }
    }

    /// Today's occasion, or the next one within 60 days.
    static func nextOccasion(from date: Date) -> Upcoming? {
        guard let occ = file?.occasions, !occ.isEmpty else { return nil }
        let jd = Hijri.jd(of: date)
        for i in 0...60 {
            let h = Hijri.jdToHijri(jd + i)
            if let o = occ.first(where: { $0.m == h.m && $0.d == h.d }) {
                return Upcoming(title: o.t, days: i, kind: o.k)
            }
        }
        return nil
    }

    /// A saying for the day (changes at midnight, same for everyone on that day).
    static func saying(for date: Date) -> Saying? {
        guard let list = file?.hikam, !list.isEmpty else { return nil }
        return list[Hijri.jd(of: date) % list.count]
    }

    static func dhikr(for date: Date) -> Dhikr? {
        guard let list = file?.adhkar, !list.isEmpty else { return nil }
        return list[(Hijri.jd(of: date) + 7) % list.count]
    }
}
