import Foundation

// Small copies of the app's digit helpers (the widget is a separate module and does not compile Models.swift).
private let widgetArabicDigits: [Character] = ["٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩"]

extension Int {
    var ar: String {
        String(String(self).map { c -> Character in
            if let v = c.wholeNumberValue, v >= 0, v < 10 { return widgetArabicDigits[v] }
            return c
        })
    }
}

extension String {
    var arabicDigits: String {
        String(map { c -> Character in
            if c.isASCII, let v = c.wholeNumberValue { return widgetArabicDigits[v] }
            return c
        })
    }
}

/// One city from cities.json (same list as the app).
struct WidgetCity: Decodable, Hashable {
    let n: String
    let lat: Double
    let lng: Double
    let tz: Double

    static let all: [WidgetCity] = {
        guard let url = Bundle.main.url(forResource: "cities", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let list = try? JSONDecoder().decode([WidgetCity].self, from: data), !list.isEmpty else {
            return [WidgetCity(n: "دبي", lat: 25.2048, lng: 55.2708, tz: 4)]
        }
        return list
    }()
}
