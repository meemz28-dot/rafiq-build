import WidgetKit
import SwiftUI
import AppIntents

/// Control Center / Lock Screen / Action Button controls (iOS 18).
struct TasbihControl: ControlWidget {
    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(kind: "RafiqTasbihControl") {
            ControlWidgetButton(action: OpenRafiqIntent(destination: .tasbih)) {
                Label("التسبيح", systemImage: "circle.dotted")
            }
        }
        .displayName("التسبيح")
        .description("افتح السبحة مباشرة")
    }
}

struct QiblaControl: ControlWidget {
    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(kind: "RafiqQiblaControl") {
            ControlWidgetButton(action: OpenRafiqIntent(destination: .qibla)) {
                Label("القبلة", systemImage: "location.north.line")
            }
        }
        .displayName("اتجاه القبلة")
        .description("افتح بوصلة القبلة")
    }
}

struct PrayerControl: ControlWidget {
    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(kind: "RafiqPrayerControl") {
            ControlWidgetButton(action: OpenRafiqIntent(destination: .prayer)) {
                Label("المواقيت", systemImage: "clock.fill")
            }
        }
        .displayName("مواقيت الصلاة")
        .description("افتح مواقيت اليوم")
    }
}
