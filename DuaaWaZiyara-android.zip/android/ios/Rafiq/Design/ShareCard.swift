import SwiftUI
import UIKit

/// The image card shared from the reader and the khira (same idea as Android's ShareCard):
/// dark patterned card, title, an excerpt in the scripture face, the source, and the app mark.
struct ShareCardView: View {
    let title: String
    let text: String
    let source: String?

    var body: some View {
        VStack(spacing: 18) {
            HStack(spacing: 8) {
                StarShape().fill(Brand.gold).frame(width: 22, height: 22)
                Text("رفيق المؤمن").font(.system(size: 15, weight: .heavy)).foregroundStyle(Brand.gold)
                Spacer()
            }
            Text(title)
                .font(.system(size: 24, weight: .heavy))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity, alignment: .leading)
            Text(text)
                .font(Font.scripture(23))
                .lineSpacing(10)
                .foregroundStyle(.white)
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)
            if let source, !source.isEmpty {
                Text(source)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Brand.gold)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            Rectangle().fill(.white.opacity(0.18)).frame(height: 1)
            Text(AppLinks.storeURL == nil ? "تطبيق رفيق المؤمن · رفيقك إلى ربّك كلّ يوم" : AppLinks.signature)
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(.white.opacity(0.75))
                .frame(maxWidth: .infinity)
        }
        .padding(28)
        .frame(width: 400)
        .background(
            ZStack {
                Brand.heroGradient
                StarPattern().foregroundStyle(.white.opacity(0.06))
            }
        )
        .environment(\.layoutDirection, .rightToLeft)
    }
}

enum ShareCard {
    /// Cuts long texts at a clause boundary so the card stays readable.
    static func excerpt(_ t: String, limit: Int = 650) -> String {
        let s = t.replacingOccurrences(of: "\n", with: " ")
        if s.count <= limit { return s }
        let head = String(s.prefix(limit))
        let cut = ["،", ".", "؛", " "].compactMap { head.range(of: $0, options: .backwards)?.lowerBound }.max()
        return (cut.map { String(head[..<$0]) } ?? head) + " …"
    }

    @MainActor static func image(title: String, text: String, source: String?) -> UIImage? {
        let renderer = ImageRenderer(content: ShareCardView(title: title, text: excerpt(text), source: source))
        renderer.scale = 3
        return renderer.uiImage
    }

    /// Opens the system share sheet with the image card plus a short text line.
    @MainActor static func present(title: String, text: String, source: String?) {
        var items: [Any] = []
        if let img = image(title: title, text: text, source: source) { items.append(img) }
        items.append(title + "\n\n" + AppLinks.signature)
        let vc = UIActivityViewController(activityItems: items, applicationActivities: nil)
        guard let scene = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene })
                .first(where: { $0.activationState == .foregroundActive }),
              var top = scene.keyWindow?.rootViewController else { return }
        while let p = top.presentedViewController { top = p }
        vc.popoverPresentationController?.sourceView = top.view
        top.present(vc, animated: true)
    }
}
