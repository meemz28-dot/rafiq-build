import SwiftUI

// MARK: - Brand v2 "محراب": cream canvas, deep teal, warm gold
// Light: a warm cream canvas (#F5F2EA) with white cards, deep-teal ink and gold accents.
// Dark: night teal (#0E1D1B) with #182B29 cards and the same gold.
// Display titles are set in Reem Kufi, scripture in Amiri, UI text in the system Arabic face.

enum Brand {
    // MARK: Surfaces (dynamic light/dark)
    /// Screen background.
    static let canvas = dynamic(light: 0xF5F2EA, dark: 0x0E1D1B)
    /// Card fill on the canvas.
    static let cardFill = dynamic(light: 0xFFFFFF, dark: 0x182B29)
    /// Secondary fill (quick-row pills, soft chips).
    static let soft = dynamic(light: 0xE8EFEC, dark: 0x1F3634)
    /// Ring / progress track.
    static let track = dynamic(light: 0xEAE4D6, dark: 0x2A3F3C)
    /// Hairline separators.
    static let line = dynamic(light: 0xE6E0D2, dark: 0x27403C)

    // MARK: Ink
    static let ink = dynamic(light: 0x10322D, dark: 0xF3F1EA)
    static let muted = dynamic(light: 0x5D6F6B, dark: 0x9FB7B2)

    // MARK: Teal family
    static let deep = Color(hex: 0x1E5C54)
    static let deeper = Color(hex: 0x175A50)
    static let deepest = Color(hex: 0x123F3A)
    static let emerald = Color(hex: 0x2A8073)
    static let mint = Color(hex: 0x5FB3A6)
    static let mintLight = Color(hex: 0x9CD3C7)
    /// Tinted ink for links and selected states (brighter in the dark).
    static let accent = dynamic(light: 0x175A50, dark: 0x7FD1C2)

    // MARK: Gold family
    static let gold = Color(hex: 0xC99A3E)
    static let goldDeep = Color(hex: 0xB08433)
    static let goldSoft = Color(hex: 0xF2D592)
    static let goldPale = Color(hex: 0xF6E3B4)
    static let sand = Color(hex: 0xF3E2BE)

    // MARK: Paper (reader)
    static let paper = dynamic(light: 0xF7F0E1, dark: 0x141F1E)
    static let paperInk = dynamic(light: 0x1F2A28, dark: 0xECE6D6)

    // MARK: Night (player, tasbih, lock screen)
    static let night = Color(hex: 0x0E1D1B)
    static let nightCard = Color(hex: 0x182B29)

    // MARK: Semantic
    static let good = Color(hex: 0x2E8B6E)
    static let mid = Color(hex: 0xB07D2E)
    static let bad = Color(hex: 0xB9503F)

    // MARK: Gradients
    /// Deep teal card gradient (tonight card, hero surfaces).
    static var heroGradient: LinearGradient {
        LinearGradient(colors: [deepest, deep, Color(hex: 0x2D7468)], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
    /// Night screen gradient (player, lock screen).
    static var nightGradient: LinearGradient {
        LinearGradient(colors: [Color(hex: 0x0E2D3A), Color(hex: 0x164C47), Color(hex: 0x0B2421)], startPoint: .top, endPoint: .bottom)
    }
    /// Purple "continue" card gradient.
    static var purpleGradient: LinearGradient {
        LinearGradient(colors: [Color(hex: 0x3B2A5C), Color(hex: 0x5B3F78), Color(hex: 0x8C5E7E)], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
    /// Purple pair for "continue" surfaces.
    static let purpleColors: [Color] = [Color(hex: 0x3B2A5C), Color(hex: 0x8C5E7E)]
    /// Gold band gradient (Hajj tile, highlights).
    static var goldBand: LinearGradient {
        LinearGradient(colors: [sand, Color(hex: 0xE9CC8E)], startPoint: .leading, endPoint: .trailing)
    }
    /// Sky gradient for the Home header by time of day.
    static func skyGradient(hour: Double, dark: Bool) -> LinearGradient {
        if dark || hour < 5 || hour >= 19 {
            return LinearGradient(colors: [Color(hex: 0x0B2430), Color(hex: 0x123F3A), dark ? night : Color(hex: 0x0E1D1B)],
                                  startPoint: .top, endPoint: .bottom)
        }
        if hour < 7 || hour >= 17 { // dawn and dusk: warmer
            return LinearGradient(colors: [Color(hex: 0x4F9E95), Color(hex: 0xB9C9A8), Color(hex: 0xF3D9A8)], startPoint: .top, endPoint: .bottom)
        }
        return LinearGradient(colors: [mint, mintLight, sand], startPoint: .top, endPoint: .bottom)
    }

    /// Category accent pairs (four calm families: teal, gold, slate blue, purple).
    static func categoryColors(_ id: String) -> [Color] {
        let teal = [deep, Color(hex: 0x0F3B35)]
        let goldish = [Color(hex: 0xE9B872), Color(hex: 0xC47F3A)]
        let slate = [Color(hex: 0x6E8FB8), Color(hex: 0x3D5F8C)]
        let purple = [Color(hex: 0x5B3F78), Color(hex: 0x3B2A5C)]
        switch id {
        case "taqibat", "sahifa", "hajj", "hajat", "quran", "akhlaq", "kafi-dua", "mashhura": return teal
        case "sabah", "yawm", "hawaij", "hikam", "nahj", "ahadith", "khutab": return goldish
        case "jumaa", "munajat", "huquq", "ramadan", "rajab", "kafi-ishra": return slate
        case "ziyarat", "osboo", "nawafil", "salawat": return purple
        default: return [emerald, deeper]
        }
    }

    static func categorySymbol(_ id: String) -> String {
        switch id {
        case "taqibat": return "circle.dotted.circle"
        case "sabah": return "sunrise.fill"
        case "yawm", "osboo": return "clock.fill"
        case "jumaa", "nawafil", "hajj": return "building.columns.fill"
        case "mashhura": return "star.fill"
        case "munajat": return "drop.fill"
        case "sahifa", "nahj", "huquq", "hikam", "ahadith": return "scroll.fill"
        case "hawaij", "hajat", "salawat", "kafi-dua": return "hands.sparkles.fill"
        case "ramadan": return "moon.stars.fill"
        case "ziyarat": return "flag.fill"
        case "rajab": return "moon.fill"
        case "tarbiya", "akhlaq", "kafi-ishra": return "leaf.fill"
        case "quran", "kafi-quran", "khutab": return "book.fill"
        default: return "sparkles"
        }
    }

    private static func dynamic(light: UInt32, dark: UInt32) -> Color {
        Color(uiColor: UIColor { trait in
            trait.userInterfaceStyle == .dark ? UIColor(hex: dark) : UIColor(hex: light)
        })
    }
}

extension Color {
    init(hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xFF) / 255, green: Double((hex >> 8) & 0xFF) / 255, blue: Double(hex & 0xFF) / 255)
    }
}

extension UIColor {
    convenience init(hex: UInt32) {
        self.init(red: CGFloat((hex >> 16) & 0xFF) / 255, green: CGFloat((hex >> 8) & 0xFF) / 255, blue: CGFloat(hex & 0xFF) / 255, alpha: 1)
    }
}

// MARK: - Type

enum DisplayWeight { case medium, semibold, bold }

extension Font {
    /// Display face (Reem Kufi) for screen titles, big numbers and section headings.
    static func display(_ size: CGFloat, _ weight: DisplayWeight = .bold) -> Font {
        switch weight {
        case .medium: return .custom("ReemKufi-Medium", size: size)
        case .semibold: return .custom("ReemKufi-SemiBold", size: size)
        case .bold: return .custom("ReemKufi-Bold", size: size)
        }
    }
    /// Scripture face (Amiri) for Quran, duas and ziyarat.
    static func scripture(_ size: CGFloat) -> Font { .custom("Amiri", size: size) }
    /// Large counter digits (Reem Kufi, Arabic-Indic digits render natively).
    static func counter(_ size: CGFloat) -> Font { .custom("ReemKufi-Bold", size: size) }
}

// MARK: - Liquid Glass helpers (iOS 26 APIs, graceful fallbacks)

@available(iOS 26.0, *)
func rafiqGlass(tint: Color?, interactive: Bool) -> Glass {
    var g = Glass.regular
    if let tint { g = g.tint(tint) }
    if interactive { g = g.interactive() }
    return g
}

extension View {
    /// Keeps content at a comfortable reading width on iPad (no effect on iPhone).
    func readableWidth(_ max: CGFloat = 820) -> some View {
        self.frame(maxWidth: max).frame(maxWidth: .infinity)
    }

    /// Full-screen night surface: gradient, girih pattern, and dark-variant glass for legible white text.
    func tealScreen() -> some View {
        self.background(
            ZStack {
                Brand.nightGradient
                GirihPattern().foregroundStyle(.white.opacity(0.05))
            }
            .ignoresSafeArea()
        )
        .environment(\.colorScheme, .dark)
    }

    /// A glass surface for floating controls and cards that sit over rich backgrounds.
    @ViewBuilder func glass(_ radius: CGFloat = 22, tint: Color? = nil, interactive: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(rafiqGlass(tint: tint, interactive: interactive), in: .rect(cornerRadius: radius))
        } else {
            self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous).fill((tint ?? .clear).opacity(0.18)))
        }
    }

    /// Capsule-shaped glass (chips, pills, toolbars).
    @ViewBuilder func glassCapsule(tint: Color? = nil, interactive: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(rafiqGlass(tint: tint, interactive: interactive), in: .capsule)
        } else {
            self.background(.ultraThinMaterial, in: Capsule())
                .overlay(Capsule().fill((tint ?? .clear).opacity(0.18)))
        }
    }

    /// Circular glass (round buttons, counters).
    @ViewBuilder func glassCircle(tint: Color? = nil, interactive: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(rafiqGlass(tint: tint, interactive: interactive), in: .circle)
        } else {
            self.background(.ultraThinMaterial, in: Circle())
                .overlay(Circle().fill((tint ?? .clear).opacity(0.18)))
        }
    }

    /// Native glass button style on iOS 26 (prominent = tinted), bordered styles before.
    @ViewBuilder func glassButton(prominent: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            if prominent { self.buttonStyle(.glassProminent) } else { self.buttonStyle(.glass) }
        } else {
            if prominent { self.buttonStyle(.borderedProminent) } else { self.buttonStyle(.bordered) }
        }
    }

    /// Lets the native tab bar shrink while scrolling (iOS 26).
    @ViewBuilder func minimizeTabBarOnScroll() -> some View {
        if #available(iOS 26.0, *) { self.tabBarMinimizeBehavior(.onScrollDown) } else { self }
    }

    /// Plain content card on the canvas (white in the light, #182B29 in the dark).
    func card(_ radius: CGFloat = 22, padding: CGFloat = 16) -> some View {
        self.padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
    }

    /// Card with the soft canvas shadow used for floating panels.
    func floatingCard(_ radius: CGFloat = 26, padding: CGFloat = 14) -> some View {
        self.padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .shadow(color: Color(hex: 0x10322D).opacity(0.14), radius: 16, y: 8)
    }

    /// Deep teal patterned hero surface, the base that glass controls float over.
    func hero(_ radius: CGFloat = 28) -> some View {
        self.background(
            ZStack {
                Brand.heroGradient
                GirihPattern().foregroundStyle(.white.opacity(0.07))
            }
            .clipShape(RoundedRectangle(cornerRadius: radius, style: .continuous))
        )
        .foregroundStyle(.white)
        // Glass over teal must use its dark variant, or white text washes out.
        .environment(\.colorScheme, .dark)
    }

    /// Keeps the screen awake while visible when the user enabled it.
    func keepScreenAwake(_ on: Bool) -> some View {
        self.onAppear { UIApplication.shared.isIdleTimerDisabled = on }
            .onDisappear { UIApplication.shared.isIdleTimerDisabled = false }
    }

    /// Hides the default navigation title and uses the canvas background (v2 screens draw their own titles).
    func canvasScreen() -> some View {
        self.background(Brand.canvas.ignoresSafeArea())
            .toolbarBackground(.hidden, for: .navigationBar)
    }
}

// MARK: - Signature pattern: girih (eight-point stars with rotated squares)

struct GirihPattern: View {
    var cell: CGFloat = 56
    var body: some View {
        Canvas { ctx, size in
            let cols = Int(size.width / cell) + 2, rows = Int(size.height / cell) + 2
            for r in 0..<rows {
                for c in 0..<cols {
                    let cx = CGFloat(c) * cell + cell / 2
                    let cy = CGFloat(r) * cell + cell / 2
                    let star = StarShape().path(in: CGRect(x: cx - cell * 0.43, y: cy - cell * 0.43, width: cell * 0.86, height: cell * 0.86))
                    ctx.stroke(star, with: .foreground, lineWidth: 1.2)
                    var sq = Path(CGRect(x: cx - cell * 0.18, y: cy - cell * 0.18, width: cell * 0.36, height: cell * 0.36))
                    sq = sq.applying(CGAffineTransform(translationX: cx, y: cy).rotated(by: .pi / 4).translatedBy(x: -cx, y: -cy))
                    ctx.stroke(sq, with: .foreground, lineWidth: 0.9)
                }
            }
        }
        .allowsHitTesting(false)
    }
}

/// Backwards-compatible name used by older screens.
typealias StarPattern = GirihPattern

/// Eight-point star (two overlapping squares), the app's mark.
struct StarShape: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let c = CGPoint(x: rect.midX, y: rect.midY), r = min(rect.width, rect.height) / 2, ri = r * 0.414
        for i in 0..<16 {
            let a = Double(i) * .pi / 8 - .pi / 2
            let rr = i % 2 == 0 ? r : ri / cos(CGFloat.pi / 8) * 0.92
            let pt = CGPoint(x: c.x + CGFloat(cos(a)) * rr, y: c.y + CGFloat(sin(a)) * rr)
            if i == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
        }
        p.closeSubpath()
        return p
    }
}

// MARK: - Skyline shapes

/// Mosque skyline: a central dome with a minaret, drawn in a 390×182 design box and scaled to the rect.
struct MosqueSilhouette: Shape {
    func path(in rect: CGRect) -> Path {
        let sx = rect.width / 390, sy = rect.height / 182
        func P(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: rect.minX + x * sx, y: rect.minY + y * sy) }
        var p = Path()
        p.move(to: P(0, 122))
        p.addCurve(to: P(120, 82), control1: P(60, 92), control2: P(90, 102))
        p.addLine(to: P(120, 62))
        p.addQuadCurve(to: P(150, 62), control: P(135, 32))
        p.addLine(to: P(150, 82))
        p.addCurve(to: P(205, 62), control1: P(175, 78), control2: P(190, 80))
        p.addQuadCurve(to: P(235, 14), control: P(205, 24))
        p.addQuadCurve(to: P(265, 62), control: P(265, 24))
        p.addCurve(to: P(390, 102), control1: P(285, 80), control2: P(320, 92))
        p.addLine(to: P(390, 182))
        p.addLine(to: P(0, 182))
        p.closeSubpath()
        // finial
        p.move(to: P(234, 0)); p.addLine(to: P(236, 12)); p.addLine(to: P(232, 12)); p.closeSubpath()
        return p
    }
}

/// Small skyline for cards: minaret on the left, low dome, in a 358×60 design box.
struct CardSkyline: Shape {
    func path(in rect: CGRect) -> Path {
        let sx = rect.width / 358, sy = rect.height / 60
        func P(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: rect.minX + x * sx, y: rect.minY + y * sy) }
        var p = Path()
        p.move(to: P(0, 60))
        p.addLine(to: P(0, 20))
        p.addQuadCurve(to: P(60, 20), control: P(30, 0))
        p.addLine(to: P(60, 0))
        p.addQuadCurve(to: P(100, 0), control: P(80, -50))
        p.addLine(to: P(100, 20))
        p.addQuadCurve(to: P(160, 26), control: P(130, 8))
        p.addLine(to: P(358, 40))
        p.addLine(to: P(358, 60))
        p.closeSubpath()
        return p
    }
}

/// Crescent moon (gold disc with a bite), drawn with a mask so it sits on any background.
struct CrescentMoon: View {
    var size: CGFloat = 44
    var color: Color = Brand.goldPale
    var body: some View {
        Circle()
            .fill(color)
            .frame(width: size, height: size)
            .mask(
                ZStack {
                    Rectangle()
                    Circle()
                        .frame(width: size * 0.9, height: size * 0.9)
                        .offset(x: size * 0.28, y: -size * 0.16)
                        .blendMode(.destinationOut)
                }
                .compositingGroup()
            )
            .accessibilityHidden(true)
    }
}

/// Faint star field for night surfaces.
struct StarField: View {
    var count: Int = 18
    var body: some View {
        Canvas { ctx, size in
            var g = SplitMix(seed: 7)
            for _ in 0..<count {
                let x = g.next() * size.width, y = g.next() * size.height * 0.6
                let r = 0.8 + g.next() * 1.2
                ctx.fill(Path(ellipseIn: CGRect(x: x, y: y, width: r * 2, height: r * 2)), with: .color(.white.opacity(0.35 + g.next() * 0.45)))
            }
        }
        .allowsHitTesting(false)
    }
}

/// Tiny deterministic generator so star fields stay put between redraws.
struct SplitMix {
    var state: UInt64
    init(seed: UInt64) { state = seed &* 0x9E3779B97F4A7C15 }
    mutating func next() -> CGFloat {
        state &+= 0x9E3779B97F4A7C15
        var z = state
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        z ^= z >> 31
        return CGFloat(z % 10_000) / 10_000
    }
}

// MARK: - Shared components

/// Progress ring (track + arc) with optional content in the middle.
struct RingProgress<Content: View>: View {
    var fraction: Double
    var size: CGFloat = 46
    var lineWidth: CGFloat = 5
    var color: Color = Brand.emerald
    @ViewBuilder var content: () -> Content

    init(fraction: Double, size: CGFloat = 46, lineWidth: CGFloat = 5, color: Color = Brand.emerald, @ViewBuilder content: @escaping () -> Content) {
        self.fraction = fraction; self.size = size; self.lineWidth = lineWidth; self.color = color; self.content = content
    }

    var body: some View {
        ZStack {
            Circle().stroke(Brand.track, lineWidth: lineWidth)
            Circle()
                .trim(from: 0, to: max(0, min(1, fraction)))
                .stroke(color, style: StrokeStyle(lineWidth: lineWidth, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .animation(.easeOut(duration: 0.35), value: fraction)
            content()
        }
        .frame(width: size, height: size)
    }
}

extension RingProgress where Content == EmptyView {
    init(fraction: Double, size: CGFloat = 46, lineWidth: CGFloat = 5, color: Color = Brand.emerald) {
        self.init(fraction: fraction, size: size, lineWidth: lineWidth, color: color) { EmptyView() }
    }
}

/// Selectable filter chip (filled when selected).
struct Chip: View {
    let text: String
    var selected: Bool = false
    var body: some View {
        Text(text)
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(selected ? Color.white : Brand.ink)
            .padding(.horizontal, 16).padding(.vertical, 9)
            .background(selected ? Brand.deeper : Brand.cardFill, in: Capsule())
    }
}

/// Section heading in the display face with an optional trailing note or action.
struct SectionHeading<Trailing: View>: View {
    let title: String
    @ViewBuilder var trailing: () -> Trailing
    init(_ title: String, @ViewBuilder trailing: @escaping () -> Trailing) { self.title = title; self.trailing = trailing }
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.display(18)).foregroundStyle(Brand.ink)
            Spacer()
            trailing().font(.caption.weight(.semibold)).foregroundStyle(Brand.accent)
        }
        .padding(.top, 6)
    }
}

extension SectionHeading where Trailing == EmptyView {
    init(_ title: String) { self.init(title) { EmptyView() } }
}

/// Round 42-pt icon button for screen headers (white disc on the canvas, translucent over imagery).
struct RoundIconButton: View {
    let symbol: String
    var label: String
    var translucent: Bool = false
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(translucent ? Color.white : Brand.ink)
                .frame(width: 42, height: 42)
                .background(translucent ? Color.white.opacity(0.14) : Brand.cardFill, in: Circle())
                .overlay(Circle().stroke(translucent ? Color.white.opacity(0.25) : .clear, lineWidth: 1))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

/// Pill button in the soft tint (quick row).
struct SoftPill: View {
    let symbol: String
    let title: String
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                Image(systemName: symbol).font(.system(size: 15, weight: .semibold))
                Text(title).font(.subheadline.weight(.semibold))
            }
            .foregroundStyle(Brand.accent)
            .frame(maxWidth: .infinity, minHeight: 50)
            .background(Brand.soft, in: Capsule())
        }
        .buttonStyle(.plain)
    }
}

/// Primary gold capsule button on dark surfaces.
struct GoldButton: View {
    let title: String
    var symbol: String? = nil
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if let symbol { Image(systemName: symbol).font(.system(size: 14, weight: .bold)) }
                Text(title).font(.subheadline.weight(.bold))
            }
            .foregroundStyle(Color(hex: 0x10322D))
            .padding(.horizontal, 22)
            .frame(height: 46)
            .background(Brand.goldSoft, in: Capsule())
        }
        .buttonStyle(.plain)
    }
}

/// Outline capsule button on dark surfaces.
struct GhostButton: View {
    let title: String
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title).font(.subheadline.weight(.semibold))
                .foregroundStyle(.white)
                .padding(.horizontal, 18)
                .frame(height: 46)
                .background(Color.white.opacity(0.12), in: Capsule())
                .overlay(Capsule().stroke(Color.white.opacity(0.35), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

/// Gradient icon chip with an SF Symbol (white glyph).
struct IconChip: View {
    let symbol: String
    var colors: [Color] = [Brand.emerald, Brand.deeper]
    var size: CGFloat = 44
    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: size * 0.44, weight: .semibold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing),
                        in: RoundedRectangle(cornerRadius: size * 0.3, style: .continuous))
    }
}

/// Flat tint icon (teal glyph on the soft tint), the v2 tool-tile glyph.
struct TintIcon: View {
    let symbol: String
    var size: CGFloat = 40
    var color: Color = Brand.accent
    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: size * 0.5, weight: .semibold))
            .foregroundStyle(color)
            .frame(width: size, height: size)
    }
}

/// White tool tile (icon + label), as in the tools grid.
struct ToolTile: View {
    let symbol: String
    let title: String
    var colors: [Color] = [Brand.emerald, Brand.deeper]
    var body: some View {
        VStack(spacing: 8) {
            TintIcon(symbol: symbol, size: 36)
            Text(title).font(.footnote.weight(.semibold)).multilineTextAlignment(.center).lineLimit(2)
                .foregroundStyle(Brand.ink)
        }
        .frame(maxWidth: .infinity, minHeight: 92)
        .padding(.horizontal, 6)
        .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

/// Section title (display face).
struct SectionTitle: View {
    let text: String
    var body: some View {
        Text(text).font(.display(18)).foregroundStyle(Brand.ink).frame(maxWidth: .infinity, alignment: .leading).padding(.top, 8)
    }
}

/// Capsule tag.
struct Tag: View {
    let text: String
    var color: Color = Brand.emerald
    var body: some View {
        Text(text).font(.caption.weight(.bold)).foregroundStyle(color)
            .padding(.horizontal, 10).padding(.vertical, 4)
            .background(color.opacity(0.12), in: Capsule())
    }
}

/// Gold outline tag on dark surfaces ("الليلة · ليلة الجمعة").
struct GoldTag: View {
    let text: String
    var body: some View {
        Text(text).font(.caption.weight(.semibold)).foregroundStyle(Brand.goldSoft)
            .padding(.horizontal, 10).padding(.vertical, 4)
            .background(Brand.goldSoft.opacity(0.14), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(Brand.goldSoft.opacity(0.35), lineWidth: 1))
    }
}

/// Gold ornament divider with a diamond, used above display titles.
struct OrnamentDivider: View {
    var color: Color = Brand.gold
    var body: some View {
        HStack(spacing: 8) {
            Rectangle().fill(color.opacity(0.5)).frame(height: 1)
            Image(systemName: "diamond.fill").font(.system(size: 9)).foregroundStyle(color)
            Rectangle().fill(color.opacity(0.5)).frame(height: 1)
        }
        .frame(maxWidth: 240)
        .accessibilityHidden(true)
    }
}

/// Empty state.
struct EmptyStateView: View {
    let symbol: String; let title: String; let message: String
    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: symbol).font(.system(size: 36)).foregroundStyle(Brand.muted)
            Text(title).font(.headline).foregroundStyle(Brand.ink)
            Text(message).font(.subheadline).foregroundStyle(Brand.muted).multilineTextAlignment(.center)
        }.frame(maxWidth: .infinity).padding(32)
    }
}

/// Scrollable screen body on the canvas, with consistent margins.
struct ScreenScroll<Content: View>: View {
    var topPadding: CGFloat = 4
    @ViewBuilder var content: () -> Content
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) { content() }
                .padding(.horizontal, 16).padding(.bottom, 28).padding(.top, topPadding)
                .readableWidth()
        }
        // Native feel: bounce only when there is more to scroll, swipe the keyboard away.
        .scrollBounceBehavior(.basedOnSize)
        .scrollDismissesKeyboard(.interactively)
        .background(Brand.canvas)
    }
}

/// Screen header in the v2 style: display title on the leading side, round action buttons on the trailing side.
struct ScreenHeader<Actions: View>: View {
    let title: String
    var subtitle: String? = nil
    @ViewBuilder var actions: () -> Actions
    init(_ title: String, subtitle: String? = nil, @ViewBuilder actions: @escaping () -> Actions) {
        self.title = title; self.subtitle = subtitle; self.actions = actions
    }
    var body: some View {
        HStack(alignment: .center, spacing: 8) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.display(32)).foregroundStyle(Brand.ink).lineLimit(1).minimumScaleFactor(0.7)
                if let subtitle { Text(subtitle).font(.footnote).foregroundStyle(Brand.muted) }
            }
            Spacer()
            actions()
        }
        .padding(.top, 8)
    }
}

extension ScreenHeader where Actions == EmptyView {
    init(_ title: String, subtitle: String? = nil) { self.init(title, subtitle: subtitle) { EmptyView() } }
}

/// Haptics.
enum Haptic {
    static func tick() { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
    static func confirm() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
    static func heavy() { UIImpactFeedbackGenerator(style: .heavy).impactOccurred() }
}
