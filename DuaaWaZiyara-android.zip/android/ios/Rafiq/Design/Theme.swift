import SwiftUI

// MARK: - Brand "محراب" for iOS
// Deep teal-green surfaces with a faint eight-point-star pattern, warm amber-gold accents for highlights and counters,
// and Apple Liquid Glass for every control that floats above content (iOS 26+, with material fallbacks).

enum Brand {
    static let deep = Color(red: 0x1F / 255, green: 0x6B / 255, blue: 0x5F / 255)      // #1F6B5F hero surfaces
    static let deeper = Color(red: 0x17 / 255, green: 0x5A / 255, blue: 0x50 / 255)    // #175A50
    static let emerald = Color(red: 0x24 / 255, green: 0x7A / 255, blue: 0x6D / 255)   // #247A6D app tint
    static let mint = Color(red: 0x4D / 255, green: 0xB3 / 255, blue: 0x9F / 255)      // #4DB39F
    static let gold = Color(red: 0xE3 / 255, green: 0xA3 / 255, blue: 0x3B / 255)      // #E3A33B highlights, counters
    static let goldDeep = Color(red: 0xB0 / 255, green: 0x84 / 255, blue: 0x33 / 255)  // #B08433
    static let good = Color(red: 0x2E / 255, green: 0x8B / 255, blue: 0x6E / 255)
    static let mid = Color(red: 0xB0 / 255, green: 0x7D / 255, blue: 0x2E / 255)
    static let bad = Color(red: 0xB9 / 255, green: 0x50 / 255, blue: 0x3F / 255)
    static let paper = Color(red: 0xFB / 255, green: 0xF6 / 255, blue: 0xE9 / 255)     // Mushaf page

    static var heroGradient: LinearGradient {
        LinearGradient(colors: [Color(red: 0x2A / 255, green: 0x80 / 255, blue: 0x73 / 255), deep, deeper],
                       startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    /// Category accent pairs (four calm families).
    static func categoryColors(_ id: String) -> [Color] {
        let e1 = [Color(red: 0.17, green: 0.53, blue: 0.47), Color(red: 0.29, green: 0.66, blue: 0.59)]
        let e2 = [Color(red: 0.15, green: 0.45, blue: 0.50), Color(red: 0.27, green: 0.60, blue: 0.65)]
        let g = [Color(red: 0.72, green: 0.52, blue: 0.20), Color(red: 0.92, green: 0.70, blue: 0.32)]
        let n = [Color(red: 0.22, green: 0.40, blue: 0.47), Color(red: 0.35, green: 0.54, blue: 0.61)]
        switch id {
        case "taqibat", "sahifa", "hajj", "hajat", "quran", "akhlaq", "kafi-dua": return e1
        case "sabah", "yawm", "hawaij", "hikam", "nahj", "ahadith", "khutab": return g
        case "jumaa", "munajat", "huquq", "ramadan", "rajab", "kafi-ishra": return n
        default: return e2
        }
    }

    static func categorySymbol(_ id: String) -> String {
        switch id {
        case "taqibat": return "circle.dotted.circle"
        case "sabah": return "sunrise.fill"
        case "yawm", "osboo": return "clock.fill"
        case "jumaa", "nawafil", "hajj": return "building.columns.fill"
        case "mashhura": return "star.fill"
        case "munajat": return "drop.fill"
        case "sahifa", "nahj", "huquq", "hikam", "ahadith": return "scroll.fill"
        case "hawaij", "hajat", "salawat", "kafi-dua": return "hands.sparkles.fill"
        case "ramadan": return "moon.stars.fill"
        case "ziyarat": return "flag.fill"
        case "rajab": return "moon.fill"
        case "tarbiya", "akhlaq", "kafi-ishra": return "leaf.fill"
        case "quran", "kafi-quran", "khutab": return "book.fill"
        default: return "sparkles"
        }
    }
}

extension Font {
    /// Scripture face (Amiri) for Quran, duas and ziyarat.
    static func scripture(_ size: CGFloat) -> Font { .custom("Amiri", size: size) }
    /// Large tabular counter digits.
    static func counter(_ size: CGFloat) -> Font { .system(size: size, weight: .heavy, design: .rounded).monospacedDigit() }
}

// MARK: - Liquid Glass helpers (iOS 26 APIs, graceful fallbacks)

@available(iOS 26.0, *)
func rafiqGlass(tint: Color?, interactive: Bool) -> Glass {
    var g = Glass.regular
    if let tint { g = g.tint(tint) }
    if interactive { g = g.interactive() }
    return g
}

extension View {
    /// Keeps content at a comfortable reading width on iPad (no effect on iPhone).
    func readableWidth(_ max: CGFloat = 820) -> some View {
        self.frame(maxWidth: max).frame(maxWidth: .infinity)
    }

    /// Full-screen teal surface: gradient, star pattern, and dark-variant glass for legible white text.
    func tealScreen() -> some View {
        self.background(
            ZStack {
                Brand.heroGradient
                StarPattern().foregroundStyle(.white.opacity(0.06))
            }
            .ignoresSafeArea()
        )
        .environment(\.colorScheme, .dark)
    }

    /// A glass surface for floating controls and cards that sit over rich backgrounds.
    @ViewBuilder func glass(_ radius: CGFloat = 22, tint: Color? = nil, interactive: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(rafiqGlass(tint: tint, interactive: interactive), in: .rect(cornerRadius: radius))
        } else {
            self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous).fill((tint ?? .clear).opacity(0.18)))
        }
    }

    /// Capsule-shaped glass (chips, pills, toolbars).
    @ViewBuilder func glassCapsule(tint: Color? = nil, interactive: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(rafiqGlass(tint: tint, interactive: interactive), in: .capsule)
        } else {
            self.background(.ultraThinMaterial, in: Capsule())
                .overlay(Capsule().fill((tint ?? .clear).opacity(0.18)))
        }
    }

    /// Circular glass (round buttons, counters).
    @ViewBuilder func glassCircle(tint: Color? = nil, interactive: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(rafiqGlass(tint: tint, interactive: interactive), in: .circle)
        } else {
            self.background(.ultraThinMaterial, in: Circle())
                .overlay(Circle().fill((tint ?? .clear).opacity(0.18)))
        }
    }

    /// Native glass button style on iOS 26 (prominent = tinted), bordered styles before.
    @ViewBuilder func glassButton(prominent: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            if prominent { self.buttonStyle(.glassProminent) } else { self.buttonStyle(.glass) }
        } else {
            if prominent { self.buttonStyle(.borderedProminent) } else { self.buttonStyle(.bordered) }
        }
    }

    /// Lets the native tab bar shrink while scrolling (iOS 26).
    @ViewBuilder func minimizeTabBarOnScroll() -> some View {
        if #available(iOS 26.0, *) { self.tabBarMinimizeBehavior(.onScrollDown) } else { self }
    }

    /// Plain content card on the grouped background (content layer, not glass).
    func card(_ radius: CGFloat = 22, padding: CGFloat = 16) -> some View {
        self.padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: radius, style: .continuous))
    }

    /// Dark patterned hero surface (JazakAllah-style), the base that glass controls float over.
    func hero(_ radius: CGFloat = 28) -> some View {
        self.background(
            ZStack {
                Brand.heroGradient
                StarPattern().foregroundStyle(.white.opacity(0.06))
            }
            .clipShape(RoundedRectangle(cornerRadius: radius, style: .continuous))
        )
        .foregroundStyle(.white)
        // Glass over teal must use its dark variant, or white text washes out.
        .environment(\.colorScheme, .dark)
    }

    /// Keeps the screen awake while visible when the user enabled it.
    func keepScreenAwake(_ on: Bool) -> some View {
        self.onAppear { UIApplication.shared.isIdleTimerDisabled = on }
            .onDisappear { UIApplication.shared.isIdleTimerDisabled = false }
    }
}

// MARK: - Signature pattern: tiled eight-point stars

struct StarPattern: View {
    var cell: CGFloat = 56
    var body: some View {
        Canvas { ctx, size in
            let cols = Int(size.width / cell) + 2, rows = Int(size.height / cell) + 2
            for r in 0..<rows {
                for c in 0..<cols {
                    let cx = CGFloat(c) * cell + (r % 2 == 0 ? 0 : cell / 2)
                    let cy = CGFloat(r) * cell
                    ctx.stroke(StarShape().path(in: CGRect(x: cx - cell * 0.32, y: cy - cell * 0.32, width: cell * 0.64, height: cell * 0.64)),
                               with: .foreground, lineWidth: 1)
                }
            }
        }
        .allowsHitTesting(false)
    }
}

/// Eight-point star (two overlapping squares), the app's mark.
struct StarShape: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let c = CGPoint(x: rect.midX, y: rect.midY), r = min(rect.width, rect.height) / 2, ri = r * 0.414
        for i in 0..<16 {
            let a = Double(i) * .pi / 8 - .pi / 2
            let rr = i % 2 == 0 ? r : ri / cos(.pi / 8) * 0.92
            let pt = CGPoint(x: c.x + CGFloat(cos(a)) * rr, y: c.y + CGFloat(sin(a)) * rr)
            if i == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
        }
        p.closeSubpath()
        return p
    }
}

// MARK: - Shared components

/// Gradient icon chip with an SF Symbol (white glyph).
struct IconChip: View {
    let symbol: String
    var colors: [Color] = [Brand.emerald, Brand.mint]
    var size: CGFloat = 44
    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: size * 0.44, weight: .semibold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing),
                        in: RoundedRectangle(cornerRadius: size * 0.3, style: .continuous))
    }
}

/// White tool tile (icon + label), as in the menu grid.
struct ToolTile: View {
    let symbol: String
    let title: String
    var colors: [Color] = [Brand.emerald, Brand.mint]
    var body: some View {
        VStack(spacing: 8) {
            IconChip(symbol: symbol, colors: colors, size: 46)
            Text(title).font(.footnote.weight(.semibold)).multilineTextAlignment(.center).lineLimit(2)
                .foregroundStyle(.primary)
        }
        .frame(maxWidth: .infinity, minHeight: 104)
        .padding(.horizontal, 6)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

/// Section title in the native grouped style.
struct SectionTitle: View {
    let text: String
    var body: some View {
        Text(text).font(.title3.weight(.bold)).frame(maxWidth: .infinity, alignment: .leading).padding(.top, 8)
    }
}

/// Capsule tag.
struct Tag: View {
    let text: String
    var color: Color = Brand.emerald
    var body: some View {
        Text(text).font(.caption.weight(.bold)).foregroundStyle(color)
            .padding(.horizontal, 10).padding(.vertical, 4)
            .background(color.opacity(0.12), in: Capsule())
    }
}

/// Empty state.
struct EmptyStateView: View {
    let symbol: String; let title: String; let message: String
    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: symbol).font(.system(size: 36)).foregroundStyle(.secondary)
            Text(title).font(.headline)
            Text(message).font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }.frame(maxWidth: .infinity).padding(32)
    }
}

/// Scrollable screen body on the grouped background, with consistent margins.
struct ScreenScroll<Content: View>: View {
    @ViewBuilder var content: () -> Content
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) { content() }
                .padding(.horizontal, 16).padding(.bottom, 28).padding(.top, 4)
                .readableWidth()
        }
        .background(Color(.systemGroupedBackground))
    }
}

/// Haptics.
enum Haptic {
    static func tick() { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
    static func confirm() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
    static func heavy() { UIImpactFeedbackGenerator(style: .heavy).impactOccurred() }
}
