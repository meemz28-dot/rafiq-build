import Foundation
import ActivityKit

/// Starts, refreshes and stops the next-prayer Live Activity.
/// Without a push server it cannot advance itself, so it is re-armed for the following prayer
/// every time the app becomes active (and it shows "حان الوقت" once due).
enum PrayerLive {
    static var supported: Bool { ActivityAuthorizationInfo().areActivitiesEnabled }

    static func start(store: Store) {
        guard supported else { return }
        let t = store.times()
        let nowH = PrayerTimes.nowHours()
        let nx = PrayerTimes.next(t, nowHours: nowH)
        let target = Date().addingTimeInterval(nx.hours * 3600)
        var sinceH = 24.0
        for k in PrayerTimes.prayerKeys {
            var dt = nowH - PrayerTimes.norm(PrayerTimes.value(t, k))
            if dt < 0 { dt += 24 }
            sinceH = min(sinceH, dt)
        }
        var afterH = nowH + nx.hours + 0.02
        if afterH >= 24 { afterH -= 24 }
        let af = PrayerTimes.next(t, nowHours: afterH)
        let state = PrayerActivityAttributes.ContentState(prayer: PrayerTimes.name(nx.key),
                                                          time: PrayerTimes.fmt(PrayerTimes.value(t, nx.key)),
                                                          target: target,
                                                          since: Date().addingTimeInterval(-sinceH * 3600),
                                                          after: "\(PrayerTimes.name(af.key)) \(PrayerTimes.fmt(PrayerTimes.value(t, af.key)))")
        let content = ActivityContent(state: state, staleDate: target.addingTimeInterval(20 * 60))
        Task {
            for a in Activity<PrayerActivityAttributes>.activities { await a.end(nil, dismissalPolicy: .immediate) }
            _ = try? Activity.request(attributes: PrayerActivityAttributes(city: store.location().n), content: content, pushType: nil)
        }
    }

    static func stop() {
        Task {
            for a in Activity<PrayerActivityAttributes>.activities { await a.end(nil, dismissalPolicy: .immediate) }
        }
    }

    /// Called when the app becomes active.
    static func refresh(store: Store) {
        if store.bool("liveActivity", false) { start(store: store) }
    }
}
