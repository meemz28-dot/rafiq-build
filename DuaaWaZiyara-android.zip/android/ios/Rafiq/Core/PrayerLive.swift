import Foundation
import ActivityKit

/// Starts, refreshes and stops the next-prayer Live Activity.
/// Without a push server it cannot advance itself, so it is re-armed for the following prayer
/// every time the app becomes active (and it shows "حان الوقت" once due).
enum PrayerLive {
    static var supported: Bool { ActivityAuthorizationInfo().areActivitiesEnabled }

    static func start(store: Store) {
        guard supported else { return }
        let t = store.times()
        let nx = PrayerTimes.next(t, nowHours: PrayerTimes.nowHours())
        let target = Date().addingTimeInterval(nx.hours * 3600)
        let state = PrayerActivityAttributes.ContentState(prayer: PrayerTimes.name(nx.key),
                                                          time: PrayerTimes.fmt(PrayerTimes.value(t, nx.key)),
                                                          target: target)
        let content = ActivityContent(state: state, staleDate: target.addingTimeInterval(20 * 60))
        Task {
            for a in Activity<PrayerActivityAttributes>.activities { await a.end(nil, dismissalPolicy: .immediate) }
            _ = try? Activity.request(attributes: PrayerActivityAttributes(city: store.location().n), content: content, pushType: nil)
        }
    }

    static func stop() {
        Task {
            for a in Activity<PrayerActivityAttributes>.activities { await a.end(nil, dismissalPolicy: .immediate) }
        }
    }

    /// Called when the app becomes active.
    static func refresh(store: Store) {
        if store.bool("liveActivity", false) { start(store: store) }
    }
}
