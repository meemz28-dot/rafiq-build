import Foundation

// MARK: - Content (exported from the Android data package by ios/tools/export_json.sh)

struct DuaaItem: Codable, Identifiable, Hashable {
    let id: String
    let title: String
    let src: String?
    let intro: String?
    let text: String
}

struct DuaaCategory: Codable, Identifiable, Hashable {
    let id: String
    let icon: String
    let name: String
    let desc: String
    let items: [DuaaItem]
}

struct KhiraStep: Codable, Hashable { let title: String; let desc: String }
struct Occasion: Codable, Hashable { let m: Int; let d: Int; let t: String; let k: String }
struct City: Codable, Hashable { let n: String; let lat: Double; let lng: Double; let tz: Double }
struct Work: Codable, Hashable { let m: Int; let d: Int; let title: String; let body: String }
struct Dhikr: Codable, Hashable { let text: String; let src: String }
struct Hikma: Codable, Hashable { let text: String; let who: String }
struct AsmaName: Codable, Hashable { let ar: String; let sharh: String }
struct Masoom: Codable, Hashable {
    let name: String; let title: String; let kunya: String; let birth: String; let passing: String
    let shrine: String; let rank: String; let era: String; let highlights: [String]; let note: String
}
struct Trait: Codable, Hashable {
    let id: String; let vice: String; let virtue: String; let clinicId: String; let commitment: String; let hint: String
}
struct HajjStep: Codable, Hashable, Identifiable {
    let id: String; let title: String; let place: String; let desc: String
    let counter: Int; let kind: String; let ruling: String
}
struct HajjTopic: Codable, Hashable { let title: String; let note: String }
struct HajjData: Codable { let umrah: [HajjStep]; let hajj: [HajjStep]; let tawafDuas: [String]; let preliminaries: [HajjTopic] }
struct KhiraData: Codable {
    let verdict: String; let themeA: String; let themeB: String; let labels: [String: String]
    let pageStart: [Int]; let pageVerdict: String; let pageThemeA: String; let pageThemeB: String
}
struct JuzData: Codable { let sura: [Int]; let aya: [Int] }

struct Content: Codable {
    let categories: [DuaaCategory]
    let khiraSteps: [KhiraStep]
    let occasions: [Occasion]
    let cities: [City]
    let works: [Work]
    let adhkar: [Dhikr]
    let hikam: [Hikma]
    let asma: [AsmaName]
    let masoomeen: [Masoom]
    let traits: [Trait]
    let khira: KhiraData
    let hajj: HajjData
    let juz: JuzData
}

/// The whole verified library, loaded once from the bundle.
enum Library {
    static let shared: Content = {
        guard let url = Bundle.main.url(forResource: "content", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let c = try? JSONDecoder().decode(Content.self, from: data) else {
            fatalError("content.json missing or malformed")
        }
        return c
    }()

    static var categories: [DuaaCategory] { shared.categories }
    static func category(_ id: String) -> DuaaCategory? { shared.categories.first { $0.id == id } }
    static func item(_ catId: String, _ itemId: String) -> DuaaItem? { category(catId)?.items.first { $0.id == itemId } }
    static func occasions(m: Int, d: Int) -> [Occasion] { shared.occasions.filter { $0.m == m && $0.d == d } }
    /// Calendar works for a Hijri day (includes month-wide works with d == 0).
    static func works(m: Int, d: Int) -> [Work] { shared.works.filter { $0.m == m && ($0.d == d || $0.d == 0) } }
}

// MARK: - Arabic digits

private let arabicDigitChars: [Character] = Array("٠١٢٣٤٥٦٧٨٩")

extension Int {
    /// ١٢٣ style digits.
    var ar: String {
        String(String(self).map { c -> Character in
            if let v = c.wholeNumberValue, v >= 0, v < 10 { return arabicDigitChars[v] }
            return c
        })
    }
}

extension String {
    /// Converts Arabic-Indic digits to Western digits (for parsing user input).
    var westernDigits: String {
        String(map { c -> Character in
            if let i = arabicDigitChars.firstIndex(of: c) { return Character(String(i)) }
            return c
        })
    }
    /// Replaces Western digits with Arabic-Indic ones.
    var arabicDigits: String {
        String(map { c -> Character in
            if c.isASCII, let v = c.wholeNumberValue { return arabicDigitChars[v] }
            return c
        })
    }
}
