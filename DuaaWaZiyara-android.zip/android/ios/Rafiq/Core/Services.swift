import Foundation
import CoreLocation
import UserNotifications
import Observation
import AVFoundation

// MARK: - Location and compass heading

@Observable
final class LocationService: NSObject, CLLocationManagerDelegate {
    @ObservationIgnored private let manager = CLLocationManager()
    var heading: Double?            // smoothed heading in degrees (true north when available), nil until available
    var headingAccuracy: Double = -1   // degrees; negative means invalid (needs calibration)
    /// Same heading without the 0/360 wrap, so a dial can rotate along the shortest path.
    var continuousHeading: Double = 0
    /// False while iOS can only give magnetic north (no location fix yet).
    var trueNorth: Bool = false
    @ObservationIgnored private var sinAvg = 0.0
    @ObservationIgnored private var cosAvg = 1.0
    var location: CLLocation?
    var authorized: Bool = false
    var errorText: String?

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyKilometer
        manager.headingFilter = 1
    }

    func requestLocation() {
        errorText = nil
        if manager.authorizationStatus == .notDetermined { manager.requestWhenInUseAuthorization() }
        manager.requestLocation()
    }
    /// Compass mode: heading plus a live, best-accuracy GPS fix (true north needs a location, and the
    /// Qibla bearing is computed from where the device actually is, not from the saved city).
    func startHeading() {
        if manager.authorizationStatus == .notDetermined { manager.requestWhenInUseAuthorization() }
        manager.headingOrientation = .portrait
        manager.desiredAccuracy = kCLLocationAccuracyBest
        if CLLocationManager.headingAvailable() { manager.startUpdatingHeading() }
        manager.startUpdatingLocation()
    }
    func stopHeading() {
        manager.stopUpdatingHeading()
        manager.stopUpdatingLocation()
        manager.desiredAccuracy = kCLLocationAccuracyKilometer
    }
    /// True when iOS reports an invalid or poor (over 25 degrees) compass reading.
    var needsCalibration: Bool { heading != nil && (headingAccuracy < 0 || headingAccuracy > 25) }

    func locationManagerDidChangeAuthorization(_ m: CLLocationManager) {
        authorized = m.authorizationStatus == .authorizedWhenInUse || m.authorizationStatus == .authorizedAlways
    }
    func locationManager(_ m: CLLocationManager, didUpdateLocations locations: [CLLocation]) { location = locations.last }
    func locationManager(_ m: CLLocationManager, didFailWithError error: Error) { errorText = "تعذّر تحديد الموقع" }
    func locationManager(_ m: CLLocationManager, didUpdateHeading h: CLHeading) {
        let raw = h.trueHeading >= 0 ? h.trueHeading : h.magneticHeading
        trueNorth = h.trueHeading >= 0
        headingAccuracy = h.headingAccuracy
        // Circular low-pass filter (averages sin/cos so 359 and 1 average to 0, not 180).
        let r = raw * .pi / 180
        let k = heading == nil ? 1.0 : 0.25
        sinAvg += k * (sin(r) - sinAvg)
        cosAvg += k * (cos(r) - cosAvg)
        var smooth = atan2(sinAvg, cosAvg) * 180 / .pi
        if smooth < 0 { smooth += 360 }
        if let prev = heading {
            var delta = (smooth - prev).truncatingRemainder(dividingBy: 360)
            if delta > 180 { delta -= 360 } else if delta < -180 { delta += 360 }
            continuousHeading += delta
        } else {
            continuousHeading = smooth
        }
        heading = smooth
    }

    /// Reverse-geocodes to a city name (best effort).
    func cityName(for loc: CLLocation) async -> String {
        let marks = try? await CLGeocoder().reverseGeocodeLocation(loc, preferredLocale: Locale(identifier: "ar"))
        return marks?.first?.locality ?? marks?.first?.administrativeArea ?? "موقعي"
    }
}

// MARK: - Local notifications (prayer times, daily dhikr)

enum Notifier {
    static func requestPermission() async -> Bool {
        (try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])) ?? false
    }

    /// Schedules the five prayers for the next 6 days. iOS keeps at most 64 pending requests, and the routine,
    /// dhikr, sadaqa and khums reminders need the rest; the app re-arms everything each time it becomes active.
    static func schedulePrayers(store: Store) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: (0..<12).flatMap { d in PrayerTimes.prayerKeys.map { "p-\(d)-\($0)" } })
        guard store.bool("notify", false) else { return }
        let city = store.location()
        for d in 0..<6 {
            guard let day = Calendar.current.date(byAdding: .day, value: d, to: Date()) else { continue }
            let t = PrayerTimes.compute(date: day, lat: city.lat, lng: city.lng, tz: city.tz, methodKey: store.method)
            for key in PrayerTimes.prayerKeys {
                let when = PrayerTimes.date(PrayerTimes.value(t, key), on: day)
                if when < Date() { continue }
                let c = UNMutableNotificationContent()
                c.title = "حان وقت صلاة \(PrayerTimes.name(key))"
                c.body = "\(city.n) · \(PrayerTimes.fmt(PrayerTimes.value(t, key)))"
                c.sound = store.strings("adhanOff").contains(key) ? .default : adhanSound(store.string("adhanSound", "takbir"))
                let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: when)
                center.add(UNNotificationRequest(identifier: "p-\(d)-\(key)", content: c,
                                                 trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
            }
        }
    }

    /// Notification sounds (each under the 30-second iOS limit). Clips from ShiaCompanion (MIT).
    struct AdhanSound { let key: String; let name: String; let file: String? }
    static let adhanSounds: [AdhanSound] = [
        AdhanSound(key: "takbir", name: "تكبير الأذان", file: "adhan_takbir.caf"),
        AdhanSound(key: "full", name: "مطلع الأذان", file: "adhan_full.caf"),
        AdhanSound(key: "default", name: "نغمة النظام", file: nil)
    ]
    static func adhanSound(_ key: String) -> UNNotificationSound {
        guard let f = adhanSounds.first(where: { $0.key == key })?.file else { return .default }
        return UNNotificationSound(named: UNNotificationSoundName(rawValue: f))
    }
    private static var previewPlayer: AVAudioPlayer?
    /// Plays the chosen sound in the app (tap again to stop).
    static func previewAdhan(_ key: String) {
        if let p = previewPlayer, p.isPlaying { p.stop(); previewPlayer = nil; return }
        guard let f = adhanSounds.first(where: { $0.key == key })?.file,
              let url = Bundle.main.url(forResource: (f as NSString).deletingPathExtension, withExtension: "caf") else { return }
        try? AVAudioSession.sharedInstance().setCategory(.playback)
        previewPlayer = try? AVAudioPlayer(contentsOf: url)
        previewPlayer?.play()
    }

    /// One repeating reminder at hour:minute with the given id.
    static func scheduleDaily(id: String, hour: Int, minute: Int, title: String, body: String) {
        let c = UNMutableNotificationContent(); c.title = title; c.body = body; c.sound = .default
        var dc = DateComponents(); dc.hour = hour; dc.minute = minute
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: id, content: c,
                                                                      trigger: UNCalendarNotificationTrigger(dateMatching: dc, repeats: true)))
    }
    static func cancel(_ ids: [String]) { UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ids) }
}
