import Foundation

/// Reading pace for Quran credit, in Arabic letters per second.
enum QuranPace {
    static let modeKey = "qpPaceMode"        // "auto", "tartil", "voice", "silent"
    private static let samplesKey = "qpPaceSamples"

    struct Mode { let key: String; let name: String; let detail: String; let lettersPerSecond: Double }
    static let modes: [Mode] = [
        Mode(key: "auto", name: "تلقائي", detail: "يتعلّم سرعتك من قراءتك", lettersPerSecond: 0),
        Mode(key: "tartil", name: "ترتيلٌ بصوت", detail: "على مهل مع أحكام التجويد", lettersPerSecond: 5),
        Mode(key: "voice", name: "قراءةٌ بصوت", detail: "حدرٌ معتاد", lettersPerSecond: 9),
        Mode(key: "silent", name: "قراءةٌ صامتة", detail: "بالنظر", lettersPerSecond: 15)
    ]

    static func mode(_ s: Store) -> String { s.string(modeKey, "auto") }

    /// Learned pace: median of recent samples, clamped to a plausible human range.
    static func learned(_ s: Store) -> Double? {
        let xs = s.string(samplesKey).split(separator: ",").compactMap { Double($0) }.sorted()
        guard xs.count >= 5 else { return nil }
        return min(25, max(3, xs[xs.count / 2]))
    }

    /// The pace used for crediting (letters per second).
    static func current(_ s: Store) -> Double {
        let m = mode(s)
        if let fixed = modes.first(where: { $0.key == m && $0.lettersPerSecond > 0 }) { return fixed.lettersPerSecond }
        return learned(s) ?? 9
    }

    static func addSample(_ s: Store, _ lettersPerSecond: Double) {
        guard lettersPerSecond.isFinite, lettersPerSecond > 1, lettersPerSecond < 60 else { return }
        var xs = s.string(samplesKey).split(separator: ",").map(String.init)
        xs.append(String(format: "%.2f", lettersPerSecond))
        s.put(samplesKey, xs.suffix(30).joined(separator: ","))
    }

    static func sampleCount(_ s: Store) -> Int {
        s.string(samplesKey).split(separator: ",").count
    }

    /// Arabic letters in a text (no diacritics, spaces, digits or marks).
    static func letters(_ t: String) -> Int {
        t.unicodeScalars.reduce(0) { n, u in
            let v = u.value
            return n + (((0x0621...0x063A).contains(v) || (0x0641...0x064A).contains(v) || (0x0671...0x06D3).contains(v)) ? 1 : 0)
        }
    }
}

/// Credits Quran verses as they are actually read: a verse counts only after its text has been
/// on screen and enough reading time has passed for its letters at the reader's own pace.
/// Time cannot be banked: unspent reading time never exceeds the text currently on screen.
final class QuranReadingTracker {
    let surah: Int
    private(set) var verseLetters: [Int] = []      // index v-1
    private(set) var verseParagraph: [Int] = []    // paragraph that ends verse v
    private var paragraphLetters: [Int] = []
    private var seen = Set<Int>()
    private var visible = Set<Int>()
    private var firstSeen: [Int: Date] = [:]
    private var budget: Double = 0
    private(set) var credited: Int                  // verses credited so far (furthest verse)
    private var lastTick = Date()

    init(surah: Int, alreadyRead: Int) {
        self.surah = surah
        self.credited = alreadyRead
    }

    /// Rebuilds the verse maps for the paragraphs as currently displayed.
    func layout(fullText: String, paragraphs: [String]) {
        let total = QuranProgress.verseCounts[max(0, min(113, surah - 1))]
        // Letters per verse, from the full text split at the "(n)" markers.
        var letters = Array(repeating: 0, count: total)
        var segStart = fullText.startIndex
        var i = fullText.startIndex
        while let open = fullText[i...].firstIndex(of: "(") {
            guard let close = fullText[open...].firstIndex(of: ")") else { break }
            let inner = String(fullText[fullText.index(after: open)..<close]).westernDigits
            if inner.count <= 3, let n = Int(inner), (1...total).contains(n) {
                letters[n - 1] += QuranPace.letters(String(fullText[segStart..<open]))
                segStart = fullText.index(after: close)
            }
            i = fullText.index(after: close)
        }
        verseLetters = letters.map { max(1, $0) }
        // Which paragraph ends each verse.
        var where_ = Array(repeating: max(0, paragraphs.count - 1), count: total)
        for (pi, p) in paragraphs.enumerated() {
            var j = p.startIndex
            while let open = p[j...].firstIndex(of: "(") {
                guard let close = p[open...].firstIndex(of: ")") else { break }
                let inner = String(p[p.index(after: open)..<close]).westernDigits
                if inner.count <= 3, let n = Int(inner), (1...total).contains(n) { where_[n - 1] = pi }
                j = p.index(after: close)
            }
        }
        verseParagraph = where_
        paragraphLetters = paragraphs.map { QuranPace.letters($0) }
        seen.removeAll(); visible.removeAll(); firstSeen.removeAll(); budget = 0
        lastTick = Date()
    }

    func setVisible(_ paragraph: Int, _ isVisible: Bool, store: Store) {
        if isVisible {
            visible.insert(paragraph)
            if !seen.contains(paragraph) {
                seen.insert(paragraph)
                let now = Date()
                firstSeen[paragraph] = now
                // Pace sample: the previous paragraph's letters over the time until this one appeared.
                if let prevTime = firstSeen[paragraph - 1], paragraphLetters.indices.contains(paragraph - 1) {
                    let dt = now.timeIntervalSince(prevTime)
                    if dt > 4 && dt < 240 { QuranPace.addSample(store, Double(paragraphLetters[paragraph - 1]) / dt) }
                }
            }
        } else {
            visible.remove(paragraph)
        }
    }

    /// Called about once a second while the reader is in front. Returns verses newly credited.
    func tick(store: Store, active: Bool) -> Int {
        let now = Date()
        let dt = min(2, max(0, now.timeIntervalSince(lastTick)))
        lastTick = now
        guard active, !visible.isEmpty, !verseLetters.isEmpty else { return 0 }
        budget += dt * QuranPace.current(store) * 1.25        // small allowance for natural variation
        // Never bank more time than the uncredited text that has been shown.
        let shownUncredited = verseLetters.indices
            .filter { $0 >= credited && seen.contains(verseParagraph[$0]) }
            .reduce(0) { $0 + verseLetters[$1] }
        budget = min(budget, Double(shownUncredited))
        var gained = 0
        while credited < verseLetters.count {
            let v = credited                                    // 0-based index of the next verse
            guard seen.contains(verseParagraph[v]), budget >= Double(verseLetters[v]) else { break }
            budget -= Double(verseLetters[v])
            credited += 1
            gained += 1
        }
        return gained
    }
}
