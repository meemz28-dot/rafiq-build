import Foundation

// MARK: - Khums (ported from Android logic/Khums.kt)

enum Khums {
    struct Marja: Hashable, Identifiable {
        let key: String; let name: String; let note: String
        let receivablesCounted: Bool
        let rulings: [[String]]   // [title, text]
        var id: String { key }
    }

    static let maraji: [Marja] = [
        Marja(key: "shirazi", name: "السيد صادق الحسيني الشيرازي (دام ظله)",
              note: "تُحتسب الديون القابلة للتحصيل ضمن الموجودات، وتُستثنى ديون المؤونة الحالّة، وفي موارد الشكّ والمصالحة يُرجع إلى وكيل المرجع المجاز.",
              receivablesCounted: true, rulings: [
                ["رأس السنة الخمسية", "على كلّ مكلّف أن يعيّن لنفسه رأس سنةٍ خمسية — وهو يوم أوّل حصوله على الربح أو بدء كسبه — فإذا حلّ خمّس كلَّ ما فضل عن مؤونته. وتأخير الدفع لا يغيّر رأس السنة، ويبقى الخمس ديناً في الذمّة."],
                ["المؤونة لا خمس فيها", "ما صُرف أو استُعمل في مؤونتك ومؤونة عيالك خلال السنة بما يليق بشأنك لا خمس فيه: دار السكن، سيارة الاستعمال، أثاث البيت المستعمَل، الملابس، نفقات الزواج والحجّ والزيارة والضيافة ونحوها."],
                ["مصرف الخمس", "يُقسَّم الخمس نصفين: سهم الإمام (عجّل الله فرجه) ويُدفع في زمن الغيبة إلى المرجع الجامع للشرائط أو وكيله المجاز، وسهم السادة ويُعطى لفقراء بني هاشم — الأحوط بإذن المرجع أو وكيله."],
                ["المصالحة", "من لم يخمّس سابقاً، أو اشتبهت عليه حساباته، أو كانت مؤونته مشتراة من أرباح غير مخمّسة، فطريقه المصالحة مع المرجع أو وكيله المجاز."]]),
        Marja(key: "sistani", name: "السيد علي الحسيني السيستاني (دام ظله)",
              note: "الدين الذي تقدر على استيفائه يُخمَّس عند رأس السنة وإن لم تستوفه، ويُستثنى دين مؤونة هذه السنة. ذو المهنة لا يجعل لكلّ ربحٍ سنةً مستقلّة.",
              receivablesCounted: true, rulings: [
                ["رأس السنة الخمسية", "سنة ذي المهنة والكسب تبدأ بيوم الشروع في العمل، ولا يجوز له أن يجعل لكلّ ربحٍ سنةً مستقلّة، فإذا حلّ رأس السنة خمّس كلّ ما لم يُصرف في المؤونة. وتُستثنى من الأرباح مؤونة التجارة: ما صُرف في سبيل تحصيلها من أجورٍ وكهرباء ونقلٍ وضرائب ونحوها."],
                ["الهدية والإرث", "ما يُتملَّك مجّاناً كالهدية يُعدّ من أرباح سنة التملّك، فالفاضل منه عن المؤونة يُخمَّس. والإرث المحتسب لا خمس فيه."],
                ["مصرف الخمس", "يُقسَّم الخمس نصفين: سهم الإمام (عجّل الله فرجه) ولا يجوز صرفه إلّا بإذن المرجع الأعلم على الأحوط، ويُسلَّم إليه أو إلى وكيله المجاز، وسهم السادة لفقراء بني هاشم."],
                ["المصالحة", "من لم يحاسب نفسه سابقاً أو اشتبهت عليه أمواله صالَحَ الحاكمَ الشرعي أو وكيله بنسبة الاحتمال."]]),
        Marja(key: "wahid", name: "الشيخ حسين الوحيد الخراساني (دام ظله)",
              note: "على نهج منهاج الصالحين (مدرسة السيد الخوئي): الأحوط تخميس الهدية الفائضة، والدين المقدور على استيفائه يُخمَّس. للموارد الخاصّة يُراجع مكتب المرجع.",
              receivablesCounted: true, rulings: [
                ["رأس السنة الخمسية", "تبدأ سنة الكاسب والموظّف بالشروع في الاكتساب أو أوّل حصول الفائدة، فإذا حلّ رأس السنة خمّس الفاضل عن مؤونته بعد استثناء مؤن التحصيل."],
                ["الهدية والإرث", "الأحوط وجوباً تخميس الهبة والهدية الفائضة عن مؤونة السنة. والإرث المحتسَب لا خمس فيه."],
                ["مصرف الخمس", "سهم الإمام (عجّل الله فرجه) يُدفع إلى المرجع أو بإذنه، وسهم السادة لفقراء بني هاشم. هذه الخلاصة على نهج المدرسة الخوئية التي ينتمي إليها سماحته — يُرجى التثبّت من مكتبه في الموارد الخاصّة."]]),
        Marja(key: "shubairi", name: "السيد موسى الشبيري الزنجاني (دام ظله)",
              note: "من المعروف من فتاواه عدم وجوب الخمس في الهدية. يُرجى التثبّت من مكتب المرجع في تفاصيل الموارد قبل العمل.",
              receivablesCounted: true, rulings: [
                ["رأس السنة الخمسية", "تبدأ سنة الكاسب والموظّف بالشروع في الاكتساب أو أوّل حصول الفائدة، فإذا حلّ رأس السنة خمّس الفاضل عن مؤونته."],
                ["الهدية والإرث", "المعروف من فتاوى سماحته أنّ الهدية لا يجب فيها الخمس، والإرث المحتسَب لا خمس فيه. يُرجى التثبّت من مكتب المرجع قبل العمل بهذه الخلاصة."],
                ["مصرف الخمس", "يُدفع الخمس إلى المرجع أو وكيله المجاز ليُصرف في موارده الشرعية."]]),
        Marja(key: "modarresi", name: "السيد محمد تقي المدرّسي (دام ظله)",
              note: "ديونك على الآخرين لا خمس فيها إلّا عند استلامها فلا تُحتسب هنا، والمدّخر لمؤونةٍ عرفية قريبة (زواج، دار سكن، دراسة) لا خمس فيه.",
              receivablesCounted: false, rulings: [
                ["رأس السنة الخمسية", "مبدأ السنة لذي الكسب والموظّف هو حال الشروع في الاكتساب، ومن حصلت له فائدة اتفاقاً فمن حين حصولها. ويجوز الحساب بالسنة الهجرية أو الميلادية، ويجوز تغيير رأس السنة بعد تخميس الفترة المنصرمة."],
                ["الادّخار للمؤونة", "ما يُدَّخر لمؤونةٍ يعتبرها العرف من الحاجات القريبة — كنفقة زواجٍ قريب أو دار سكن أو دراسة — لا خمس فيه."],
                ["مصرف الخمس", "يُقسَّم الخمس سهمين: سهم الإمام (عجّل الله فرجه) وسهم السادة، ويُرجع فيهما إلى المرجع أو وكيله المجاز."]])
    ]
    static func marja(_ key: String) -> Marja { maraji.first { $0.key == key } ?? maraji[0] }

    struct Inputs {
        var cash = 0.0, goods = 0.0, trade = 0.0, metals = 0.0, receivables = 0.0, other = 0.0
        var khumsed = 0.0, loans = 0.0, debts = 0.0
        var mixed = 0.0, mixedSeparate = true
    }
    struct Result { let base: Double; let keep: Double; let khums: Double; let imam: Double; let sada: Double }

    static func calc(_ inp: Inputs, _ marja: Marja) -> Result {
        let rec = marja.receivablesCounted ? inp.receivables : 0
        let assets = inp.cash + inp.goods + inp.trade + inp.metals + rec + inp.other
        let exempt = inp.khumsed + inp.loans + inp.debts
        var base = max(0, assets - exempt)
        if !inp.mixedSeparate { base += inp.mixed }
        let khums = base * 0.20
        let mixedKhums = inp.mixedSeparate ? inp.mixed * 0.20 : 0
        let total = khums + mixedKhums
        return Result(base: base, keep: base - khums, khums: total, imam: total / 2, sada: total / 2)
    }

    static func isKhumsDay(_ h: Hijri.HDate, m: Int, d: Int, adj: Int) -> Bool {
        if h.m != m { return false }
        if h.d == d { return true }
        return d == 30 && h.d == 29 && Hijri.monthLength(h.y, h.m, adj: adj) == 29
    }

    static func daysUntilKhumsDay(m: Int, d: Int, adj: Int, from: Int = 0) -> Int {
        let jd = Hijri.jd(of: Date())
        for k in from...(from + 400) where isKhumsDay(Hijri.jdToHijri(jd + k, adj: adj), m: m, d: d, adj: adj) { return k }
        return from
    }

    static let currencies: [(String, String)] = [
        ("د.إ", "درهم إماراتي"), ("د.ع", "دينار عراقي"), ("ر.س", "ريال سعودي"), ("د.ك", "دينار كويتي"),
        ("د.ب", "دينار بحريني"), ("ر.ع", "ريال عماني"), ("ر.ق", "ريال قطري"), ("$", "دولار"),
        ("€", "يورو"), ("£", "جنيه"), ("ت", "تومان")
    ]

    /// 12,345.50 style with Arabic digits.
    static func money(_ v: Double) -> String {
        let f = NumberFormatter()
        f.numberStyle = .decimal
        f.maximumFractionDigits = 2
        f.minimumFractionDigits = 0
        f.locale = Locale(identifier: "en_US")
        return (f.string(from: NSNumber(value: v)) ?? "0").arabicDigits
    }
}

// MARK: - Arabic search (ported from Android logic/ArabicSearch.kt)

enum ArabicSearch {
    private static let tashkeel: Set<Unicode.Scalar> = {
        var s = Set<Unicode.Scalar>()
        for v in 0x064B...0x0652 { if let u = Unicode.Scalar(v) { s.insert(u) } }
        for v in 0x0653...0x065F { if let u = Unicode.Scalar(v) { s.insert(u) } }
        for v in [0x0670, 0x0640] { if let u = Unicode.Scalar(v) { s.insert(u) } }
        return s
    }()

    static func stripTashkeel(_ s: String) -> String {
        String(String.UnicodeScalarView(s.unicodeScalars.filter { !tashkeel.contains($0) }))
    }

    static func normalize(_ s: String) -> String {
        var t = stripTashkeel(s)
        for (a, b) in [("أ", "ا"), ("إ", "ا"), ("آ", "ا"), ("ى", "ي"), ("ة", "ه"), ("ؤ", "و"), ("ئ", "ي")] {
            t = t.replacingOccurrences(of: a, with: b)
        }
        return t.split(whereSeparator: { $0.isWhitespace }).joined(separator: " ")
    }

    struct Entry { let cat: DuaaCategory; let item: DuaaItem; let nTitle: String; let nSrc: String; let nIntro: String; let nText: String }
    struct Hit: Identifiable { let cat: DuaaCategory; let item: DuaaItem; let snippet: String; let score: Int; var id: String { cat.id + "|" + item.id } }

    static let index: [Entry] = Library.categories.flatMap { c in
        c.items.map { Entry(cat: c, item: $0, nTitle: normalize($0.title), nSrc: normalize($0.src ?? ""),
                            nIntro: normalize($0.intro ?? ""), nText: normalize($0.text.replacingOccurrences(of: "\n", with: " "))) }
    }

    static func search(_ query: String) -> [Hit] {
        let nq = normalize(query)
        if nq.isEmpty { return [] }
        let terms = nq.split(separator: " ").map(String.init)
        var hits: [Hit] = []
        for e in index {
            guard terms.allSatisfy({ e.nTitle.contains($0) || e.nSrc.contains($0) || e.nIntro.contains($0) || e.nText.contains($0) }) else { continue }
            var score = 0
            if e.nTitle == nq { score += 1000 }
            else if e.nTitle.hasPrefix(nq) { score += 600 }
            else if e.nTitle.contains(nq) { score += 400 }
            else if terms.allSatisfy({ e.nTitle.contains($0) }) { score += 250 }
            if e.nSrc.contains(nq) { score += 80 }
            if e.nIntro.contains(nq) { score += 60 }
            if e.nText.contains(nq) { score += 40 }
            var snippet = ""
            if let first = terms.first, let r = e.nText.range(of: first) {
                let ix = e.nText.distance(from: e.nText.startIndex, to: r.lowerBound)
                let plain = Array(stripTashkeel(e.item.text.replacingOccurrences(of: "\n", with: " ")))
                let st = max(0, ix - 20), en = min(st + 80, plain.count)
                if en > st { snippet = (st > 0 ? "…" : "") + String(plain[st..<en]).trimmingCharacters(in: .whitespaces) + "…" }
            }
            hits.append(Hit(cat: e.cat, item: e.item, snippet: snippet, score: score))
        }
        return hits.sorted { $0.score != $1.score ? $0.score > $1.score : $0.item.title < $1.item.title }
    }
}

// MARK: - "What to read now" (ported from Android logic/Recommend.kt)

enum Recommend {
    struct Suggestion: Hashable { let catId: String; let itemId: String; let reason: String; let label: String }

    private static func sug(_ c: String, _ i: String, _ reason: String, _ label: String) -> Suggestion? {
        Library.item(c, i) != nil ? Suggestion(catId: c, itemId: i, reason: reason, label: label) : nil
    }

    /// weekday: 0 = Sunday … 6 = Saturday.
    static func now(hMonth m: Int, hDay d: Int, weekday: Int, hour: Int) -> Suggestion {
        if m == 9, let s = sug("mashhura", "m-iftitah", "في شهر رمضان المبارك", "دعاء الافتتاح") { return s }
        if m == 1, (1...12).contains(d), let s = sug("ziyarat", "z-ashura", "في أيام عاشوراء", "زيارة عاشوراء") { return s }
        if m == 9, [19, 21, 23].contains(d), let s = sug("ramadan", "r-jawshan", "من أعمال ليالي القدر", "الجوشن الكبير") { return s }
        if m == 8, d == 15, let s = sug("mashhura", "m-nudba", "في ليلة النصف من شعبان", "دعاء الندبة") { return s }
        if weekday == 4, hour >= 18, let s = sug("mashhura", "m-kumayl", "ليلة الجمعة", "دعاء كميل") { return s }
        if weekday == 5 {
            if hour < 10, let s = sug("mashhura", "m-nudba", "صباح الجمعة", "دعاء الندبة") { return s }
            if let s = sug("jumaa", "j-samat", "يوم الجمعة", "دعاء السمات") { return s }
            if let s = sug("mashhura", "m-tawassul", "يوم الجمعة", "دعاء التوسّل") { return s }
        }
        let fallback = Suggestion(catId: "quran", itemId: "q-001", reason: "تلاوة", label: "سورة الفاتحة")
        switch hour {
        case 4...10: return sug("sabah", Library.category("sabah")?.items.first?.id ?? "", "أذكار الصباح", "تعقيبات الصباح") ?? fallback
        case 20...23, 0...3: return sug("quran", "q-067", "قبل النوم", "سورة الملك") ?? fallback
        default: return sug("quran", "q-018", "تلاوة اليوم", "سورة الكهف") ?? fallback
        }
    }
}

// MARK: - Recommended fasting (ported from Android data/Amaal.kt)

enum Fasting {
    /// weekday: 0 = Sunday … 6 = Saturday.
    static func rec(hm: Int, hd: Int, weekday: Int) -> (recommended: Bool, reason: String) {
        if hm == 10 && hd == 1 { return (false, "عيد الفطر — يحرُم صيامه") }
        if hm == 12 && hd == 10 { return (false, "عيد الأضحى — يحرُم صيامه") }
        if hm == 1 && hd == 10 { return (false, "عاشوراء — لا يُصام تبرّكاً، ويُستحبّ الإمساك إلى ما بعد الزوال دون نيّة الصوم") }
        if hm == 9 { return (true, "شهر رمضان — صيامه واجب") }
        let special: [String: String] = [
            "7-13": "ولادة أمير المؤمنين (ع)", "7-27": "المبعث النبوي", "8-3": "ولادة الإمام الحسين (ع)",
            "3-17": "المولد النبوي", "12-9": "يوم عرفة (لمن لا يُضعفه عن الدعاء)", "12-18": "عيد الغدير",
            "1-1": "أول محرّم", "11-25": "يوم دحو الأرض"]
        if let s = special["\(hm)-\(hd)"] { return (true, "\(s) — يُستحب صيامه") }
        if hm == 12 && (11...13).contains(hd) { return (false, "من أيام التشريق — يحرُم صيامها على من كان بمنى") }
        if (13...15).contains(hd) { return (true, "من الأيام البيض (١٣–١٥) — يُستحب صيامها في كل شهر") }
        if weekday == 1 { return (true, "يوم الإثنين — يُستحب صيامه") }
        if weekday == 4 { return (true, "يوم الخميس — يُستحب صيامه") }
        return (false, "ليس من أيام الصيام المستحب المخصوص؛ ويجوز صيام التطوّع")
    }
}

// MARK: - Qibla

/// Qibla bearing, distance and the sun-based check (no compass needed).
/// Bearing formula and Kaaba coordinates follow batoulapps/adhan-swift (MIT), verified against its test vectors.
enum Qibla {
    static let kaabaLat = 21.4225241, kaabaLng = 39.8261818
    private static let rad = Double.pi / 180

    /// Great-circle bearing from true north, degrees 0..360.
    static func bearing(lat: Double, lng: Double) -> Double {
        let t1 = sin((kaabaLng - lng) * rad)
        let t2 = cos(lat * rad) * tan(kaabaLat * rad)
        let t3 = sin(lat * rad) * cos((kaabaLng - lng) * rad)
        let b = atan2(t1, t2 - t3) / rad
        return (b + 360).truncatingRemainder(dividingBy: 360)
    }

    /// Haversine distance to the Kaaba in km.
    static func distanceKm(lat: Double, lng: Double) -> Double {
        let dLat = (kaabaLat - lat) * rad, dLng = (kaabaLng - lng) * rad
        let a = sin(dLat / 2) * sin(dLat / 2) + cos(lat * rad) * cos(kaabaLat * rad) * sin(dLng / 2) * sin(dLng / 2)
        return 6371.0 * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    /// Sun azimuth (from true north) and altitude in degrees (NOAA low-precision model, about 0.1 degree).
    static func sun(at date: Date, lat: Double, lng: Double) -> (azimuth: Double, altitude: Double) {
        let jd = date.timeIntervalSince1970 / 86400 + 2440587.5
        let d = jd - 2451545.0
        let g = (357.529 + 0.98560028 * d).truncatingRemainder(dividingBy: 360) * rad
        let q = (280.459 + 0.98564736 * d).truncatingRemainder(dividingBy: 360)
        let l = (q + 1.915 * sin(g) + 0.020 * sin(2 * g)) * rad
        let e = (23.439 - 0.00000036 * d) * rad
        let ra = (atan2(cos(e) * sin(l), cos(l)) / rad / 15 + 24).truncatingRemainder(dividingBy: 24)
        let dec = asin(sin(e) * sin(l))
        var eqt = q / 15 - ra
        eqt = ((eqt + 12).truncatingRemainder(dividingBy: 24) + 24).truncatingRemainder(dividingBy: 24) - 12
        let ut = ((jd + 0.5) - floor(jd + 0.5)) * 24
        let h = 15 * (ut + lng / 15 + eqt - 12) * rad
        let ph = lat * rad
        let alt = asin(sin(ph) * sin(dec) + cos(ph) * cos(dec) * cos(h)) / rad
        let az = atan2(-sin(h), tan(dec) * cos(ph) - sin(ph) * cos(h)) / rad
        return ((az + 360).truncatingRemainder(dividingBy: 360), alt)
    }

    /// A moment when the sun stands exactly in the Qibla direction (`toward`) or exactly behind it,
    /// so a person facing the sun, or facing along their own shadow, faces the Qibla.
    struct SunAlignment: Hashable { let date: Date; let toward: Bool; let altitude: Double }

    private static func signedDiff(_ a: Double, _ b: Double) -> Double {
        let x = (a - b + 540).truncatingRemainder(dividingBy: 360)
        return (x < 0 ? x + 360 : x) - 180
    }

    /// Alignments during the given local day with the sun at least 3 degrees above the horizon.
    static func sunAlignments(on day: Date, lat: Double, lng: Double, stepMinutes: Int = 1) -> [SunAlignment] {
        let start = Calendar.current.startOfDay(for: day)
        let b = bearing(lat: lat, lng: lng)
        let targets: [(Double, Bool)] = [(b, true), ((b + 180).truncatingRemainder(dividingBy: 360), false)]
        var out: [SunAlignment] = []
        var prev: [Double]? = nil
        var m = 0
        while m <= 1440 {
            let t = start.addingTimeInterval(Double(m) * 60)
            let s = sun(at: t, lat: lat, lng: lng)
            let cur = targets.map { signedDiff(s.azimuth, $0.0) }
            if let p = prev, s.altitude > 3 {
                for k in 0..<2 where p[k] < 0 && cur[k] >= 0 && abs(cur[k] - p[k]) < 90 {
                    out.append(SunAlignment(date: t, toward: targets[k].1, altitude: s.altitude))
                }
            }
            prev = cur
            m += stepMinutes
        }
        return out.sorted { $0.date < $1.date }
    }

    /// The first day (from tomorrow, up to a year ahead) that has an alignment.
    static func nextAlignmentDay(after day: Date, lat: Double, lng: Double) -> Date? {
        for i in 1...366 {
            guard let d = Calendar.current.date(byAdding: .day, value: i, to: day) else { continue }
            if !sunAlignments(on: d, lat: lat, lng: lng, stepMinutes: 4).isEmpty { return d }
        }
        return nil
    }
}
