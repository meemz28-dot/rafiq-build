import Foundation
import BackgroundTasks

/// Re-arms every reminder in the background, so the adhan keeps coming even if the app is not
/// opened for days (iOS only fires notifications that were scheduled in advance).
enum BackgroundRefresh {
    static let identifier = "com.shirazi.rafiq.refresh"

    /// Asks iOS to wake the app again in a few hours (the system decides the exact time).
    static func submit() {
        let req = BGAppRefreshTaskRequest(identifier: identifier)
        req.earliestBeginDate = Date().addingTimeInterval(6 * 3600)
        try? BGTaskScheduler.shared.submit(req)
    }

    /// Runs on the main actor: rebuilds all scheduled reminders from current settings.
    @MainActor static func rearmAll() {
        let store = Store()
        Notifier.schedulePrayers(store: store)
        PrayerRoutines.refreshAll(store: store)
        PersonalOccasions.reschedule(store)
        KhumsReminder.reschedule(store)
        PrayerLive.refresh(store: store)
    }
}
