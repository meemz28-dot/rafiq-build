import Foundation

/// Public links used when sharing. Set `storeURL` once the app is published; until then shares carry the name only.
enum AppLinks {
    static let storeURL: String? = nil

    static var shareText: String {
        var t = "تطبيق «رفيق المؤمن»: الأدعية والزيارات والقرآن الكريم كاملاً بالصوت، ومواقيت الصلاة والقبلة والتقويم الهجري. مجاني بلا إعلانات ولا حساب."
        if let u = storeURL { t += "\n" + u }
        return t
    }

    /// One line appended to shared duas and image cards.
    static var signature: String {
        if let u = storeURL { return "تطبيق رفيق المؤمن · " + u }
        return "تطبيق رفيق المؤمن"
    }
}
