import Foundation

/// Astronomical prayer times (PrayTimes style) with the Shari'a midnight; a direct port of the Android logic.
enum PrayerTimes {
    struct Method: Hashable {
        let key: String; let name: String
        let fajr: Double; let maghrib: Double?   // nil => sunset based; otherwise depression degrees
        let isha: Double; let ishaMin: Bool      // ishaMin => isha = maghrib + 90 min
        let jafariMidnight: Bool
    }

    static let methods: [Method] = [
        Method(key: "jafari", name: "الجعفري (ليفا - قم)", fajr: 16.0, maghrib: 4.0, isha: 14.0, ishaMin: false, jafariMidnight: true),
        Method(key: "hadi", name: "الهادي (البوعلي)", fajr: 18.0, maghrib: 4.0, isha: 0.0, ishaMin: true, jafariMidnight: true),
        Method(key: "tehran", name: "طهران", fajr: 17.7, maghrib: 4.5, isha: 14.0, ishaMin: false, jafariMidnight: true),
        Method(key: "karachi", name: "كراتشي", fajr: 18.0, maghrib: nil, isha: 18.0, ishaMin: false, jafariMidnight: false),
        Method(key: "mwl", name: "رابطة العالم الإسلامي", fajr: 18.0, maghrib: nil, isha: 17.0, ishaMin: false, jafariMidnight: false),
        Method(key: "makkah", name: "أم القرى (مكة)", fajr: 18.5, maghrib: nil, isha: 0.0, ishaMin: true, jafariMidnight: false)
    ]
    static func method(_ key: String) -> Method { methods.first { $0.key == key } ?? methods[0] }

    struct Times: Hashable {
        let fajr: Double, sunrise: Double, dhuhr: Double, asr: Double, maghrib: Double, isha: Double, midnight: Double
    }

    struct Slot: Hashable { let key: String; let name: String; let symbol: String }
    static let slots: [Slot] = [
        Slot(key: "fajr", name: "الفجر", symbol: "sunrise"),
        Slot(key: "sunrise", name: "الشروق", symbol: "sun.horizon"),
        Slot(key: "dhuhr", name: "الظهر", symbol: "sun.max"),
        Slot(key: "asr", name: "العصر", symbol: "sun.min"),
        Slot(key: "maghrib", name: "المغرب", symbol: "sunset"),
        Slot(key: "isha", name: "العشاء", symbol: "moon.stars"),
        Slot(key: "midnight", name: "منتصف الليل", symbol: "moon.zzz")
    ]
    static let prayerKeys = ["fajr", "dhuhr", "asr", "maghrib", "isha"]

    private static func rtd(_ r: Double) -> Double { r * 180.0 / .pi }
    private static func dtr(_ d: Double) -> Double { d * .pi / 180.0 }

    private static func sunPos(_ jd: Double) -> (decl: Double, eqt: Double) {
        let d = jd - 2451545.0
        let g = (357.529 + 0.98560028 * d).truncatingRemainder(dividingBy: 360)
        let q = (280.459 + 0.98564736 * d).truncatingRemainder(dividingBy: 360)
        let l = (q + 1.915 * sin(dtr(g)) + 0.020 * sin(dtr(2 * g))).truncatingRemainder(dividingBy: 360)
        let e = 23.439 - 0.00000036 * d
        let decl = rtd(asin(sin(dtr(e)) * sin(dtr(l))))
        var ra = rtd(atan2(cos(dtr(e)) * sin(dtr(l)), cos(dtr(l)))) / 15.0
        ra = (ra.truncatingRemainder(dividingBy: 24) + 24).truncatingRemainder(dividingBy: 24)
        return (decl, q / 15.0 - ra)
    }

    private static func tAngle(_ angle: Double, _ lat: Double, _ decl: Double) -> Double? {
        let x = (-sin(dtr(angle)) - sin(dtr(lat)) * sin(dtr(decl))) / (cos(dtr(lat)) * cos(dtr(decl)))
        if x < -1 || x > 1 { return nil }
        return rtd(acos(x)) / 15.0
    }

    private static func asrAngle(_ lat: Double, _ decl: Double) -> Double? {
        let angle = rtd(atan(1.0 / (1.0 + tan(abs(dtr(lat - decl))))))
        let x = (sin(dtr(angle)) - sin(dtr(lat)) * sin(dtr(decl))) / (cos(dtr(lat)) * cos(dtr(decl)))
        if x < -1 || x > 1 { return nil }
        return rtd(acos(x)) / 15.0
    }

    static func compute(date: Date, lat: Double, lng: Double, tz: Double, methodKey: String) -> Times {
        let m = method(methodKey)
        let c = Calendar(identifier: .gregorian).dateComponents([.year, .month, .day], from: date)
        let jd = Double(Hijri.gToJd(c.year ?? 2026, c.month ?? 1, c.day ?? 1)) - lng / (15.0 * 24.0)
        let sp = sunPos(jd)
        let decl = sp.decl
        let noon = 12.0 - sp.eqt - lng / 15.0 + tz
        let ha = tAngle(0.833, lat, decl) ?? 6.0
        let sunrise = noon - ha
        let sunset = noon + ha
        let night = 24.0 - 2 * ha

        let fajr: Double = tAngle(m.fajr, lat, decl).map { noon - $0 } ?? (sunrise - night / 7.0)
        var maghrib = sunset
        if let mgDeg = m.maghrib { maghrib = tAngle(mgDeg, lat, decl).map { noon + $0 } ?? (sunset + night / 12.0) }
        let isha: Double = m.ishaMin ? maghrib + 1.5 : (tAngle(m.isha, lat, decl).map { noon + $0 } ?? (sunset + night / 7.0))
        let asr = noon + (asrAngle(lat, decl) ?? 0.0)
        let midnight: Double
        if m.jafariMidnight {
            midnight = (maghrib + ((fajr + 24) - maghrib) / 2.0).truncatingRemainder(dividingBy: 24)
        } else {
            midnight = (sunset + ((sunrise + 24) - sunset) / 2.0).truncatingRemainder(dividingBy: 24)
        }
        return Times(fajr: fajr, sunrise: sunrise, dhuhr: noon, asr: asr, maghrib: maghrib, isha: isha, midnight: midnight)
    }

    static func norm(_ t: Double) -> Double { ((t.truncatingRemainder(dividingBy: 24)) + 24).truncatingRemainder(dividingBy: 24) }

    static func value(_ t: Times, _ key: String) -> Double {
        switch key {
        case "fajr": return t.fajr
        case "sunrise": return t.sunrise
        case "dhuhr": return t.dhuhr
        case "asr": return t.asr
        case "maghrib": return t.maghrib
        case "isha": return t.isha
        case "midnight": return t.midnight
        default: return .nan
        }
    }

    /// "4:24 ص" style, Arabic digits.
    static func fmt(_ tIn: Double) -> String {
        if tIn.isNaN { return "—" }
        let t = norm(tIn)
        var h = Int(floor(t))
        var mi = Int((t - Double(h)) * 60 + 0.5)
        if mi == 60 { mi = 0; h += 1 }
        if h >= 24 { h -= 24 }
        let am = h < 12
        var hh = h % 12
        if hh == 0 { hh = 12 }
        let mm = mi < 10 ? "0\(mi)" : "\(mi)"
        return "\(hh):\(mm) \(am ? "ص" : "م")".arabicDigits
    }

    /// Next prayer key and hours remaining from `nowHours` (local decimal hours).
    static func next(_ t: Times, nowHours: Double) -> (key: String, hours: Double) {
        var k = "fajr"; var best = Double.greatestFiniteMagnitude
        for s in slots where s.key != "sunrise" && s.key != "midnight" {
            var dt = norm(value(t, s.key)) - nowHours
            if dt < 0 { dt += 24 }
            if dt < best { best = dt; k = s.key }
        }
        return (k, best)
    }

    static func name(_ key: String) -> String { slots.first { $0.key == key }?.name ?? key }

    static func nowHours(_ date: Date = Date()) -> Double {
        let c = Calendar.current.dateComponents([.hour, .minute, .second], from: date)
        return Double(c.hour ?? 0) + Double(c.minute ?? 0) / 60 + Double(c.second ?? 0) / 3600
    }

    /// Converts decimal local hours on `day` to a Date (for notifications).
    static func date(_ hours: Double, on day: Date) -> Date {
        let start = Calendar.current.startOfDay(for: day)
        return start.addingTimeInterval(norm(hours) * 3600)
    }

    /// "٣س ٤١د" countdown text.
    static func countdown(_ hours: Double) -> String {
        let total = Int(hours * 60)
        let h = total / 60, m = total % 60
        return h > 0 ? "\(h.ar)س \(m.ar)د" : "\(m.ar)د"
    }
}
