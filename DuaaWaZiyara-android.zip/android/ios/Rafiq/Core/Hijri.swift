import Foundation

/// Hijri calendar (tabular algorithm, same as Android) with a ±2 day adjustment.
enum Hijri {
    static let months = ["مُحَرَّم", "صَفَر", "ربيع الأول", "ربيع الثاني", "جُمادى الأولى", "جُمادى الآخرة",
                         "رَجَب", "شَعبان", "رَمَضان", "شَوّال", "ذو القَعدة", "ذو الحِجّة"]
    /// 0 = Sunday … 6 = Saturday
    static let weekDays = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"]

    struct HDate: Hashable { let y: Int; let m: Int; let d: Int }
    struct GDate: Hashable { let y: Int; let m: Int; let d: Int }

    static func gToJd(_ y: Int, _ m: Int, _ d: Int) -> Int {
        let a = Int(floor(Double(14 - m) / 12.0))
        let yy = y + 4800 - a
        let mm = m + 12 * a - 3
        return d + Int(floor((153.0 * Double(mm) + 2) / 5)) + 365 * yy
            + Int(floor(Double(yy) / 4.0)) - Int(floor(Double(yy) / 100.0)) + Int(floor(Double(yy) / 400.0)) - 32045
    }

    static func jdToHijri(_ jdIn: Int, adj: Int = 0) -> HDate {
        let jd = jdIn + adj
        let l0 = jd - 1948440 + 10632
        let n = Int(floor(Double(l0 - 1) / 10631.0))
        var l = l0 - 10631 * n + 354
        let lD = Double(l)
        let j = Int(floor((10985.0 - lD) / 5316) * floor((50.0 * lD) / 17719) + floor(lD / 5670.0) * floor((43.0 * lD) / 15238))
        l = l - Int(floor((30.0 - Double(j)) / 15)) * Int(floor((17719.0 * Double(j)) / 50))
            - Int(floor(Double(j) / 16.0)) * Int(floor((15238.0 * Double(j)) / 43)) + 29
        let m = Int(floor((24.0 * Double(l)) / 709))
        let d = l - Int(floor((709.0 * Double(m)) / 24))
        let y = 30 * n + j - 30
        return HDate(y: y, m: m, d: d)
    }

    static func hijriToJd(_ y: Int, _ m: Int, _ d: Int, adj: Int = 0) -> Int {
        Int(floor((11.0 * Double(y) + 3) / 30)) + 354 * y + 30 * m - Int(floor(Double(m - 1) / 2.0)) + d + 1948440 - 385 - adj
    }

    static func jdToGreg(_ jdIn: Int) -> GDate {
        let a = jdIn + 32044
        let b = Int(floor((4.0 * Double(a) + 3) / 146097))
        let c = a - Int(floor((146097.0 * Double(b)) / 4))
        let dd = Int(floor((4.0 * Double(c) + 3) / 1461))
        let e = c - Int(floor((1461.0 * Double(dd)) / 4))
        let m = Int(floor((5.0 * Double(e) + 2) / 153))
        let day = e - Int(floor((153.0 * Double(m) + 2) / 5)) + 1
        let month = m + 3 - 12 * Int(floor(Double(m) / 10.0))
        let year = 100 * b + dd - 4800 + Int(floor(Double(m) / 10.0))
        return GDate(y: year, m: month, d: day)
    }

    static func jd(of date: Date) -> Int {
        let c = Calendar(identifier: .gregorian).dateComponents([.year, .month, .day], from: date)
        return gToJd(c.year ?? 2026, c.month ?? 1, c.day ?? 1)
    }

    static func date(fromJd jd: Int) -> Date {
        let g = jdToGreg(jd)
        return Calendar(identifier: .gregorian).date(from: DateComponents(year: g.y, month: g.m, day: g.d, hour: 12)) ?? Date()
    }

    static func today(adj: Int = 0) -> HDate { jdToHijri(jd(of: Date()), adj: adj) }

    static func monthLength(_ y: Int, _ m: Int, adj: Int = 0) -> Int {
        let jd1 = hijriToJd(y, m, 1, adj: adj)
        let ny = m == 12 ? y + 1 : y
        let nm = m == 12 ? 1 : m + 1
        let days = hijriToJd(ny, nm, 1, adj: adj) - jd1
        return min(30, max(29, days))
    }

    /// 0 = Sunday … 6 = Saturday, for a Julian day number.
    static func weekday(ofJd jd: Int) -> Int { (jd + 1) % 7 }

    static func format(_ h: HDate) -> String { "\(h.d.ar) \(months[max(0, min(11, h.m - 1))]) \(h.y.ar) هـ" }
}
