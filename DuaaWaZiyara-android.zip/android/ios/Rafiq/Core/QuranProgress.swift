import Foundation

/// Quran reading progress measured in verses, the unit the narrations use:
/// «تُكتب له مكان كلّ آيةٍ يقرؤها عشر حسنات» (al-Kafi 2, Fadl al-Quran ch. 7, sahih),
/// «ينبغي… أن يقرأ منه في كلّ يومٍ خمسين آية» (ch. 5, hasan).
///
/// The reader reports the furthest verse reached in each surah; a khatma completes when every
/// verse has been reached, then a new one starts. Points = verses read (one per verse, lifetime).
enum QuranProgress {
    // Keys
    private static let reachKey = "qpReach"        // "s:v,s:v" furthest verse per surah, current khatma
    private static let lifetimeKey = "qpLifetime"  // verses read, all time (= points)
    private static let khatmasKey = "qpKhatmas"    // completed khatmas
    private static let histKey = "qpAyatHist"      // verses per day
    private static let listenKey = "qpListenHist"  // surahs listened to the end, per day
    static let goalKey = "qpGoal"                  // daily verse goal
    static let planDaysKey = "qpPlanDays"          // khatma plan length (0 = none)
    static let planStartKey = "qpPlanStart"
    private static let migratedKey = "qpMigrated"

    // MARK: Static Quran structure (from the bundled text)

    /// Verse count per surah, index 0 = Al-Fatiha.
    static let verseCounts: [Int] = {
        guard let c = Library.category("quran") else { return Array(repeating: 1, count: 114) }
        return c.items.map { max(1, maxVerse(in: $0.text)) }
    }()

    static var totalVerses: Int { verseCounts.reduce(0, +) }

    /// Global index (0-based) of the first verse of each surah.
    static let surahOffsets: [Int] = {
        var out: [Int] = []
        var acc = 0
        for n in verseCounts { out.append(acc); acc += n }
        return out
    }()

    /// Largest "(n)" verse marker in a piece of text (Western or Arabic-Indic digits).
    static func maxVerse(in text: String) -> Int {
        var best = 0
        var i = text.startIndex
        while let open = text[i...].firstIndex(of: "(") {
            guard let close = text[open...].firstIndex(of: ")") else { break }
            let inner = String(text[text.index(after: open)..<close]).westernDigits
            if inner.count <= 3, let n = Int(inner) { best = max(best, n) }
            i = text.index(after: close)
        }
        return best
    }

    static func surahNumber(_ itemId: String) -> Int? {
        guard itemId.hasPrefix("q-"), let n = Int(itemId.dropFirst(2)), (1...114).contains(n) else { return nil }
        return n
    }

    // MARK: State

    static func reach(_ s: Store) -> [Int: Int] {
        var out: [Int: Int] = [:]
        for part in s.string(reachKey).split(separator: ",") {
            let p = part.split(separator: ":")
            if p.count == 2, let k = Int(p[0]), let v = Int(p[1]) { out[k] = v }
        }
        return out
    }

    private static func saveReach(_ s: Store, _ m: [Int: Int]) {
        s.put(reachKey, m.sorted { $0.key < $1.key }.map { "\($0.key):\($0.value)" }.joined(separator: ","))
    }

    static func lifetime(_ s: Store) -> Int { s.int(lifetimeKey, 0) }
    static func khatmas(_ s: Store) -> Int { s.int(khatmasKey, 0) }
    static func goal(_ s: Store) -> Int { s.int(goalKey, 50) }
    static func today(_ s: Store) -> Int { s.seriesValue(histKey, offset: 0) }
    static func history(_ s: Store) -> [Int: Int] { s.series(histKey) }
    static func listenedToday(_ s: Store) -> Int { s.seriesValue(listenKey, offset: 0) }
    static func listenedTotal(_ s: Store) -> Int { s.series(listenKey).values.reduce(0, +) }

    /// Verses reached in the current khatma.
    static func khatmaVerses(_ s: Store) -> Int {
        let r = reach(s)
        return (1...114).reduce(0) { $0 + min(r[$1] ?? 0, verseCounts[$1 - 1]) }
    }

    static func khatmaFraction(_ s: Store) -> Double {
        Double(khatmaVerses(s)) / Double(max(1, totalVerses))
    }

    static func surahFraction(_ s: Store, _ n: Int) -> Double {
        Double(min(reach(s)[n] ?? 0, verseCounts[n - 1])) / Double(verseCounts[n - 1])
    }

    /// Where to continue: the first surah not finished, and the next verse in it.
    static func next(_ s: Store) -> (surah: Int, verse: Int) {
        let r = reach(s)
        for n in 1...114 where (r[n] ?? 0) < verseCounts[n - 1] { return (n, (r[n] ?? 0) + 1) }
        return (1, 1)
    }

    /// Fraction of each of the 30 juz covered in the current khatma.
    static func juzFractions(_ s: Store) -> [Double] {
        let starts = Library.shared.juz
        guard starts.sura.count == 30, starts.aya.count == 30 else { return Array(repeating: 0, count: 30) }
        func globalIndex(_ sura: Int, _ aya: Int) -> Int { surahOffsets[max(0, min(113, sura - 1))] + max(0, aya - 1) }
        let r = reach(s)
        var out: [Double] = []
        for j in 0..<30 {
            let a = globalIndex(starts.sura[j], starts.aya[j])
            let b = j < 29 ? globalIndex(starts.sura[j + 1], starts.aya[j + 1]) : totalVerses
            var covered = 0
            for n in 1...114 {
                let lo = surahOffsets[n - 1], read = min(r[n] ?? 0, verseCounts[n - 1])
                let hi = lo + read                       // covered range [lo, hi)
                covered += max(0, min(hi, b) - max(lo, a))
            }
            out.append(Double(covered) / Double(max(1, b - a)))
        }
        return out
    }

    /// Plan: verses per day needed to finish the khatma on time (nil without a plan).
    static func planDaily(_ s: Store) -> (perDay: Int, daysLeft: Int, onTrack: Bool)? {
        let days = s.int(planDaysKey, 0)
        guard days > 0 else { return nil }
        let elapsed = max(0, s.today - s.int(planStartKey, s.today))
        let daysLeft = max(1, days - elapsed)
        let remaining = max(0, totalVerses - khatmaVerses(s))
        let perDay = Int((Double(remaining) / Double(daysLeft)).rounded(.up))
        let expected = Int(Double(totalVerses) * min(1, Double(elapsed) / Double(days)))
        return (perDay, daysLeft, khatmaVerses(s) >= expected)
    }

    static func startPlan(_ s: Store, days: Int) {
        s.put(planDaysKey, max(0, days))
        s.put(planStartKey, s.today)
        if days > 0 { s.put(goalKey, max(1, Int((Double(totalVerses) / Double(days)).rounded(.up)))) }
    }

    /// Consecutive days with at least one verse read, ending today or yesterday.
    static func streak(_ s: Store) -> Int {
        let m = history(s)
        var day = (m[s.today] ?? 0) > 0 ? s.today : s.today - 1
        var n = 0
        while (m[day] ?? 0) > 0 { n += 1; day -= 1 }
        return n
    }

    static func level(_ points: Int) -> (name: String, num: Int, next: Int?) {
        let steps: [(Int, String)] = [(0, "مبتدئ"), (50, "قارئ ناشئ"), (500, "قارئ مواظب"),
                                      (2000, "قارئ متقدّم"), (6236, "خاتمٌ للقرآن"), (18708, "صاحب القرآن")]
        var idx = 0
        for (i, st) in steps.enumerated() where points >= st.0 { idx = i }
        let next = idx + 1 < steps.count ? steps[idx + 1].0 : nil
        return (steps[idx].1, idx + 1, next)
    }

    // MARK: Recording

    struct Event { let verses: Int; let surahDone: Bool; let khatmaDone: Bool }

    /// Records that verses up to `verse` of `surah` were read. Only new verses count.
    @discardableResult
    static func record(_ s: Store, surah: Int, upTo verse: Int) -> Event {
        migrate(s)
        guard (1...114).contains(surah) else { return Event(verses: 0, surahDone: false, khatmaDone: false) }
        let count = verseCounts[surah - 1]
        var r = reach(s)
        let old = min(r[surah] ?? 0, count)
        let new = min(max(0, verse), count)
        guard new > old else { return Event(verses: 0, surahDone: false, khatmaDone: false) }
        let delta = new - old
        r[surah] = new
        s.put(lifetimeKey, lifetime(s) + delta)
        s.setSeries(histKey, day: s.today, value: today(s) + delta, keepDays: 400)
        let surahDone = new >= count
        var khatmaDone = false
        if surahDone && (1...114).allSatisfy({ (r[$0] ?? 0) >= verseCounts[$0 - 1] }) {
            khatmaDone = true
            s.put(khatmasKey, khatmas(s) + 1)
            r = [:]                                  // a new khatma starts
            if s.int(planDaysKey, 0) > 0 { s.put(planStartKey, s.today) }
        }
        saveReach(s, r)
        return Event(verses: delta, surahDone: surahDone, khatmaDone: khatmaDone)
    }

    /// Listening to a whole surah is tracked separately (it is not counted as reading).
    static func recordListened(_ s: Store, surah: Int) {
        guard (1...114).contains(surah) else { return }
        s.setSeries(listenKey, day: s.today, value: listenedToday(s) + 1, keepDays: 400)
    }

    static func resetKhatma(_ s: Store) {
        saveReach(s, [:])
        if s.int(planDaysKey, 0) > 0 { s.put(planStartKey, s.today) }
    }

    /// One-time import of the old per-surah ticks: finished surahs count as fully read.
    static func migrate(_ s: Store) {
        guard !s.bool(migratedKey, false) else { return }
        s.put(migratedKey, true)
        let old = s.string("quranDone").split(separator: ",").compactMap { surahNumber(String($0)) }
        guard !old.isEmpty else { return }
        var r = reach(s)
        var added = 0
        for n in old where (r[n] ?? 0) < verseCounts[n - 1] {
            added += verseCounts[n - 1] - (r[n] ?? 0)
            r[n] = verseCounts[n - 1]
        }
        saveReach(s, r)
        s.put(lifetimeKey, lifetime(s) + added)
    }
}
