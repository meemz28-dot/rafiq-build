import Foundation

/// Searches open audio sources that publish files for listening and downloading:
/// Internet Archive, podcast episodes (Apple's public podcast directory), and Quran recitations (mp3quran.net).
enum AudioSearch {

    struct ArchiveHit: Identifiable, Hashable {
        let id: String          // archive.org identifier
        let title: String
        let creator: String
        let license: String?
    }

    // MARK: Helpers

    private static func get(_ url: URL) async -> Any? {
        var req = URLRequest(url: url)
        req.timeoutInterval = 20
        req.setValue("RafiqAlMumin-iOS", forHTTPHeaderField: "User-Agent")
        guard let (data, resp) = try? await URLSession.shared.data(for: req),
              let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { return nil }
        return try? JSONSerialization.jsonObject(with: data)
    }

    private static func enc(_ s: String) -> String {
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "&+=?#")
        return s.addingPercentEncoding(withAllowedCharacters: allowed) ?? s
    }

    /// Archive fields can be a string or an array of strings.
    private static func str(_ v: Any?) -> String? {
        if let s = v as? String { return s }
        if let a = v as? [Any] { return a.compactMap { $0 as? String }.first }
        if let n = v as? NSNumber { return n.stringValue }
        return nil
    }

    private static func seconds(_ v: Any?) -> Double? {
        guard let s = str(v) else { return nil }
        if let d = Double(s) { return d }
        let parts = s.split(separator: ":").compactMap { Double($0) }
        guard !parts.isEmpty else { return nil }
        return parts.reduce(0) { $0 * 60 + $1 }
    }

    // MARK: Internet Archive

    static func archive(_ q: String) async -> [ArchiveHit] {
        let query = "(\(q)) AND mediatype:(audio)"
        let s = "https://archive.org/advancedsearch.php?q=\(enc(query))&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&fl%5B%5D=licenseurl&sort%5B%5D=downloads+desc&rows=30&page=1&output=json"
        guard let url = URL(string: s),
              let root = await get(url) as? [String: Any],
              let response = root["response"] as? [String: Any],
              let docs = response["docs"] as? [[String: Any]] else { return [] }
        return docs.compactMap { d in
            guard let id = str(d["identifier"]) else { return nil }
            return ArchiveHit(id: id, title: str(d["title"]) ?? id, creator: str(d["creator"]) ?? "",
                              license: str(d["licenseurl"]))
        }
    }

    /// The playable files of one archive item (MP3 / M4A), one per recording.
    static func archiveFiles(_ hit: ArchiveHit) async -> [AudioItem] {
        guard let url = URL(string: "https://archive.org/metadata/\(enc(hit.id))"),
              let root = await get(url) as? [String: Any],
              let files = root["files"] as? [[String: Any]] else { return [] }
        let rank: [String: Int] = ["VBR MP3": 0, "MP3": 1, "128Kbps MP3": 2, "64Kbps MP3": 3, "M4A": 4, "Apple Lossless Audio": 9]
        var best: [String: (rank: Int, file: [String: Any])] = [:]
        var order: [String] = []
        for f in files {
            guard let name = str(f["name"]) else { continue }
            let lower = name.lowercased()
            guard lower.hasSuffix(".mp3") || lower.hasSuffix(".m4a") else { continue }
            let format = str(f["format"]) ?? ""
            let r = rank[format] ?? 5
            let base = (name as NSString).deletingPathExtension
                .replacingOccurrences(of: "_64kb", with: "").replacingOccurrences(of: "_128kb", with: "")
            if let cur = best[base] {
                if r < cur.rank { best[base] = (r, f) }
            } else {
                best[base] = (r, f)
                order.append(base)
            }
        }
        var pathAllowed = CharacterSet.urlPathAllowed
        pathAllowed.remove(charactersIn: "?#")
        return order.compactMap { base -> AudioItem? in
            guard let f = best[base]?.file, let name = str(f["name"]) else { return nil }
            let path = name.addingPercentEncoding(withAllowedCharacters: pathAllowed) ?? name
            let u = "https://archive.org/download/\(hit.id)/\(path)"
            let title = str(f["title"]) ?? (name as NSString).deletingPathExtension
            return AudioItem.remote(title: title, subtitle: hit.creator.isEmpty ? hit.title : hit.creator,
                                    url: u, source: .archive, license: hit.license, duration: seconds(f["length"]))
        }
    }

    // MARK: Podcasts (episodes)

    static func podcastEpisodes(_ q: String) async -> [AudioItem] {
        var out: [AudioItem] = []
        var seen = Set<String>()
        for country in ["ae", "sa", "us"] {
            let s = "https://itunes.apple.com/search?media=podcast&entity=podcastEpisode&limit=25&country=\(country)&term=\(enc(q))"
            guard let url = URL(string: s), let root = await get(url) as? [String: Any],
                  let results = root["results"] as? [[String: Any]] else { continue }
            for r in results {
                guard let u = str(r["episodeUrl"]), !seen.contains(u) else { continue }
                seen.insert(u)
                let ms = (r["trackTimeMillis"] as? NSNumber)?.doubleValue
                out.append(.remote(title: str(r["trackName"]) ?? "حلقة", subtitle: str(r["collectionName"]) ?? "",
                                   url: u, source: .podcast, duration: ms.map { $0 / 1000 }))
            }
            if out.count >= 30 { break }
        }
        return out
    }

    // MARK: Quran (mp3quran.net)

    struct Reciter { let name: String; let server: String; let surahs: Set<Int> }

    private final class QuranCache {
        var suwar: [Int: String] = [:]
        var reciters: [Reciter] = []
    }
    private static let cache = QuranCache()

    private static func loadQuran() async {
        if cache.suwar.isEmpty, let url = URL(string: "https://mp3quran.net/api/v3/suwar?language=ar"),
           let root = await get(url) as? [String: Any], let list = root["suwar"] as? [[String: Any]] {
            for s in list {
                if let id = (s["id"] as? NSNumber)?.intValue, let n = str(s["name"]) {
                    cache.suwar[id] = n.trimmingCharacters(in: .whitespaces)
                }
            }
        }
        if cache.reciters.isEmpty, let url = URL(string: "https://mp3quran.net/api/v3/reciters?language=ar"),
           let root = await get(url) as? [String: Any], let list = root["reciters"] as? [[String: Any]] {
            var rs: [Reciter] = []
            for r in list {
                guard let name = str(r["name"]), let moshafs = r["moshaf"] as? [[String: Any]],
                      let m = moshafs.first, let server = str(m["server"]) else { continue }
                let surahs = Set((str(m["surah_list"]) ?? "").split(separator: ",").compactMap { Int($0) })
                rs.append(Reciter(name: name, server: server.hasSuffix("/") ? server : server + "/", surahs: surahs))
            }
            cache.reciters = rs
        }
    }

    private static func item(_ r: Reciter, _ n: Int) -> AudioItem {
        let name = cache.suwar[n] ?? "\(n)"
        return .remote(title: "سورة \(name)", subtitle: r.name, url: r.server + String(format: "%03d.mp3", n), source: .quran)
    }

    /// Matches surah names and reciter names. "سورة الكهف" gives Al-Kahf by several reciters,
    /// a reciter's name gives that reciter's surahs, both give the exact recitation.
    static func quran(_ q: String) async -> [AudioItem] {
        await loadQuran()
        var nq = ArabicSearch.normalize(q)
        for p in ["سوره ", "سورة "] where nq.hasPrefix(p) { nq = String(nq.dropFirst(p.count)) }
        let terms = nq.split(separator: " ").map(String.init).filter { $0.count >= 2 }
        guard !terms.isEmpty else { return [] }
        let surahMatches = cache.suwar.filter { (_, name) in
            let n = ArabicSearch.normalize(name)
            return terms.contains { n == $0 || (n.count > 3 && n.contains($0)) || (n.hasPrefix("ال") && String(n.dropFirst(2)) == $0) }
        }.keys.sorted()
        let reciterMatches = cache.reciters.filter { r in
            let n = ArabicSearch.normalize(r.name)
            return terms.contains { $0.count >= 3 && n.contains($0) }
        }
        var out: [AudioItem] = []
        if !surahMatches.isEmpty && !reciterMatches.isEmpty {
            for r in reciterMatches.prefix(5) { for s in surahMatches where r.surahs.contains(s) { out.append(item(r, s)) } }
        } else if !surahMatches.isEmpty {
            for s in surahMatches.prefix(6) {
                for r in cache.reciters.filter({ $0.surahs.contains(s) }).prefix(8) { out.append(item(r, s)) }
            }
        } else if let r = reciterMatches.first {
            for s in r.surahs.sorted() { out.append(item(r, s)) }
        }
        return Array(out.prefix(60))
    }

    // MARK: Direct link

    static func linkItem(_ text: String) -> AudioItem? {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let u = URL(string: t), let scheme = u.scheme?.lowercased(), scheme == "https" || scheme == "http" else { return nil }
        let name = (u.deletingPathExtension().lastPathComponent.removingPercentEncoding ?? u.lastPathComponent)
        return .remote(title: name.isEmpty ? "تسجيل" : name, subtitle: u.host ?? "رابط", url: t, source: .link)
    }
}
