import Foundation

/// Searches open audio sources that publish files for listening and downloading:
/// Internet Archive, podcast episodes (Apple's public podcast directory), and Quran recitations (mp3quran.net).
enum AudioSearch {

    struct ArchiveHit: Identifiable, Hashable {
        let id: String          // archive.org identifier
        let title: String
        let creator: String
        let license: String?
    }

    // MARK: Helpers

    private static func get(_ url: URL) async -> Any? {
        var req = URLRequest(url: url)
        req.timeoutInterval = 20
        req.setValue("RafiqAlMumin-iOS", forHTTPHeaderField: "User-Agent")
        guard let (data, resp) = try? await URLSession.shared.data(for: req),
              let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { return nil }
        return try? JSONSerialization.jsonObject(with: data)
    }

    private static func enc(_ s: String) -> String {
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "&+=?#")
        return s.addingPercentEncoding(withAllowedCharacters: allowed) ?? s
    }

    /// Archive fields can be a string or an array of strings.
    private static func str(_ v: Any?) -> String? {
        if let s = v as? String { return s }
        if let a = v as? [Any] { return a.compactMap { $0 as? String }.first }
        if let n = v as? NSNumber { return n.stringValue }
        return nil
    }

    private static func seconds(_ v: Any?) -> Double? {
        guard let s = str(v) else { return nil }
        if let d = Double(s) { return d }
        let parts = s.split(separator: ":").compactMap { Double($0) }
        guard !parts.isEmpty else { return nil }
        return parts.reduce(0) { $0 * 60 + $1 }
    }

    // MARK: Query expansion (Arabic and common English transliterations find each other)

    private static let synonyms: [[String]] = [
        ["دعاء", "ادعيه", "أدعية", "dua", "duaa", "dua'a", "supplication"],
        ["كميل", "kumayl", "kumail", "komail", "kumeel"],
        ["زياره", "زيارة", "ziyarat", "ziarat", "ziyara", "ziyarah"],
        ["عاشوراء", "ashura", "ashoora", "ashura"],
        ["توسل", "tawassul", "tawasul", "tawassal"],
        ["ندبه", "ندبة", "nudba", "nudbah", "nudbah"],
        ["جوشن", "jawshan", "joshan", "jaushan"],
        ["صباح", "sabah", "sabaah"],
        ["عهد", "ahad", "ahd"],
        ["سمات", "simat", "samaat", "simaat"],
        ["افتتاح", "iftitah", "iftetah"],
        ["ابو حمزه", "abu hamza", "abuhamza"],
        ["عرفه", "عرفة", "arafa", "arafah", "arafat"],
        ["جامعه", "جامعة", "jamia", "jamea", "jamiah"],
        ["وارث", "warith", "waris"],
        ["امين الله", "aminallah", "ameenallah"],
        ["ال ياسين", "aal yasin", "ale yasin", "aale yaseen"],
        ["حديث الكساء", "hadith kisa", "hadees e kisa", "kisa"],
        ["مناجاه", "مناجاة", "munajat", "munajaat"],
        ["الصحيفه السجاديه", "sahifa sajjadia", "sahifa sajjadiya"],
        ["قران", "قرآن", "quran", "koran"],
        ["مجلس", "مجالس", "majlis", "majalis"],
        ["لطميه", "لطمية", "latmiya", "latmia", "noha", "nauha"],
        ["فاني", "fani"], ["باسم الكربلائي", "الكربلائي", "basim karbalaei", "karbalaei", "karbalai"],
        ["الحلواجي", "halwachi", "halawachi", "alhalwachi"],
        ["فرهمند", "farahmand"], ["الصابري", "sabri"], ["سماواتي", "samavati", "samawati"],
        ["الاكرف", "akraf", "alakraf"], ["ميثم التمار", "maytham al tammar", "maitham tammar"],
        ["يستشير", "yastashir"], ["مشلول", "mashlool", "mashlul"]
    ]

    /// The query plus its known Arabic/English equivalents (at most 4 variants). Every known word is
    /// translated together, so "كميل باسم الكربلائي" also searches "kumayl basim karbalaei" (not a mix).
    static func expand(_ q: String) -> [String] {
        let nq = ArabicSearch.normalize(q).lowercased()
        var hits: [(hit: String, latin: [String], arabic: [String])] = []
        for group in synonyms {
            let ng = group.map { ArabicSearch.normalize($0).lowercased() }.filter { !$0.isEmpty }
            guard let hit = ng.filter({ nq.contains($0) }).max(by: { $0.count < $1.count }) else { continue }
            if hits.contains(where: { $0.hit.contains(hit) || hit.contains($0.hit) }) { continue }
            let alts = ng.filter { $0 != hit }
            hits.append((hit, alts.filter(isLatin), alts.filter { !isLatin($0) }))
        }
        var out: [String] = [q]
        func add(_ v: String) { if !out.contains(v) && out.count < 4 { out.append(v) } }
        for i in 0..<2 {
            var v = nq
            var changed = false
            for h in hits where !h.latin.isEmpty {
                v = v.replacingOccurrences(of: h.hit, with: h.latin[min(i, h.latin.count - 1)])
                changed = true
            }
            if changed { add(v) }
        }
        var v = nq
        var changed = false
        for h in hits where !h.arabic.isEmpty {
            v = v.replacingOccurrences(of: h.hit, with: h.arabic[0])
            changed = true
        }
        if changed { add(v) }
        return out
    }


    // MARK: Topic vs reciter (the dua decides what matches, the reciter only ranks)

    private static let reciterNames: [String] = [
        "باسم الكربلائي", "الكربلائي", "basim karbalaei", "karbalaei", "karbalai", "علي فاني", "فاني", "fani",
        "اباذر الحلواجي", "الحلواجي", "halwachi", "halawachi", "alhalwachi", "فرهمند", "farahmand",
        "الصابري", "sabri", "مهدي سماواتي", "سماواتي", "samavati", "samawati", "حسين الاكرف", "الاكرف", "akraf",
        "alakraf", "ميثم التمار", "maytham al tammar", "maitham tammar", "يستشير", "yastashir", "مشلول", "mashlool", "mashlul"
    ].map { ArabicSearch.normalize($0).lowercased() }.sorted { $0.count > $1.count }

    /// Words that mean the user wants a dua/ziyara/majlis, never a Quran recitation.
    private static let devotionalWords: [String] = [
        "دعاء", "ادعيه", "زياره", "مناجاه", "حديث الكساء", "توسل", "كميل", "ندبه", "جوشن", "سمات", "افتتاح",
        "عرفه", "جامعه", "وارث", "عاشوراء", "مجلس", "مجالس", "لطميه", "نعي", "قصيده", "dua", "ziyara", "ziyarat",
        "munajat", "latmiya", "noha", "majlis", "kumayl", "kumail", "tawassul", "nudba", "jawshan",
        "ال ياسين", "امين الله", "aal yasin", "ale yasin", "ashura", "warith", "jamia"
    ].map { ArabicSearch.normalize($0).lowercased() }

    /// Splits "دعاء كميل باسم الكربلائي" into topic "دعاء كميل" and reciter "باسم الكربلائي".
    static func split(_ q: String) -> (topic: String, reciter: String) {
        var t = " " + ArabicSearch.normalize(q).lowercased() + " "
        var found: [String] = []
        for r in reciterNames where t.contains(" " + r + " ") {
            t = t.replacingOccurrences(of: " " + r + " ", with: " ")
            found.append(r)
        }
        let topic = t.split(separator: " ").joined(separator: " ")
        return (topic, found.first ?? "")
    }

    static func isDevotional(_ q: String) -> Bool {
        let n = ArabicSearch.normalize(q).lowercased()
        return devotionalWords.contains { n.contains($0) }
    }

    /// Variants that must match: the topic when there is one, otherwise the reciter alone.
    static func topicVariants(_ q: String) -> [String] {
        let s = split(q)
        return expand(s.topic.isEmpty ? q : s.topic)
    }

    /// Items by the requested reciter first, keeping the original order otherwise.
    static func rankByReciter<T>(_ items: [T], _ q: String, text: (T) -> String) -> [T] {
        let r = split(q).reciter
        guard !r.isEmpty, !split(q).topic.isEmpty else { return items }
        let rv = expand(r)
        let a = items.filter { matches(text($0), rv) }
        let b = items.filter { !matches(text($0), rv) }
        return a + b
    }

    private static func isLatin(_ s: String) -> Bool {
        s.unicodeScalars.contains { $0.isASCII && CharacterSet.letters.contains($0) }
    }

    // MARK: Internet Archive

    /// True when every word of at least one variant appears in the text (Arabic-normalised, case-insensitive).
    static func matches(_ text: String, _ variants: [String]) -> Bool {
        let t = ArabicSearch.normalize(text).lowercased()
            .replacingOccurrences(of: "_", with: " ").replacingOccurrences(of: "-", with: " ")
        return variants.contains { v in
            let words = ArabicSearch.normalize(v).lowercased().split(separator: " ").map(String.init)
            return !words.isEmpty && words.allSatisfy { t.contains($0) }
        }
    }

    /// Title matches first (so a dua search is not flooded by items that only mention it),
    /// then a general search to fill up, then filtered by relevance.
    static func archive(_ q: String) async -> [ArchiveHit] {
        let vs = topicVariants(q)
        let titleQuery = "(" + vs.map { "title:(\($0))" }.joined(separator: " OR ") + ") AND mediatype:(audio)"
        var hits = await archiveQuery(titleQuery).filter { matches($0.title + " " + $0.creator, vs) }
        if hits.count < 12 {
            let general = "(" + vs.map { "(\($0))" }.joined(separator: " OR ") + ") AND mediatype:(audio)"
            let more = await archiveQuery(general)
            let have = Set(hits.map { $0.id })
            hits += more.filter { !have.contains($0.id) && matches($0.title + " " + $0.creator, vs) }
        }
        return rankByReciter(hits, q) { $0.title + " " + $0.creator }
    }

    private static func archiveQuery(_ query: String) async -> [ArchiveHit] {
        let s = "https://archive.org/advancedsearch.php?q=\(enc(query))&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&fl%5B%5D=licenseurl&sort%5B%5D=downloads+desc&rows=40&page=1&output=json"
        guard let url = URL(string: s),
              let root = await get(url) as? [String: Any],
              let response = root["response"] as? [String: Any],
              let docs = response["docs"] as? [[String: Any]] else { return [] }
        return docs.compactMap { d in
            guard let id = str(d["identifier"]) else { return nil }
            return ArchiveHit(id: id, title: str(d["title"]) ?? id, creator: str(d["creator"]) ?? "",
                              license: str(d["licenseurl"]))
        }
    }

    /// The playable files of one archive item (MP3 / M4A), one per recording.
    static func archiveFiles(_ hit: ArchiveHit) async -> [AudioItem] {
        guard let url = URL(string: "https://archive.org/metadata/\(enc(hit.id))"),
              let root = await get(url) as? [String: Any],
              let files = root["files"] as? [[String: Any]] else { return [] }
        let rank: [String: Int] = ["VBR MP3": 0, "MP3": 1, "128Kbps MP3": 2, "64Kbps MP3": 3, "M4A": 4, "Apple Lossless Audio": 9]
        var best: [String: (rank: Int, file: [String: Any])] = [:]
        var order: [String] = []
        for f in files {
            guard let name = str(f["name"]) else { continue }
            let lower = name.lowercased()
            guard lower.hasSuffix(".mp3") || lower.hasSuffix(".m4a") else { continue }
            let format = str(f["format"]) ?? ""
            let r = rank[format] ?? 5
            let base = (name as NSString).deletingPathExtension
                .replacingOccurrences(of: "_64kb", with: "").replacingOccurrences(of: "_128kb", with: "")
            if let cur = best[base] {
                if r < cur.rank { best[base] = (r, f) }
            } else {
                best[base] = (r, f)
                order.append(base)
            }
        }
        var pathAllowed = CharacterSet.urlPathAllowed
        pathAllowed.remove(charactersIn: "?#")
        return order.compactMap { base -> AudioItem? in
            guard let f = best[base]?.file, let name = str(f["name"]) else { return nil }
            let path = name.addingPercentEncoding(withAllowedCharacters: pathAllowed) ?? name
            let u = "https://archive.org/download/\(hit.id)/\(path)"
            let title = str(f["title"]) ?? (name as NSString).deletingPathExtension
            return AudioItem.remote(title: title, subtitle: hit.creator.isEmpty ? hit.title : hit.creator,
                                    url: u, source: .archive, license: hit.license, duration: seconds(f["length"]),
                                    artwork: "https://archive.org/services/img/\(hit.id)")
        }
    }

    /// The files of the top archive items, shown directly as playable, downloadable tracks.
    static func archiveTracks(_ hits: [ArchiveHit], query: String, items: Int = 8, perItem: Int = 6) async -> [AudioItem] {
        let vs = topicVariants(query)
        let top = Array(hits.prefix(items))
        var byIndex: [Int: [AudioItem]] = [:]
        await withTaskGroup(of: (Int, [AudioItem]).self) { group in
            for (i, h) in top.enumerated() {
                group.addTask {
                    let files = await archiveFiles(h)
                    // In a big collection keep the files that match; a matching collection title keeps all.
                    let relevant = matches(h.title + " " + h.creator, vs) ? files : files.filter { matches($0.title, vs) }
                    return (i, Array(relevant.prefix(perItem)))
                }
            }
            for await (i, files) in group { byIndex[i] = files }
        }
        return (0..<top.count).flatMap { byIndex[$0] ?? [] }
    }

    // MARK: Podcasts (episodes)

    static func podcastEpisodes(_ q: String) async -> [AudioItem] {
        var out: [AudioItem] = []
        var seen = Set<String>()
        let pairs: [(String, String)] = topicVariants(q).prefix(3).flatMap { v in ["ae", "us", "iq"].map { (v, $0) } }
        for (term, country) in pairs {
            let s = "https://itunes.apple.com/search?media=podcast&entity=podcastEpisode&limit=25&country=\(country)&term=\(enc(term))"
            guard let url = URL(string: s), let root = await get(url) as? [String: Any],
                  let results = root["results"] as? [[String: Any]] else { continue }
            for r in results {
                guard let u = str(r["episodeUrl"]), !seen.contains(u) else { continue }
                let text = (str(r["trackName"]) ?? "") + " " + (str(r["collectionName"]) ?? "") + " " + (str(r["description"]) ?? "")
                guard matches(text, topicVariants(q)) else { continue }
                seen.insert(u)
                let ms = (r["trackTimeMillis"] as? NSNumber)?.doubleValue
                out.append(.remote(title: str(r["trackName"]) ?? "حلقة", subtitle: str(r["collectionName"]) ?? "",
                                   url: u, source: .podcast, duration: ms.map { $0 / 1000 },
                                   artwork: str(r["artworkUrl600"]) ?? str(r["artworkUrl160"]) ?? str(r["artworkUrl100"])))
            }
            if out.count >= 45 { break }
        }
        return rankByReciter(out, q) { $0.title + " " + $0.subtitle }
    }

    // MARK: Quran (mp3quran.net)

    struct Reciter { let name: String; let server: String; let surahs: Set<Int> }

    private final class QuranCache {
        var suwar: [Int: String] = [:]
        var reciters: [Reciter] = []
    }
    private static let cache = QuranCache()

    private static func loadQuran() async {
        if cache.suwar.isEmpty, let url = URL(string: "https://mp3quran.net/api/v3/suwar?language=ar"),
           let root = await get(url) as? [String: Any], let list = root["suwar"] as? [[String: Any]] {
            for s in list {
                if let id = (s["id"] as? NSNumber)?.intValue, let n = str(s["name"]) {
                    cache.suwar[id] = n.trimmingCharacters(in: .whitespaces)
                }
            }
        }
        if cache.reciters.isEmpty, let url = URL(string: "https://mp3quran.net/api/v3/reciters?language=ar"),
           let root = await get(url) as? [String: Any], let list = root["reciters"] as? [[String: Any]] {
            var rs: [Reciter] = []
            for r in list {
                guard let name = str(r["name"]), let moshafs = r["moshaf"] as? [[String: Any]],
                      let m = moshafs.first, let server = str(m["server"]) else { continue }
                let surahs = Set((str(m["surah_list"]) ?? "").split(separator: ",").compactMap { Int($0) })
                rs.append(Reciter(name: name, server: server.hasSuffix("/") ? server : server + "/", surahs: surahs))
            }
            cache.reciters = rs
        }
    }

    /// All reciters with their surah lists (cached after the first call).
    static func quranReciters() async -> [Reciter] {
        await loadQuran()
        return cache.reciters
    }

    private static func item(_ r: Reciter, _ n: Int) -> AudioItem {
        let name = cache.suwar[n] ?? "\(n)"
        return .remote(title: "سورة \(name)", subtitle: r.name, url: r.server + String(format: "%03d.mp3", n), source: .quran)
    }

    /// Matches surah names and reciter names. "سورة الكهف" gives Al-Kahf by several reciters,
    /// a reciter's name gives that reciter's surahs, both give the exact recitation.
    static func quran(_ q: String) async -> [AudioItem] {
        if isDevotional(q) || !split(q).reciter.isEmpty { return [] }
        await loadQuran()
        var nq = ArabicSearch.normalize(q)
        for p in ["سوره ", "سورة "] where nq.hasPrefix(p) { nq = String(nq.dropFirst(p.count)) }
        let terms = nq.split(separator: " ").map(String.init).filter { $0.count >= 2 }
        guard !terms.isEmpty else { return [] }
        let surahMatches = cache.suwar.filter { (_, name) in
            let n = ArabicSearch.normalize(name)
            return terms.contains { n == $0 || (n.count > 3 && n.contains($0)) || (n.hasPrefix("ال") && String(n.dropFirst(2)) == $0) }
        }.keys.sorted()
        // A reciter matches only when every non-surah word of the query is part of their name.
        let surahWords = Set(terms.filter { t in cache.suwar.values.contains { ArabicSearch.normalize($0).contains(t) } })
        let nameTerms = terms.filter { !surahWords.contains($0) && $0 != "ال" }
        let reciterMatches = nameTerms.isEmpty ? [] : cache.reciters.filter { r in
            let words = Set(ArabicSearch.normalize(r.name).split(separator: " ").map(String.init))
            return nameTerms.allSatisfy { t in t.count >= 3 && (words.contains(t) || words.contains("ال" + t)) }
        }
        var out: [AudioItem] = []
        if !surahMatches.isEmpty && !reciterMatches.isEmpty {
            for r in reciterMatches.prefix(5) { for s in surahMatches where r.surahs.contains(s) { out.append(item(r, s)) } }
        } else if !surahMatches.isEmpty {
            for s in surahMatches.prefix(6) {
                for r in cache.reciters.filter({ $0.surahs.contains(s) }).prefix(8) { out.append(item(r, s)) }
            }
        } else if let r = reciterMatches.first {
            for s in r.surahs.sorted() { out.append(item(r, s)) }
        }
        return Array(out.prefix(60))
    }

    // MARK: Wikimedia Commons (openly licensed audio; non-MP3 files use Commons' MP3 transcode)

    static func commons(_ q: String) async -> [AudioItem] {
        var out: [AudioItem] = []
        var seen = Set<String>()
        for v in topicVariants(q).prefix(2) {
            let s = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrnamespace=6&gsrlimit=20&gsrsearch=\(enc("filetype:audio " + v))&prop=imageinfo&iiprop=url%7Csize%7Cextmetadata"
            guard let url = URL(string: s), let root = await get(url) as? [String: Any],
                  let query = root["query"] as? [String: Any],
                  let pages = query["pages"] as? [String: Any] else { continue }
            for (_, raw) in pages {
                guard let page = raw as? [String: Any], let title = str(page["title"]),
                      let infos = page["imageinfo"] as? [[String: Any]], let info = infos.first,
                      let fileURL = str(info["url"]), !seen.contains(fileURL) else { continue }
                seen.insert(fileURL)
                let lower = fileURL.lowercased()
                var playable = fileURL
                if !(lower.hasSuffix(".mp3") || lower.hasSuffix(".m4a") || lower.hasSuffix(".wav")) {
                    // upload.wikimedia.org/wikipedia/commons/a/ab/X.ogg -> .../transcoded/a/ab/X.ogg/X.ogg.mp3
                    guard let r = fileURL.range(of: "/wikipedia/commons/") else { continue }
                    let rest = String(fileURL[r.upperBound...])
                    let name = (rest as NSString).lastPathComponent
                    playable = String(fileURL[..<r.upperBound]) + "transcoded/" + rest + "/" + name + ".mp3"
                }
                let meta = info["extmetadata"] as? [String: Any]
                let lic = (meta?["LicenseShortName"] as? [String: Any]).flatMap { str($0["value"]) }
                let artist = (meta?["Artist"] as? [String: Any]).flatMap { str($0["value"]) }?
                    .replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
                let clean = (title.replacingOccurrences(of: "File:", with: "") as NSString).deletingPathExtension
                guard matches(clean, topicVariants(q)) else { continue }
                out.append(.remote(title: clean, subtitle: artist ?? "Wikimedia Commons", url: playable,
                                   source: .commons, license: lic ?? "CC"))
            }
        }
        return out
    }

    // MARK: Direct link

    static func linkItem(_ text: String) -> AudioItem? {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let u = URL(string: t), let scheme = u.scheme?.lowercased(), scheme == "https" || scheme == "http" else { return nil }
        let name = (u.deletingPathExtension().lastPathComponent.removingPercentEncoding ?? u.lastPathComponent)
        return .remote(title: name.isEmpty ? "تسجيل" : name, subtitle: u.host ?? "رابط", url: t, source: .link)
    }
}
