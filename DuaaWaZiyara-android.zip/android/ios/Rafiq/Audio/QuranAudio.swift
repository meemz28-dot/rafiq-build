import SwiftUI

/// The built-in "whole Quran" playlist: 114 surahs by the chosen reciter, auto-advancing.
enum QuranAudio {
    static let reciterKey = "quranReciter"
    static let lastKey = "quranLastSurah"
    /// Shown first in the reciter list (matched by name).
    static let preferred = ["عبدالباسط", "المنشاوي", "الحصري", "العفاسي", "الغامدي", "المعيقلي", "الطبلاوي", "الشاطري"]

    /// Reciters with a complete recording (114 surahs), preferred names first.
    static func reciters() async -> [AudioSearch.Reciter] {
        let all = await AudioSearch.quranReciters().filter { $0.surahs.count >= 114 }
        func rank(_ r: AudioSearch.Reciter) -> Int {
            let n = ArabicSearch.normalize(r.name)
            return preferred.firstIndex { n.contains(ArabicSearch.normalize($0)) } ?? 99
        }
        return all.sorted { a, b in
            let ra = rank(a), rb = rank(b)
            return ra != rb ? ra < rb : a.name < b.name
        }
    }

    static func selected(_ list: [AudioSearch.Reciter]) -> AudioSearch.Reciter? {
        let name = UserDefaults.standard.string(forKey: reciterKey) ?? ""
        return list.first { $0.name == name } ?? list.first
    }

    static func surahTitle(_ n: Int) -> String {
        if let c = Library.category("quran"), c.items.indices.contains(n - 1) { return c.items[n - 1].title }
        return "سورة \(n.ar)"
    }

    static func item(_ r: AudioSearch.Reciter, _ n: Int) -> AudioItem {
        .remote(title: surahTitle(n), subtitle: r.name, url: r.server + String(format: "%03d.mp3", n), source: .quran)
    }

    static func items(_ r: AudioSearch.Reciter) -> [AudioItem] {
        (1...114).filter { r.surahs.contains($0) }.map { item(r, $0) }
    }

    static func surahNumber(_ item: AudioItem) -> Int? {
        guard item.source == .quran, let u = item.remoteURL else { return nil }
        return Int(((u as NSString).lastPathComponent as NSString).deletingPathExtension)
    }

    /// Plays from surah `n` (1-based) to the end of the Quran with the saved reciter.
    @MainActor static func play(from n: Int = 1) async {
        let list = await reciters()
        guard let r = selected(list) else { return }
        let all = items(r)
        guard let start = all.firstIndex(where: { surahNumber($0) == n }) ?? all.indices.first else { return }
        AudioPlayer.shared.play(all[start], queue: all, name: "القرآن الكريم · \(r.name)")
    }
}

// MARK: - Card shown at the top of Listen

struct QuranPlaylistCard: View {
    let onOpen: () -> Void
    @AppStorage(QuranAudio.lastKey) private var last = 0
    @AppStorage(QuranAudio.reciterKey) private var reciterName = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                Image(systemName: "book.closed.fill")
                    .font(.title3).foregroundStyle(Brand.gold)
                VStack(alignment: .leading, spacing: 2) {
                    Text("القرآن الكريم كاملاً").font(.headline)
                    Text(reciterName.isEmpty ? "١١٤ سورة · تشغيل تلقائي" : "١١٤ سورة · \(reciterName)")
                        .font(.caption).foregroundStyle(.white.opacity(0.8)).lineLimit(1)
                }
                Spacer()
                Button(action: onOpen) {
                    Image(systemName: "list.bullet").font(.headline)
                        .frame(width: 36, height: 36)
                }
                .glassButton()
                .accessibilityLabel("السور والقرّاء")
            }
            HStack(spacing: 10) {
                Button {
                    Task { await QuranAudio.play(from: 1) }
                } label: {
                    Label("تشغيل من الفاتحة", systemImage: "play.fill").font(.subheadline.weight(.bold))
                        .frame(maxWidth: .infinity)
                }
                .glassButton(prominent: true)
                if last > 1 {
                    Button {
                        Task { await QuranAudio.play(from: last) }
                    } label: {
                        Label("متابعة: \(QuranAudio.surahTitle(last).replacingOccurrences(of: "سورة ", with: ""))",
                              systemImage: "arrow.uturn.backward").font(.subheadline.weight(.bold))
                            .lineLimit(1).frame(maxWidth: .infinity)
                    }
                    .glassButton()
                }
            }
        }
        .padding(16)
        .hero(22)
    }
}

// MARK: - Full Quran playlist screen

struct QuranPlaylistView: View {
    @State private var reciters: [AudioSearch.Reciter] = []
    @State private var loaded = false
    @State private var confirmDownload = false
    @State private var library = AudioLibrary.shared
    @State private var player = AudioPlayer.shared
    @State private var linkingItem: AudioItem?
    @AppStorage(QuranAudio.reciterKey) private var reciterName = ""

    private var reciter: AudioSearch.Reciter? {
        reciters.first { $0.name == reciterName } ?? reciters.first
    }
    private var items: [AudioItem] { reciter.map { QuranAudio.items($0) } ?? [] }

    var body: some View {
        List {
            Section {
                if !loaded {
                    HStack { Spacer(); ProgressView(); Spacer() }
                } else if reciters.isEmpty {
                    Text("تعذّر تحميل قائمة القرّاء. تحقّق من الاتصال ثم أعد المحاولة.").foregroundStyle(.secondary)
                } else {
                    Picker("القارئ", selection: Binding(get: { reciter?.name ?? "" }, set: { reciterName = $0 })) {
                        ForEach(reciters, id: \.name) { r in Text(r.name).tag(r.name) }
                    }
                    .pickerStyle(.navigationLink)
                    HStack(spacing: 10) {
                        Button {
                            if let r = reciter { player.playAll(QuranAudio.items(r), name: "القرآن الكريم · \(r.name)") }
                        } label: { Label("تشغيل الكلّ", systemImage: "play.fill").frame(maxWidth: .infinity) }
                        .buttonStyle(.borderedProminent).tint(Brand.emerald)
                        Button {
                            if let r = reciter { player.playAll(QuranAudio.items(r), name: "القرآن الكريم · \(r.name)", shuffle: true) }
                        } label: { Label("عشوائي", systemImage: "shuffle").frame(maxWidth: .infinity) }
                        .buttonStyle(.bordered).tint(Brand.emerald)
                    }
                    let missing = items.filter { !library.isDownloaded($0.id) && !library.isDownloading($0.id) }
                    if !missing.isEmpty {
                        Button { confirmDownload = true } label: {
                            Label("تنزيل المصحف كاملاً للاستماع دون إنترنت (\(missing.count.ar) سورة)", systemImage: "arrow.down.circle")
                        }
                    } else {
                        Label("المصحف كاملاً منزّل على جهازك", systemImage: "checkmark.circle.fill").foregroundStyle(Brand.good)
                    }
                }
            } footer: {
                Text("التشغيل ينتقل تلقائياً من سورة إلى التي تليها حتى الختام. التسجيلات من mp3quran.net.")
            }
            if !items.isEmpty {
                Section("السور") {
                    ForEach(items) { it in
                        ListenRow(item: it, queue: items, linkTarget: nil, onLink: { _ in }, onMore: { linkingItem = $0 })
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("القرآن الكريم")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            reciters = await QuranAudio.reciters()
            loaded = true
        }
        .confirmationDialog("تنزيل المصحف كاملاً", isPresented: $confirmDownload, titleVisibility: .visible) {
            Button("تنزيل ١١٤ سورة") {
                for it in items where !library.isDownloaded(it.id) { library.download(it) }
                Haptic.confirm()
            }
            Button("إلغاء", role: .cancel) {}
        } message: {
            Text("الحجم نحو ١ إلى ٢ غيغابايت بحسب القارئ. يُفضَّل الاتصال بشبكة Wi‑Fi، ويستمرّ التنزيل حتى لو أغلقت التطبيق.")
        }
        .sheet(item: $linkingItem) { item in
            NavigationStack { ListenLinkDuaSheet(item: item) }
                .environment(\.layoutDirection, .rightToLeft)
        }
    }
}
