import Foundation
import AVFoundation
import MediaPlayer
import Observation
import UIKit

// MARK: - Model

enum AudioSource: String, Codable, CaseIterable, Identifiable {
    case archive, podcast, quran, link, file, commons
    var id: String { rawValue }

    var name: String {
        switch self {
        case .archive: return "أرشيف الإنترنت"
        case .podcast: return "بودكاست"
        case .quran: return "القرآن الكريم"
        case .link: return "رابط"
        case .file: return "ملف"
        case .commons: return "ويكيميديا كومنز"
        }
    }

    var symbol: String {
        switch self {
        case .archive: return "building.columns"
        case .podcast: return "antenna.radiowaves.left.and.right"
        case .quran: return "book.closed"
        case .link: return "link"
        case .file: return "doc"
        case .commons: return "globe"
        }
    }
}

struct AudioItem: Codable, Identifiable, Hashable {
    var id: String
    var title: String
    var subtitle: String
    var remoteURL: String?
    var source: AudioSource
    var license: String?
    var duration: Double?
    var localName: String?
    var addedAt: Date = Date()

    static func remote(title: String, subtitle: String, url: String, source: AudioSource,
                       license: String? = nil, duration: Double? = nil) -> AudioItem {
        AudioItem(id: source.rawValue + ":" + url, title: title, subtitle: subtitle, remoteURL: url,
                  source: source, license: license, duration: duration, localName: nil)
    }
}

struct AudioPlaylist: Codable, Identifiable, Hashable {
    var id: String = UUID().uuidString
    var name: String
    var itemIds: [String] = []
}

enum AudioFormat {
    /// "١:٠٣:٢٠" or "٣:٢٠".
    static func time(_ s: Double?) -> String {
        guard let s, s.isFinite, s >= 0 else { return "" }
        let t = Int(s.rounded())
        let h = t / 3600, m = (t % 3600) / 60, sec = t % 60
        let str = h > 0 ? String(format: "%d:%02d:%02d", h, m, sec) : String(format: "%d:%02d", m, sec)
        return str.arabicDigits
    }

    static func bytes(_ b: Int64) -> String {
        let f = ByteCountFormatter()
        f.allowedUnits = [.useMB, .useGB]
        f.countStyle = .file
        return f.string(fromByteCount: b).arabicDigits
    }
}

// MARK: - Library (saved recordings, downloads, links to duas)

/// Offline audio library. Files live in Application Support/Audio (not backed up as user documents,
/// never shared). Downloads use a background URLSession so they continue when the app is closed.
@Observable
final class AudioLibrary {
    static let shared = AudioLibrary()

    var items: [AudioItem] = []
    /// Active downloads: item id -> fraction 0...1 (negative while the size is unknown).
    var progress: [String: Double] = [:]
    /// "catId|itemId" -> audio item id.
    var links: [String: String] = [:]
    var lastError: String?
    var playlists: [AudioPlaylist] = []

    @ObservationIgnored var backgroundCompletion: (() -> Void)?
    @ObservationIgnored private var pending: [String: AudioItem] = [:]
    @ObservationIgnored private let downloader = AudioDownloader()
    @ObservationIgnored private lazy var session: URLSession = {
        let c = URLSessionConfiguration.background(withIdentifier: "com.shirazi.rafiq.audio")
        c.sessionSendsLaunchEvents = true
        c.isDiscretionary = false
        c.allowsCellularAccess = true
        return URLSession(configuration: c, delegate: downloader, delegateQueue: nil)
    }()

    private struct FileModel: Codable {
        var items: [AudioItem]
        var links: [String: String]
        var pending: [AudioItem]
        var playlists: [AudioPlaylist]?
    }

    static var folder: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let dir = base.appendingPathComponent("Audio", isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }
    private static var indexURL: URL { folder.appendingPathComponent("library.json") }

    init() {
        if let data = try? Data(contentsOf: Self.indexURL),
           let m = try? JSONDecoder().decode(FileModel.self, from: data) {
            items = m.items
            links = m.links
            playlists = m.playlists ?? []
            for p in m.pending { pending[p.id] = p; progress[p.id] = -1 }
        }
        downloader.library = self
        // Reconnect to downloads that were running when the app was closed.
        session.getAllTasks { tasks in
            let live = Set(tasks.compactMap { $0.taskDescription })
            DispatchQueue.main.async {
                for id in Array(self.pending.keys) where !live.contains(id) {
                    self.pending[id] = nil
                    self.progress[id] = nil
                }
                self.save()
            }
        }
    }

    private func save() {
        let m = FileModel(items: items, links: links, pending: Array(pending.values), playlists: playlists)
        if let data = try? JSONEncoder().encode(m) { try? data.write(to: Self.indexURL, options: .atomic) }
    }

    // MARK: Queries

    func saved(_ id: String) -> AudioItem? { items.first { $0.id == id } }
    func isDownloaded(_ id: String) -> Bool { saved(id)?.localName != nil }
    func isDownloading(_ id: String) -> Bool { progress[id] != nil }

    func localURL(_ item: AudioItem) -> URL? {
        guard let name = (saved(item.id) ?? item).localName else { return nil }
        let u = Self.folder.appendingPathComponent(name)
        return FileManager.default.fileExists(atPath: u.path) ? u : nil
    }

    /// Local file when downloaded, else the remote stream.
    func playableURL(_ item: AudioItem) -> URL? {
        if let l = localURL(item) { return l }
        if let r = item.remoteURL { return URL(string: r) }
        return nil
    }

    var totalBytes: Int64 {
        items.compactMap { $0.localName }.reduce(Int64(0)) { sum, name in
            let p = Self.folder.appendingPathComponent(name).path
            let attrs = (try? FileManager.default.attributesOfItem(atPath: p)) ?? [:]
            let size = (attrs[.size] as? NSNumber)?.int64Value ?? 0
            return sum + size
        }
    }

    // MARK: Changes

    /// Keeps an item in the library without downloading it (a link to stream).
    func keep(_ item: AudioItem) {
        if saved(item.id) == nil { items.insert(item, at: 0); save() }
    }

    func download(_ item: AudioItem) {
        guard !isDownloaded(item.id), !isDownloading(item.id),
              let s = item.remoteURL, let url = URL(string: s) else { return }
        lastError = nil
        pending[item.id] = item
        progress[item.id] = -1
        let task = session.downloadTask(with: url)
        task.taskDescription = item.id
        task.resume()
        save()
    }

    func cancelDownload(_ id: String) {
        session.getAllTasks { tasks in
            tasks.filter { $0.taskDescription == id }.forEach { $0.cancel() }
        }
        pending[id] = nil
        progress[id] = nil
        save()
    }

    // MARK: Playlists

    @discardableResult
    func createPlaylist(_ name: String) -> AudioPlaylist {
        let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let p = AudioPlaylist(name: clean.isEmpty ? "قائمة \((playlists.count + 1).ar)" : clean)
        playlists.append(p)
        save()
        return p
    }

    func renamePlaylist(_ id: String, _ name: String) {
        guard let i = playlists.firstIndex(where: { $0.id == id }) else { return }
        let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if !clean.isEmpty { playlists[i].name = clean; save() }
    }

    func deletePlaylist(_ id: String) { playlists.removeAll { $0.id == id }; save() }

    func add(_ item: AudioItem, toPlaylist id: String) {
        guard let i = playlists.firstIndex(where: { $0.id == id }) else { return }
        keep(item)
        if !playlists[i].itemIds.contains(item.id) { playlists[i].itemIds.append(item.id) }
        save()
    }

    func removeFromPlaylist(_ id: String, at offsets: IndexSet) {
        guard let i = playlists.firstIndex(where: { $0.id == id }) else { return }
        for o in offsets.sorted(by: >) where o < playlists[i].itemIds.count { playlists[i].itemIds.remove(at: o) }
        save()
    }

    func movePlaylistItems(_ id: String, from: IndexSet, to: Int) {
        guard let i = playlists.firstIndex(where: { $0.id == id }) else { return }
        playlists[i].itemIds.move(fromOffsets: from, toOffset: to)
        save()
    }

    func playlist(_ id: String) -> AudioPlaylist? { playlists.first { $0.id == id } }
    func items(of p: AudioPlaylist) -> [AudioItem] { p.itemIds.compactMap { saved($0) } }

    func delete(_ item: AudioItem) {
        if let name = saved(item.id)?.localName {
            try? FileManager.default.removeItem(at: Self.folder.appendingPathComponent(name))
        }
        items.removeAll { $0.id == item.id }
        links = links.filter { $0.value != item.id }
        for i in playlists.indices { playlists[i].itemIds.removeAll { $0 == item.id } }
        save()
    }

    /// Removes the downloaded file but keeps the item as a stream link.
    func removeDownload(_ item: AudioItem) {
        guard let i = items.firstIndex(where: { $0.id == item.id }), let name = items[i].localName else { return }
        try? FileManager.default.removeItem(at: Self.folder.appendingPathComponent(name))
        if items[i].remoteURL == nil { items.remove(at: i) } else { items[i].localName = nil }
        save()
    }

    func link(_ item: AudioItem, catId: String, itemId: String) {
        keep(item)
        links["\(catId)|\(itemId)"] = item.id
        save()
    }

    func unlink(catId: String, itemId: String) {
        links["\(catId)|\(itemId)"] = nil
        save()
    }

    func linked(catId: String, itemId: String) -> AudioItem? {
        guard let id = links["\(catId)|\(itemId)"] else { return nil }
        return saved(id)
    }

    func linkedDuaKeys(_ audioId: String) -> [String] { links.filter { $0.value == audioId }.map { $0.key } }

    /// Copies an audio file (from Files, or shared from another app) into the library.
    @discardableResult
    func importFile(_ url: URL) -> AudioItem? {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let ext = url.pathExtension.isEmpty ? "m4a" : url.pathExtension.lowercased()
        let name = UUID().uuidString + "." + ext
        let dest = Self.folder.appendingPathComponent(name)
        do { try FileManager.default.copyItem(at: url, to: dest) } catch {
            lastError = "تعذّر استيراد الملف"
            return nil
        }
        let title = url.deletingPathExtension().lastPathComponent
        let dur = CMTimeGetSeconds(AVURLAsset(url: dest).duration)
        let item = AudioItem(id: "file:" + name, title: title, subtitle: "ملف مستورد", remoteURL: nil,
                             source: .file, license: nil, duration: dur.isFinite ? dur : nil, localName: name)
        items.insert(item, at: 0)
        save()
        return item
    }

    // MARK: Called by the downloader (main thread)

    fileprivate func finished(id: String, fileName: String) {
        guard var item = pending[id] ?? saved(id) else { return }
        pending[id] = nil
        progress[id] = nil
        item.localName = fileName
        if let i = items.firstIndex(where: { $0.id == id }) { items[i] = item } else { items.insert(item, at: 0) }
        save()
    }

    fileprivate func failed(id: String, message: String?) {
        pending[id] = nil
        progress[id] = nil
        if let message { lastError = message }
        save()
    }

    fileprivate func update(id: String, fraction: Double) { progress[id] = fraction }
}

/// URLSession delegate (kept separate from the observable library).
private final class AudioDownloader: NSObject, URLSessionDownloadDelegate {
    weak var library: AudioLibrary?

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let id = downloadTask.taskDescription else { return }
        if let http = downloadTask.response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            DispatchQueue.main.async { self.library?.failed(id: id, message: "تعذّر التنزيل (\(http.statusCode))") }
            return
        }
        // A web page instead of audio means a broken or protected link: do not save it as a recording.
        let mime = downloadTask.response?.mimeType?.lowercased() ?? ""
        if mime.hasPrefix("text/") || mime.contains("html") || mime.contains("json") {
            DispatchQueue.main.async { self.library?.failed(id: id, message: "الرابط لا يشير إلى ملف صوتي") }
            return
        }
        // The temporary file must be moved before this method returns.
        var ext = downloadTask.response?.suggestedFilename.map { ($0 as NSString).pathExtension } ?? ""
        if ext.isEmpty { ext = downloadTask.originalRequest?.url?.pathExtension ?? "" }
        if ext.isEmpty || ext.count > 4 { ext = "mp3" }
        let name = UUID().uuidString + "." + ext.lowercased()
        let dest = AudioLibrary.folder.appendingPathComponent(name)
        do {
            try FileManager.default.moveItem(at: location, to: dest)
            DispatchQueue.main.async { self.library?.finished(id: id, fileName: name) }
        } catch {
            DispatchQueue.main.async { self.library?.failed(id: id, message: "تعذّر حفظ الملف") }
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard let id = downloadTask.taskDescription else { return }
        let f = totalBytesExpectedToWrite > 0 ? Double(totalBytesWritten) / Double(totalBytesExpectedToWrite) : -1
        DispatchQueue.main.async { self.library?.update(id: id, fraction: f) }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error, let id = task.taskDescription else { return }
        let cancelled = (error as NSError).code == NSURLErrorCancelled
        DispatchQueue.main.async { self.library?.failed(id: id, message: cancelled ? nil : "انقطع التنزيل، حاول مجدداً") }
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async {
            self.library?.backgroundCompletion?()
            self.library?.backgroundCompletion = nil
        }
    }
}

// MARK: - Player

/// One shared player: background playback, lock screen and Control Center controls, queue,
/// speed and sleep timer.
@Observable
final class AudioPlayer {
    static let shared = AudioPlayer()

    var current: AudioItem?
    var queue: [AudioItem] = []
    var isPlaying = false
    var position: Double = 0
    var duration: Double = 0
    var rate: Float = UserDefaults.standard.object(forKey: "audioRate") == nil ? 1 : UserDefaults.standard.float(forKey: "audioRate")
    /// 0 off · 1 repeat the list · 2 repeat this recording
    var repeatMode: Int = UserDefaults.standard.integer(forKey: "audioRepeat")
    var shuffled = false
    /// Name of the playlist being played (for the player header).
    var queueName: String?
    var sleepEnd: Date?
    var sleepAtTrackEnd = false
    var showFull = false
    var failed = false

    @ObservationIgnored private var player: AVPlayer?
    @ObservationIgnored private var timeObserver: Any?
    @ObservationIgnored private var endObserver: NSObjectProtocol?
    @ObservationIgnored private var statusObservation: NSKeyValueObservation?
    @ObservationIgnored private var sleepTimer: Timer?

    init() { setupRemoteCommands() }

    var hasNext: Bool { index.map { $0 + 1 < queue.count } ?? false }
    var hasPrevious: Bool { index.map { $0 > 0 } ?? false }
    private var index: Int? { current.flatMap { c in queue.firstIndex { $0.id == c.id } } }

    /// Plays a whole list from the start (or shuffled), advancing automatically.
    func playAll(_ items: [AudioItem], name: String? = nil, shuffle: Bool = false) {
        guard !items.isEmpty else { return }
        let list = shuffle ? items.shuffled() : items
        shuffled = shuffle
        play(list[0], queue: list, name: name)
    }

    func toggleShuffle() {
        guard let c = current, queue.count > 1 else { shuffled.toggle(); return }
        let rest = queue.filter { $0.id != c.id }
        queue = shuffled ? ([c] + rest) : ([c] + rest.shuffled())
        shuffled.toggle()
    }

    func cycleRepeat() {
        repeatMode = (repeatMode + 1) % 3
        UserDefaults.standard.set(repeatMode, forKey: "audioRepeat")
    }

    func play(_ item: AudioItem, queue q: [AudioItem]? = nil, name: String? = nil) {
        guard let url = AudioLibrary.shared.playableURL(item) else { failed = true; return }
        if q != nil || queue.first(where: { $0.id == item.id }) == nil { queueName = name }
        queue = q ?? [item]
        current = item
        failed = false
        position = 0
        duration = item.duration ?? 0
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
        try? AVAudioSession.sharedInstance().setActive(true)

        teardown()
        let playerItem = AVPlayerItem(url: url)
        let p = AVPlayer(playerItem: playerItem)
        p.automaticallyWaitsToMinimizeStalling = true
        player = p
        statusObservation = playerItem.observe(\.status, options: [.new]) { [weak self] it, _ in
            DispatchQueue.main.async {
                guard let self else { return }
                if it.status == .failed { self.failed = true; self.isPlaying = false }
                let d = CMTimeGetSeconds(it.duration)
                if d.isFinite && d > 0 { self.duration = d; self.updateNowPlaying() }
            }
        }
        timeObserver = p.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.5, preferredTimescale: 600), queue: .main) { [weak self] t in
            guard let self else { return }
            self.position = CMTimeGetSeconds(t)
            if let d = self.player?.currentItem?.duration, CMTimeGetSeconds(d).isFinite, CMTimeGetSeconds(d) > 0 {
                self.duration = CMTimeGetSeconds(d)
            }
        }
        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: playerItem, queue: .main) { [weak self] _ in
            self?.trackEnded()
        }
        p.playImmediately(atRate: rate)
        isPlaying = true
        updateNowPlaying()
    }

    func toggle() {
        guard let p = player else { if let c = current { play(c, queue: queue) }; return }
        if isPlaying { p.pause() } else { p.playImmediately(atRate: rate) }
        isPlaying.toggle()
        updateNowPlaying()
    }

    func seek(to s: Double) {
        let target = max(0, duration > 0 ? min(s, duration - 0.5) : s)
        player?.seek(to: CMTime(seconds: target, preferredTimescale: 600))
        position = target
        updateNowPlaying()
    }

    func skip(_ s: Double) { seek(to: position + s) }

    func next() {
        guard let i = index else { return }
        if i + 1 < queue.count { play(queue[i + 1], queue: queue, name: queueName) }
        else if repeatMode == 1, let first = queue.first { play(first, queue: queue, name: queueName) }
    }

    func previous() {
        if position > 5 { seek(to: 0); return }
        guard let i = index, i > 0 else { seek(to: 0); return }
        play(queue[i - 1], queue: queue, name: queueName)
    }

    func setRate(_ r: Float) {
        rate = r
        UserDefaults.standard.set(r, forKey: "audioRate")
        if isPlaying { player?.rate = r }
        updateNowPlaying()
    }

    /// Minutes until pause; 0 pauses at the end of the current recording; nil cancels.
    func setSleep(minutes: Int?) {
        sleepTimer?.invalidate()
        sleepTimer = nil
        sleepEnd = nil
        sleepAtTrackEnd = false
        guard let minutes else { return }
        if minutes == 0 { sleepAtTrackEnd = true; return }
        let end = Date().addingTimeInterval(Double(minutes) * 60)
        sleepEnd = end
        sleepTimer = Timer.scheduledTimer(withTimeInterval: Double(minutes) * 60, repeats: false) { [weak self] _ in
            guard let self else { return }
            if self.isPlaying { self.toggle() }
            self.sleepEnd = nil
        }
    }

    func stop() {
        teardown()
        isPlaying = false
        current = nil
        queue = []
        queueName = nil
        position = 0
        duration = 0
        setSleep(minutes: nil)
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }

    private func trackEnded() {
        if sleepAtTrackEnd {
            sleepAtTrackEnd = false
            isPlaying = false
            updateNowPlaying()
            return
        }
        if repeatMode == 2 {
            seek(to: 0)
            player?.playImmediately(atRate: rate)
            return
        }
        if hasNext || (repeatMode == 1 && queue.count > 0) { next() } else {
            isPlaying = false
            seek(to: 0)
            player?.pause()
        }
    }

    private func teardown() {
        if let t = timeObserver { player?.removeTimeObserver(t) }
        timeObserver = nil
        if let e = endObserver { NotificationCenter.default.removeObserver(e) }
        endObserver = nil
        statusObservation?.invalidate()
        statusObservation = nil
        player?.pause()
        player = nil
    }

    // MARK: Lock screen / Control Center

    private func updateNowPlaying() {
        guard let c = current else { return }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: c.title,
            MPMediaItemPropertyArtist: c.subtitle,
            MPMediaItemPropertyAlbumTitle: "رفيق المؤمن",
            MPNowPlayingInfoPropertyElapsedPlaybackTime: position,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? Double(rate) : 0.0
        ]
        if duration > 0 { info[MPMediaItemPropertyPlaybackDuration] = duration }
        if let art = Self.artwork { info[MPMediaItemPropertyArtwork] = art }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }

    private static let artwork: MPMediaItemArtwork? = {
        let size = CGSize(width: 600, height: 600)
        let img = UIGraphicsImageRenderer(size: size).image { ctx in
            let colors = [UIColor(red: 0x2A / 255, green: 0x80 / 255, blue: 0x73 / 255, alpha: 1).cgColor,
                          UIColor(red: 0x17 / 255, green: 0x5A / 255, blue: 0x50 / 255, alpha: 1).cgColor] as CFArray
            if let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1]) {
                ctx.cgContext.drawLinearGradient(g, start: .zero, end: CGPoint(x: size.width, y: size.height), options: [])
            }
            let cfg = UIImage.SymbolConfiguration(pointSize: 220, weight: .semibold)
            if let sym = UIImage(systemName: "moon.stars.fill", withConfiguration: cfg)?
                .withTintColor(UIColor(red: 0xE3 / 255, green: 0xA3 / 255, blue: 0x3B / 255, alpha: 1), renderingMode: .alwaysOriginal) {
                let r = CGRect(x: (size.width - sym.size.width) / 2, y: (size.height - sym.size.height) / 2,
                               width: sym.size.width, height: sym.size.height)
                sym.draw(in: r)
            }
        }
        return MPMediaItemArtwork(boundsSize: size) { _ in img }
    }()

    private func setupRemoteCommands() {
        let c = MPRemoteCommandCenter.shared()
        c.playCommand.addTarget { [weak self] _ in
            guard let self else { return .commandFailed }
            if !self.isPlaying { self.toggle() }
            return .success
        }
        c.pauseCommand.addTarget { [weak self] _ in
            guard let self else { return .commandFailed }
            if self.isPlaying { self.toggle() }
            return .success
        }
        c.togglePlayPauseCommand.addTarget { [weak self] _ in self?.toggle(); return .success }
        c.skipForwardCommand.preferredIntervals = [15]
        c.skipForwardCommand.addTarget { [weak self] _ in self?.skip(15); return .success }
        c.skipBackwardCommand.preferredIntervals = [15]
        c.skipBackwardCommand.addTarget { [weak self] _ in self?.skip(-15); return .success }
        c.nextTrackCommand.addTarget { [weak self] _ in self?.next(); return .success }
        c.previousTrackCommand.addTarget { [weak self] _ in self?.previous(); return .success }
        c.changePlaybackPositionCommand.addTarget { [weak self] e in
            guard let self, let e = e as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            self.seek(to: e.positionTime)
            return .success
        }
    }
}
