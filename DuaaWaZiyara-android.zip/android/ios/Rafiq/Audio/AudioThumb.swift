import SwiftUI

/// Cover image for a recording: the source's own artwork (podcast cover, archive image, embedded MP3
/// cover, saved offline with downloads), a numbered tile for Quran surahs, or a clear source tile.
/// Large and high-contrast on purpose: easier to recognise than text, especially for older users.
struct AudioThumb: View {
    let item: AudioItem
    var size: CGFloat = 56

    private var radius: CGFloat { size * 0.22 }

    var body: some View {
        ZStack {
            if let url = AudioLibrary.shared.artwork(item) {
                if url.isFileURL, let img = UIImage(contentsOfFile: url.path) {
                    Image(uiImage: img).resizable().scaledToFill()
                } else {
                    AsyncImage(url: url, transaction: Transaction(animation: .easeIn(duration: 0.2))) { phase in
                        if case .success(let image) = phase {
                            image.resizable().scaledToFill()
                        } else {
                            fallback
                        }
                    }
                }
            } else {
                fallback
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: radius, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous).strokeBorder(Color.primary.opacity(0.08), lineWidth: 1))
        .accessibilityHidden(true)
    }

    @ViewBuilder private var fallback: some View {
        if let n = QuranAudio.surahNumber(item) {
            // Quran: the surah number, big and gold on the app's teal, like a mushaf marker.
            ZStack {
                LinearGradient(colors: [Brand.deep, Brand.deeper], startPoint: .topLeading, endPoint: .bottomTrailing)
                StarShape().fill(Brand.gold.opacity(0.22)).padding(size * 0.08)
                Text(n.ar)
                    .font(.ui(size: size * (n > 99 ? 0.30 : 0.36), weight: .heavy))
                    .foregroundStyle(.white)
            }
        } else {
            // Night scene (moon over a skyline), the v2 placeholder for recordings without a cover.
            ZStack(alignment: .bottom) {
                LinearGradient(colors: [Color(hex: 0x2D7468), Color(hex: 0x123F3A)], startPoint: .topLeading, endPoint: .bottomTrailing)
                if size >= 120 { StarField(count: 10) }
                CrescentMoon(size: size * 0.3)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                    .padding(size * 0.12)
                CardSkyline().fill(Color(hex: 0x0B2E2A)).frame(height: size * 0.34)
                if size < 120 {
                    Image(systemName: item.source.symbol)
                        .font(.system(size: size * 0.22, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.9))
                        .padding(.bottom, size * 0.08)
                }
            }
        }
    }

    private var sourceColor: String {
        switch item.source {
        case .podcast: return "sabah"
        case .archive: return "ziyarat"
        case .commons: return "hikam"
        case .file, .link: return "munajat"
        case .quran: return "quran"
        }
    }
}
