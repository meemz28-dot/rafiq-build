import SwiftUI
import UniformTypeIdentifiers

// MARK: - استمع: search open audio sources, keep an offline library

struct ListenView: View {
    @Environment(AppNav.self) private var nav
    @State private var library = AudioLibrary.shared
    @State private var player = AudioPlayer.shared

    @State private var tab = 0                 // 0 بحث · 1 مكتبتي
    @State private var query = ""
    @State private var source: ListenFilter = .all
    @State private var loading = false
    @State private var quran: [AudioItem] = []
    @State private var podcasts: [AudioItem] = []
    @State private var archive: [AudioSearch.ArchiveHit] = []
    @State private var tracks: [AudioItem] = []
    @State private var commonsItems: [AudioItem] = []
    @State private var pendingSources: [String] = []
    @State private var searched = false
    @State private var openArchive: AudioSearch.ArchiveHit?
    @State private var showLink = false
    @State private var linkText = ""
    @State private var showImporter = false
    @State private var linkTarget: String?     // "catId|itemId" when opened from a dua
    @State private var linkingItem: AudioItem?
    @State private var toast: String?
    @FocusState private var searchFocused: Bool
    @State private var openPlaylist: String?
    @State private var showQuran = false
    @State private var showNewPlaylist = false
    @State private var newPlaylistName = ""
    @State private var showStorage = false
    @AppStorage(ListenDiscover.favReciterKey) private var favReciter = ""
    @AppStorage("listenOfflineOnly") private var offlineOnly = false

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 12) {
                    HStack(alignment: .center) {
                        Text("استمع").font(.display(32)).foregroundStyle(Brand.ink)
                        Spacer()
                        segmentPills
                        addMenu
                    }
                    .padding(.top, 6)
                    LibrarySearchField(text: $query, focused: $searchFocused, placeholder: "ابحث: كميل، الكهف، باسم الكربلائي…")
                        .onSubmit { tab = 0 }
                }
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets())
            }
            if let target = linkTarget, let title = ListenLinking.title(target) {
                Section {
                    HStack {
                        Label("اختر تسجيلاً لربطه بـ «\(title)»", systemImage: "link")
                            .font(.ui(.subheadline, .semibold))
                            .foregroundStyle(Brand.emerald)
                        Spacer()
                        Button("إلغاء") { linkTarget = nil }
                            .font(.ui(.subheadline))
                    }
                }
            }
            if query.trimmingCharacters(in: .whitespaces).count < 2 || tab == 1 {
                Section {
                    QuranPlaylistCard { showQuran = true }
                        .listRowInsets(EdgeInsets())
                        .listRowBackground(Color.clear)
                }
            }
            if tab == 0 { searchContent } else { libraryContent }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Brand.canvas)
        .toolbar(.hidden, for: .navigationBar)
        .statusBarBacking()
        .task(id: "\(query)|\(source.rawValue)|\(tab)") { await runSearch() }
        .onAppear {
            if let q = nav.pendingListen { query = q; nav.pendingListen = nil; tab = 0 }
            // No automatic keyboard: Listen is a tab now and the Quran card should stay visible.
            if let t = nav.pendingLinkTarget { linkTarget = t; nav.pendingLinkTarget = nil }
        }
        .alert("لصق رابط صوتي", isPresented: $showLink) {
            TextField("https://…", text: $linkText)
            Button("تشغيل") { addLink(download: false) }
            Button("تنزيل") { addLink(download: true) }
            Button("إلغاء", role: .cancel) { linkText = "" }
        } message: {
            Text("رابط مباشر لملف صوتي (mp3 أو m4a). لا تُنزَّل مقاطع يوتيوب ونحوه.")
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.audio], allowsMultipleSelection: true) { r in
            if case .success(let urls) = r {
                let added = urls.compactMap { library.importFile($0) }
                if !added.isEmpty { tab = 1; flash("أُضيف \(added.count.ar) ملف") }
            }
        }
        .sheet(item: $openArchive) { hit in
            NavigationStack { ListenArchiveSheet(hit: hit, linkTarget: linkTarget) { link($0) } }
                .environment(\.layoutDirection, .rightToLeft)
        }
        .sheet(item: $linkingItem) { item in
            NavigationStack { ListenLinkDuaSheet(item: item) }
                .environment(\.layoutDirection, .rightToLeft)
        }
        .navigationDestination(item: $openPlaylist) { id in ListenPlaylistView(playlistId: id) }
        .navigationDestination(isPresented: $showQuran) { QuranPlaylistView() }
        .navigationDestination(isPresented: $showStorage) { ListenStorageView() }
        .alert("قائمة تشغيل جديدة", isPresented: $showNewPlaylist) {
            TextField("مثلاً: أدعية ليلة الجمعة", text: $newPlaylistName)
            Button("إنشاء") { library.createPlaylist(newPlaylistName); tab = 1 }
            Button("إلغاء", role: .cancel) {}
        }
        .overlay(alignment: .top) {
            if let toast {
                Text(toast)
                    .font(.ui(.footnote, .bold))
                    .padding(.horizontal, 16).padding(.vertical, 10)
                    .glassCapsule()
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .padding(.top, 6)
            }
        }
    }

    /// بحث · مكتبتي as a pill group (v2).
    private var segmentPills: some View {
        HStack(spacing: 2) {
            ForEach([(0, "بحث"), (1, libraryTabTitle)], id: \.0) { t in
                Button { withAnimation(.snappy) { tab = t.0 }; Haptic.tick() } label: {
                    Text(t.1).font(.ui(.caption, .bold))
                        .foregroundStyle(tab == t.0 ? Color.white : Brand.ink)
                        .padding(.horizontal, 12).frame(height: 34)
                        .background(tab == t.0 ? Brand.deeper : Color.clear, in: Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(tab == t.0 ? .isSelected : [])
            }
        }
        .padding(3)
        .background(Brand.cardFill, in: Capsule())
    }

    private var addMenu: some View {
        Menu {
            Button { showLink = true } label: { Label("لصق رابط صوتي", systemImage: "link") }
            Button { showImporter = true } label: { Label("استيراد من الملفات", systemImage: "folder") }
            Divider()
            Button { showStorage = true } label: { Label("التنزيلات والمساحة", systemImage: "internaldrive") }
        } label: {
            Image(systemName: "plus")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(Brand.ink)
                .frame(width: 42, height: 42)
                .background(Brand.cardFill, in: Circle())
        }
        .accessibilityLabel("إضافة تسجيل")
    }

    private var libraryTabTitle: String {
        let n = library.progress.count
        if n > 0 { return "مكتبتي · ⬇ \(n.ar)" }
        return library.items.isEmpty ? "مكتبتي" : "مكتبتي · \(library.items.count.ar)"
    }

    // MARK: Search

    @ViewBuilder private var searchContent: some View {
        Section {
            Picker("المصدر", selection: $source) {
                ForEach(ListenFilter.allCases) { f in Text(f.title).tag(f) }
            }
            .pickerStyle(.menu)
        }
        if query.trimmingCharacters(in: .whitespaces).count < 2 {
            ListenDiscoverContent(onPick: { pick($0) }, onRead: { nav.openReader($0.catId, $0.itemId) })
            Section {
                ListenHint()
                    .contentShape(Rectangle())
                    .onTapGesture { searchFocused = true }
            }
        } else if searched && noResults {
            Section {
                EmptyStateView(symbol: "waveform.slash", title: "لا نتائج لـ «\(query)»",
                               message: !favReciter.isEmpty && query.contains(favReciter)
                                   ? "لا تسجيل بصوت \(favReciter) في المصادر المفتوحة. اختر «أيّ قارئ» أو احذف اسمه من البحث."
                                   : "جرّب كلمة أخرى، أو اسم القارئ، أو الصق رابطاً مباشراً من زر +")
            }
        } else {
            if !quran.isEmpty {
                Section("القرآن الكريم · mp3quran") {
                    ForEach(quran) { it in ListenRow(item: it, queue: quran, linkTarget: linkTarget, onLink: { link($0) }, onMore: { linkingItem = $0 }) }
                }
            }
            if loading {
                Section {
                    HStack(spacing: 10) {
                        ProgressView()
                        Text("جارٍ البحث في: " + pendingSources.joined(separator: "، "))
                            .font(.ui(.footnote)).foregroundStyle(.secondary)
                    }
                }
            }
            if !tracks.isEmpty {
                Section {
                    ForEach(tracks) { it in ListenRow(item: it, queue: tracks, linkTarget: linkTarget, onLink: { link($0) }, onMore: { linkingItem = $0 }) }
                } header: {
                    Text("تسجيلات · أرشيف الإنترنت")
                } footer: {
                    Text("اضغط ⬇ للتنزيل والاستماع دون إنترنت.")
                }
            }
            if !podcasts.isEmpty {
                Section("حلقات بودكاست") {
                    ForEach(podcasts) { it in ListenRow(item: it, queue: podcasts, linkTarget: linkTarget, onLink: { link($0) }, onMore: { linkingItem = $0 }) }
                }
            }
            if !commonsItems.isEmpty {
                Section("ويكيميديا كومنز · رخص مفتوحة") {
                    ForEach(commonsItems) { it in ListenRow(item: it, queue: commonsItems, linkTarget: linkTarget, onLink: { link($0) }, onMore: { linkingItem = $0 }) }
                }
            }
            if !archive.isEmpty {
                Section("مجموعات الأرشيف (كلّ الملفات)") {
                    ForEach(archive) { hit in
                        Button { openArchive = hit } label: { ListenArchiveRow(hit: hit) }
                            .buttonStyle(.plain)
                    }
                }
            }
            Section {
                Text("النتائج من مصادر تنشر ملفاتها للاستماع والتنزيل. حقوق كلّ تسجيل لأصحابه، وتظهر رخصته إن وُجدت.")
                    .font(.ui(.caption)).foregroundStyle(.secondary)
            }
        }
    }

    private var noResults: Bool {
        quran.isEmpty && podcasts.isEmpty && archive.isEmpty && tracks.isEmpty && commonsItems.isEmpty
    }

    private func runSearch() async {
        let q = query.trimmingCharacters(in: .whitespaces)
        guard tab == 0, q.count >= 2 else {
            quran = []; podcasts = []; archive = []; tracks = []; commonsItems = []; searched = false
            loading = false
            return
        }
        try? await Task.sleep(nanoseconds: 450_000_000)   // debounce typing
        if Task.isCancelled { return }
        loading = true
        searched = false
        quran = []; podcasts = []; archive = []; tracks = []; commonsItems = []
        let f = source
        let wantQ = f == .all || f == .quran, wantA = f == .all || f == .archive
        let wantP = f == .all || f == .podcast, wantC = f == .all || f == .commons
        pendingSources = (wantQ ? ["القرآن"] : []) + (wantA ? ["الأرشيف"] : []) + (wantP ? ["البودكاست"] : []) + (wantC ? ["كومنز"] : [])
        async let qr = Self.quranIf(wantQ, q)
        async let ar = Self.archiveIf(wantA, q)
        async let pc = Self.podcastIf(wantP, q)
        async let cm = Self.commonsIf(wantC, q)
        // Show each source as soon as it answers.
        let r1 = await qr
        if Task.isCancelled { return }
        quran = r1
        pendingSources.removeAll { $0 == "القرآن" }
        let hits = await ar
        if Task.isCancelled { return }
        archive = hits
        let r3 = await pc
        if Task.isCancelled { return }
        podcasts = r3
        pendingSources.removeAll { $0 == "البودكاست" }
        let r4 = await cm
        if Task.isCancelled { return }
        commonsItems = r4
        pendingSources.removeAll { $0 == "كومنز" }
        if !hits.isEmpty {
            let t = await AudioSearch.archiveTracks(hits, query: q)
            if Task.isCancelled { return }
            tracks = t
        }
        pendingSources.removeAll { $0 == "الأرشيف" }
        loading = false
        searched = true
    }

    private static func quranIf(_ on: Bool, _ q: String) async -> [AudioItem] {
        if !on { return [] }
        return await AudioSearch.quran(q)
    }
    private static func archiveIf(_ on: Bool, _ q: String) async -> [AudioSearch.ArchiveHit] {
        if !on { return [] }
        return await AudioSearch.archive(q)
    }
    private static func podcastIf(_ on: Bool, _ q: String) async -> [AudioItem] {
        if !on { return [] }
        return await AudioSearch.podcastEpisodes(q)
    }
    private static func commonsIf(_ on: Bool, _ q: String) async -> [AudioItem] {
        if !on { return [] }
        return await AudioSearch.commons(q)
    }

    // MARK: Library

    @ViewBuilder private var libraryContent: some View {
        let downloading = library.progress.keys.sorted()
        if !downloading.isEmpty {
            Section("قيد التنزيل") {
                ForEach(downloading, id: \.self) { id in
                    ListenDownloadingRow(id: id)
                }
            }
        }
        if let err = library.lastError {
            Section { Label(err, systemImage: "exclamationmark.triangle").foregroundStyle(Brand.bad) }
        }
        Section {
            ForEach(library.playlists) { p in
                HStack(spacing: 12) {
                    Button {
                        player.playAll(library.items(of: p), name: p.name)
                    } label: {
                        Image(systemName: "play.fill")
                            .font(.system(size: 14, weight: .bold)).foregroundStyle(.white)
                            .frame(width: 36, height: 36)
                            .background(RoundedRectangle(cornerRadius: 10).fill(Brand.gold))
                    }
                    .buttonStyle(.plain)
                    .disabled(p.itemIds.isEmpty)
                    Button { openPlaylist = p.id } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(p.name).font(.ui(.subheadline, .semibold)).foregroundStyle(.primary)
                                Text(verbatim: "\(p.itemIds.count.ar) تسجيل").font(.ui(.caption)).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.left").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
                .swipeActions(edge: .trailing) {
                    Button(role: .destructive) { library.deletePlaylist(p.id) } label: { Label("حذف", systemImage: "trash") }
                }
            }
            Button { newPlaylistName = ""; showNewPlaylist = true } label: {
                Label("قائمة تشغيل جديدة", systemImage: "plus.circle.fill")
            }
        } header: {
            Text("قوائم التشغيل")
        } footer: {
            Text("أضف أيّ تسجيل إلى قائمة من زر ⋯ بجانبه؛ وتعمل القائمة تلقائياً من تسجيلٍ إلى الذي يليه.")
        }
        let recent = player.recent.prefix(5)
        if !recent.isEmpty {
            Section("استمعت مؤخراً") {
                ForEach(Array(recent)) { it in ListenResumeRow(item: it) }
            }
        }
        if library.items.isEmpty {
            Section {
                EmptyStateView(symbol: "headphones", title: "مكتبتك فارغة",
                               message: "ابحث عن دعاء أو سورة ونزّلها لتسمعها دون إنترنت، أو استورد ملفاً من زر +. ويمكنك مشاركة مقطع صوتي من واتساب أو تيليجرام إلى «رفيق المؤمن».")
            }
        } else {
            Section {
                let shown = offlineOnly ? library.items.filter { library.isDownloaded($0.id) } : library.items
                Button {
                    player.playAll(shown, name: "المحفوظات")
                } label: {
                    Label("تشغيل الكلّ", systemImage: "play.fill").font(.ui(.headline))
                }
                .disabled(shown.isEmpty)
                Toggle(isOn: $offlineOnly) { Label("المنزّل فقط (دون إنترنت)", systemImage: "wifi.slash") }
                    .tint(Brand.emerald)
                ForEach(shown) { item in
                    ListenRow(item: item, queue: shown, linkTarget: linkTarget, onLink: { link($0) }, onMore: { linkingItem = $0 })
                        .swipeActions(edge: .trailing) {
                            Button(role: .destructive) { library.delete(item) } label: { Label("حذف", systemImage: "trash") }
                        }
                }
            } header: {
                Text("المحفوظات")
            } footer: {
                Button { showStorage = true } label: {
                    Text("المساحة المستخدمة: \(AudioFormat.bytes(library.totalBytes)) · إدارة التنزيلات")
                        .font(.ui(.footnote))
                }
            }
        }
    }

    // MARK: Actions

    private func addLink(download: Bool) {
        defer { linkText = "" }
        guard let item = AudioSearch.linkItem(linkText) else { flash("الرابط غير صالح"); return }
        library.keep(item)
        if download { library.download(item); tab = 1 } else { player.play(item) }
    }

    /// A famous dua: plays its linked recording, or searches for one ready to link.
    private func pick(_ c: CuratedAudio) {
        if let a = library.linked(catId: c.catId, itemId: c.itemId) {
            player.play(a)
            return
        }
        linkTarget = c.id
        tab = 0
        query = ListenDiscover.query(c, reciter: favReciter)
        Haptic.tick()
    }

    private func link(_ item: AudioItem) {
        guard let t = linkTarget else { return }
        let p = t.split(separator: "|").map(String.init)
        guard p.count == 2 else { return }
        library.link(item, catId: p[0], itemId: p[1])
        if !library.isDownloaded(item.id) { library.download(item) }
        Haptic.confirm()
        flash("رُبط التسجيل بالدعاء ويُنزَّل الآن ✓")
        linkTarget = nil
    }

    private func flash(_ s: String) {
        withAnimation { toast = s }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { withAnimation { toast = nil } }
    }
}

enum ListenFilter: String, CaseIterable, Identifiable {
    case all, quran, archive, podcast, commons
    var id: String { rawValue }
    var title: String {
        switch self {
        case .all: return "كلّ المصادر"
        case .quran: return "القرآن الكريم"
        case .archive: return "أرشيف الإنترنت"
        case .podcast: return "بودكاست"
        case .commons: return "ويكيميديا كومنز"
        }
    }
}

enum ListenLinking {
    static func title(_ key: String) -> String? {
        let p = key.split(separator: "|").map(String.init)
        guard p.count == 2, let c = Library.category(p[0]), let it = c.items.first(where: { $0.id == p[1] }) else { return nil }
        return it.title
    }
}

private struct ListenHint: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("ابحث في مصادر مفتوحة", systemImage: "magnifyingglass").font(.ui(.headline))
            Text("• القرآن الكريم بأصوات عشرات القرّاء\n• أرشيف الإنترنت: أدعية وزيارات ومجالس\n• حلقات البودكاست من القنوات الإسلامية\n• ويكيميديا كومنز: تسجيلات برخص مفتوحة\n• اكتب بالعربية أو الإنجليزية: كميل = Kumail\n• أو الصق رابطاً مباشراً، أو شارك مقطعاً من واتساب وتيليجرام إلى التطبيق")
                .font(.ui(.subheadline)).foregroundStyle(.secondary)
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Rows

struct ListenRow: View {
    let item: AudioItem
    let queue: [AudioItem]
    let linkTarget: String?
    let onLink: (AudioItem) -> Void
    let onMore: (AudioItem) -> Void

    @State private var library = AudioLibrary.shared
    @State private var player = AudioPlayer.shared

    private var isCurrent: Bool { player.current?.id == item.id }

    var body: some View {
        HStack(spacing: 12) {
            Button {
                if isCurrent { player.toggle() } else { player.play(item, queue: queue) }
            } label: {
                // Tap the picture to play: a big, familiar target.
                AudioThumb(item: item, size: 58)
                    .overlay(alignment: .bottomLeading) {
                        Image(systemName: isCurrent && player.isPlaying ? "pause.fill" : "play.fill")
                            .font(.system(size: 12, weight: .heavy))
                            .foregroundStyle(.white)
                            .frame(width: 26, height: 26)
                            .background(Circle().fill(isCurrent ? Brand.gold : Brand.emerald))
                            .overlay(Circle().strokeBorder(.white, lineWidth: 2))
                            .offset(x: -4, y: 4)
                    }
            }
            .buttonStyle(.plain)
            .accessibilityLabel(isCurrent && player.isPlaying ? "إيقاف مؤقت" : "تشغيل")

            VStack(alignment: .leading, spacing: 3) {
                Text(item.title).font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink).lineLimit(2)
                HStack(spacing: 6) {
                    Image(systemName: item.source.symbol)
                    Text(item.subtitle).lineLimit(1)
                    if let d = item.duration, d > 0 { Text(verbatim: "· \(AudioFormat.time(d))") }
                }
                .font(.ui(.caption)).foregroundStyle(.secondary)
                if item.license != nil {
                    Text("رخصة مفتوحة").font(.ui(.caption2, .bold)).foregroundStyle(Brand.good)
                }
            }
            Spacer(minLength: 4)
            trailing
            Menu { actions } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.secondary)
                    .frame(width: 28, height: 34)
                    .contentShape(Rectangle())
            }
            .accessibilityLabel("خيارات")
        }
        .padding(.vertical, 10)
        .contextMenu { actions }
        .listRowSeparator(.hidden)
        .listRowBackground(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(Brand.cardFill)
                .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(library.isDownloaded(item.id) || isCurrent ? Brand.gold : Color.clear, lineWidth: 1.5))
                .padding(.vertical, 5)
        )
    }

    @ViewBuilder private var actions: some View {
        Menu {
            ForEach(library.playlists) { p in
                Button {
                    library.add(item, toPlaylist: p.id)
                    Haptic.confirm()
                } label: {
                    Label(p.name, systemImage: p.itemIds.contains(item.id) ? "checkmark" : "music.note.list")
                }
            }
            Divider()
            Button {
                let p = library.createPlaylist("")
                library.add(item, toPlaylist: p.id)
                Haptic.confirm()
            } label: { Label("قائمة جديدة", systemImage: "plus") }
        } label: {
            Label("إضافة إلى قائمة تشغيل", systemImage: "text.badge.plus")
        }
        Button { onMore(item) } label: { Label("ربط بدعاء…", systemImage: "link") }
        if library.isDownloaded(item.id) {
            Button { library.removeDownload(item) } label: { Label("حذف الملف المنزّل", systemImage: "icloud.slash") }
        } else if item.remoteURL != nil && !library.isDownloading(item.id) {
            Button { library.download(item) } label: { Label("تنزيل", systemImage: "arrow.down.circle") }
        }
        if let r = item.remoteURL, let u = URL(string: r) {
            ShareLink(item: u) { Label("مشاركة الرابط", systemImage: "square.and.arrow.up") }
        }
    }

    @ViewBuilder private var trailing: some View {
        if linkTarget != nil {
            Button { onLink(item) } label: {
                Label("ربط", systemImage: "link").font(.ui(.caption, .bold))
            }
            .buttonStyle(.borderedProminent)
            .tint(Brand.gold)
        } else if library.isDownloaded(item.id) {
            Image(systemName: "checkmark").font(.system(size: 15, weight: .semibold)).foregroundStyle(Brand.emerald)
                .frame(width: 44, height: 44).overlay(Circle().stroke(Brand.emerald, lineWidth: 1.5)).accessibilityLabel("منزّل")
        } else if let p = library.progress[item.id] {
            ListenProgressRing(fraction: p).frame(width: 26, height: 26)
                .onTapGesture { library.cancelDownload(item.id) }
        } else if item.remoteURL != nil {
            Button { library.download(item); Haptic.tick() } label: {
                Image(systemName: "arrow.down").font(.system(size: 15, weight: .semibold)).foregroundStyle(Brand.accent)
                    .frame(width: 44, height: 44).background(Brand.soft, in: Circle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("تنزيل")
        }
    }
}

struct ListenProgressRing: View {
    let fraction: Double
    var body: some View {
        ZStack {
            Circle().stroke(Color.secondary.opacity(0.25), lineWidth: 3)
            if fraction >= 0 {
                Circle().trim(from: 0, to: max(0.03, fraction))
                    .stroke(Brand.emerald, style: StrokeStyle(lineWidth: 3, lineCap: .round))
                    .rotationEffect(.degrees(-90))
            } else {
                ProgressView().scaleEffect(0.6)
            }
            Image(systemName: "stop.fill").font(.system(size: 8)).foregroundStyle(Brand.emerald)
        }
        .accessibilityLabel("إلغاء التنزيل")
    }
}

private struct ListenDownloadingRow: View {
    let id: String
    @State private var library = AudioLibrary.shared
    var body: some View {
        HStack {
            ListenProgressRing(fraction: library.progress[id] ?? -1).frame(width: 26, height: 26)
            Text(library.saved(id)?.title ?? "تسجيل").font(.ui(.subheadline)).lineLimit(1)
            Spacer()
            if let p = library.progress[id], p >= 0 {
                Text(verbatim: "\(Int(p * 100).ar)٪").font(.ui(.caption).monospacedDigit()).foregroundStyle(.secondary)
            }
            Button { library.cancelDownload(id) } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
                .buttonStyle(.plain)
        }
    }
}

private struct ListenArchiveRow: View {
    let hit: AudioSearch.ArchiveHit
    var body: some View {
        HStack(spacing: 12) {
            AsyncImage(url: URL(string: "https://archive.org/services/img/\(hit.id)")) { phase in
                if case .success(let image) = phase {
                    image.resizable().scaledToFill()
                } else {
                    Image(systemName: "rectangle.stack.fill").foregroundStyle(.white)
                        .frame(maxWidth: .infinity, maxHeight: .infinity).background(Brand.deep)
                }
            }
            .frame(width: 58, height: 58)
            .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                Text(hit.title).font(.ui(.subheadline, .semibold)).lineLimit(2)
                Text(hit.creator.isEmpty ? "archive.org" : hit.creator).font(.ui(.caption)).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer()
            Image(systemName: "chevron.left").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
        }
        .contentShape(Rectangle())
    }
}

// MARK: - Archive item (its files)

private struct ListenArchiveSheet: View {
    let hit: AudioSearch.ArchiveHit
    let linkTarget: String?
    let onLink: (AudioItem) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var files: [AudioItem] = []
    @State private var loaded = false
    @State private var linkingItem: AudioItem?
    @State private var library = AudioLibrary.shared

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 4) {
                    Text(hit.title).font(.ui(.headline))
                    if !hit.creator.isEmpty { Text(hit.creator).font(.ui(.subheadline)).foregroundStyle(.secondary) }
                    if let l = hit.license, let u = URL(string: l) {
                        Link("الرخصة", destination: u).font(.ui(.caption, .bold))
                    }
                }
            }
            if !loaded {
                Section { HStack { Spacer(); ProgressView(); Spacer() } }
            } else if files.isEmpty {
                Section { Text("لا توجد ملفات صوتية قابلة للتشغيل في هذا العنصر.").foregroundStyle(.secondary) }
            } else {
                Section {
                    if files.count > 1 {
                        Button {
                            for f in files { library.download(f) }
                            Haptic.confirm()
                        } label: { Label("تنزيل الكلّ (\(files.count.ar))", systemImage: "arrow.down.circle") }
                    }
                    ForEach(files) { f in
                        ListenRow(item: f, queue: files, linkTarget: linkTarget,
                                  onLink: { onLink($0); dismiss() }, onMore: { linkingItem = $0 })
                    }
                }
            }
        }
        .navigationTitle("التسجيلات")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("تم") { dismiss() } } }
        .task {
            files = await AudioSearch.archiveFiles(hit)
            loaded = true
        }
        .sheet(item: $linkingItem) { item in
            NavigationStack { ListenLinkDuaSheet(item: item) }
                .environment(\.layoutDirection, .rightToLeft)
        }
    }
}

// MARK: - Link a recording to a dua

struct ListenLinkDuaSheet: View {
    let item: AudioItem
    @Environment(\.dismiss) private var dismiss
    @State private var q = ""
    @State private var library = AudioLibrary.shared

    private var hits: [ArabicSearch.Hit] {
        let t = q.trimmingCharacters(in: .whitespaces)
        return t.count < 2 ? [] : Array(ArabicSearch.search(t).prefix(40))
    }

    var body: some View {
        List {
            let linked = library.linkedDuaKeys(item.id).compactMap { k -> (String, String)? in
                ListenLinking.title(k).map { (k, $0) }
            }
            if !linked.isEmpty {
                Section("مربوط بـ") {
                    ForEach(linked.indices, id: \.self) { i in
                        let pair = linked[i]
                        let k = pair.0
                        HStack {
                            Text(pair.1)
                            Spacer()
                            Button("فكّ") {
                                let p = k.split(separator: "|").map(String.init)
                                if p.count == 2 { library.unlink(catId: p[0], itemId: p[1]) }
                            }
                            .font(.ui(.caption, .bold))
                        }
                    }
                }
            }
            Section {
                ForEach(hits) { h in
                    Button {
                        library.link(item, catId: h.cat.id, itemId: h.item.id)
                        Haptic.confirm()
                        dismiss()
                    } label: {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(h.item.title).foregroundStyle(.primary)
                            Text(h.cat.name).font(.ui(.caption)).foregroundStyle(.secondary)
                        }
                    }
                }
            } header: {
                Text(q.isEmpty ? "اكتب اسم الدعاء أو الزيارة" : "اختر الدعاء")
            }
        }
        .searchable(text: $q, placement: .navigationBarDrawer(displayMode: .always), prompt: "دعاء كميل، زيارة عاشوراء…")
        .navigationTitle("ربط «\(item.title)»")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .cancellationAction) { Button("إلغاء") { dismiss() } } }
        .onAppear { if q.isEmpty { q = item.title.count < 40 ? item.title : "" } }
    }
}

// MARK: - Mini player (floats above the tab bar) and full player

struct MiniPlayerBar: View {
    @State private var player = AudioPlayer.shared

    var body: some View {
        if let c = player.current {
            HStack(spacing: 12) {
                AudioThumb(item: c, size: 44)
                VStack(alignment: .leading, spacing: 2) {
                    Text(c.title).font(.ui(.footnote, .bold)).foregroundStyle(.white).lineLimit(1)
                    Text(verbatim: "\(AudioFormat.time(player.position)) من \(AudioFormat.time(player.duration)) · \(String(format: "%g×", Double(player.rate)).arabicDigits)")
                        .font(.ui(.caption2)).foregroundStyle(.white.opacity(0.7)).lineLimit(1).monospacedDigit()
                }
                Spacer(minLength: 4)
                Button { player.skip(-15) } label: {
                    Image(systemName: "gobackward.15").font(.system(size: 17, weight: .semibold)).foregroundStyle(.white)
                        .frame(width: 36, height: 36)
                }
                .buttonStyle(.plain).accessibilityLabel("رجوع ١٥ ثانية")
                Button { player.toggle() } label: {
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(Color(hex: 0x10322D))
                        .frame(width: 40, height: 40)
                        .background(Brand.goldSoft, in: Circle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(player.isPlaying ? "إيقاف مؤقت" : "تشغيل")
                Button { player.stop() } label: {
                    Image(systemName: "xmark").font(.caption.weight(.bold)).foregroundStyle(.white.opacity(0.7))
                        .frame(width: 30, height: 36)
                }
                .buttonStyle(.plain).accessibilityLabel("إغلاق المشغّل")
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(Color(hex: 0x0B2421).opacity(0.96), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(alignment: .bottom) {
                GeometryReader { g in
                    Capsule().fill(Brand.goldSoft)
                        .frame(width: player.duration > 0 ? g.size.width * CGFloat(min(1, player.position / player.duration)) : 0, height: 2)
                }
                .frame(height: 2)
                .padding(.horizontal, 22)
                .padding(.bottom, 4)
            }
            .shadow(color: .black.opacity(0.25), radius: 14, y: 6)
            .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .onTapGesture { player.showFull = true }
            .padding(.horizontal, 14)
            .environment(\.colorScheme, .dark)
            .sheet(isPresented: $player.showFull) {
                PlayerSheet().environment(\.layoutDirection, .rightToLeft)
            }
        }
    }
}

/// Full player (v2 night): artwork, title, linked-text chip, read-along box, slider, controls, next up.
struct PlayerSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var player = AudioPlayer.shared
    @State private var library = AudioLibrary.shared
    @State private var scrub: Double?
    @State private var linking: AudioItem?

    /// The dua whose text this recording is linked to (first link).
    private var linkedText: (DuaaCategory, DuaaItem)? {
        guard let c = player.current, let key = library.linkedDuaKeys(c.id).first else { return nil }
        let p = key.split(separator: "|").map(String.init)
        guard p.count == 2, let cat = Library.category(p[0]), let it = cat.items.first(where: { $0.id == p[1] }) else { return nil }
        return (cat, it)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                topRow
                artwork
                titles
                readAlong
                scrubber
                controls
                if player.failed {
                    Text("تعذّر تشغيل هذا التسجيل. تحقّق من الاتصال أو من الرابط.")
                        .font(.ui(.footnote)).foregroundStyle(Brand.goldSoft)
                }
                extras
                nextUp
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 30)
        }
        .scrollBounceBehavior(.basedOnSize)
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .tealScreen()
        .presentationDragIndicator(.hidden)
        .sheet(item: $linking) { item in
            NavigationStack { ListenLinkDuaSheet(item: item) }
                .environment(\.layoutDirection, .rightToLeft)
                .environment(\.colorScheme, .light)
        }
    }

    private var topRow: some View {
        HStack {
            RoundIconButton(symbol: "chevron.down", label: "إغلاق", translucent: true) { dismiss() }
            Spacer()
            if let qn = player.queueName, player.queue.count > 1,
               let i = player.queue.firstIndex(where: { $0.id == player.current?.id }) {
                Text("من قائمة: \(qn) · \((i + 1).ar) من \(player.queue.count.ar)").font(.ui(.caption, .semibold)).foregroundStyle(.white.opacity(0.85)).lineLimit(1)
            } else {
                Text("يُشغَّل الآن").font(.ui(.caption, .semibold)).foregroundStyle(.white.opacity(0.85))
            }
            Spacer()
            Menu {
                Button { player.toggleShuffle() } label: { Label(player.shuffled ? "إيقاف العشوائي" : "تشغيل عشوائي", systemImage: "shuffle") }
                Button { player.cycleRepeat() } label: {
                    Label(player.repeatMode == 0 ? "تكرار: لا" : player.repeatMode == 1 ? "تكرار: القائمة" : "تكرار: التسجيل", systemImage: player.repeatMode == 2 ? "repeat.1" : "repeat")
                }
                if let c = player.current {
                    Button { linking = c } label: { Label("ربط بنصّ", systemImage: "link") }
                    if c.remoteURL != nil && !library.isDownloaded(c.id) {
                        Button { library.download(c); Haptic.tick() } label: { Label("تنزيل", systemImage: "arrow.down.circle") }
                    }
                }
            } label: {
                Image(systemName: "list.bullet")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 42, height: 42)
                    .background(Color.white.opacity(0.14), in: Circle())
                    .overlay(Circle().stroke(Color.white.opacity(0.25), lineWidth: 1))
            }
            .accessibilityLabel("خيارات القائمة")
        }
        .padding(.top, 14)
    }

    @ViewBuilder private var artwork: some View {
        Group {
            if let c = player.current {
                AudioThumb(item: c, size: 270)
            } else {
                Image(systemName: "moon.stars.fill").font(.system(size: 90)).foregroundStyle(Brand.goldSoft)
                    .frame(width: 270, height: 270)
            }
        }
        .shadow(color: .black.opacity(0.35), radius: 24, y: 12)
        .scaleEffect(player.isPlaying ? 1 : 0.94)
        .animation(.spring(duration: 0.4), value: player.isPlaying)
        .padding(.top, 6)
    }

    private var titles: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 4) {
                Text(player.current?.title ?? "").font(.display(26)).lineLimit(2).minimumScaleFactor(0.7)
                Text(player.current?.subtitle ?? "").font(.ui(.subheadline)).foregroundStyle(.white.opacity(0.75)).lineLimit(1)
            }
            Spacer(minLength: 8)
            if let t = linkedText {
                Button {
                    dismiss()
                    AppNav.shared.openReader(t.0.id, t.1.id)
                } label: {
                    Text("النصّ مرتبط").font(.ui(.caption, .bold)).foregroundStyle(Color(hex: 0x10322D))
                        .padding(.horizontal, 12).padding(.vertical, 8)
                        .background(Brand.goldSoft, in: Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("افتح النصّ المرتبط")
            } else if let c = player.current, QuranAudio.surahNumber(c) == nil {
                Button { linking = c } label: {
                    Text("اربط بنصّ").font(.ui(.caption, .bold)).foregroundStyle(.white)
                        .padding(.horizontal, 12).padding(.vertical, 8)
                        .background(Color.white.opacity(0.14), in: Capsule())
                }
                .buttonStyle(.plain)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    /// Three lines of the linked text around where the recording probably is (letter-weighted share of elapsed time).
    @ViewBuilder private var readAlong: some View {
        if let t = linkedText, player.duration > 0 {
            let paras = LibraryText.phrases(t.1.text, tashkeel: true)
            if paras.count >= 1 {
                let counts = paras.map { max(1, ArabicSearch.stripTashkeel($0).filter { $0.isLetter }.count) }
                let total = Double(counts.reduce(0, +))
                let f = max(0, min(1, (scrub ?? player.position) / player.duration))
                let cur = readAlongIndex(counts: counts, total: total, f: f)
                VStack(spacing: 8) {
                    if cur > 0 { Text(paras[cur - 1]).font(.scripture(16)).foregroundStyle(.white.opacity(0.45)).lineLimit(1) }
                    Text(paras[cur]).font(.scripture(22)).fontWeight(.bold).foregroundStyle(Brand.goldSoft).lineLimit(2).minimumScaleFactor(0.8)
                    if cur + 1 < paras.count { Text(paras[cur + 1]).font(.scripture(16)).foregroundStyle(.white.opacity(0.45)).lineLimit(1) }
                }
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 16).padding(.vertical, 14)
                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Color.white.opacity(0.1), lineWidth: 1))
                .animation(.easeInOut(duration: 0.3), value: cur)
                .accessibilityLabel("النصّ المصاحب")
            }
        }
    }

    private func readAlongIndex(counts: [Int], total: Double, f: Double) -> Int {
        var acc = 0.0
        for (i, c) in counts.enumerated() {
            acc += Double(c)
            if acc / total >= f { return i }
        }
        return max(0, counts.count - 1)
    }

    private var scrubber: some View {
        VStack(spacing: 4) {
            Slider(value: Binding(get: { scrub ?? player.position }, set: { scrub = $0 }),
                   in: 0...max(1, player.duration),
                   onEditingChanged: { editing in
                       if !editing, let s = scrub { player.seek(to: s); scrub = nil }
                   })
            .tint(Brand.goldSoft)
            .environment(\.layoutDirection, .leftToRight)
            HStack {
                Text("-" + AudioFormat.time(max(0, player.duration - (scrub ?? player.position))))
                Spacer()
                Text(AudioFormat.time(scrub ?? player.position))
            }
            .font(.ui(.caption).monospacedDigit()).foregroundStyle(.white.opacity(0.7))
        }
    }

    private var controls: some View {
        VStack(spacing: 14) {
            HStack(spacing: 18) {
                sleepMenu
                Spacer(minLength: 0)
                Button { player.skip(15) } label: { controlIcon("goforward.15") }
                    .accessibilityLabel("تقديم ١٥ ثانية")
                Button { player.toggle() } label: {
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(Color(hex: 0x10322D))
                        .frame(width: 76, height: 76)
                        .background(Circle().fill(Brand.goldSoft))
                        .shadow(color: Brand.goldSoft.opacity(0.35), radius: 16, y: 6)
                }
                .accessibilityLabel(player.isPlaying ? "إيقاف مؤقت" : "تشغيل")
                Button { player.skip(-15) } label: { controlIcon("gobackward.15") }
                    .accessibilityLabel("رجوع ١٥ ثانية")
                Spacer(minLength: 0)
                rateButton
            }
            if player.queue.count > 1 {
                HStack(spacing: 14) {
                    Button { player.previous() } label: { controlIcon("backward.end.fill", size: 40) }
                        .accessibilityLabel("السابق")
                    if let i = player.queue.firstIndex(where: { $0.id == player.current?.id }) {
                        Text(verbatim: "\((i + 1).ar) من \(player.queue.count.ar)").font(.ui(.caption, .bold)).foregroundStyle(.white.opacity(0.75)).frame(minWidth: 70)
                    }
                    Button { player.next() } label: { controlIcon("forward.end.fill", size: 40) }
                        .disabled(!(player.hasNext || player.repeatMode == 1))
                        .opacity(player.hasNext || player.repeatMode == 1 ? 1 : 0.35)
                        .accessibilityLabel("التالي")
                }
            }
        }
        .buttonStyle(.plain)
        .environment(\.layoutDirection, .leftToRight)
    }

    private func controlIcon(_ name: String, size: CGFloat = 48) -> some View {
        Image(systemName: name)
            .font(.system(size: size * 0.42, weight: .semibold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(Color.white.opacity(0.1), in: Circle())
    }

    private var rateButton: some View {
        Button {
            let steps: [Float] = [1, 1.25, 1.5, 1.75, 2, 0.75]
            let i = steps.firstIndex(where: { abs($0 - player.rate) < 0.01 }) ?? 0
            player.setRate(steps[(i + 1) % steps.count])
            Haptic.tick()
        } label: {
            Text(String(format: "%g×", Double(player.rate)).arabicDigits)
                .font(.ui(.caption, .heavy))
                .foregroundStyle(player.rate == 1 ? Color.white : Brand.goldSoft)
                .frame(width: 48, height: 48)
                .background(Color.white.opacity(0.1), in: Circle())
        }
        .accessibilityLabel("سرعة التشغيل")
    }

    private var sleepMenu: some View {
        Menu {
            Button("إيقاف بعد ١٥ دقيقة") { player.setSleep(minutes: 15) }
            Button("إيقاف بعد ٣٠ دقيقة") { player.setSleep(minutes: 30) }
            Button("إيقاف بعد ساعة") { player.setSleep(minutes: 60) }
            Button("عند انتهاء التسجيل") { player.setSleep(minutes: 0) }
            if player.sleepEnd != nil || player.sleepAtTrackEnd {
                Button("إلغاء المؤقّت", role: .destructive) { player.setSleep(minutes: nil) }
            }
        } label: {
            let on = player.sleepEnd != nil || player.sleepAtTrackEnd
            Image(systemName: on ? "moon.zzz.fill" : "moon.zzz")
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(on ? Brand.goldSoft : .white)
                .frame(width: 48, height: 48)
                .background(Color.white.opacity(0.1), in: Circle())
        }
        .accessibilityLabel("مؤقّت النوم")
    }

    @ViewBuilder private var extras: some View {
        HStack(spacing: 10) {
            if let end = player.sleepEnd {
                Label { Text(end, style: .timer) } icon: { Image(systemName: "moon.zzz.fill") }
                    .font(.ui(.caption, .bold)).foregroundStyle(Brand.goldSoft)
            } else if player.sleepAtTrackEnd {
                Label("يتوقّف عند نهاية التسجيل", systemImage: "moon.zzz.fill").font(.ui(.caption, .bold)).foregroundStyle(Brand.goldSoft)
            }
            if let c = player.current, let p = library.progress[c.id] {
                Label(p >= 0 ? "يُنزَّل \(Int(p * 100).ar)٪" : "يُنزَّل…", systemImage: "arrow.down.circle")
                    .font(.ui(.caption, .bold)).foregroundStyle(.white.opacity(0.8))
            } else if let c = player.current, library.isDownloaded(c.id) {
                Label("محفوظ للاستماع دون اتصال", systemImage: "checkmark.circle").font(.ui(.caption, .bold)).foregroundStyle(.white.opacity(0.7))
            }
        }
    }

    @ViewBuilder private var nextUp: some View {
        if player.queue.count > 1, let i = player.queue.firstIndex(where: { $0.id == player.current?.id }), i + 1 < player.queue.count {
            let n = player.queue[i + 1]
            Button { player.next() } label: {
                HStack(spacing: 12) {
                    AudioThumb(item: n, size: 44)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("التالي").font(.ui(.caption2)).foregroundStyle(.white.opacity(0.7))
                        Text(n.title).font(.ui(.subheadline, .bold)).lineLimit(1)
                    }
                    Spacer()
                    Text(verbatim: "\((i + 2).ar) في القائمة").font(.ui(.caption)).foregroundStyle(.white.opacity(0.6))
                }
                .padding(12)
                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            }
            .buttonStyle(.plain)
        }
    }
}


// MARK: - Playlist

struct ListenPlaylistView: View {
    let playlistId: String
    @State private var library = AudioLibrary.shared
    @State private var player = AudioPlayer.shared
    @State private var renaming = false
    @State private var name = ""
    @State private var linkingItem: AudioItem?

    private var playlist: AudioPlaylist? { library.playlist(playlistId) }
    private var items: [AudioItem] { playlist.map { library.items(of: $0) } ?? [] }

    var body: some View {
        List {
            Section {
                HStack(spacing: 10) {
                    Button { player.playAll(items, name: playlist?.name) } label: {
                        Label("تشغيل", systemImage: "play.fill").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent).tint(Brand.emerald)
                    Button { player.playAll(items, name: playlist?.name, shuffle: true) } label: {
                        Label("عشوائي", systemImage: "shuffle").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered).tint(Brand.emerald)
                }
                .disabled(items.isEmpty)
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets())
                let missing = items.filter { $0.remoteURL != nil && !library.isDownloaded($0.id) }
                if !missing.isEmpty {
                    Button {
                        for it in missing { library.download(it) }
                        Haptic.confirm()
                    } label: {
                        Label("تنزيل الكلّ للاستماع دون إنترنت (\(missing.count.ar))", systemImage: "arrow.down.circle")
                    }
                }
            }
            if items.isEmpty {
                Section {
                    EmptyStateView(symbol: "music.note.list", title: "القائمة فارغة",
                                   message: "من «استمع» اضغط ⋯ بجانب أيّ تسجيل ثم «إضافة إلى قائمة تشغيل».")
                }
            } else {
                Section {
                    ForEach(items) { it in
                        ListenRow(item: it, queue: items, linkTarget: nil, onLink: { _ in }, onMore: { linkingItem = $0 })
                    }
                    .onDelete { library.removeFromPlaylist(playlistId, at: $0) }
                    .onMove { library.movePlaylistItems(playlistId, from: $0, to: $1) }
                } footer: {
                    Text("التشغيل ينتقل تلقائياً إلى التسجيل التالي. اسحب لإعادة الترتيب من زر «تعديل».")
                }
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Brand.canvas)
        .navigationTitle(playlist?.name ?? "قائمة تشغيل")
        .toolbar {
            ToolbarItem(placement: .topBarLeading) { EditButton() }
            ToolbarItem(placement: .topBarLeading) {
                Button { name = playlist?.name ?? ""; renaming = true } label: { Image(systemName: "pencil") }
                    .accessibilityLabel("إعادة التسمية")
            }
        }
        .alert("اسم القائمة", isPresented: $renaming) {
            TextField("الاسم", text: $name)
            Button("حفظ") { library.renamePlaylist(playlistId, name) }
            Button("إلغاء", role: .cancel) {}
        }
        .sheet(item: $linkingItem) { item in
            NavigationStack { ListenLinkDuaSheet(item: item) }
                .environment(\.layoutDirection, .rightToLeft)
        }
    }
}
