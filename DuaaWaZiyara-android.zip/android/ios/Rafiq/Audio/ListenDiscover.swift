import SwiftUI

// MARK: - Discover: famous duas and ziyarat, today's suggestion, favourite reciter

/// A well-known dua or ziyara that has its text in the library and is easy to find as audio.
struct CuratedAudio: Identifiable, Hashable {
    let catId: String
    let itemId: String
    let title: String
    /// Short search key (expanded to English transliterations by AudioSearch).
    let key: String
    let symbol: String
    var id: String { "\(catId)|\(itemId)" }
}

/// A curated item with the reason it fits now.
struct CuratedSuggestion: Identifiable {
    let item: CuratedAudio
    let why: String
    var id: String { item.id }
}

enum ListenDiscover {
    static let favReciterKey = "favReciter"

    static let all: [CuratedAudio] = [
        CuratedAudio(catId: "mashhura", itemId: "m-kumayl", title: "دعاء كميل", key: "دعاء كميل", symbol: "moon.stars.fill"),
        CuratedAudio(catId: "mashhura", itemId: "m-tawassul", title: "دعاء التوسل", key: "دعاء التوسل", symbol: "hands.sparkles.fill"),
        CuratedAudio(catId: "mashhura", itemId: "m-ahd", title: "دعاء العهد", key: "دعاء العهد", symbol: "sunrise.fill"),
        CuratedAudio(catId: "mashhura", itemId: "m-nudba", title: "دعاء الندبة", key: "دعاء الندبة", symbol: "heart.fill"),
        CuratedAudio(catId: "ziyarat", itemId: "z-ashura", title: "زيارة عاشوراء", key: "زيارة عاشوراء", symbol: "flame.fill"),
        CuratedAudio(catId: "ziyarat", itemId: "z-warith", title: "زيارة وارث", key: "زيارة وارث", symbol: "building.columns.fill"),
        CuratedAudio(catId: "ziyarat", itemId: "z-amin", title: "زيارة أمين الله", key: "زيارة امين الله", symbol: "building.columns"),
        CuratedAudio(catId: "ziyarat", itemId: "z-jamia", title: "الزيارة الجامعة", key: "الزيارة الجامعة", symbol: "books.vertical.fill"),
        CuratedAudio(catId: "ziyarat", itemId: "z-yasin", title: "زيارة آل ياسين", key: "زيارة ال ياسين", symbol: "star.fill"),
        CuratedAudio(catId: "ziyarat", itemId: "z-kisa", title: "حديث الكساء", key: "حديث الكساء", symbol: "person.3.fill"),
        CuratedAudio(catId: "sabah", itemId: "sb-sabah-ali", title: "دعاء الصباح", key: "دعاء الصباح", symbol: "sun.max.fill"),
        CuratedAudio(catId: "jumaa", itemId: "j-samat", title: "دعاء السمات", key: "دعاء السمات", symbol: "sparkles"),
        CuratedAudio(catId: "mashhura", itemId: "m-iftitah", title: "دعاء الافتتاح", key: "دعاء الافتتاح", symbol: "moon.fill"),
        CuratedAudio(catId: "ramadan", itemId: "r-abuhamza", title: "دعاء أبي حمزة", key: "دعاء ابو حمزه", symbol: "moon.haze.fill"),
        CuratedAudio(catId: "ramadan", itemId: "r-jawshan", title: "الجوشن الكبير", key: "دعاء الجوشن", symbol: "shield.fill"),
        CuratedAudio(catId: "mashhura", itemId: "m-arafa", title: "دعاء عرفة", key: "دعاء عرفة", symbol: "mountain.2.fill"),
    ].filter { Library.item($0.catId, $0.itemId) != nil }

    /// Well-known reciters of duas and ziyarat (names as their recordings are usually titled).
    static let reciters = ["باسم الكربلائي", "علي فاني", "أباذر الحلواجي", "مهدي سماواتي", "حسين الأكرف", "ميثم التمار"]

    static func find(_ itemId: String) -> CuratedAudio? { all.first { $0.itemId == itemId } }

    static func query(_ c: CuratedAudio, reciter: String) -> String {
        reciter.isEmpty ? c.key : c.key + " " + reciter
    }

    /// What fits today, with the reason shown under it (weekday and Hijri month).
    static func today(_ h: Hijri.HDate, date: Date = Date()) -> [CuratedSuggestion] {
        let wd = Calendar(identifier: .gregorian).component(.weekday, from: date)   // 1 = Sunday
        let hour = Calendar(identifier: .gregorian).component(.hour, from: date)
        var out: [(String, String)] = []
        if h.m == 1 && h.d <= 13 { out.append(("z-ashura", "أيام محرّم")) }
        if h.m == 9 {
            out.append(("m-iftitah", "كلّ ليلة من شهر رمضان"))
            out.append(("r-abuhamza", "في أسحار شهر رمضان"))
        }
        if h.m == 12 && h.d == 9 { out.append(("m-arafa", "يوم عرفة")) }
        // Thursday evening is the eve of Friday (ليلة الجمعة).
        if (wd == 5 && hour >= 15) || (wd == 6 && hour < 4) { out.append(("m-kumayl", "ليلة الجمعة")) }
        if wd == 6 && hour >= 4 {
            out.append(("m-nudba", "يوم الجمعة"))
            if hour >= 12 { out.append(("j-samat", "آخر ساعات الجمعة")) }
        }
        if (wd == 3 && hour >= 15) || (wd == 4 && hour < 4) { out.append(("m-tawassul", "ليلة الأربعاء")) }
        if hour >= 4 && hour < 11 { out.append(("m-ahd", "بعد صلاة الصبح")) }
        var seen = Set<String>()
        return out.compactMap { (pair: (String, String)) -> CuratedSuggestion? in
            let (id, why) = pair
            guard !seen.contains(id), let c = find(id) else { return nil }
            seen.insert(id)
            return CuratedSuggestion(item: c, why: why)
        }
        .prefix(3).map { $0 }
    }
}

// MARK: - Views

/// Shown on the Listen search tab before anything is typed.
struct ListenDiscoverContent: View {
    let onPick: (CuratedAudio) -> Void
    let onRead: (CuratedAudio) -> Void
    @Environment(Store.self) private var store
    @Environment(\.horizontalSizeClass) private var hSize
    @AppStorage(ListenDiscover.favReciterKey) private var reciter = ""
    @State private var library = AudioLibrary.shared
    @State private var player = AudioPlayer.shared

    var body: some View {
        if let r = continueItem {
            Section("أكمل الاستماع") {
                ListenResumeRow(item: r)
            }
        }
        let today = ListenDiscover.today(store.hijriToday())
        if !today.isEmpty {
            Section("مقترح الآن") {
                ForEach(today) { s in
                    Button { onPick(s.item) } label: { suggestion(s.item, s.why) }
                        .buttonStyle(.plain)
                        .contextMenu { readButton(s.item) }
                }
            }
        }
        Section {
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: hSize == .regular ? 4 : 2), spacing: 10) {
                ForEach(ListenDiscover.all) { c in
                    Button { onPick(c) } label: { tile(c) }
                        .buttonStyle(.plain)
                        .contextMenu { readButton(c) }
                }
            }
            .listRowBackground(Color.clear)
            .listRowInsets(EdgeInsets(top: 4, leading: 0, bottom: 4, trailing: 0))
        } header: {
            Text("أدعية وزيارات مشهورة")
        } footer: {
            Text("اضغط للبحث عن تسجيل، ثم «ربط» ليُنزَّل ويرتبط بالنص. بعدها يعمل من هنا ومن صفحة الدعاء مباشرة.")
        }
        Section {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    chip("أيّ قارئ", value: "")
                    ForEach(ListenDiscover.reciters, id: \.self) { chip($0, value: $0) }
                }
                .padding(.vertical, 2)
            }
            .listRowBackground(Color.clear)
            .listRowInsets(EdgeInsets())
        } header: {
            Text("القارئ المفضّل")
        } footer: {
            Text("يُضاف اسم القارئ إلى البحث عند اختيار دعاء من الأعلى.")
        }
    }

    /// The most recent long recording that was left part-way.
    private var continueItem: AudioItem? {
        player.recent.first { it in
            it.id != player.current?.id && (player.resumeFraction(it) ?? 0) > 0.02
        }
    }

    private func readButton(_ c: CuratedAudio) -> some View {
        Button { onRead(c) } label: { Label("اقرأ النص", systemImage: "book") }
    }

    private func suggestion(_ c: CuratedAudio, _ why: String) -> some View {
        let linked = library.linked(catId: c.catId, itemId: c.itemId)
        return HStack(spacing: 12) {
            Image(systemName: c.symbol)
                .font(.system(size: 20, weight: .semibold)).foregroundStyle(.white)
                .frame(width: 48, height: 48)
                .background(RoundedRectangle(cornerRadius: 12).fill(Brand.gold.gradient))
            VStack(alignment: .leading, spacing: 2) {
                Text(c.title).font(.headline)
                Text(why).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: linked == nil ? "magnifyingglass" : "play.circle.fill")
                .font(.title2).foregroundStyle(Brand.emerald)
        }
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
        .accessibilityHint(linked == nil ? "ابحث عن تسجيل" : "تشغيل")
    }

    private func tile(_ c: CuratedAudio) -> some View {
        let linked = library.linked(catId: c.catId, itemId: c.itemId)
        let offline = linked.map { library.isDownloaded($0.id) } ?? false
        return VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: c.symbol).font(.system(size: 18, weight: .semibold)).foregroundStyle(Brand.gold)
                Spacer()
                if linked != nil {
                    Image(systemName: offline ? "checkmark.circle.fill" : "play.circle.fill")
                        .foregroundStyle(offline ? Brand.good : Brand.emerald)
                }
            }
            Text(c.title).font(.subheadline.weight(.bold)).foregroundStyle(.primary)
                .lineLimit(2).multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)
            Text(linked == nil ? "ابحث عن تسجيل" : (offline ? "منزّل · تشغيل" : "تشغيل"))
                .font(.caption2).foregroundStyle(.secondary)
        }
        .padding(12)
        .frame(minHeight: 96, alignment: .top)
        .background(RoundedRectangle(cornerRadius: 16).fill(Color(.secondarySystemGroupedBackground)))
        .contentShape(RoundedRectangle(cornerRadius: 16))
        .accessibilityElement(children: .combine)
    }

    private func chip(_ title: String, value: String) -> some View {
        let on = reciter == value
        return Button {
            reciter = value
            Haptic.tick()
        } label: {
            Text(title).font(.subheadline.weight(.semibold))
                .padding(.horizontal, 14).padding(.vertical, 8)
                .foregroundStyle(on ? .white : .primary)
                .background(Capsule().fill(on ? AnyShapeStyle(Brand.emerald) : AnyShapeStyle(Color(.secondarySystemGroupedBackground))))
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

/// A recording with its saved place: tap to continue.
struct ListenResumeRow: View {
    let item: AudioItem
    @State private var player = AudioPlayer.shared

    var body: some View {
        Button { player.play(item) } label: {
            HStack(spacing: 12) {
                AudioThumb(item: item, size: 52)
                VStack(alignment: .leading, spacing: 4) {
                    Text(item.title).font(.subheadline.weight(.semibold)).lineLimit(1)
                    if let f = player.resumeFraction(item) {
                        ProgressView(value: f).tint(Brand.gold)
                        Text("متابعة من \(AudioFormat.time(player.resume[item.id]))")
                            .font(.caption).foregroundStyle(.secondary)
                    } else {
                        Text(item.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                Spacer()
                Image(systemName: "play.circle.fill").font(.title).foregroundStyle(Brand.emerald)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Storage and downloads

struct ListenStorageView: View {
    @State private var library = AudioLibrary.shared
    @State private var player = AudioPlayer.shared
    @AppStorage(AudioLibrary.wifiOnlyKey) private var wifiOnly = false
    @State private var confirmAll = false
    @State private var confirmHistory = false

    var body: some View {
        List {
            Section {
                HStack {
                    Label("المساحة المستخدمة", systemImage: "internaldrive")
                    Spacer()
                    Text(AudioFormat.bytes(library.totalBytes)).foregroundStyle(.secondary).monospacedDigit()
                }
                HStack {
                    Label("تسجيلات على الجهاز", systemImage: "arrow.down.circle")
                    Spacer()
                    Text(library.downloadedItems.count.ar).foregroundStyle(.secondary)
                }
            }
            Section {
                Toggle(isOn: $wifiOnly) { Label("التنزيل عبر Wi‑Fi فقط", systemImage: "wifi") }
                    .tint(Brand.emerald)
            } footer: {
                Text(wifiOnly ? "تنتظر التنزيلات حتى تتصل بشبكة Wi‑Fi، ثم تكتمل حتى لو كان التطبيق مغلقاً. ينطبق على التنزيلات الجديدة."
                              : "تُنزَّل التسجيلات عبر Wi‑Fi أو بيانات الجوال.")
            }
            let items = library.downloadedItems
            if !items.isEmpty {
                Section {
                    ForEach(items) { it in
                        HStack(spacing: 12) {
                            AudioThumb(item: it, size: 40)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(it.title).font(.subheadline).lineLimit(1)
                                Text(it.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer()
                            Text(AudioFormat.bytes(library.fileSize(it))).font(.caption).foregroundStyle(.secondary)
                        }
                        .swipeActions(edge: .trailing) {
                            if it.remoteURL != nil {
                                Button(role: .destructive) { library.removeDownload(it) } label: {
                                    Label("حذف الملف", systemImage: "icloud.slash")
                                }
                            } else {
                                Button(role: .destructive) { library.delete(it) } label: { Label("حذف", systemImage: "trash") }
                            }
                        }
                    }
                } header: {
                    Text("الأكبر حجماً أولاً")
                } footer: {
                    Text("اسحب لحذف الملف. يبقى التسجيل في مكتبتك للاستماع عبر الإنترنت، ويمكن تنزيله مجدداً.")
                }
                Section {
                    Button(role: .destructive) { confirmAll = true } label: {
                        Label("حذف كلّ الملفات المنزّلة", systemImage: "trash")
                    }
                }
            }
            if !player.recent.isEmpty {
                Section {
                    Button(role: .destructive) { confirmHistory = true } label: {
                        Label("مسح سجلّ الاستماع ومواضع المتابعة", systemImage: "clock.arrow.circlepath")
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("التنزيلات والمساحة")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("حذف كلّ الملفات المنزّلة؟", isPresented: $confirmAll, titleVisibility: .visible) {
            Button("حذف الملفات", role: .destructive) { library.removeAllDownloads(); Haptic.confirm() }
            Button("إلغاء", role: .cancel) {}
        } message: {
            Text("تبقى التسجيلات وقوائم التشغيل والروابط بالأدعية، وتعمل عبر الإنترنت. الملفات المستوردة لا تُحذف.")
        }
        .confirmationDialog("مسح السجلّ؟", isPresented: $confirmHistory, titleVisibility: .visible) {
            Button("مسح", role: .destructive) { player.clearRecent() }
            Button("إلغاء", role: .cancel) {}
        }
    }
}
