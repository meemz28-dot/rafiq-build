import SwiftUI

// MARK: - Hajj and Umrah guide (ported from Android ui/HajjScreen.kt + ui/HajjData.kt)

fileprivate let hajjSaiGuidance = "لا يجب في السعي دعاءٌ مخصوصٌ لكلّ شوط. يُستحبّ الإكثارُ من ذكر الله والصلاةِ على محمّدٍ وآل محمّد، والدعاءِ المأثورِ عن أهل البيت (ع). وعلى الصفا والمروة: استقبِلِ الكعبةَ وكبِّرْ واحمَدِ اللهَ وأثنِ عليهِ ثمّ ادعُ بحاجتك."
fileprivate let hajjTalbiya = "لَبَّيْكَ اللّٰهُمَّ لَبَّيْكَ، لَبَّيْكَ لا شَريكَ لَكَ لَبَّيْكَ، إِنَّ الْحَمْدَ وَالنِّعْمَةَ لَكَ وَالْمُلْكَ، لا شَريكَ لَكَ لَبَّيْكَ."
fileprivate let hajjOrdinals = ["الأول", "الثاني", "الثالث", "الرابع", "الخامس", "السادس", "السابع"]
fileprivate let hajjSupportEmail = "feedback@rafiqalmumin.app"

/// Done step ids, stored like Android: comma-joined string at "hajjDone".
fileprivate func hajjDoneList(_ store: Store) -> [String] {
    store.string("hajjDone").split(separator: ",").map { String($0) }.filter { !$0.isEmpty }
}

fileprivate func hajjToggleStep(_ store: Store, _ id: String) {
    var a = hajjDoneList(store)
    if let i = a.firstIndex(of: id) { a.remove(at: i) } else { a.append(id) }
    store.put("hajjDone", a.joined(separator: ","))
}

fileprivate func hajjDoneCount(_ store: Store, prefix: String) -> Int {
    hajjDoneList(store).filter { $0.hasPrefix(prefix) }.count
}

/// When each step falls (Dhul Hijja days for Hajj al-Tamattu'), shown on the step.
fileprivate let hajjDay: [String: String] = [
    "h-lbs": "٨ ذو الحجّة · يوم التروية", "h-ihram": "٨ ذو الحجّة · يوم التروية",
    "h-arafat": "٩ ذو الحجّة · من الظهر إلى المغرب", "h-mashar": "ليلة ١٠ وحتى طلوع الشمس",
    "h-ramy1": "١٠ ذو الحجّة · يوم النحر", "h-hady": "١٠ ذو الحجّة · يوم النحر", "h-halq": "١٠ ذو الحجّة · يوم النحر",
    "h-tawaf": "بعد الحلق، من يوم ١٠", "h-salat": "بعد طواف الحجّ", "h-sai": "بعد صلاة الطواف",
    "h-tawafnisa": "بعد السعي", "h-salatnisa": "بعد طواف النساء",
    "h-mabit": "ليلتا ١١ و١٢ (و١٣ لبعض الحجّاج)", "h-ramy": "نهار ١١ و١٢ (و١٣)"
]

/// Duas of the place (from «أدعية الحجّ والعمرة»), matched by words in their titles.
fileprivate let hajjStepDuaWords: [String: [String]] = [
    "ihram": ["التلبية"], "tawaf": ["الطواف ومواضعه", "الحجر الأسود", "دخول المسجد"], "tawafnisa": ["الطواف ومواضعه"],
    "salat": ["صلاة الطواف"], "salatnisa": ["صلاة الطواف"], "sai": ["الصفا والمروة"],
    "arafat": ["بعرفات", "منى وعرفات"], "mashar": ["المشعر"], "ramy1": ["رمي"], "ramy": ["رمي"]
]

fileprivate func hajjStepDuas(_ stepId: String) -> [DuaaItem] {
    let key = stepId.split(separator: "-").dropFirst().joined(separator: "-")
    guard let words = hajjStepDuaWords[key], let cat = Library.category("hajj") else { return [] }
    return cat.items.filter { it in words.contains { it.title.contains($0) } }
}

/// Gold progress ring.
fileprivate struct HajjRing: View {
    let progress: Double
    var lineWidth: CGFloat = 5
    var body: some View {
        ZStack {
            Circle().stroke(Color.white.opacity(0.18), lineWidth: lineWidth)
            Circle()
                .trim(from: 0, to: CGFloat(max(0, min(1, progress))))
                .stroke(Brand.gold, style: StrokeStyle(lineWidth: lineWidth, lineCap: .round))
                .rotationEffect(.degrees(-90))
        }
    }
}

// MARK: - Hub

struct HajjView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @State private var guide: String?

    private var data: HajjData { Library.shared.hajj }
    private var duas: [DuaaItem] { Library.category("hajj")?.items ?? [] }

    var body: some View {
        ScreenScroll {
            heroCard
            if !duas.isEmpty { duasCard }
            noticeCard
            SectionTitle(text: "مقدّمات ومسائل")
            preliminariesCard
            SectionTitle(text: "عدّاد الطواف والسعي")
            HajjTawafCounter(fixedKind: nil)
            SectionTitle(text: "التلبية")
            talbiyaCard
            reportRow
        }
        .navigationTitle("الحجّ والعمرة")
        .navigationBarTitleDisplayMode(.large)
    }

    private var heroCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("ابدأ المناسك خطوةً بخطوة").font(.headline)
            ritualRow(title: "عمرة التمتّع", key: "umrah", prefix: "u-", total: data.umrah.count)
            ritualRow(title: "حجّ التمتّع", key: "hajj", prefix: "h-", total: data.hajj.count)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .hero()
    }

    private func ritualRow(title: String, key: String, prefix: String, total: Int) -> some View {
        let done = hajjDoneCount(store, prefix: prefix)
        let frac: Double = total > 0 ? min(1, Double(done) / Double(total)) : 0
        return Button {
            nav.open(.hajjGuide(key))
        } label: {
            HStack(spacing: 14) {
                ZStack {
                    HajjRing(progress: frac)
                    Image(systemName: "building.columns.fill").font(.system(size: 16, weight: .semibold))
                }
                .frame(width: 48, height: 48)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.headline)
                    Text(verbatim: "\(done.ar) من \(total.ar) خطوةً مكتملة").font(.caption).opacity(0.8)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.forward").font(.footnote.weight(.semibold)).opacity(0.7)
            }
            .foregroundStyle(.white)
            .padding(12)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .glass(18, interactive: true)
    }

    private var duasCard: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 12) {
                IconChip(symbol: Brand.categorySymbol("hajj"), colors: Brand.categoryColors("hajj"), size: 40)
                VStack(alignment: .leading, spacing: 2) {
                    Text("أدعية المواقف").font(.headline)
                    Text("ما يُقال في كلّ موقفٍ بترتيب المناسك").font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(.bottom, 6)
            ForEach(Array(duas.enumerated()), id: \.offset) { pair in
                duaRow(index: pair.offset, item: pair.element)
            }
        }
        .card()
    }

    private func duaRow(index: Int, item: DuaaItem) -> some View {
        VStack(spacing: 0) {
            if index > 0 { Divider() }
            Button {
                nav.openReader("hajj", item.id)
            } label: {
                HStack(spacing: 10) {
                    Text((index + 1).ar).font(.caption.weight(.bold)).foregroundStyle(Brand.gold).frame(width: 24)
                    Text(item.title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary).lineLimit(1)
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.forward").font(.caption).foregroundStyle(.tertiary)
                }
                .padding(.vertical, 10)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
    }

    private var noticeCard: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "flag.fill").foregroundStyle(Brand.gold)
            Text("دليلٌ إرشاديٌّ للتسلسل العامّ للمناسك. الأحكامُ التفصيليّةُ في مناسك مرجعك، ولا يُعتمَد عليه في أداء المناسك دون الرجوع إليها.")
                .font(.footnote)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Brand.gold.opacity(0.13), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var preliminariesCard: some View {
        VStack(spacing: 0) {
            ForEach(Array(data.preliminaries.enumerated()), id: \.offset) { pair in
                VStack(spacing: 0) {
                    if pair.offset > 0 { Divider() }
                    HajjTopicRow(topic: pair.element)
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private var talbiyaCard: some View {
        Text(hajjTalbiya)
            .font(.scripture(20))
            .lineSpacing(10)
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .card()
    }

    @ViewBuilder private var reportRow: some View {
        let subject = "ملاحظة على دليل الحجّ والعمرة".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        if let url = URL(string: "mailto:\(hajjSupportEmail)?subject=\(subject)") {
            Link(destination: url) {
                Label("أبلِغ عن ملاحظةٍ أو خطأ", systemImage: "flag")
                    .font(.footnote.weight(.medium))
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
        }
    }
}

// MARK: - Expandable topic

fileprivate struct HajjTopicRow: View {
    let topic: HajjTopic
    @State private var open = false
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { open.toggle() }
            } label: {
                HStack {
                    Text(topic.title).font(.subheadline.weight(.bold)).foregroundStyle(.primary)
                    Spacer(minLength: 8)
                    Image(systemName: "chevron.down")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(Brand.emerald)
                        .rotationEffect(.degrees(open ? 0 : 90))
                }
                .padding(.vertical, 12)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if open {
                Text(topic.note)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.bottom, 12)
            }
        }
    }
}

// MARK: - Tawaf / Sa'i counter

fileprivate struct HajjTawafCounter: View {
    let fixedKind: String?
    /// Which tawaf or sa'i this is (the step id), so the count survives leaving the screen or a call.
    var storageKey: String = "free"
    @State private var mode = "tawaf"
    @State private var count = 0
    @State private var loaded = false

    private var kind: String {
        if let k = fixedKind, !k.isEmpty { return k }
        return mode
    }
    private var done: Bool { count >= 7 }
    private var duas: [String] { Library.shared.hajj.tawafDuas }

    var body: some View {
        VStack(spacing: 14) {
            if fixedKind == nil {
                Picker("", selection: $mode) {
                    Text("الطواف").tag("tawaf")
                    Text("السعي").tag("sai")
                }
                .pickerStyle(.segmented)
            }
            tapButton
            Text(kind == "tawaf" ? "من 7 أشواطٍ حول الكعبة" : "من 7 أشواطٍ بين الصفا والمروة")
                .font(.footnote).opacity(0.8)
            dots
            guidance
            HStack(spacing: 10) {
                Button {
                    advance()
                } label: {
                    Text(done ? "اكتملت ٧ أشواط ✓" : "الشوط التالي")
                        .font(.subheadline.weight(.bold))
                        .frame(maxWidth: .infinity)
                }
                .glassButton(prominent: !done)
                .controlSize(.large)
                Button {
                    if count > 0 { count -= 1; Haptic.tick() }
                } label: {
                    Image(systemName: "arrow.uturn.backward").font(.subheadline.weight(.bold))
                }
                .glassButton()
                .controlSize(.large)
                .accessibilityLabel("تراجع شوطاً")
                .disabled(count == 0)
                Button {
                    count = 0
                    Haptic.tick()
                } label: {
                    Text("تصفير").font(.subheadline.weight(.bold))
                }
                .glassButton()
                .controlSize(.large)
            }
            Text("يبقى العدّ محفوظاً لو خرجت من الشاشة، وتبقى الشاشة مضاءة أثناءه.")
                .font(.caption2).opacity(0.7)
                .multilineTextAlignment(.center)
        }
        .padding(18)
        .frame(maxWidth: .infinity)
        .environment(\.colorScheme, .dark)
        .hero()
        .keepScreenAwake(true)
        .onAppear {
            count = UserDefaults.standard.integer(forKey: countKey)
            loaded = true
        }
        .onChange(of: mode) { _, _ in
            count = UserDefaults.standard.integer(forKey: countKey)
        }
        .onChange(of: count) { _, v in
            if loaded { UserDefaults.standard.set(v, forKey: countKey) }
        }
    }

    private var countKey: String { "hajjCount-\(storageKey)-\(kind)" }

    private func advance() {
        guard count < 7 else { return }
        count += 1
        if count == 7 { Haptic.confirm() } else { Haptic.tick() }
    }

    private var tapButton: some View {
        Button {
            advance()
        } label: {
            VStack(spacing: 2) {
                Text(count.ar).font(.counter(64)).foregroundStyle(Brand.gold)
                Image(systemName: done ? "checkmark" : "hand.tap.fill").font(.footnote.weight(.bold)).opacity(0.8)
            }
            .foregroundStyle(.white)
            .frame(width: 168, height: 168)
            .contentShape(Circle())
        }
        .buttonStyle(.plain)
        .glassCircle(tint: Brand.emerald, interactive: true)
    }

    private var dots: some View {
        HStack(spacing: 8) {
            ForEach(0..<7, id: \.self) { d in
                Circle()
                    .fill(d < count ? Brand.gold : Color.white.opacity(0.25))
                    .frame(width: d < count ? 12 : 10, height: d < count ? 12 : 10)
            }
        }
    }

    @ViewBuilder private var guidance: some View {
        if kind == "tawaf" {
            if count >= 1 && count <= 7 && count - 1 < duas.count {
                VStack(spacing: 8) {
                    Text("دعاء الشوط \(hajjOrdinals[count - 1])").font(.caption.weight(.bold)).foregroundStyle(Brand.gold)
                    Text(duas[count - 1])
                        .font(.scripture(18))
                        .lineSpacing(8)
                        .multilineTextAlignment(.center)
                        .fixedSize(horizontal: false, vertical: true)
                    Text("مأثورٌ عن الإمام الصادق (ع) برواية معاوية بن عمّار")
                        .font(.caption2.weight(.medium)).foregroundStyle(Brand.gold)
                        .multilineTextAlignment(.center)
                }
                .padding(14)
                .frame(maxWidth: .infinity)
                .glass(16)
            } else {
                Text("اضغط «الشوط التالي» عند إتمام كلّ شوط، مبتدئاً من الحجر الأسود.")
                    .font(.footnote).opacity(0.8)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
        } else {
            Text(hajjSaiGuidance)
                .font(.footnote)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
                .padding(14)
                .frame(maxWidth: .infinity)
                .glass(16)
        }
    }
}

// MARK: - Step-by-step guide

struct HajjGuideScreen: View {
    let ritual: String
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var i = 0
    @State private var showSteps = false
    @State private var positioned = false

    private var steps: [HajjStep] { ritual == "umrah" ? Library.shared.hajj.umrah : Library.shared.hajj.hajj }
    private var title: String { ritual == "umrah" ? "عمرة التمتّع" : "حجّ التمتّع" }
    private var isLast: Bool { i >= steps.count - 1 }

    var body: some View {
        ScreenScroll {
            if steps.indices.contains(i) {
                header
                stepBody(steps[i])
            }
        }
        .safeAreaInset(edge: .bottom) { navBar }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
        .animation(.easeInOut(duration: 0.2), value: i)
        .simultaneousGesture(
            DragGesture(minimumDistance: 40).onEnded { v in
                guard abs(v.translation.width) > abs(v.translation.height) * 1.5 else { return }
                // Right-to-left: swipe toward the left goes forward.
                if v.translation.width < -60, !isLast { i += 1; Haptic.tick() }
                if v.translation.width > 60, i > 0 { i -= 1; Haptic.tick() }
            }
        )
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { showSteps = true } label: { Image(systemName: "list.number") }
                    .accessibilityLabel("كلّ الخطوات")
            }
        }
        .sheet(isPresented: $showSteps) {
            NavigationStack { stepsList }
                .presentationDetents([.medium, .large])
                .environment(\.layoutDirection, .rightToLeft)
        }
        .onAppear {
            // Continue from the first step not yet done.
            guard !positioned else { return }
            positioned = true
            let done = Set(hajjDoneList(store))
            if let first = steps.firstIndex(where: { !done.contains($0.id) }) { i = first }
        }
    }

    private var stepsList: some View {
        let done = Set(hajjDoneList(store))
        return List {
            ForEach(Array(steps.enumerated()), id: \.offset) { n, st in
                Button {
                    i = n
                    showSteps = false
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: done.contains(st.id) ? "checkmark.circle.fill" : (n == i ? "circle.inset.filled" : "circle"))
                            .font(.title3)
                            .foregroundStyle(done.contains(st.id) ? Brand.good : Brand.emerald)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(verbatim: "\((n + 1).ar). \(st.title)").font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                            Text([st.place, hajjDay[st.id]].compactMap { $0 }.joined(separator: " · "))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var header: some View {
        let frac = steps.isEmpty ? 0 : min(1, Double(i + 1) / Double(steps.count))
        return VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.headline)
            Text("الخطوة \((i + 1).ar) من \(steps.count.ar)").font(.caption).opacity(0.8)
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.22))
                    Capsule().fill(Brand.gold).frame(width: geo.size.width * CGFloat(frac))
                }
            }
            .frame(height: 6)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .hero()
    }

    @ViewBuilder private func stepBody(_ step: HajjStep) -> some View {
        let done = hajjDoneList(store).contains(step.id)
        HStack(spacing: 8) {
            Label(step.place, systemImage: "mappin")
                .font(.caption.weight(.bold))
                .foregroundStyle(Brand.emerald)
                .padding(.horizontal, 12).padding(.vertical, 6)
                .background(Brand.emerald.opacity(0.12), in: Capsule())
            if let d = hajjDay[step.id] {
                Label(d, systemImage: "calendar")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(Brand.goldDeep)
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .background(Brand.gold.opacity(0.15), in: Capsule())
                    .lineLimit(1).minimumScaleFactor(0.8)
            }
        }
        HStack(spacing: 12) {
            Text((i + 1).ar)
                .font(.headline)
                .foregroundStyle(.white)
                .frame(width: 34, height: 34)
                .background(Brand.emerald, in: Circle())
            Text(step.title).font(.title2.weight(.heavy))
        }
        Text(step.desc)
            .font(.body)
            .lineSpacing(6)
            .fixedSize(horizontal: false, vertical: true)
        let duas = hajjStepDuas(step.id)
        if !duas.isEmpty {
            VStack(alignment: .leading, spacing: 0) {
                Label("أدعية هذا الموقف", systemImage: "book.fill")
                    .font(.footnote.weight(.bold)).foregroundStyle(Brand.emerald)
                    .padding(.bottom, 6)
                ForEach(duas) { d in
                    NavigationLink(value: Route.reader("hajj", d.id)) {
                        HStack {
                            Text(d.title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                            Spacer(minLength: 0)
                            Image(systemName: "chevron.forward").font(.caption).foregroundStyle(.tertiary)
                        }
                        .padding(.vertical, 9)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
            }
            .card(16, padding: 14)
        }
        if !step.ruling.isEmpty {
            HajjRulingBlock(step: step).id(step.id)
        }
        if step.counter == 7 {
            HajjTawafCounter(fixedKind: step.kind, storageKey: step.id).id(step.id)
        }
        Button {
            hajjToggleStep(store, step.id)
            if done { Haptic.tick() } else { Haptic.confirm() }
        } label: {
            HStack(spacing: 8) {
                Image(systemName: done ? "checkmark.circle.fill" : "circle")
                Text(done ? "أُتمّت هذه الخطوة ✓ — اضغط للتراجع" : "أتممتُ هذه الخطوة")
            }
            .font(.subheadline.weight(.bold))
            .foregroundStyle(Brand.emerald)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 15)
            .background((done ? Brand.good.opacity(0.16) : Brand.emerald.opacity(0.10)),
                        in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(done ? Brand.good : Brand.emerald.opacity(0.3), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var navBar: some View {
        HStack(spacing: 10) {
            Button {
                if i > 0 { i -= 1 }
            } label: {
                Text("السابق").font(.headline).frame(maxWidth: .infinity)
            }
            .glassButton()
            .controlSize(.large)
            .disabled(i == 0)
            Button {
                if isLast { dismiss() } else { i += 1 }
            } label: {
                Text(isLast ? "إنهاء" : "التالي").font(.headline).frame(maxWidth: .infinity)
            }
            .glassButton(prominent: true)
            .controlSize(.large)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }
}

fileprivate struct HajjRulingBlock: View {
    let step: HajjStep
    @State private var open = false
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { open.toggle() }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "book.fill")
                    Text("أحكام هذه الخطوة").font(.footnote.weight(.bold))
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.down").font(.caption.weight(.bold)).rotationEffect(.degrees(open ? 0 : 90))
                }
                .foregroundStyle(Brand.emerald)
                .padding(14)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if open {
                Text(step.ruling.isEmpty ? "الأحكامُ التفصيليّةُ لهذه الخطوة تُضاف من مصدرٍ موثّق. يُرجى الرجوع إلى مناسك مرجعك في هذه المسألة." : step.ruling)
                    .font(.footnote)
                    .lineSpacing(4)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding([.horizontal, .bottom], 14)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Brand.emerald.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
