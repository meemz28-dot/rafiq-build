import SwiftUI

// MARK: - Hajj and Umrah guide (ported from Android ui/HajjScreen.kt + ui/HajjData.kt)

fileprivate let hajjSaiGuidance = "لا يجب في السعي دعاءٌ مخصوصٌ لكلّ شوط. يُستحبّ الإكثارُ من ذكر الله والصلاةِ على محمّدٍ وآل محمّد، والدعاءِ المأثورِ عن أهل البيت (ع). وعلى الصفا والمروة: استقبِلِ الكعبةَ وكبِّرْ واحمَدِ اللهَ وأثنِ عليهِ ثمّ ادعُ بحاجتك."
fileprivate let hajjTalbiya = "لَبَّيْكَ اللّٰهُمَّ لَبَّيْكَ، لَبَّيْكَ لا شَريكَ لَكَ لَبَّيْكَ، إِنَّ الْحَمْدَ وَالنِّعْمَةَ لَكَ وَالْمُلْكَ، لا شَريكَ لَكَ لَبَّيْكَ."
fileprivate let hajjOrdinals = ["الأول", "الثاني", "الثالث", "الرابع", "الخامس", "السادس", "السابع"]
fileprivate let hajjSupportEmail = "feedback@rafiqalmumin.app"

/// Done step ids, stored like Android: comma-joined string at "hajjDone".
fileprivate func hajjDoneList(_ store: Store) -> [String] {
    store.string("hajjDone").split(separator: ",").map { String($0) }.filter { !$0.isEmpty }
}

fileprivate func hajjToggleStep(_ store: Store, _ id: String) {
    var a = hajjDoneList(store)
    if let i = a.firstIndex(of: id) { a.remove(at: i) } else { a.append(id) }
    store.put("hajjDone", a.joined(separator: ","))
}

fileprivate func hajjDoneCount(_ store: Store, prefix: String) -> Int {
    hajjDoneList(store).filter { $0.hasPrefix(prefix) }.count
}

/// When each step falls (Dhul Hijja days for Hajj al-Tamattu'), shown on the step.
fileprivate let hajjDay: [String: String] = [
    "h-lbs": "٨ ذو الحجّة · يوم التروية", "h-ihram": "٨ ذو الحجّة · يوم التروية",
    "h-arafat": "٩ ذو الحجّة · من الظهر إلى المغرب", "h-mashar": "ليلة ١٠ وحتى طلوع الشمس",
    "h-ramy1": "١٠ ذو الحجّة · يوم النحر", "h-hady": "١٠ ذو الحجّة · يوم النحر", "h-halq": "١٠ ذو الحجّة · يوم النحر",
    "h-tawaf": "بعد الحلق، من يوم ١٠", "h-salat": "بعد طواف الحجّ", "h-sai": "بعد صلاة الطواف",
    "h-tawafnisa": "بعد السعي", "h-salatnisa": "بعد طواف النساء",
    "h-mabit": "ليلتا ١١ و١٢ (و١٣ لبعض الحجّاج)", "h-ramy": "نهار ١١ و١٢ (و١٣)"
]

/// Duas of the place (from «أدعية الحجّ والعمرة»), matched by words in their titles.
fileprivate let hajjStepDuaWords: [String: [String]] = [
    "ihram": ["التلبية"], "tawaf": ["الطواف ومواضعه", "الحجر الأسود", "دخول المسجد"], "tawafnisa": ["الطواف ومواضعه"],
    "salat": ["صلاة الطواف"], "salatnisa": ["صلاة الطواف"], "sai": ["الصفا والمروة"],
    "arafat": ["بعرفات", "منى وعرفات"], "mashar": ["المشعر"], "ramy1": ["رمي"], "ramy": ["رمي"]
]

fileprivate func hajjStepDuas(_ stepId: String) -> [DuaaItem] {
    let key = stepId.split(separator: "-").dropFirst().joined(separator: "-")
    guard let words = hajjStepDuaWords[key], let cat = Library.category("hajj") else { return [] }
    return cat.items.filter { it in words.contains { it.title.contains($0) } }
}

/// Gold progress ring.
fileprivate struct HajjRing: View {
    let progress: Double
    var lineWidth: CGFloat = 5
    var body: some View {
        ZStack {
            Circle().stroke(Color.white.opacity(0.18), lineWidth: lineWidth)
            Circle()
                .trim(from: 0, to: CGFloat(max(0, min(1, progress))))
                .stroke(Brand.gold, style: StrokeStyle(lineWidth: lineWidth, lineCap: .round))
                .rotationEffect(.degrees(-90))
        }
    }
}

// MARK: - Hub

struct HajjView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @State private var guide: String?

    private var data: HajjData { Library.shared.hajj }
    private var duas: [DuaaItem] { Library.category("hajj")?.items ?? [] }

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ScreenScroll(topPadding: 0) {
            ScreenHeader("الحج والعمرة") {
                RoundIconButton(symbol: "chevron.backward", label: "رجوع") { dismiss() }
            }
            heroCard
            if !duas.isEmpty { duasCard }
            noticeCard
            SectionTitle(text: "مقدّمات ومسائل")
            preliminariesCard
            SectionTitle(text: "عدّاد الطواف والسعي")
            HajjTawafCounter(fixedKind: nil)
            SectionTitle(text: "التلبية")
            talbiyaCard
            reportRow
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    private var heroCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("ابدأ المناسك خطوةً بخطوة").font(.subheadline.weight(.bold)).foregroundStyle(.white)
            ritualRow(title: "عمرة التمتّع", key: "umrah", prefix: "u-", total: data.umrah.count)
            ritualRow(title: "حجّ التمتّع", key: "hajj", prefix: "h-", total: data.hajj.count)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .hero()
    }

    private func ritualRow(title: String, key: String, prefix: String, total: Int) -> some View {
        let done = hajjDoneCount(store, prefix: prefix)
        let frac: Double = total > 0 ? min(1, Double(done) / Double(total)) : 0
        return Button {
            nav.open(.hajjGuide(key))
        } label: {
            HStack(spacing: 14) {
                ZStack {
                    HajjRing(progress: frac)
                    Image(systemName: "building.columns.fill").font(.system(size: 16, weight: .semibold))
                }
                .frame(width: 48, height: 48)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.headline)
                    Text(verbatim: "\(done.ar) من \(total.ar) خطوةً مكتملة").font(.caption).opacity(0.8)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.forward").font(.footnote.weight(.semibold)).opacity(0.7)
            }
            .foregroundStyle(.white)
            .padding(12)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .glass(18, interactive: true)
    }

    private var duasCard: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 12) {
                IconChip(symbol: Brand.categorySymbol("hajj"), colors: Brand.categoryColors("hajj"), size: 40)
                VStack(alignment: .leading, spacing: 2) {
                    Text("أدعية المواقف").font(.headline)
                    Text("ما يُقال في كلّ موقفٍ بترتيب المناسك").font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(.bottom, 6)
            ForEach(Array(duas.enumerated()), id: \.offset) { pair in
                duaRow(index: pair.offset, item: pair.element)
            }
        }
        .card()
    }

    private func duaRow(index: Int, item: DuaaItem) -> some View {
        VStack(spacing: 0) {
            if index > 0 { Divider() }
            Button {
                nav.openReader("hajj", item.id)
            } label: {
                HStack(spacing: 10) {
                    Text((index + 1).ar).font(.caption.weight(.bold)).foregroundStyle(Brand.gold).frame(width: 24)
                    Text(item.title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary).lineLimit(1)
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.forward").font(.caption).foregroundStyle(.tertiary)
                }
                .padding(.vertical, 10)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
    }

    private var noticeCard: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "flag.fill").foregroundStyle(Brand.gold)
            Text("دليلٌ إرشاديٌّ للتسلسل العامّ للمناسك. الأحكامُ التفصيليّةُ في مناسك مرجعك، ولا يُعتمَد عليه في أداء المناسك دون الرجوع إليها.")
                .font(.footnote)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Brand.gold.opacity(0.13), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var preliminariesCard: some View {
        VStack(spacing: 0) {
            ForEach(Array(data.preliminaries.enumerated()), id: \.offset) { pair in
                VStack(spacing: 0) {
                    if pair.offset > 0 { Divider() }
                    HajjTopicRow(topic: pair.element)
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private var talbiyaCard: some View {
        Text(hajjTalbiya)
            .font(.scripture(20))
            .lineSpacing(10)
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .card()
    }

    @ViewBuilder private var reportRow: some View {
        let subject = "ملاحظة على دليل الحجّ والعمرة".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        if let url = URL(string: "mailto:\(hajjSupportEmail)?subject=\(subject)") {
            Link(destination: url) {
                Label("أبلِغ عن ملاحظةٍ أو خطأ", systemImage: "flag")
                    .font(.footnote.weight(.medium))
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
        }
    }
}

// MARK: - Expandable topic

fileprivate struct HajjTopicRow: View {
    let topic: HajjTopic
    @State private var open = false
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { open.toggle() }
            } label: {
                HStack {
                    Text(topic.title).font(.subheadline.weight(.bold)).foregroundStyle(.primary)
                    Spacer(minLength: 8)
                    Image(systemName: "chevron.down")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(Brand.emerald)
                        .rotationEffect(.degrees(open ? 0 : 90))
                }
                .padding(.vertical, 12)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if open {
                Text(topic.note)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.bottom, 12)
            }
        }
    }
}

// MARK: - Tawaf / Sa'i counter (v2: white disc with seven arc segments, Kaaba in the middle)

fileprivate struct HajjTawafCounter: View {
    let fixedKind: String?
    /// Which tawaf or sa'i this is (the step id), so the count survives leaving the screen or a call.
    var storageKey: String = "free"
    @State private var mode = "tawaf"
    @State private var count = 0
    @State private var loaded = false
    @State private var lapStart = Date()

    private var kind: String {
        if let k = fixedKind, !k.isEmpty { return k }
        return mode
    }
    private var done: Bool { count >= 7 }
    private var duas: [String] { Library.shared.hajj.tawafDuas }

    var body: some View {
        VStack(spacing: 14) {
            if fixedKind == nil {
                HStack(spacing: 2) {
                    ForEach([("tawaf", "الطواف"), ("sai", "السعي")], id: \.0) { t in
                        Button { withAnimation(.snappy) { mode = t.0 } } label: {
                            Text(t.1).font(.caption.weight(.bold))
                                .foregroundStyle(mode == t.0 ? Color.white : Brand.ink)
                                .padding(.horizontal, 16).frame(height: 34)
                                .background(mode == t.0 ? Brand.deeper : Color.clear, in: Capsule())
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(3)
                .background(Brand.cardFill, in: Capsule())
            }
            disc
            HStack(spacing: 10) {
                pill(count == 0 ? "ابدأ من الحجر" : "تراجع شوطاً", enabled: count > 0) {
                    if count > 0 { count -= 1; lapStart = Date(); Haptic.tick() }
                }
                TimelineView(.periodic(from: lapStart, by: 1)) { ctx in
                    let secs = max(0, Int(ctx.date.timeIntervalSince(lapStart)))
                    pill(done ? "اكتملت ٧ أشواط ✓" : "الشوط \((min(7, count + 1)).ar): \((secs / 60).ar) د", enabled: true) {
                        count = 0; lapStart = Date(); Haptic.tick()
                    }
                }
            }
            guidance
        }
        .frame(maxWidth: .infinity)
        .keepScreenAwake(true)
        .onAppear {
            count = UserDefaults.standard.integer(forKey: countKey)
            loaded = true
        }
        .onChange(of: mode) { _, _ in
            count = UserDefaults.standard.integer(forKey: countKey)
        }
        .onChange(of: count) { _, v in
            if loaded { UserDefaults.standard.set(v, forKey: countKey) }
        }
    }

    private var countKey: String { "hajjCount-\(storageKey)-\(kind)" }

    private func advance() {
        guard count < 7 else { return }
        count += 1
        lapStart = Date()
        if count == 7 { Haptic.confirm() } else { Haptic.tick() }
    }

    private var disc: some View {
        Button(action: advance) {
            ZStack {
                Circle().fill(Brand.cardFill)
                    .shadow(color: Color(hex: 0x10322D).opacity(0.14), radius: 20, y: 10)
                Canvas { ctx, size in
                    let c = CGPoint(x: size.width / 2, y: size.height / 2)
                    let r = size.width / 2 - 22
                    let gap = 0.07
                    for i in 0..<7 {
                        let a0 = -Double.pi / 2 + Double(i) * 2 * .pi / 7 + gap
                        let a1 = -Double.pi / 2 + Double(i + 1) * 2 * .pi / 7 - gap
                        var p = Path()
                        for k in 0...24 {
                            let a = a0 + (a1 - a0) * Double(k) / 24
                            let pt = CGPoint(x: c.x + r * CGFloat(cos(a)), y: c.y + r * CGFloat(sin(a)))
                            if k == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
                        }
                        ctx.stroke(p, with: .color(i < count ? Brand.emerald : Color(hex: 0xE4DCC8)),
                                   style: StrokeStyle(lineWidth: 14, lineCap: .round))
                    }
                }
                VStack(spacing: 4) {
                    if kind == "tawaf" {
                        ZStack(alignment: .top) {
                            RoundedRectangle(cornerRadius: 3).fill(Color(hex: 0x1C1C1E)).frame(width: 36, height: 38)
                            Rectangle().fill(Brand.gold).frame(width: 36, height: 6).padding(.top, 8)
                        }
                    } else {
                        Image(systemName: "figure.walk").font(.system(size: 30, weight: .semibold)).foregroundStyle(Brand.deeper)
                    }
                    Text(count.ar).font(.display(52)).foregroundStyle(Brand.ink)
                        .contentTransition(.numericText()).animation(.snappy(duration: 0.2), value: count)
                    Text(done ? "اكتملت الأشواط السبعة" : (kind == "tawaf" ? "من ٧ أشواط · اضغط عند الحجر" : "من ٧ أشواط · اضغط عند الصفا أو المروة"))
                        .font(.caption).foregroundStyle(Brand.muted)
                }
            }
            .frame(width: 260, height: 260)
            .contentShape(Circle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel("أتممتُ شوطاً")
        .accessibilityValue("\(count.ar) من ٧")
    }

    private func pill(_ title: String, enabled: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title).font(.caption.weight(.semibold)).foregroundStyle(Brand.ink)
                .padding(.horizontal, 16).frame(height: 40)
                .background(Brand.cardFill, in: Capsule())
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
        .opacity(enabled ? 1 : 0.6)
    }

    @ViewBuilder private var guidance: some View {
        if kind == "tawaf" {
            if count >= 1 && count <= 7 && count - 1 < duas.count {
                VStack(spacing: 8) {
                    Text("دعاء الشوط \(hajjOrdinals[count - 1])").font(.caption.weight(.bold)).foregroundStyle(Brand.goldDeep)
                    Text(duas[count - 1])
                        .font(.scripture(18))
                        .lineSpacing(8)
                        .multilineTextAlignment(.center)
                        .foregroundStyle(Brand.ink)
                        .fixedSize(horizontal: false, vertical: true)
                    Text("مأثورٌ عن الإمام الصادق (ع) برواية معاوية بن عمّار")
                        .font(.caption2.weight(.medium)).foregroundStyle(Brand.muted)
                        .multilineTextAlignment(.center)
                }
                .card(18, padding: 14)
            }
        } else {
            Text(hajjSaiGuidance)
                .font(.footnote).foregroundStyle(Brand.ink)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
                .card(18, padding: 14)
        }
    }
}

// MARK: - Step-by-step guide (v2)

struct HajjGuideScreen: View {
    let ritual: String
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var i = 0
    @State private var showSteps = false
    @State private var positioned = false

    private var steps: [HajjStep] { ritual == "umrah" ? Library.shared.hajj.umrah : Library.shared.hajj.hajj }
    private var title: String { ritual == "umrah" ? "عمرة التمتّع" : "حجّ التمتّع" }
    private var isLast: Bool { i >= steps.count - 1 }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if steps.indices.contains(i) {
                    progressDashes
                    stepBody(steps[i])
                }
            }
            .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 24)
            .readableWidth()
        }
        .scrollBounceBehavior(.basedOnSize)
        .background(Color(hex: 0xF7F1E3).ignoresSafeArea())
        .safeAreaInset(edge: .top, spacing: 0) { topBar }
        .safeAreaInset(edge: .bottom, spacing: 0) { navBar }
        .toolbar(.hidden, for: .navigationBar)
        .toolbar(.hidden, for: .tabBar)
        .animation(.easeInOut(duration: 0.2), value: i)
        .simultaneousGesture(
            DragGesture(minimumDistance: 40).onEnded { v in
                guard abs(v.translation.width) > abs(v.translation.height) * 1.5 else { return }
                // Right-to-left: swipe toward the left goes forward.
                if v.translation.width < -60, !isLast { i += 1; Haptic.tick() }
                if v.translation.width > 60, i > 0 { i -= 1; Haptic.tick() }
            }
        )
        .sheet(isPresented: $showSteps) {
            NavigationStack { stepsList }
                .presentationDetents([.medium, .large])
                .environment(\.layoutDirection, .rightToLeft)
        }
        .onAppear {
            // Continue from the first step not yet done.
            guard !positioned else { return }
            positioned = true
            let done = Set(hajjDoneList(store))
            if let first = steps.firstIndex(where: { !done.contains($0.id) }) { i = first }
        }
    }

    private var topBar: some View {
        HStack {
            RoundIconButton(symbol: "chevron.backward", label: "رجوع") { dismiss() }
            Spacer()
            Text(verbatim: "\(title) · الخطوة \((i + 1).ar) من \(steps.count.ar)").font(.subheadline.weight(.bold)).foregroundStyle(Brand.ink)
            Spacer()
            RoundIconButton(symbol: "list.bullet", label: "كلّ الخطوات") { showSteps = true }
        }
        .padding(.horizontal, 16).padding(.vertical, 8)
        .background(Color(hex: 0xF7F1E3).opacity(0.95))
    }

    private var progressDashes: some View {
        let done = Set(hajjDoneList(store))
        return HStack(spacing: 3) {
            ForEach(Array(steps.enumerated()), id: \.offset) { n, st in
                Capsule()
                    .fill(n == i ? Brand.gold : (done.contains(st.id) || n < i ? Brand.emerald : Color(hex: 0xE4DCC8)))
                    .frame(height: 5)
            }
        }
        .accessibilityHidden(true)
    }

    private var stepsList: some View {
        let done = Set(hajjDoneList(store))
        return List {
            ForEach(Array(steps.enumerated()), id: \.offset) { n, st in
                Button {
                    i = n
                    showSteps = false
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: done.contains(st.id) ? "checkmark.circle.fill" : (n == i ? "circle.inset.filled" : "circle"))
                            .font(.title3)
                            .foregroundStyle(done.contains(st.id) ? Brand.good : Brand.emerald)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(verbatim: "\((n + 1).ar). \(st.title)").font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                            Text([st.place, hajjDay[st.id]].compactMap { $0 }.joined(separator: " · "))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }

    @ViewBuilder private func stepBody(_ step: HajjStep) -> some View {
        let done = hajjDoneList(store).contains(step.id)
        VStack(alignment: .leading, spacing: 8) {
            Text(step.title).font(.display(30)).foregroundStyle(Brand.ink)
            HStack(spacing: 8) {
                Text(step.place).font(.caption.weight(.semibold)).foregroundStyle(Brand.deeper)
                    .padding(.horizontal, 10).padding(.vertical, 5)
                    .background(Color(hex: 0xE3EFEC), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                if let d = hajjDay[step.id] {
                    Text(d).font(.caption.weight(.semibold)).foregroundStyle(Color(hex: 0x7A5E22))
                        .padding(.horizontal, 10).padding(.vertical, 5)
                        .background(Brand.sand, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .lineLimit(1).minimumScaleFactor(0.8)
                }
            }
            Text(step.desc)
                .font(.subheadline)
                .foregroundStyle(Color(hex: 0x3E524E))
                .lineSpacing(5)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 4)
        if step.counter == 7 {
            HajjTawafCounter(fixedKind: step.kind, storageKey: step.id).id(step.id)
                .padding(.top, 6)
        }
        let duas = hajjStepDuas(step.id)
        if !duas.isEmpty {
            VStack(spacing: 0) {
                ForEach(Array(duas.enumerated()), id: \.element.id) { n, d in
                    NavigationLink(value: Route.reader("hajj", d.id)) {
                        HStack(spacing: 10) {
                            Image(systemName: "book").font(.system(size: 15, weight: .semibold)).foregroundStyle(Brand.gold)
                            Text(d.title).font(.subheadline.weight(.semibold)).foregroundStyle(Brand.ink)
                            Spacer(minLength: 0)
                            Text(d.src ?? "مفاتيح الجنان").font(.caption).foregroundStyle(Brand.muted).lineLimit(1)
                        }
                        .padding(.horizontal, 16).padding(.vertical, 13)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    if n < duas.count - 1 { Divider().overlay(Color(hex: 0xF0EADB)).padding(.leading, 16) }
                }
            }
            .card(22, padding: 0)
        }
        if !step.ruling.isEmpty {
            HajjRulingBlock(step: step).id(step.id)
        }
        if done {
            Button {
                hajjToggleStep(store, step.id)
                Haptic.tick()
            } label: {
                Label("أُتمّت هذه الخطوة ✓ · اضغط للتراجع", systemImage: "checkmark.circle.fill")
                    .font(.caption.weight(.semibold)).foregroundStyle(Brand.good)
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.plain)
            .padding(.top, 4)
        }
    }

    private var navBar: some View {
        let step = steps.indices.contains(i) ? steps[i] : nil
        let nextTitle = steps.indices.contains(i + 1) ? steps[i + 1].title : nil
        return HStack(spacing: 10) {
            Button {
                if i > 0 { i -= 1; Haptic.tick() }
            } label: {
                Text("السابقة").font(.subheadline.weight(.semibold)).foregroundStyle(Brand.ink)
                    .frame(maxWidth: .infinity).frame(height: 54)
                    .background(Brand.cardFill, in: Capsule())
            }
            .buttonStyle(.plain)
            .disabled(i == 0)
            .opacity(i == 0 ? 0.5 : 1)
            Button {
                if let step, !hajjDoneList(store).contains(step.id) { hajjToggleStep(store, step.id) }
                Haptic.confirm()
                if isLast { dismiss() } else { i += 1 }
            } label: {
                Text(nextTitle.map { "أتممتها · التالية: \($0)" } ?? "أتممتها · إنهاء")
                    .font(.subheadline.weight(.bold)).foregroundStyle(.white)
                    .lineLimit(1).minimumScaleFactor(0.75)
                    .padding(.horizontal, 12)
                    .frame(maxWidth: .infinity).frame(height: 54)
                    .background(Brand.deeper, in: Capsule())
            }
            .buttonStyle(.plain)
            .layoutPriority(1)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(
            LinearGradient(colors: [Color(hex: 0xF7F1E3).opacity(0), Color(hex: 0xF7F1E3)], startPoint: .top, endPoint: .bottom)
                .allowsHitTesting(false)
        )
    }
}

fileprivate struct HajjRulingBlock: View {
    let step: HajjStep
    @State private var open = false
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { open.toggle() }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "book.fill")
                    Text("أحكام هذه الخطوة").font(.footnote.weight(.bold))
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.down").font(.caption.weight(.bold)).rotationEffect(.degrees(open ? 0 : 90))
                }
                .foregroundStyle(Brand.emerald)
                .padding(14)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if open {
                Text(step.ruling.isEmpty ? "الأحكامُ التفصيليّةُ لهذه الخطوة تُضاف من مصدرٍ موثّق. يُرجى الرجوع إلى مناسك مرجعك في هذه المسألة." : step.ruling)
                    .font(.footnote)
                    .lineSpacing(4)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding([.horizontal, .bottom], 14)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Brand.emerald.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
