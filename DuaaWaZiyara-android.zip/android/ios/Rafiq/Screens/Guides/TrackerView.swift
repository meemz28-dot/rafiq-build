import SwiftUI
import CoreMotion
import Observation

// MARK: - Rak'at counter (ported from Android ui/PrayerTrackerScreen.kt + logic/PrayerMotionDetector.kt)

fileprivate enum TrackerPosture { case standing, bowing, prostrating, sitting, unknown }

/// Experimental posture detector on CoreMotion gravity. Same thresholds and state machine as Android:
/// standing, bowing, standing, two prostrations = one rak'ah. All on device.
@Observable
fileprivate final class TrackerMotionDetector {
    var posture: TrackerPosture = .unknown
    var rakah = 0
    var sajda = 0
    var running = false

    @ObservationIgnored private let manager = CMMotionManager()
    @ObservationIgnored private var current: TrackerPosture = .unknown
    @ObservationIgnored private var lastStable: TrackerPosture = .unknown
    @ObservationIgnored private var stableSince = Date()
    @ObservationIgnored private var sawBowing = false
    @ObservationIgnored private var sawStandingAfterBow = false
    @ObservationIgnored private var prostrations = 0

    var isSupported: Bool { manager.isDeviceMotionAvailable }

    func start() {
        guard manager.isDeviceMotionAvailable, !manager.isDeviceMotionActive else { return }
        reset()
        manager.deviceMotionUpdateInterval = 1.0 / 50.0
        manager.startDeviceMotionUpdates(to: OperationQueue.main) { [weak self] motion, _ in
            guard let self, let motion else { return }
            self.process(motion.gravity)
        }
        running = true
    }

    func stop() {
        if manager.isDeviceMotionActive { manager.stopDeviceMotionUpdates() }
        running = false
    }

    func reset() {
        rakah = 0
        sajda = 0
        posture = .unknown
        current = .unknown
        lastStable = .unknown
        sawBowing = false
        sawStandingAfterBow = false
        prostrations = 0
    }

    private func process(_ g: CMAcceleration) {
        // CoreMotion gravity points down (upright phone: y = -1); Android accelerometer reads the opposite sign.
        let gx = -g.x, gy = -g.y, gz = -g.z
        let norm = max(0.0001, (gx * gx + gy * gy + gz * gz).squareRoot())
        let gyN = gy / norm
        let gzN = gz / norm

        let detected: TrackerPosture
        if gyN > 0.72 {
            detected = .standing
        } else if gyN >= 0.20 && gyN <= 0.72 && gzN > 0.45 {
            detected = .bowing
        } else if gzN > 0.78 || gyN < -0.35 {
            detected = .prostrating
        } else if gyN >= 0.20 && gyN <= 0.72 {
            detected = .sitting
        } else {
            detected = current
        }

        let now = Date()
        if detected != current {
            current = detected
            stableSince = now
        }
        // Accept a posture only after it is stable for about 400 ms.
        if current != lastStable && now.timeIntervalSince(stableSince) > 0.4 {
            lastStable = current
            posture = current
            handleTransition(current)
        }
    }

    private func handleTransition(_ p: TrackerPosture) {
        switch p {
        case .bowing:
            sawBowing = true
            sawStandingAfterBow = false
        case .standing:
            if sawBowing { sawStandingAfterBow = true }
        case .prostrating:
            sajda += 1
            prostrations += 1
            Haptic.tick()
            if sawBowing && prostrations >= 2 {
                rakah += 1
                sawBowing = false
                sawStandingAfterBow = false
                prostrations = 0
                Haptic.confirm()
            }
        default:
            break
        }
    }
}

struct TrackerView: View {
    @State private var mode = "manual"

    var body: some View {
        ScreenScroll {
            Picker("", selection: $mode) {
                Text("يدويّ").tag("manual")
                Text("تلقائيّ · تجريبيّ").tag("motion")
            }
            .pickerStyle(.segmented)
            if mode == "manual" {
                TrackerManualPanel()
            } else {
                TrackerMotionPanel()
            }
        }
        .navigationTitle("عدّاد الركعات")
        .navigationBarTitleDisplayMode(.inline)
        .keepScreenAwake(true)
    }
}

// MARK: - Manual counter (reliable default)

fileprivate struct TrackerPrayer { let name: String; let rakat: Int }

fileprivate let trackerPrayers: [TrackerPrayer] = [
    TrackerPrayer(name: "الفجر", rakat: 2), TrackerPrayer(name: "الظهر", rakat: 4),
    TrackerPrayer(name: "العصر", rakat: 4), TrackerPrayer(name: "المغرب", rakat: 3),
    TrackerPrayer(name: "العشاء", rakat: 4), TrackerPrayer(name: "نافلة", rakat: 2)
]

fileprivate struct TrackerManualPanel: View {
    @State private var prayerIdx = 1
    @State private var rakah = 0

    private var target: Int { trackerPrayers.indices.contains(prayerIdx) ? trackerPrayers[prayerIdx].rakat : 2 }
    private var done: Bool { rakah >= target }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("الصلاة").font(.ui(.footnote, .bold)).foregroundStyle(.secondary)
            prayerChips
            counterHero
            HStack(spacing: 10) {
                Button {
                    if rakah > 0 { rakah -= 1; Haptic.tick() }
                } label: {
                    Text("− ركعة").font(.ui(.headline)).frame(maxWidth: .infinity)
                }
                .glassButton()
                .controlSize(.large)
                Button {
                    rakah = 0
                    Haptic.tick()
                } label: {
                    Text("تصفير").font(.ui(.headline)).frame(maxWidth: .infinity)
                }
                .glassButton()
                .controlSize(.large)
            }
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "sparkle").foregroundStyle(Brand.gold)
                Text("يعينك على تتبّع ركعاتك إن خشيت السهو. إن شككت في عددها بعد الانتهاء فالعمل على ما تيقّنت، وراجع أحكام سجود السهو.")
                    .font(.ui(.caption))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Brand.gold.opacity(0.09), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
    }

    private var prayerChips: some View {
        HStack(spacing: 6) {
            ForEach(Array(trackerPrayers.enumerated()), id: \.offset) { pair in
                let sel = pair.offset == prayerIdx
                Button {
                    prayerIdx = pair.offset
                    rakah = 0
                } label: {
                    VStack(spacing: 2) {
                        Text(pair.element.name).font(.ui(.caption2, .bold)).lineLimit(1).minimumScaleFactor(0.7)
                        Text(pair.element.rakat.ar).font(.ui(.caption2)).opacity(0.8)
                    }
                    .foregroundStyle(sel ? Color.white : Color.primary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background((sel ? Brand.emerald : Color(.secondarySystemGroupedBackground)),
                                in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var counterHero: some View {
        VStack(spacing: 14) {
            Text(done ? "أتممت صلاتك ✓" : "الركعة").font(.ui(.subheadline, .bold)).opacity(0.85)
            Button {
                if rakah < target {
                    rakah += 1
                    if rakah == target { Haptic.confirm() } else { Haptic.tick() }
                }
            } label: {
                VStack(spacing: 0) {
                    Text(rakah.ar).font(.counter(84)).foregroundStyle(Brand.gold)
                    Text("من \(target.ar) ركعات").font(.ui(.subheadline)).opacity(0.8)
                }
                .foregroundStyle(.white)
                .frame(width: 210, height: 210)
                .contentShape(Circle())
            }
            .buttonStyle(.plain)
            .glassCircle(tint: Brand.emerald, interactive: true)
            HStack(spacing: 8) {
                ForEach(0..<target, id: \.self) { i in
                    Circle()
                        .fill(i < rakah ? Brand.gold : Color.white.opacity(0.3))
                        .frame(width: 12, height: 12)
                }
            }
            Text(done ? "اضغط «تصفير» لصلاةٍ جديدة" : "انقر لإتمام كلّ ركعة").font(.ui(.caption)).opacity(0.7)
        }
        .padding(.vertical, 28)
        .frame(maxWidth: .infinity)
        .hero()
    }
}

// MARK: - Experimental motion mode

fileprivate struct TrackerMotionPanel: View {
    @State private var detector = TrackerMotionDetector()

    private var postureLabel: String {
        switch detector.posture {
        case .standing: return "قيام"
        case .bowing: return "ركوع"
        case .prostrating: return "سجود"
        case .sitting: return "جلوس"
        case .unknown: return "—"
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "sparkle").foregroundStyle(Brand.mid)
                Text("وضعٌ تجريبيّ: ضع الهاتف في جيب الصدر أو الجيب الأمامي ليقدّر حركاتك. قد يُخطئ بحسب وضع الهاتف وسرعتك — والوضع اليدويّ أدقّ. ليس مرجعاً لصحّة الصلاة.")
                    .font(.ui(.caption))
                    .foregroundStyle(Brand.mid)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Brand.mid.opacity(0.12), in: RoundedRectangle(cornerRadius: 16, style: .continuous))

            if detector.isSupported {
                supportedBody
            } else {
                Text("جهازك لا يحتوي مُستشعِر التسارع اللازم لهذا الوضع. استخدم العدّاد اليدويّ.")
                    .font(.ui(.subheadline))
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity)
                    .card(20, padding: 20)
            }
        }
        .onDisappear { detector.stop() }
    }

    private var supportedBody: some View {
        VStack(spacing: 16) {
            VStack(spacing: 16) {
                HStack(spacing: 12) {
                    counterTile("الركعات", detector.rakah)
                    counterTile("السجدات", detector.sajda)
                }
                Text(postureLabel)
                    .font(.ui(.title2, .heavy))
                    .foregroundStyle(detector.running ? Brand.gold : Color.white.opacity(0.7))
                    .frame(width: 130, height: 130)
                    .glassCircle(tint: detector.running ? Brand.emerald : nil)
                Text(detector.running ? "يرصد الآن…" : "متوقّف")
                    .font(.ui(.footnote, .bold))
                    .foregroundStyle(detector.running ? Brand.mint : Color.white.opacity(0.7))
            }
            .padding(20)
            .frame(maxWidth: .infinity)
            .environment(\.colorScheme, .dark)
            .hero()

            Button {
                if detector.running { detector.stop() } else { detector.start() }
            } label: {
                Text(detector.running ? "إيقاف" : "ابدأ الرصد").font(.ui(.headline)).frame(maxWidth: .infinity)
            }
            .glassButton(prominent: !detector.running)
            .controlSize(.large)
            Button {
                detector.reset()
            } label: {
                Text("تصفير العدّاد").font(.ui(.headline)).frame(maxWidth: .infinity)
            }
            .glassButton()
            .controlSize(.large)
        }
    }

    private func counterTile(_ label: String, _ value: Int) -> some View {
        VStack(spacing: 2) {
            Text(value.ar).font(.counter(38)).foregroundStyle(Brand.gold)
            Text(label).font(.ui(.footnote, .bold)).opacity(0.8)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 18)
        .glass(20)
    }
}
