import SwiftUI

// MARK: - Quran completion plan (ported from Android ui/KhatmaScreen.kt + Settings khatmaPlan/khatmaStart/khatmaDone)

fileprivate let khatmaSuras: [DuaaItem] = Library.category("quran")?.items ?? []
/// Text lengths in UTF-16 units, as Kotlin String.length, computed once.
fileprivate let khatmaWeights: [Int] = khatmaSuras.map { max(1, $0.text.utf16.count) }

/// Splits the suras over the plan days by size, so daily loads are close (same algorithm as Android).
fileprivate func khatmaSchedule(days: Int) -> [[Int]] {
    if days <= 0 || khatmaSuras.isEmpty { return [] }
    let total = khatmaWeights.reduce(0, +)
    let target = total / days
    var out: [[Int]] = []
    var cur: [Int] = []
    var acc = 0
    for i in khatmaSuras.indices {
        cur.append(i)
        acc += khatmaWeights[i]
        if acc >= target && out.count < days - 1 {
            out.append(cur)
            cur = []
            acc = 0
        }
    }
    if !cur.isEmpty { out.append(cur) }
    while out.count < days { out.append([]) }
    return out
}

/// Absolute UTC day, as Android Calendar.timeInMillis / 86400000.
fileprivate func khatmaEpochDay() -> Int { Int(floor(Date().timeIntervalSince1970 / 86400)) }

fileprivate struct KhatmaPlanOption { let key: String; let title: String; let sub: String }

fileprivate let khatmaOptions: [KhatmaPlanOption] = [
    KhatmaPlanOption(key: "30", title: "ختمة الشهر", sub: "جزءٌ كلّ يوم تقريباً — خطّة رمضان المعتادة"),
    KhatmaPlanOption(key: "40", title: "ختمة الأربعين", sub: "وِردٌ يوميّ أخفّ مع مداومة أربعين يوماً"),
    KhatmaPlanOption(key: "90", title: "ختمة الفصل", sub: "صفحاتٌ يسيرة كلّ يوم، الأنسب لمن يبدأ")
]

struct KhatmaView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private var plan: String { store.string("khatmaPlan") }
    private var days: Int { Int(plan) ?? 0 }
    private var doneList: [String] {
        store.string("khatmaDone").split(separator: ",").map { String($0) }.filter { !$0.isEmpty }
    }

    var body: some View {
        ScreenScroll {
            if plan.isEmpty {
                chooseHero
                ForEach(khatmaOptions, id: \.key) { opt in
                    optionRow(opt)
                }
            } else {
                activePlan
            }
        }
        .navigationTitle("الختمة")
        .navigationBarTitleDisplayMode(.large)
    }

    // MARK: Actions (Android Settings.startKhatma / toggleKhatma / endKhatma)

    private func start(_ key: String) {
        store.put("khatmaPlan", key)
        store.put("khatmaStart", khatmaEpochDay())
        store.put("khatmaDone", "")
        Haptic.confirm()
    }

    private func toggle(_ id: String) {
        var a = doneList
        if let i = a.firstIndex(of: id) { a.remove(at: i) } else { a.append(id) }
        store.put("khatmaDone", a.joined(separator: ","))
        Haptic.tick()
    }

    private func end() {
        store.put("khatmaPlan", "")
        store.put("khatmaDone", "")
    }

    // MARK: No plan yet

    private var chooseHero: some View {
        VStack(spacing: 8) {
            Image(systemName: "book.closed.fill").font(.system(size: 30)).foregroundStyle(Brand.gold)
            Text("ابدأ ختمةً جديدة").font(.title2.weight(.heavy))
            Text("اختر مدّة الختمة، ويقسّم التطبيق السور على أيّامها بأحمالٍ متقاربة، ويتابع معك ما أنجزت يوماً بيوم.")
                .font(.footnote)
                .opacity(0.88)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 26)
        .padding(.horizontal, 20)
        .frame(maxWidth: .infinity)
        .hero()
    }

    private func optionRow(_ opt: KhatmaPlanOption) -> some View {
        Button {
            start(opt.key)
        } label: {
            HStack(spacing: 14) {
                Text((Int(opt.key) ?? 0).ar)
                    .font(.counter(17))
                    .foregroundStyle(Brand.emerald)
                    .frame(width: 46, height: 46)
                    .background(Brand.emerald.opacity(0.14), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                VStack(alignment: .leading, spacing: 2) {
                    Text(opt.title).font(.headline).foregroundStyle(.primary).lineLimit(1)
                    Text(opt.sub).font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.leading)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.forward").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
            }
            .card(18)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    // MARK: Running plan

    @ViewBuilder private var activePlan: some View {
        let schedule = khatmaSchedule(days: days)
        let done = Set(doneList)
        let doneCount = done.count
        let total = khatmaSuras.count
        let pct = total > 0 ? Int((Double(doneCount) * 100 / Double(total)).rounded()) : 0
        let dayIndex = days > 0 ? min(days - 1, max(0, khatmaEpochDay() - store.int("khatmaStart", 0))) : 0
        progressHero(pct: pct, doneCount: doneCount, total: total, dayIndex: dayIndex)

        SectionTitle(text: "وِرد اليوم")
        let todays = dayIndex < schedule.count ? schedule[dayIndex] : []
        if todays.isEmpty {
            Text("لا سور مقرّرة لهذا اليوم — اغتنمه لمراجعة ما مضى.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .card(16)
        } else {
            VStack(spacing: 0) {
                ForEach(Array(todays.enumerated()), id: \.offset) { pair in
                    if pair.element < khatmaSuras.count {
                        if pair.offset > 0 { Divider().padding(.leading, 40) }
                        suraRow(khatmaSuras[pair.element], done: done.contains(khatmaSuras[pair.element].id))
                    }
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 4)
            .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        }

        SectionTitle(text: "خريطة الخطّة")
        dayMap(schedule: schedule, done: done, dayIndex: dayIndex)

        Button(role: .destructive) {
            end()
        } label: {
            Text("إنهاء الختمة وبدء غيرها").font(.headline).frame(maxWidth: .infinity)
        }
        .glassButton()
        .controlSize(.large)
        .padding(.top, 6)
    }

    private func progressHero(pct: Int, doneCount: Int, total: Int, dayIndex: Int) -> some View {
        HStack(spacing: 18) {
            ZStack {
                Circle().stroke(Color.white.opacity(0.18), lineWidth: 10)
                Circle()
                    .trim(from: 0, to: CGFloat(max(0, min(100, pct))) / 100)
                    .stroke(Brand.gold, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                Text("\(pct.ar)٪").font(.counter(24)).foregroundStyle(Brand.gold)
            }
            .frame(width: 104, height: 104)
            VStack(alignment: .leading, spacing: 6) {
                Text("\(doneCount.ar) من \(total.ar) سورة").font(.headline)
                Text("اليوم \((dayIndex + 1).ar) من \(days.ar)")
                    .font(.caption.weight(.bold))
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .glassCapsule()
            }
            Spacer(minLength: 0)
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .hero()
    }

    private func suraRow(_ s: DuaaItem, done: Bool) -> some View {
        HStack(spacing: 12) {
            Button {
                toggle(s.id)
            } label: {
                Image(systemName: done ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 24))
                    .foregroundStyle(done ? Brand.emerald : Color(.tertiaryLabel))
                    .frame(width: 32, height: 44)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel(done ? "منجَز" : s.title)
            Button {
                nav.openReader("quran", s.id)
            } label: {
                HStack {
                    Text(s.title).font(.subheadline.weight(.bold)).foregroundStyle(.primary).lineLimit(1)
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.forward").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
                }
                .frame(minHeight: 44)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
    }

    private func dayMap(schedule: [[Int]], done: Set<String>, dayIndex: Int) -> some View {
        let columns = Array(repeating: GridItem(.flexible(), spacing: 4), count: 10)
        return LazyVGrid(columns: columns, spacing: 4) {
            ForEach(0..<schedule.count, id: \.self) { idx in
                let dayDone = !schedule[idx].isEmpty && schedule[idx].allSatisfy { $0 < khatmaSuras.count && done.contains(khatmaSuras[$0].id) }
                let isToday = idx == dayIndex
                Text((idx + 1).ar)
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(dayDone || isToday ? Color.white : Color.secondary)
                    .frame(maxWidth: .infinity)
                    .frame(height: 26)
                    .background(dayDone ? Brand.good : (isToday ? Brand.gold : Color(.tertiarySystemFill)),
                                in: RoundedRectangle(cornerRadius: 6, style: .continuous))
            }
        }
        .card(18, padding: 14)
    }
}
