import SwiftUI

// MARK: - My journey dashboard (ported from Android ui/JourneyScreen.kt)

struct JourneyView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private var best: Int { store.int("bestStreak", 0) }

    private var activeDays30: Int {
        (0..<30).filter { MuhasabaLogic.dayScore(store, offset: $0) > 0 }.count
    }

    var body: some View {
        ScreenScroll {
            heroCard
            HStack(spacing: 12) {
                statTile(value: activeDays30.ar, label: "يوماً نشطاً", sub: "آخر ٣٠ يوماً", symbol: "star.fill", accent: Brand.emerald)
                statTile(value: best.ar, label: "أطول سلسلة", sub: "رقمك القياسيّ", symbol: "sparkle", accent: Brand.goldDeep)
            }
            weekCard
            Text("أدوات رحلتك")
                .font(.footnote.weight(.bold))
                .foregroundStyle(.secondary)
                .padding(.top, 8)
            pointsCard
            HStack(alignment: .top, spacing: 12) {
                muhasabaTile
                qadaTile
            }
            traitTile
            HStack(alignment: .top, spacing: 12) {
                JourneyGridCard(symbol: "sparkle", title: "خِيرة القرآن", stat: "استشِر عند الحيرة", accent: Brand.goldDeep, progress: nil) {
                    nav.openTool(.khira)
                }
                JourneyGridCard(symbol: "hands.sparkles.fill", title: "حاسبة الخمس", stat: "احسب خمسك", accent: Brand.emerald, progress: nil) {
                    nav.openTool(.khums)
                }
            }
            footer
        }
        .navigationTitle("رحلتي")
        .navigationBarTitleDisplayMode(.large)
    }

    // MARK: Hero: streak

    private var heroCard: some View {
        let streak = store.streak
        let frac = best > 0 ? min(1, Double(streak) / Double(best)) : 0
        return VStack(spacing: 10) {
            Text("سلسلة المواظبة").font(.footnote.weight(.bold)).opacity(0.85)
            ZStack {
                Circle().stroke(Color.white.opacity(0.18), lineWidth: 10)
                Circle()
                    .trim(from: 0, to: CGFloat(frac))
                    .stroke(Brand.gold, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                VStack(spacing: 0) {
                    Text(streak.ar).font(.counter(52)).foregroundStyle(Brand.gold)
                    Text(streak == 1 ? "يوم" : "يوماً").font(.subheadline.weight(.bold)).opacity(0.9)
                }
            }
            .frame(width: 156, height: 156)
            Text("أطول سلسلة: \(best.ar) يوماً")
                .font(.caption.weight(.bold))
                .padding(.horizontal, 14).padding(.vertical, 7)
                .glassCapsule()
        }
        .padding(.vertical, 24)
        .frame(maxWidth: .infinity)
        .hero()
    }

    private func statTile(value: String, label: String, sub: String, symbol: String, accent: Color) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(accent)
                .frame(width: 36, height: 36)
                .background(accent.opacity(0.13), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                .padding(.bottom, 8)
            Text(value).font(.counter(30)).foregroundStyle(accent)
            Text(label).font(.footnote.weight(.bold))
            Text(sub).font(.caption2).foregroundStyle(.secondary)
        }
        .card(20)
    }

    // MARK: Week activity

    private var weekCard: some View {
        let labels = ["اليوم", "أمس", "٣", "٤", "٥", "٦", "٧"]
        return VStack(alignment: .leading, spacing: 14) {
            Text("نشاطك هذا الأسبوع").font(.subheadline.weight(.heavy))
            HStack(spacing: 0) {
                ForEach(0..<7, id: \.self) { offset in
                    let score = MuhasabaLogic.dayScore(store, offset: offset)
                    let frac = Double(score) / 4
                    VStack(spacing: 6) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 11, style: .continuous)
                                .fill(score == 0 ? Color(.tertiarySystemFill) : Brand.emerald.opacity(0.25 + frac * 0.6))
                            if score > 0 {
                                Text(score.ar)
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(frac > 0.5 ? Color.white : Brand.emerald)
                            }
                        }
                        .frame(width: 34, height: 34)
                        .overlay(RoundedRectangle(cornerRadius: 11, style: .continuous)
                            .stroke(offset == 0 ? Brand.gold : Color.clear, lineWidth: 1.5))
                        Text(labels[offset]).font(.caption2.weight(.medium)).foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            Text("كلّ يومٍ تُتمّ فيه وِردك أو محاسبتك يُضيء هنا (الدرجة من ٤).")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .card(20, padding: 18)
    }

    // MARK: Tool cards

    private var pointsCard: some View {
        let points = QuranPointsLevel.points(store)
        let lv = QuranPointsLevel.level(points)
        let surahsDone = QuranPointsLevel.doneSet(store).count
        let pct = max(0, min(100, surahsDone * 100 / 114))
        return Button {
            nav.openTool(.qpoints)
        } label: {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 13) {
                    Image(systemName: "book.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(Brand.emerald)
                        .frame(width: 46, height: 46)
                        .background(Brand.emerald.opacity(0.13), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("نقاط القراءة").font(.headline).foregroundStyle(.primary)
                        Text("\(points.ar) نقطة · المستوى \(lv.num.ar): \(lv.name)").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.forward").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                }
                ProgressView(value: Double(pct) / 100).tint(Brand.emerald)
                Text("الختمة: \(surahsDone.ar) من ١١٤ (\(pct.ar)٪)").font(.caption2).foregroundStyle(.secondary)
            }
            .card(20, padding: 18)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private var muhasabaTile: some View {
        let muhCount = MuhasabaLogic.count(MuhasabaLogic.mask(store))
        return JourneyGridCard(symbol: "star.fill", title: "محاسبة النفس",
                               stat: muhCount > 0 ? "\(muhCount.ar) من ٨ اليوم" : "لم تبدأ اليوم",
                               accent: Brand.emerald, progress: Double(muhCount) / 8) {
            nav.openTool(.muhasaba)
        }
    }

    private var qadaTile: some View {
        let rem = QadaKeys.totalRemaining(store)
        return JourneyGridCard(symbol: "clock.fill", title: "قضاء الفوائت",
                               stat: rem > 0 ? "\(rem.ar) متبقّية" : "لا فوائت",
                               accent: Brand.goldDeep, progress: nil) {
            nav.openTool(.qada)
        }
    }

    private var traitTile: some View {
        let active = TraitProgress.isActive(store)
        let name = TraitProgress.current(store)?.vice
        let done = TraitProgress.doneCount(store)
        let target = max(1, TraitProgress.target(store))
        let stat: String
        if active, let name {
            stat = "تخلية «\(name)» — \(done.ar) من \(target.ar) يوماً"
        } else {
            stat = "ابدأ رحلة تهذيب صفة"
        }
        let progress: Double? = active ? min(1, Double(done) / Double(target)) : nil
        return JourneyGridCard(symbol: "leaf.fill", title: "صفة الشهر", stat: stat, accent: Brand.goldDeep, progress: progress) {
            nav.openTool(.trait)
        }
    }

    private var footer: some View {
        VStack(spacing: 4) {
            Text("«أَحَبُّ الأَعْمَالِ إِلَى اللهِ أَدْوَمُهَا وَإِنْ قَلَّ»")
                .font(.scripture(17))
                .foregroundStyle(Brand.emerald)
                .multilineTextAlignment(.center)
            Text("المداومة على القليل خيرٌ من الكثير المنقطع")
                .font(.caption2)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(20)
        .frame(maxWidth: .infinity)
        .background(Brand.emerald.opacity(0.09), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .padding(.top, 8)
    }
}

/// Square tool card for the journey grid.
fileprivate struct JourneyGridCard: View {
    let symbol: String
    let title: String
    let stat: String
    let accent: Color
    let progress: Double?
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 4) {
                Image(systemName: symbol)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(accent)
                    .frame(width: 42, height: 42)
                    .background(accent.opacity(0.13), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                    .padding(.bottom, 8)
                Text(title).font(.subheadline.weight(.heavy)).foregroundStyle(.primary).lineLimit(1)
                Text(stat).font(.caption2).foregroundStyle(.secondary).lineLimit(2).multilineTextAlignment(.leading)
                if let p = progress {
                    ProgressView(value: max(0, min(1, p))).tint(accent).padding(.top, 6)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .card(18)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}
