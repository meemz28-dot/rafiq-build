import SwiftUI

// MARK: - My journey dashboard (ported from Android ui/JourneyScreen.kt)

struct JourneyView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private var best: Int { store.int("bestStreak", 0) }

    private var activeDays30: Int {
        (0..<30).filter { MuhasabaLogic.dayScore(store, offset: $0) > 0 }.count
    }

    @Environment(\.dismiss) private var dismiss

    private func wirdOn(_ bit: Int) -> Bool { store.wirdMask & (1 << bit) != 0 }
    private var habitsDone: Int {
        [wirdOn(0), wirdOn(1), wirdOn(2), QuranProgress.today(store) >= QuranProgress.goal(store)].filter { $0 }.count
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                header
                VStack(alignment: .leading, spacing: 14) {
                    habitsCard
                    HStack(alignment: .top, spacing: 12) {
                        muhasabaCard
                        traitCard
                    }
                    .fixedSize(horizontal: false, vertical: true)
                    achievementsRow
                    pointsCard
                    HStack(alignment: .top, spacing: 12) {
                        qadaTile
                        JourneyGridCard(symbol: "sparkle", title: "خِيرة القرآن", stat: "استشِر عند الحيرة", accent: Brand.goldDeep, progress: nil) {
                            nav.openTool(.khira)
                        }
                    }
                    footer
                }
                .padding(.horizontal, 16).padding(.top, 14).padding(.bottom, 28)
                .readableWidth()
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Brand.canvas)
        .toolbar(.hidden, for: .navigationBar)
    }

    // MARK: Header: streak ring, today's habits, week circles

    private var header: some View {
        let streak = store.streak
        let frac = best > 0 ? min(1, Double(streak) / Double(best)) : (streak > 0 ? 1 : 0)
        return ZStack(alignment: .top) {
            Brand.heroGradient
            GirihPattern().foregroundStyle(.white.opacity(0.07))
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    RoundIconButton(symbol: "chevron.backward", label: "رجوع", translucent: true) { dismiss() }
                    Spacer()
                    Text("رحلتي").font(.display(26)).foregroundStyle(.white)
                    Spacer()
                    RoundIconButton(symbol: "chart.bar", label: "ختمتي ونقاطي", translucent: true) { nav.openTool(.khatma) }
                }
                .padding(.top, 54)
                HStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(verbatim: streak > 0 ? "\(streak.ar) \(streak == 1 ? "يوم" : (streak <= 10 ? "أيام" : "يوماً")) متتالياً · أفضل سلسلة \(best.ar)" : "ابدأ سلسلتك اليوم · أفضل سلسلة \(best.ar)")
                            .font(.caption).foregroundStyle(.white.opacity(0.8))
                        Text(verbatim: "\(habitsDone.ar) من ٤ عادات اليوم").font(.display(26)).foregroundStyle(.white)
                        Text(habitsDone >= 4 ? "اكتمل يومك · تقبّل الله" : "تبقّى \((4 - habitsDone).ar) · قبل منتصف الليل")
                            .font(.caption).foregroundStyle(.white.opacity(0.8))
                    }
                    Spacer(minLength: 8)
                    ZStack {
                        Circle().stroke(Color.white.opacity(0.18), lineWidth: 8)
                        Circle().trim(from: 0, to: max(0.004, frac))
                            .stroke(Brand.goldSoft, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                            .rotationEffect(.degrees(-90))
                        Text(streak.ar).font(.display(28)).foregroundStyle(.white)
                    }
                    .frame(width: 92, height: 92)
                }
                weekCircles
                Spacer(minLength: 20)
            }
            .padding(.horizontal, 20)
        }
        .frame(height: 340)
        .clipped()
        .environment(\.colorScheme, .dark)
    }

    private var weekCircles: some View {
        HStack(spacing: 0) {
            ForEach((0..<7).reversed(), id: \.self) { offset in
                let date = Calendar.current.date(byAdding: .day, value: -offset, to: Date()) ?? Date()
                let wd = max(0, min(6, Calendar.current.component(.weekday, from: date) - 1))
                let score = MuhasabaLogic.dayScore(store, offset: offset)
                VStack(spacing: 6) {
                    ZStack {
                        Circle().fill(score >= 4 ? Brand.goldSoft : (score > 0 ? Color.white.opacity(0.18) : Color.white.opacity(0.08)))
                        Circle().stroke(offset == 0 ? Brand.goldSoft : Color.clear, lineWidth: 2)
                        if score > 0 {
                            Text(score.ar).font(.caption.weight(.bold)).foregroundStyle(score >= 4 ? Color(hex: 0x10322D) : .white)
                        }
                    }
                    .frame(width: 34, height: 34)
                    Text(Hijri.weekDays[wd]).font(.caption2).foregroundStyle(.white.opacity(0.8)).lineLimit(1).minimumScaleFactor(0.7)
                }
                .frame(maxWidth: .infinity)
            }
        }
        .accessibilityLabel("نشاط الأسبوع")
    }

    // MARK: Today's habits

    private var habitsCard: some View {
        let verses = QuranProgress.today(store), goal = QuranProgress.goal(store)
        let weekday = max(0, min(6, Calendar.current.component(.weekday, from: Date()) - 1))
        let duaId = ["d-sun", "d-mon", "d-tue", "d-wed", "d-thu", "d-fri", "d-sat"][weekday]
        return VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text("عاداتي اليوم").font(.subheadline.weight(.bold)).foregroundStyle(Brand.ink)
                Spacer()
                Text(verbatim: "\(habitsDone.ar) / ٤").font(.caption).foregroundStyle(Brand.muted)
            }
            .padding(.bottom, 6)
            habitRow("دعاء اليوم", sub: nil, done: wirdOn(0)) { if !wirdOn(0) { store.toggleWird(0) }; nav.openReader("osboo", duaId) }
            habitRow("\(goal.ar) آية من القرآن", sub: verses > 0 ? "\(verses.ar) من \(goal.ar)" : nil, done: verses >= goal) { nav.openTool(.khatma) }
            habitRow("تسبيح الزهراء (ع)", sub: nil, done: wirdOn(1)) { if !wirdOn(1) { store.toggleWird(1) }; nav.present(.tasbih) }
            habitRow("ذكر اليوم", sub: nil, done: wirdOn(2), toggles: true) { store.toggleWird(2); Haptic.tick() }
            habitRow("صدقة اليوم", sub: nil, done: wirdOn(3), toggles: true) { store.toggleWird(3); Haptic.tick() }
        }
        .card(22, padding: 16)
    }

    private func habitRow(_ title: String, sub: String?, done: Bool, toggles: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                ZStack {
                    Circle().fill(done ? Brand.emerald : Color.clear)
                    Circle().stroke(done ? Brand.emerald : Brand.goldDeep, lineWidth: 2)
                    if done { Image(systemName: "checkmark").font(.system(size: 12, weight: .bold)).foregroundStyle(.white) }
                }
                .frame(width: 26, height: 26)
                Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(done ? Brand.muted : Brand.ink).strikethrough(done, color: Brand.muted)
                Spacer()
                if let sub { Text(sub).font(.caption).foregroundStyle(Brand.muted) }
                else if !done && !toggles { Text("اقرأ").font(.caption.weight(.bold)).foregroundStyle(Brand.accent).padding(.horizontal, 10).padding(.vertical, 5).background(Brand.soft, in: RoundedRectangle(cornerRadius: 10, style: .continuous)) }
            }
            .padding(.vertical, 8)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(done ? .isSelected : [])
    }

    // MARK: Muhasaba (purple) and trait cards

    private var muhasabaCard: some View {
        let muhCount = MuhasabaLogic.count(MuhasabaLogic.mask(store))
        let total = MuhasabaLogic.items.count
        return Button { nav.openTool(.muhasaba) } label: {
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text("محاسبة النفس").font(.caption.weight(.bold)).foregroundStyle(Brand.goldSoft)
                    Spacer()
                    Text("الليلة").font(.caption2).foregroundStyle(.white.opacity(0.7))
                }
                Text(verbatim: "\(total.ar) أسئلة").font(.display(24)).foregroundStyle(.white)
                Text(muhCount > 0 ? "أجبتَ على \(muhCount.ar) · أكمل الليلة" : "راجع يومك قبل النوم")
                    .font(.caption).foregroundStyle(.white.opacity(0.8)).fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 8)
                Text(muhCount >= total ? "اكتملت ✓" : "أكمل الليلة").font(.caption.weight(.bold)).foregroundStyle(Color(hex: 0x3B2A5C))
                    .padding(.horizontal, 12).padding(.vertical, 7).background(Brand.goldSoft, in: Capsule())
            }
            .padding(16)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            .background(Brand.purpleGradient, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private var traitCard: some View {
        let active = TraitProgress.isActive(store)
        let trait = TraitProgress.current(store)
        let done = TraitProgress.doneCount(store)
        let target = max(1, TraitProgress.target(store))
        let day = TraitProgress.dayNumber(store)
        return Button { nav.openTool(.trait) } label: {
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text("صفة الشهر").font(.caption.weight(.bold)).foregroundStyle(Brand.goldDeep)
                    Spacer()
                    if active { Text(verbatim: "اليوم \(min(day, target).ar) من \(target.ar)").font(.caption2).foregroundStyle(Brand.muted) }
                }
                Text(active ? (trait?.virtue ?? "") : "ابدأ").font(.display(24)).foregroundStyle(Brand.ink).lineLimit(1).minimumScaleFactor(0.7)
                Capsule().fill(Brand.track).frame(height: 5)
                    .overlay(alignment: .leading) {
                        GeometryReader { g in Capsule().fill(Brand.goldDeep).frame(width: g.size.width * (active ? min(1, Double(done) / Double(target)) : 0)) }
                    }
                Text(active ? (trait?.commitment ?? "") : "اختر خُلُقاً تتمرّن عليه شهراً كاملاً")
                    .font(.caption2).foregroundStyle(Brand.muted).lineLimit(3).fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }
            .padding(16)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private var achievementsRow: some View {
        let khatmas = QuranProgress.khatmas(store)
        let parts: [String] = [
            khatmas > 0 ? "\(khatmas.ar) \(khatmas == 1 ? "ختمة" : "ختمات")" : nil,
            best > 0 ? "أطول سلسلة \(best.ar) \(best == 1 ? "يوم" : "يوماً")" : nil,
            activeDays30 > 0 ? "\(activeDays30.ar) \(activeDays30 == 1 ? "يوم نشط" : "يوماً نشطاً") في الشهر" : nil
        ].compactMap { $0 }
        return HStack(spacing: 12) {
            Image(systemName: "rosette").font(.system(size: 20, weight: .semibold)).foregroundStyle(Brand.goldDeep)
                .frame(width: 46, height: 46).background(Brand.gold.opacity(0.15), in: Circle())
            VStack(alignment: .leading, spacing: 2) {
                Text("إنجازات").font(.subheadline.weight(.bold)).foregroundStyle(Brand.ink)
                Text(parts.isEmpty ? "تظهر هنا إنجازاتك مع المواظبة" : parts.joined(separator: " · ")).font(.caption).foregroundStyle(Brand.muted).lineLimit(2)
            }
            Spacer()
            Image(systemName: "chevron.backward").font(.caption.weight(.bold)).foregroundStyle(Brand.muted)
        }
        .card(22, padding: 14)
        .onTapGesture { nav.openTool(.khatma) }
    }

    // MARK: Tool cards

    private var pointsCard: some View {
        let points = QuranPointsLevel.points(store)
        let lv = QuranPointsLevel.level(points)
        let verses = QuranProgress.khatmaVerses(store)
        let pct = max(0, min(100, Int((QuranProgress.khatmaFraction(store) * 100).rounded())))
        return Button {
            nav.openTool(.khatma)
        } label: {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 13) {
                    Image(systemName: "book.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(Brand.emerald)
                        .frame(width: 46, height: 46)
                        .background(Brand.emerald.opacity(0.13), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("نقاط القراءة").font(.headline).foregroundStyle(.primary)
                        Text(verbatim: "\(points.ar) نقطة · المستوى \(lv.num.ar): \(lv.name)").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.forward").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                }
                ProgressView(value: Double(pct) / 100).tint(Brand.emerald)
                Text("الختمة: \(verses.ar) من \(QuranProgress.totalVerses.ar) آية (\(pct.ar)٪) · اليوم \(QuranProgress.today(store).ar) آية").font(.caption2).foregroundStyle(.secondary)
            }
            .card(20, padding: 18)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private var muhasabaTile: some View {
        let muhCount = MuhasabaLogic.count(MuhasabaLogic.mask(store))
        return JourneyGridCard(symbol: "star.fill", title: "محاسبة النفس",
                               stat: muhCount > 0 ? "\(muhCount.ar) من ٨ اليوم" : "لم تبدأ اليوم",
                               accent: Brand.emerald, progress: Double(muhCount) / 8) {
            nav.openTool(.muhasaba)
        }
    }

    private var qadaTile: some View {
        let rem = QadaKeys.totalRemaining(store)
        return JourneyGridCard(symbol: "clock.fill", title: "قضاء الفوائت",
                               stat: rem > 0 ? "\(rem.ar) متبقّية" : "لا فوائت",
                               accent: Brand.goldDeep, progress: nil) {
            nav.openTool(.qada)
        }
    }

    private var traitTile: some View {
        let active = TraitProgress.isActive(store)
        let name = TraitProgress.current(store)?.vice
        let done = TraitProgress.doneCount(store)
        let target = max(1, TraitProgress.target(store))
        let stat: String
        if active, let name {
            stat = "تخلية «\(name)» — \(done.ar) من \(target.ar) يوماً"
        } else {
            stat = "ابدأ رحلة تهذيب صفة"
        }
        let progress: Double? = active ? min(1, Double(done) / Double(target)) : nil
        return JourneyGridCard(symbol: "leaf.fill", title: "صفة الشهر", stat: stat, accent: Brand.goldDeep, progress: progress) {
            nav.openTool(.trait)
        }
    }

    private var footer: some View {
        VStack(spacing: 4) {
            Text("«أَحَبُّ الأَعْمَالِ إِلَى اللهِ أَدْوَمُهَا وَإِنْ قَلَّ»")
                .font(.scripture(17))
                .foregroundStyle(Brand.emerald)
                .multilineTextAlignment(.center)
            Text("المداومة على القليل خيرٌ من الكثير المنقطع")
                .font(.caption2)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(20)
        .frame(maxWidth: .infinity)
        .background(Brand.emerald.opacity(0.09), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .padding(.top, 8)
    }
}

/// Square tool card for the journey grid.
fileprivate struct JourneyGridCard: View {
    let symbol: String
    let title: String
    let stat: String
    let accent: Color
    let progress: Double?
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 4) {
                Image(systemName: symbol)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(accent)
                    .frame(width: 42, height: 42)
                    .background(accent.opacity(0.13), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                    .padding(.bottom, 8)
                Text(title).font(.subheadline.weight(.heavy)).foregroundStyle(.primary).lineLimit(1)
                Text(stat).font(.caption2).foregroundStyle(.secondary).lineLimit(2).multilineTextAlignment(.leading)
                if let p = progress {
                    ProgressView(value: max(0, min(1, p))).tint(accent).padding(.top, 6)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .card(18)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}
