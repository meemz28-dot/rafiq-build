import SwiftUI

// MARK: - Recommended deeds by Hijri date (ported from Android ui/AmaalScreen.kt)

struct AmaalView: View {
    @Environment(Store.self) private var store
    @State private var selectedMonth: Int?
    @State private var expanded: String?
    @State private var collapsedToday: Set<String> = []

    private var today: Hijri.HDate { store.hijriToday() }
    private var month: Int { selectedMonth ?? today.m }

    private func monthName(_ m: Int) -> String { Hijri.months[max(0, min(11, m - 1))] }

    var body: some View {
        ScreenScroll {
            fastingCard
            todaySection
            SectionTitle(text: "تصفّح حسب الشهر")
            monthChips
            monthSection
        }
        .navigationTitle("الأعمال والمستحبّات")
        .navigationBarTitleDisplayMode(.large)
    }

    private var fastingCard: some View {
        let weekday = Calendar(identifier: .gregorian).component(.weekday, from: Date()) - 1
        let fast = Fasting.rec(hm: today.m, hd: today.d, weekday: weekday)
        return HStack(spacing: 14) {
            Image(systemName: "moon.fill")
                .font(.system(size: 20, weight: .semibold))
                .foregroundStyle(fast.recommended ? Brand.good : Color.secondary)
                .frame(width: 44, height: 44)
                .background((fast.recommended ? Brand.good.opacity(0.18) : Color(.tertiarySystemFill)),
                            in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                Text(fast.recommended ? "صيام اليوم مستحبّ" : "صيام اليوم")
                    .font(.ui(.headline))
                    .foregroundStyle(fast.recommended ? Brand.good : Color.primary)
                Text(fast.reason)
                    .font(.ui(.caption))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background((fast.recommended ? Brand.good.opacity(0.12) : Color(.secondarySystemGroupedBackground)),
                    in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }

    @ViewBuilder private var todaySection: some View {
        let works = Library.works(m: today.m, d: today.d)
        if !works.isEmpty {
            SectionTitle(text: "أعمال اليوم — \(today.d.ar) \(monthName(today.m))")
            ForEach(Array(works.enumerated()), id: \.offset) { pair in
                let key = "\(pair.element.m)-\(pair.element.d)-\(pair.element.title)"
                AmaalWorkCard(title: pair.element.title, text: pair.element.body,
                              isOpen: !collapsedToday.contains(key)) {
                    if collapsedToday.contains(key) { collapsedToday.remove(key) } else { collapsedToday.insert(key) }
                }
            }
        }
    }

    private var monthChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(1...12, id: \.self) { m in
                    Button {
                        selectedMonth = m
                        expanded = nil
                    } label: {
                        Text(monthName(m))
                            .font(.ui(.caption, .bold))
                            .foregroundStyle(m == month ? Color.white : Color.primary)
                            .padding(.horizontal, 14).padding(.vertical, 8)
                            .background((m == month ? Brand.emerald : Color(.secondarySystemGroupedBackground)), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.vertical, 2)
        }
    }

    @ViewBuilder private var monthSection: some View {
        let works = Library.shared.works.filter { $0.m == month }
        if works.isEmpty {
            Text("لا توجد أعمال مخصوصة مسجّلة في هذا الشهر.")
                .font(.ui(.footnote))
                .foregroundStyle(.secondary)
        } else {
            ForEach(Array(works.enumerated()), id: \.offset) { pair in
                let w = pair.element
                let key = "\(w.m)-\(w.d)-\(w.title)"
                AmaalWorkCard(title: w.d == 0 ? w.title : "\(w.title) (\(w.d.ar) \(monthName(w.m)))",
                              text: w.body, isOpen: expanded == key) {
                    expanded = expanded == key ? nil : key
                }
            }
        }
    }
}

fileprivate struct AmaalWorkCard: View {
    let title: String
    let text: String
    let isOpen: Bool
    let onToggle: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Button {
                withAnimation(.easeInOut(duration: 0.22)) { onToggle() }
            } label: {
                HStack(spacing: 10) {
                    Circle().fill(Brand.gold).frame(width: 8, height: 8)
                    Text(title)
                        .font(.ui(.subheadline, .heavy))
                        .foregroundStyle(.primary)
                        .multilineTextAlignment(.leading)
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.down")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)
                        .rotationEffect(.degrees(isOpen ? 0 : 90))
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if isOpen {
                Text(text)
                    .font(.ui(.subheadline))
                    .lineSpacing(6)
                    .fixedSize(horizontal: false, vertical: true)
                    .textSelection(.enabled)
            }
        }
        .card(20)
    }
}
