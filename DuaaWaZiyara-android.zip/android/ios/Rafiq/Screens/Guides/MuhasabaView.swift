import SwiftUI

// MARK: - Daily self-accounting (ported from Android ui/MuhasabaScreen.kt + Settings muhasaba / activity log)

/// Shared muhasaba state (Android keys: muhDay, muhMask, muhHist, activityLog).
enum MuhasabaLogic {
    static let items = [
        "هل صلّيتُ الفرائض الخمس في أوقاتها؟",
        "هل ذكرتُ الله وسبّحتُ في يومي؟",
        "هل قرأتُ شيئاً من القرآن؟",
        "هل صنتُ لساني عن الغيبة والكذب؟",
        "هل أحسنتُ إلى والديّ أو أهلي؟",
        "هل نفعتُ أحداً أو قضيتُ حاجةً لمؤمن؟",
        "هل تجنّبتُ ما يُغضِب الله؟",
        "هل استغفرتُ وتُبتُ ممّا قصّرتُ فيه؟"
    ]

    /// Today's bit mask (resets when the day changes).
    static func mask(_ store: Store) -> Int {
        store.int("muhDay", -1) == store.today ? store.int("muhMask", 0) : 0
    }

    static func count(_ mask: Int) -> Int {
        (0..<8).filter { mask & (1 << $0) != 0 }.count
    }

    static func toggle(_ store: Store, bit: Int) {
        let day = store.today
        let next = mask(store) ^ (1 << bit)
        store.put("muhDay", day)
        store.put("muhMask", next)
        store.setSeries("muhHist", day: day, value: count(next), keepDays: 90)
        logActivity(store, day: day, score: activityScore(wird: store.wirdMask, muhCount: count(next)))
    }

    /// Day score 0...4 from the wird mask and the muhasaba count (same rule as Android).
    static func activityScore(wird: Int, muhCount: Int) -> Int {
        var score = 0
        if wird & 0b1111 == 0b1111 { score += 2 } else if wird != 0 { score += 1 }
        if muhCount >= 6 { score += 2 } else if muhCount > 0 { score += 1 }
        return max(0, min(4, score))
    }

    /// Keeps the highest score of the day, 60 days (Android logActivity).
    static func logActivity(_ store: Store, day: Int, score: Int) {
        let prev = store.series("activityLog")[day] ?? -1
        if score > prev { store.setSeries("activityLog", day: day, value: score, keepDays: 60) }
    }

    /// Score for a past day: stored log or recomputed from the wird and muhasaba series.
    static func dayScore(_ store: Store, offset: Int) -> Int {
        let day = store.today - offset
        let logged = store.series("activityLog")[day] ?? 0
        let wird = store.series("wird")[day] ?? 0
        let muh = store.series("muhHist")[day] ?? 0
        return max(logged, activityScore(wird: wird, muhCount: muh))
    }

    static func daysActive(_ store: Store, window: Int) -> Int {
        let t = store.today
        return store.series("muhHist").filter { $0.key > t - window && $0.value > 0 }.count
    }

    static func average(_ store: Store, window: Int) -> Double {
        let t = store.today
        let vals = store.series("muhHist").filter { $0.key > t - window }.map { $0.value }
        return vals.isEmpty ? 0 : Double(vals.reduce(0, +)) / Double(vals.count)
    }

    /// 0 = Sunday ... 6 = Saturday.
    static func bestWeekday(_ store: Store) -> Int? {
        let map = store.series("muhHist")
        if map.isEmpty { return nil }
        var sum = [Int](repeating: 0, count: 7)
        var cnt = [Int](repeating: 0, count: 7)
        for (day, v) in map {
            let dow = ((day + 4) % 7 + 7) % 7
            sum[dow] += v
            cnt[dow] += 1
        }
        var best = -1
        var bestAvg = -1.0
        for d in 0..<7 where cnt[d] > 0 {
            let a = Double(sum[d]) / Double(cnt[d])
            if a > bestAvg { bestAvg = a; best = d }
        }
        return best >= 0 ? best : nil
    }
}

fileprivate struct MuhasabaRing: View {
    let progress: Double
    var body: some View {
        ZStack {
            Circle().stroke(Color.white.opacity(0.18), lineWidth: 10)
            Circle()
                .trim(from: 0, to: CGFloat(max(0, min(1, progress))))
                .stroke(Brand.gold, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                .rotationEffect(.degrees(-90))
        }
    }
}

struct MuhasabaView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(Store.self) private var store

    private var mask: Int { MuhasabaLogic.mask(store) }
    private var doneCount: Int { MuhasabaLogic.count(mask) }
    private var pct: Int { Int((Double(doneCount) * 100 / Double(MuhasabaLogic.items.count)).rounded()) }

    var body: some View {
        ScreenScroll {
            ScreenHeader("محاسبة النفس", subtitle: "كلّ ليلة: ﴿وَنَفْسٍ وَمَا سَوَّاهَا﴾") {
                RoundIconButton(symbol: "chevron.backward", label: "رجوع") { dismiss() }
            }
            heroCard
            quoteCard
            trendCard
            traitQuestion
            ForEach(Array(MuhasabaLogic.items.enumerated()), id: \.offset) { pair in
                itemRow(index: pair.offset, text: pair.element)
            }
            messageCard
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    private var heroCard: some View {
        HStack(spacing: 20) {
            ZStack {
                MuhasabaRing(progress: Double(doneCount) / Double(MuhasabaLogic.items.count))
                Text(verbatim: "\(pct.ar)٪").font(.counter(26)).foregroundStyle(Brand.gold)
            }
            .frame(width: 110, height: 110)
            VStack(alignment: .leading, spacing: 6) {
                Text("محاسبة النفس").font(.ui(.title3, .heavy))
                Text(verbatim: "\(doneCount.ar) من \(MuhasabaLogic.items.count.ar)")
                    .font(.ui(.subheadline, .bold))
                    .opacity(0.85)
            }
            Spacer(minLength: 0)
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .hero()
    }

    private var quoteCard: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "scroll.fill").foregroundStyle(Brand.emerald)
            Text("قال الإمام الكاظم (ع): «لَيسَ مِنّا مَن لَم يُحاسِب نَفسَهُ في كُلِّ يَوم». راجِع يومك كل ليلة بصدق، واشكر الله على ما وُفِّقت، واستغفر لما قصّرت.")
                .font(.ui(.footnote))
                .foregroundStyle(Brand.emerald)
                .lineSpacing(4)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Brand.emerald.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    private var trendCard: some View {
        let days = MuhasabaLogic.daysActive(store, window: 30)
        let avg = MuhasabaLogic.average(store, window: 30)
        let bestDow = MuhasabaLogic.bestWeekday(store)
        return VStack(alignment: .leading, spacing: 14) {
            Text("اتّجاهك (آخر ١٤ يوماً)").font(.ui(.subheadline, .heavy))
            trendBars
            HStack {
                Text("اليوم")
                Spacer()
                Text("قبل ١٤ يوماً")
            }
            .font(.ui(.caption2))
            .foregroundStyle(.secondary)
            HStack {
                statColumn(value: days.ar, label: "يوماً محاسَباً")
                Divider().frame(height: 36)
                statColumn(value: String(format: "%.1f", avg).arabicDigits, label: "متوسّط ٨/يوم")
            }
            if let best = bestDow, days >= 3 {
                Label("أكثر أيامك التزاماً: \(Hijri.weekDays[max(0, min(6, best))])", systemImage: "sparkle")
                    .font(.ui(.caption, .bold))
                    .padding(12)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Brand.gold.opacity(0.12), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            } else if days < 3 {
                Text("تابِع المحاسبة أياماً لترى اتّجاهك ونمطك الأسبوعيّ.")
                    .font(.ui(.caption2))
                    .foregroundStyle(.secondary)
            }
        }
        .card(20, padding: 18)
    }

    /// Bars for the last 14 days; today sits at the leading edge as in Android.
    private var trendBars: some View {
        HStack(alignment: .bottom, spacing: 3) {
            ForEach(0..<14, id: \.self) { offset in
                let v = store.seriesValue("muhHist", offset: offset)
                let frac = max(0, min(1, Double(v) / 8))
                RoundedRectangle(cornerRadius: 4, style: .continuous)
                    .fill(v == 0 ? Color(.tertiarySystemFill) : Brand.emerald.opacity(0.4 + frac * 0.6))
                    .frame(height: max(3, 70 * CGFloat(frac)))
                    .frame(maxWidth: .infinity)
            }
        }
        .frame(height: 70, alignment: .bottom)
    }

    private func statColumn(value: String, label: String) -> some View {
        VStack(spacing: 2) {
            Text(value).font(.counter(22)).foregroundStyle(Brand.emerald)
            Text(label).font(.ui(.caption2)).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    @ViewBuilder private var traitQuestion: some View {
        if TraitProgress.isActive(store), let t = TraitProgress.current(store) {
            let done = TraitProgress.doneToday(store)
            Button {
                TraitProgress.setToday(store, done: !done)
                Haptic.tick()
            } label: {
                HStack(spacing: 14) {
                    checkCircle(done, color: Brand.gold)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("سؤال صفة الشهر — تخلية «\(t.vice)»")
                            .font(.ui(.caption, .heavy))
                            .foregroundStyle(Brand.gold)
                            .lineLimit(1)
                        Text("هل أتممتَ عملَ اليوم بالضدّ؟ \(t.commitment)")
                            .font(.ui(.subheadline, .medium))
                            .foregroundStyle(.primary)
                            .multilineTextAlignment(.leading)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer(minLength: 0)
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Brand.gold.opacity(done ? 0.14 : 0.07), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Brand.gold.opacity(done ? 0.55 : 0.3), lineWidth: 1))
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
    }

    private func checkCircle(_ on: Bool, color: Color) -> some View {
        ZStack {
            Circle().fill(on ? color : Color.clear)
            Circle().stroke(on ? color : Color(.separator), lineWidth: 1.5)
            if on { Image(systemName: "checkmark").font(.system(size: 13, weight: .bold)).foregroundStyle(.white) }
        }
        .frame(width: 28, height: 28)
    }

    private func itemRow(index: Int, text: String) -> some View {
        let done = mask & (1 << index) != 0
        return Button {
            MuhasabaLogic.toggle(store, bit: index)
            if done { Haptic.tick() } else { Haptic.confirm() }
        } label: {
            HStack(spacing: 14) {
                checkCircle(done, color: Brand.emerald)
                Text(text)
                    .font(.ui(.body, .medium))
                    .foregroundStyle(.primary)
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background((done ? Brand.emerald.opacity(0.10) : Color(.secondarySystemGroupedBackground)),
                        in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(done ? Brand.emerald.opacity(0.4) : Color.clear, lineWidth: 1))
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private var messageCard: some View {
        let msg: String
        if pct == 100 {
            msg = "ما شاء الله، يومٌ مبارك. تقبّل الله وثبّتك."
        } else if pct >= 60 {
            msg = "خيرٌ كثير، أكمِل ما بقي واستغفر لما فات."
        } else if pct > 0 {
            msg = "بداية طيّبة، حاسِب نفسك بصدق وجدّد العزم غداً."
        } else {
            msg = "راجِع يومك بصدق؛ كل خطوة نحو الله مباركة."
        }
        return Text(msg)
            .font(.ui(.subheadline, .bold))
            .foregroundStyle(Brand.goldDeep)
            .multilineTextAlignment(.center)
            .padding(14)
            .frame(maxWidth: .infinity)
            .background(Brand.gold.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
