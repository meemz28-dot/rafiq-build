import SwiftUI

// MARK: - Interactive Ziyarat Ashura guide (ported from Android ui/AshuraGuideScreen.kt)

fileprivate let ashuraLan = "اللّهُمَّ العَنْ أَوَّلَ ظالِمٍ ظَلَمَ حَقَّ مُحَمَّدٍ وَآلِ مُحَمَّدٍ وَآخِرَ تابِعٍ لَهُ عَلى ذلِكَ، اللّهُمَّ العَنْ العِصابَةَ الَّتِي جاهَدَتِ الحُسَيْنَ وَشايَعَتْ وَبايَعَتْ وَتابَعَتْ عَلى قَتْلِهِ اللّهُمَّ العَنْهُمْ جَميعاً."
fileprivate let ashuraSalam = "السَّلامُ عَلَيْكَ يا أَبا عَبْدِ الله وَعَلى الأَرواحِ الَّتِي حَلَّتْ بِفِنائِكَ، عَلَيْكَ مِنِّي سَلامُ اللهِ أَبَداً مابَقِيتُ وَبَقِيَ اللَيْلُ وَالنَّهارُ وَلا جَعَلَهُ الله آخِرَ العَهْدِ مِنِّي لِزِيارَتِكُمْ . السَّلامُ عَلى الحُسَيْنِ وَعَلى عَلِيِّ بْنِ الحُسَيْنِ وَعَلى أَوْلادِ الحُسَيْنِ وَعَلى أَصْحابِ الحُسَيْنِ."
fileprivate let ashuraClosing = """
اللّهُمَّ خُصَّ أَنْتَ أَوَّلَ ظالِمٍ بِاللَّعْنِ مِنِّي وَأَبْدأْ بِهِ أَوَّلاً ثُمَّ الثَّانِي وَالثَّالِثَ وَالرَّابِعَ، اللّهُمَّ الْعَنْ يَزِيدَ خامِساً وَالعَنْ عُبَيْدَ الله بْنَ زِيادٍ وَابْنَ مَرْجانَةَ وَعُمَرَ بْنَ سَعْدٍ وَشِمْراً وَآلَ أَبِي سُفْيانَ وَآلَ زِيادٍ وَآلَ مَرْوانَ إلى يَوْمِ القِيامَةِ.

اللّهُمَّ لَكَ الحَمْدُ حَمْدَ الشَّاكِرِينَ لَكَ عَلى مُصابِهِمْ، الحَمْدُ للهِ عَلى عَظِيمِ رَزِيَّتِي، اللّهُمَّ ارْزُقْنِي شَفاعَةَ الحُسَيْنِ يَوْمَ الوُرُودِ وَثَبِّتْ لِي قَدَمَ صِدْقٍ عِنْدَكَ مَعَ الحُسَيْنِ وَأَصْحابِ الحُسَيْنِ الَّذِينَ بَذَلُوا مُهَجَهُمْ دُونَ الحُسَيْنِ عَلَيهِ السَّلامُ.
"""

fileprivate struct AshuraStep {
    let phase: String
    let title: String
    let how: String
    var say: String? = nil
    var times: Int = 0   // > 0 means a repetition counter step
}

fileprivate let ashuraSteps: [AshuraStep] = [
    AshuraStep(phase: "تمهيد", title: "زيارة عاشوراء",
               how: "زيارة عاشوراء من أجلّ الزيارات وأعظمها ثواباً، تُقرأ يوم عاشوراء وفي كل يوم. لها كيفية مخصوصة: تقرأ متن الزيارة، ثم تلعن الظالمين مئة مرّة، ثم تسلّم على الحسين (ع) مئة مرّة، ثم تدعو بدعاء الختام، ثم تسجد. سنمشي معك خطوة بخطوة."),
    AshuraStep(phase: "النيّة", title: "النيّة والاستقبال",
               how: "استقبل القبلة (أو حرم الإمام الحسين عليه السلام إن كنت هناك)، واخطر بقلبك نيّة زيارة الإمام الحسين (ع) قربةً إلى الله."),
    AshuraStep(phase: "المتن", title: "قراءة متن الزيارة",
               how: "اقرأ متن زيارة عاشوراء كاملاً (تجده في باب الزيارات). ابدأ بـ«السلام عليك يا أبا عبد الله» إلى آخر المتن. يمكنك فتحه في القارئ التفاعلي ثم العودة لإكمال الأعمال.",
               say: "اَلسَّلامُ عَلَيْكَ يا اَبا عَبْدِ اللهِ، اَلسَّلامُ عَلَيْكَ يَا بْنَ رَسُولِ اللهِ..."),
    AshuraStep(phase: "اللعن", title: "اللعن مئة مرّة",
               how: "بعد المتن، العن الظالمين مئة مرّة. اضغط الدائرة في كل مرّة تقولها. يجوز الاقتصار على مرّة واحدة بنيّة المئة عند الضرورة.",
               say: ashuraLan, times: 100),
    AshuraStep(phase: "السلام", title: "السلام مئة مرّة",
               how: "ثم سلّم على الإمام الحسين (ع) مئة مرّة. اضغط الدائرة في كل مرّة.",
               say: ashuraSalam, times: 100),
    AshuraStep(phase: "الختام", title: "دعاء الختام",
               how: "ثم اقرأ دعاء الختام (دعاء علقمة يأتي بعده إن أردت).",
               say: ashuraClosing),
    AshuraStep(phase: "السجدة", title: "سجدة الختام",
               how: "اسجد، وقل في سجودك:",
               say: "اَللّهُمَّ لَكَ الْحَمْدُ حَمْدَ الشّاكِرينَ لَكَ عَلى مُصابِهِمْ، اَلْحَمْدُ للهِ عَلى عَظيمِ رَزِيَّتي، اَللّهُمَّ ارْزُقْني شَفاعَةَ الْحُسَيْنِ يَوْمَ الْوُرُودِ، وَثَبِّتْ لي قَدَمَ صِدْقٍ عِنْدَكَ مَعَ الْحُسَيْنِ وَاَصْحابِ الْحُسَيْنِ الَّذينَ بَذَلُوا مُهَجَهُمْ دُونَ الْحُسَيْنِ عَلَيْهِ السَّلامُ."),
    AshuraStep(phase: "تمّ", title: "تقبّل الله",
               how: "بهذا تمّت زيارة عاشوراء. يُستحب بعدها قراءة دعاء علقمة (صفوان) — تجده في باب الزيارات. تقبّل الله أعمالك وحشرك مع الحسين وأصحابه.")
]

struct AshuraView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.dismiss) private var dismiss
    @State private var i = 0
    @State private var counts: [Int: Int] = [:]

    private var scale: CGFloat { CGFloat(store.fontSize / 21.0) }
    private var isLast: Bool { i >= ashuraSteps.count - 1 }

    var body: some View {
        ScreenScroll {
            if ashuraSteps.indices.contains(i) {
                header(ashuraSteps[i])
                stepBody(ashuraSteps[i])
            }
        }
        .safeAreaInset(edge: .bottom) { navBar }
        .navigationTitle("دليل زيارة عاشوراء")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { store.fontSize = max(15, store.fontSize - 2) } label: { Text("أ-").font(.headline) }
                Button { store.fontSize = min(40, store.fontSize + 2) } label: { Text("أ+").font(.headline) }
            }
        }
        .animation(.easeInOut(duration: 0.2), value: i)
    }

    private func header(_ s: AshuraStep) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(s.phase)
                .font(.caption.weight(.heavy))
                .padding(.horizontal, 12).padding(.vertical, 6)
                .glassCapsule()
            Text(s.title)
                .font(.system(size: 24 * scale, weight: .heavy))
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 3) {
                ForEach(0..<ashuraSteps.count, id: \.self) { idx in
                    Capsule()
                        .fill(idx <= i ? Brand.gold : Color.white.opacity(0.22))
                        .frame(height: 4)
                }
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .hero()
    }

    @ViewBuilder private func stepBody(_ s: AshuraStep) -> some View {
        Text(s.how)
            .font(.system(size: 16 * scale))
            .lineSpacing(8 * scale)
            .fixedSize(horizontal: false, vertical: true)
        if i == 2 {
            Button {
                nav.openReader("ziyarat", "z-ashura")
            } label: {
                Label("افتح المتن الكامل", systemImage: "book.fill").font(.subheadline.weight(.heavy))
            }
            .glassButton(prominent: true)
            .controlSize(.large)
        }
        if let say = s.say {
            sayCard(say, times: s.times)
        }
        if s.times > 0 {
            counter(s)
        }
    }

    private func sayCard(_ say: String, times: Int) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Circle().fill(Brand.gold).frame(width: 8, height: 8)
                Text(times > 0 ? "تقول (\(times.ar) مرّة):" : "تقول:")
                    .font(.system(size: 14 * scale, weight: .heavy))
                    .foregroundStyle(Brand.gold)
            }
            Text(say)
                .font(.scripture(22 * scale))
                .lineSpacing(12 * scale)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Brand.emerald.opacity(0.11), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }

    private func counter(_ s: AshuraStep) -> some View {
        let c = counts[i] ?? 0
        let frac = s.times > 0 ? min(1, Double(c) / Double(s.times)) : 0
        let full = c >= s.times
        return VStack(spacing: 14) {
            Text("\(c.ar) / \(s.times.ar)").font(.counter(34)).foregroundStyle(Brand.gold)
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.2))
                    Capsule().fill(Brand.gold).frame(width: geo.size.width * CGFloat(frac))
                }
            }
            .frame(height: 8)
            Button {
                if c < s.times {
                    counts[i] = c + 1
                    if c + 1 == s.times { Haptic.confirm() } else { Haptic.tick() }
                }
            } label: {
                VStack(spacing: 6) {
                    Image(systemName: full ? "checkmark" : "circle.dotted.circle").font(.system(size: 30, weight: .semibold))
                    Text(full ? "تمّ" : "اضغط").font(.subheadline.weight(.heavy))
                }
                .foregroundStyle(.white)
                .frame(width: 132, height: 132)
                .contentShape(Circle())
            }
            .buttonStyle(.plain)
            .glassCircle(tint: Brand.emerald, interactive: true)
            Button {
                counts[i] = 0
                Haptic.tick()
            } label: {
                Text("تصفير").font(.footnote.weight(.bold)).padding(.horizontal, 6)
            }
            .glassButton()
        }
        .padding(20)
        .frame(maxWidth: .infinity)
        .environment(\.colorScheme, .dark)
        .hero()
    }

    private var navBar: some View {
        HStack(spacing: 12) {
            if i > 0 {
                Button {
                    i -= 1
                } label: {
                    Label("السابق", systemImage: "chevron.backward").font(.headline).frame(maxWidth: .infinity)
                }
                .glassButton()
                .controlSize(.large)
            }
            Button {
                if isLast { dismiss() } else { i += 1 }
            } label: {
                Text(isLast ? "تمّ - إغلاق" : "التالي").font(.headline).frame(maxWidth: .infinity)
            }
            .glassButton(prominent: true)
            .controlSize(.large)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }
}
