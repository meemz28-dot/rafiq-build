import SwiftUI

// MARK: - Interactive Ziyarat Ashura guide (ported from Android ui/AshuraGuideScreen.kt)

fileprivate let ashuraLan = "اللّهُمَّ العَنْ أَوَّلَ ظالِمٍ ظَلَمَ حَقَّ مُحَمَّدٍ وَآلِ مُحَمَّدٍ وَآخِرَ تابِعٍ لَهُ عَلى ذلِكَ، اللّهُمَّ العَنْ العِصابَةَ الَّتِي جاهَدَتِ الحُسَيْنَ وَشايَعَتْ وَبايَعَتْ وَتابَعَتْ عَلى قَتْلِهِ اللّهُمَّ العَنْهُمْ جَميعاً."
fileprivate let ashuraSalam = "السَّلامُ عَلَيْكَ يا أَبا عَبْدِ الله وَعَلى الأَرواحِ الَّتِي حَلَّتْ بِفِنائِكَ، عَلَيْكَ مِنِّي سَلامُ اللهِ أَبَداً مابَقِيتُ وَبَقِيَ اللَيْلُ وَالنَّهارُ وَلا جَعَلَهُ الله آخِرَ العَهْدِ مِنِّي لِزِيارَتِكُمْ . السَّلامُ عَلى الحُسَيْنِ وَعَلى عَلِيِّ بْنِ الحُسَيْنِ وَعَلى أَوْلادِ الحُسَيْنِ وَعَلى أَصْحابِ الحُسَيْنِ."
fileprivate let ashuraClosing = """
اللّهُمَّ خُصَّ أَنْتَ أَوَّلَ ظالِمٍ بِاللَّعْنِ مِنِّي وَأَبْدأْ بِهِ أَوَّلاً ثُمَّ الثَّانِي وَالثَّالِثَ وَالرَّابِعَ، اللّهُمَّ الْعَنْ يَزِيدَ خامِساً وَالعَنْ عُبَيْدَ الله بْنَ زِيادٍ وَابْنَ مَرْجانَةَ وَعُمَرَ بْنَ سَعْدٍ وَشِمْراً وَآلَ أَبِي سُفْيانَ وَآلَ زِيادٍ وَآلَ مَرْوانَ إلى يَوْمِ القِيامَةِ.

اللّهُمَّ لَكَ الحَمْدُ حَمْدَ الشَّاكِرِينَ لَكَ عَلى مُصابِهِمْ، الحَمْدُ للهِ عَلى عَظِيمِ رَزِيَّتِي، اللّهُمَّ ارْزُقْنِي شَفاعَةَ الحُسَيْنِ يَوْمَ الوُرُودِ وَثَبِّتْ لِي قَدَمَ صِدْقٍ عِنْدَكَ مَعَ الحُسَيْنِ وَأَصْحابِ الحُسَيْنِ الَّذِينَ بَذَلُوا مُهَجَهُمْ دُونَ الحُسَيْنِ عَلَيهِ السَّلامُ.
"""

fileprivate struct AshuraStep {
    let phase: String
    let title: String
    let how: String
    var say: String? = nil
    var times: Int = 0   // > 0 means a repetition counter step
}

fileprivate let ashuraSteps: [AshuraStep] = [
    AshuraStep(phase: "تمهيد", title: "زيارة عاشوراء",
               how: "زيارة عاشوراء من أجلّ الزيارات وأعظمها ثواباً، تُقرأ يوم عاشوراء وفي كل يوم. لها كيفية مخصوصة: تقرأ متن الزيارة، ثم تلعن الظالمين مئة مرّة، ثم تسلّم على الحسين (ع) مئة مرّة، ثم تدعو بدعاء الختام، ثم تسجد. سنمشي معك خطوة بخطوة."),
    AshuraStep(phase: "النيّة", title: "النيّة والاستقبال",
               how: "استقبل القبلة (أو حرم الإمام الحسين عليه السلام إن كنت هناك)، واخطر بقلبك نيّة زيارة الإمام الحسين (ع) قربةً إلى الله."),
    AshuraStep(phase: "المتن", title: "قراءة متن الزيارة",
               how: "اقرأ متن زيارة عاشوراء كاملاً (تجده في باب الزيارات). ابدأ بـ«السلام عليك يا أبا عبد الله» إلى آخر المتن. يمكنك فتحه في القارئ التفاعلي ثم العودة لإكمال الأعمال.",
               say: "اَلسَّلامُ عَلَيْكَ يا اَبا عَبْدِ اللهِ، اَلسَّلامُ عَلَيْكَ يَا بْنَ رَسُولِ اللهِ..."),
    AshuraStep(phase: "اللعن", title: "اللعن مئة مرّة",
               how: "بعد المتن، العن الظالمين مئة مرّة. اضغط الدائرة في كل مرّة تقولها. يجوز الاقتصار على مرّة واحدة بنيّة المئة عند الضرورة.",
               say: ashuraLan, times: 100),
    AshuraStep(phase: "السلام", title: "السلام مئة مرّة",
               how: "ثم سلّم على الإمام الحسين (ع) مئة مرّة. اضغط الدائرة في كل مرّة.",
               say: ashuraSalam, times: 100),
    AshuraStep(phase: "الختام", title: "دعاء الختام",
               how: "ثم اقرأ دعاء الختام (دعاء علقمة يأتي بعده إن أردت).",
               say: ashuraClosing),
    AshuraStep(phase: "السجدة", title: "سجدة الختام",
               how: "اسجد، وقل في سجودك:",
               say: "اَللّهُمَّ لَكَ الْحَمْدُ حَمْدَ الشّاكِرينَ لَكَ عَلى مُصابِهِمْ، اَلْحَمْدُ للهِ عَلى عَظيمِ رَزِيَّتي، اَللّهُمَّ ارْزُقْني شَفاعَةَ الْحُسَيْنِ يَوْمَ الْوُرُودِ، وَثَبِّتْ لي قَدَمَ صِدْقٍ عِنْدَكَ مَعَ الْحُسَيْنِ وَاَصْحابِ الْحُسَيْنِ الَّذينَ بَذَلُوا مُهَجَهُمْ دُونَ الْحُسَيْنِ عَلَيْهِ السَّلامُ."),
    AshuraStep(phase: "تمّ", title: "تقبّل الله",
               how: "بهذا تمّت زيارة عاشوراء. يُستحب بعدها قراءة دعاء علقمة (صفوان) — تجده في باب الزيارات. تقبّل الله أعمالك وحشرك مع الحسين وأصحابه.")
]

struct AshuraView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.dismiss) private var dismiss
    @State private var i = 0
    @State private var counts: [Int: Int] = [:]

    private var scale: CGFloat { CGFloat(store.fontSize / 21.0) }
    private var isLast: Bool { i >= ashuraSteps.count - 1 }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if ashuraSteps.indices.contains(i) {
                    dashes
                    stepBody(ashuraSteps[i])
                }
            }
            .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 24)
            .readableWidth()
        }
        .scrollBounceBehavior(.basedOnSize)
        .background(Color(hex: 0xF7F1E3).ignoresSafeArea())
        .safeAreaInset(edge: .top, spacing: 0) { topBar }
        .safeAreaInset(edge: .bottom, spacing: 0) { navBar }
        .toolbar(.hidden, for: .navigationBar)
        .environment(\.colorScheme, .light)
        .keepScreenAwake(true)
        .animation(.easeInOut(duration: 0.2), value: i)
    }

    private var topBar: some View {
        HStack {
            RoundIconButton(symbol: "chevron.backward", label: "رجوع") { dismiss() }
            Spacer()
            Text(verbatim: "زيارة عاشوراء · الخطوة \((i + 1).ar) من \(ashuraSteps.count.ar)").font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink)
            Spacer()
            Menu {
                Button { store.fontSize = min(40, store.fontSize + 2) } label: { Label("تكبير الخط", systemImage: "textformat.size.larger") }
                Button { store.fontSize = max(15, store.fontSize - 2) } label: { Label("تصغير الخط", systemImage: "textformat.size.smaller") }
                Button { nav.openReader("ziyarat", "z-ashura") } label: { Label("المتن الكامل", systemImage: "book") }
            } label: {
                Image(systemName: "textformat.size").font(.system(size: 16, weight: .medium)).foregroundStyle(Brand.ink)
                    .frame(width: 42, height: 42).background(Color.white, in: Circle())
            }
            .accessibilityLabel("خيارات")
        }
        .padding(.horizontal, 16).padding(.vertical, 8)
        .background(Color(hex: 0xF7F1E3).opacity(0.95))
    }

    private var dashes: some View {
        HStack(spacing: 3) {
            ForEach(0..<ashuraSteps.count, id: \.self) { n in
                Capsule().fill(n == i ? Brand.gold : (n < i ? Brand.emerald : Color(hex: 0xE4DCC8))).frame(height: 5)
            }
        }
        .accessibilityHidden(true)
    }

    @ViewBuilder private func stepBody(_ s: AshuraStep) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(s.title).font(.display(30)).foregroundStyle(Brand.ink)
            Text(s.phase).font(.ui(.caption, .semibold)).foregroundStyle(Brand.deeper)
                .padding(.horizontal, 10).padding(.vertical, 5)
                .background(Color(hex: 0xE3EFEC), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            Text(s.how)
                .font(.ui(size: 15 * scale))
                .foregroundStyle(Color(hex: 0x3E524E))
                .lineSpacing(6 * scale)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 4)
        if i == 2 {
            Button { nav.openReader("ziyarat", "z-ashura") } label: {
                HStack(spacing: 10) {
                    Image(systemName: "book").foregroundStyle(Brand.gold)
                    Text("افتح المتن الكامل").font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink)
                    Spacer()
                    Text("مفاتيح الجنان").font(.ui(.caption)).foregroundStyle(Brand.muted)
                }
                .card(22, padding: 14)
            }
            .buttonStyle(.plain)
        }
        if let say = s.say { sayCard(say, times: s.times) }
        if s.times > 0 { counter(s) }
    }

    private func sayCard(_ say: String, times: Int) -> some View {
        VStack(spacing: 12) {
            OrnamentDivider(color: Brand.gold)
            Text(times > 0 ? "تقول (\(times.ar) مرّة):" : "تقول:").font(.ui(.caption, .bold)).foregroundStyle(Brand.goldDeep)
            Text(say)
                .font(.scripture(22 * scale))
                .lineSpacing(12 * scale)
                .foregroundStyle(Brand.ink)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
                .fixedSize(horizontal: false, vertical: true)
            OrnamentDivider(color: Brand.gold)
        }
        .padding(18)
        .background(Color(hex: 0xFBF7EC), in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(Brand.gold.opacity(0.6), lineWidth: 1.5))
    }

    private func counter(_ s: AshuraStep) -> some View {
        let c = counts[i] ?? 0
        let full = c >= s.times
        return VStack(spacing: 12) {
            Button {
                if c < s.times {
                    counts[i] = c + 1
                    if c + 1 == s.times { Haptic.confirm() } else { Haptic.tick() }
                }
            } label: {
                ZStack {
                    Circle().fill(Brand.cardFill).shadow(color: Color(hex: 0x10322D).opacity(0.14), radius: 20, y: 10)
                    Circle().stroke(Color(hex: 0xE4DCC8), lineWidth: 12).padding(22)
                    Circle().trim(from: 0, to: min(1, Double(c) / Double(max(1, s.times))))
                        .stroke(full ? Brand.good : Brand.emerald, style: StrokeStyle(lineWidth: 12, lineCap: .round))
                        .rotationEffect(.degrees(-90)).padding(22)
                    VStack(spacing: 2) {
                        Text(c.ar).font(.display(52)).foregroundStyle(Brand.ink).contentTransition(.numericText())
                        Text(full ? "تمّ · تقبّل الله" : "من \(s.times.ar) · اضغط لكلّ مرّة").font(.ui(.caption)).foregroundStyle(Brand.muted)
                    }
                }
                .frame(width: 240, height: 240)
                .contentShape(Circle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("عُدّ مرّة")
            .accessibilityValue("\(c.ar) من \(s.times.ar)")
            Button { counts[i] = 0; Haptic.tick() } label: {
                Text("من جديد").font(.ui(.caption, .semibold)).foregroundStyle(Brand.ink)
                    .padding(.horizontal, 16).frame(height: 40).background(Brand.cardFill, in: Capsule())
            }
            .buttonStyle(.plain)
            .disabled(c == 0).opacity(c == 0 ? 0.5 : 1)
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 6)
    }

    private var navBar: some View {
        let nextTitle = ashuraSteps.indices.contains(i + 1) ? ashuraSteps[i + 1].title : nil
        return HStack(spacing: 10) {
            Button { if i > 0 { i -= 1; Haptic.tick() } } label: {
                Text("السابقة").font(.ui(.subheadline, .semibold)).foregroundStyle(Brand.ink)
                    .frame(maxWidth: .infinity).frame(height: 54).background(Brand.cardFill, in: Capsule())
            }
            .buttonStyle(.plain).disabled(i == 0).opacity(i == 0 ? 0.5 : 1)
            Button { Haptic.tick(); if isLast { dismiss() } else { i += 1 } } label: {
                Text(nextTitle.map { "أتممتها · التالية: \($0)" } ?? "تمّ · إغلاق")
                    .font(.ui(.subheadline, .bold)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.75)
                    .padding(.horizontal, 12).frame(maxWidth: .infinity).frame(height: 54)
                    .background(Brand.deeper, in: Capsule())
            }
            .buttonStyle(.plain).layoutPriority(1)
        }
        .padding(.horizontal, 16).padding(.vertical, 10)
    }
}
