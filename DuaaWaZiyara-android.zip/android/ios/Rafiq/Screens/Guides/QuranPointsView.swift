import SwiftUI

// MARK: - Quran reading points (ported from Android QuranPointsScreen in ui/MoreScreens.kt + Settings points/khatma planner)

/// Shared Quran points state (Android keys: quranPoints, quranDone, khatmaAwarded, khActive, khDays, khStart, khJuz, readHist).
enum QuranPointsLevel {
    static let featured: Set<String> = [
        "q-001", "q-002", "q-018", "q-036", "q-048", "q-055", "q-056",
        "q-067", "q-044", "q-076", "q-062", "q-112", "q-113", "q-114"
    ]

    /// Featured suras give 15 points, others 10.
    static func surahPoints(_ id: String) -> Int { featured.contains(id) ? 15 : 10 }

    static func points(_ s: Store) -> Int { s.int("quranPoints", 0) }

    static func doneSet(_ s: Store) -> Set<String> {
        Set(s.string("quranDone").split(separator: ",").map { String($0) }.filter { !$0.isEmpty })
    }

    /// Records a finished sura once (Android Settings.completeSurah). Returns points granted, 0 if already done, -1 if not a sura.
    /// Completing all 114 adds a one-time 500 point khatma bonus.
    @discardableResult
    static func completeSurah(_ s: Store, _ id: String) -> Int {
        if !id.hasPrefix("q-") { return -1 }
        var done = doneSet(s)
        if done.contains(id) { return 0 }
        let pts = surahPoints(id)
        done.insert(id)
        var total = points(s) + pts
        var bonus = 0
        if done.count >= 114 && !s.bool("khatmaAwarded", false) {
            bonus = 500
            total += bonus
            s.put("khatmaAwarded", true)
        }
        s.put("quranDone", done.sorted().joined(separator: ","))
        s.put("quranPoints", total)
        return pts + bonus
    }

    static func level(_ p: Int) -> (name: String, num: Int) {
        if p >= 1140 { return ("حافظ مثابر", 5) }
        if p >= 600 { return ("قارئ متقدّم", 4) }
        if p >= 300 { return ("قارئ مواظب", 3) }
        if p >= 100 { return ("قارئ ناشئ", 2) }
        return ("مبتدئ", 1)
    }

    /// Consecutive reading days ending today or yesterday.
    static func readingStreak(_ s: Store) -> Int {
        let map = s.series("readHist")
        if map.isEmpty { return 0 }
        var cursor = (map[s.today] ?? 0) > 0 ? s.today : s.today - 1
        var count = 0
        while (map[cursor] ?? 0) > 0 { count += 1; cursor -= 1 }
        return count
    }

    static func readDays(_ s: Store, window: Int) -> Int {
        let t = s.today
        return s.series("readHist").filter { $0.key > t - window && $0.value > 0 }.count
    }

    // Juz planner
    static func plannerActive(_ s: Store) -> Bool { s.bool("khActive", false) }
    static func plannerDays(_ s: Store) -> Int { max(1, s.int("khDays", 30)) }
    static func juzDone(_ s: Store) -> Int { s.int("khJuz", 0) }
    static func startPlanner(_ s: Store, days: Int) {
        s.put("khActive", true)
        s.put("khDays", max(1, min(365, days)))
        s.put("khStart", s.today)
        s.put("khJuz", 0)
    }
    static func setJuz(_ s: Store, _ n: Int) {
        let v = max(0, min(30, n))
        s.put("khJuz", v)
        if v >= 30 { s.put("khActive", false) }
    }
    static func cancelPlanner(_ s: Store) { s.put("khActive", false) }
    static func expectedJuz(_ s: Store) -> Int {
        if !plannerActive(s) { return 0 }
        let elapsed = s.today - s.int("khStart", 0) + 1
        let perDay = 30.0 / Double(plannerDays(s))
        return max(0, min(30, Int(Double(elapsed) * perDay)))
    }
}

struct QuranPointsView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private var suras: [DuaaItem] { Library.category("quran")?.items ?? [] }
    private var total: Int { suras.isEmpty ? 114 : suras.count }

    var body: some View {
        ScreenScroll {
            heroCard
            progressCard
            streakCard
            plannerCard
            rulesCard
            nextSurahCard
            Text("التحفيز وسيلةٌ لا غاية؛ المقصود تدبّر كتاب الله والمداومة عليه.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .navigationTitle("نقاط القرآن")
        .navigationBarTitleDisplayMode(.large)
    }

    private var heroCard: some View {
        let points = QuranPointsLevel.points(store)
        let lv = QuranPointsLevel.level(points)
        let doneCount = QuranPointsLevel.doneSet(store).count
        let frac = min(1, Double(doneCount) / Double(max(1, total)))
        return VStack(spacing: 10) {
            Text("مجموع نقاطك").font(.footnote.weight(.bold)).opacity(0.82)
            ZStack {
                Circle().stroke(Color.white.opacity(0.18), lineWidth: 10)
                Circle()
                    .trim(from: 0, to: CGFloat(frac))
                    .stroke(Brand.gold, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                Text(points.ar)
                    .font(.counter(44))
                    .foregroundStyle(.white)
                    .minimumScaleFactor(0.5)
                    .lineLimit(1)
                    .padding(.horizontal, 18)
            }
            .frame(width: 150, height: 150)
            Text("المستوى \(lv.num.ar) · \(lv.name)")
                .font(.footnote.weight(.heavy))
                .padding(.horizontal, 16).padding(.vertical, 7)
                .glassCapsule(tint: Brand.gold)
        }
        .padding(.vertical, 24)
        .frame(maxWidth: .infinity)
        .hero()
    }

    private var progressCard: some View {
        let doneCount = QuranPointsLevel.doneSet(store).count
        let frac = min(1, Double(doneCount) / Double(max(1, total)))
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("السور المقروءة").font(.headline)
                Spacer()
                Text("\(doneCount.ar) / \(total.ar) سورة").font(.subheadline.weight(.heavy)).foregroundStyle(Brand.emerald)
            }
            ProgressView(value: frac).tint(Brand.emerald)
            Text(doneCount >= total ? "أتممتَ قراءة سور القرآن كاملةً — جعلها الله في ميزان حسناتك."
                                    : "تُحتسب السورة تلقائياً عند قراءتها حتّى النهاية، فتُضاف نقاطها.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .card(20)
    }

    private var streakCard: some View {
        let streak = QuranPointsLevel.readingStreak(store)
        let days30 = QuranPointsLevel.readDays(store, window: 30)
        let columns = Array(repeating: GridItem(.flexible(), spacing: 4), count: 7)
        let unit = streak == 1 ? "يوم" : "يوماً"
        return VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                Image(systemName: "star.fill")
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(Brand.gold)
                    .frame(width: 44, height: 44)
                    .background(Brand.gold.opacity(0.14), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                VStack(alignment: .leading, spacing: 2) {
                    Text("سلسلة القراءة").font(.headline)
                    Text(streak > 0 ? "\(streak.ar) \(unit) متتالية — لا تكسرها" : "اقرأ اليوم لتبدأ سلسلتك")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            LazyVGrid(columns: columns, spacing: 4) {
                ForEach(0..<21, id: \.self) { offset in
                    let read = store.seriesValue("readHist", offset: offset) > 0
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(read ? Brand.emerald.opacity(0.85) : Color(.tertiarySystemFill))
                        .overlay(RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .stroke(offset == 0 ? Brand.gold : Color.clear, lineWidth: 1.5))
                        .aspectRatio(1, contentMode: .fit)
                }
            }
            Text("\(days30.ar) يوماً قرأتَ فيها خلال آخر ٣٠ يوماً.")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .card(20)
    }

    private var plannerCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("مخطّط الختمة", systemImage: "book.fill")
                .font(.headline)
                .labelStyle(.titleAndIcon)
            if QuranPointsLevel.plannerActive(store) {
                plannerActive
            } else {
                plannerIdle
            }
        }
        .card(20)
    }

    private var plannerIdle: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("حدّد مدّةً لختم القرآن، وسنوزّع الأجزاء على الأيام ونتابع وتيرتك.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 8) {
                ForEach([7, 30, 60], id: \.self) { d in
                    Button {
                        QuranPointsLevel.startPlanner(store, days: d)
                        Haptic.confirm()
                    } label: {
                        Text(d == 7 ? "أسبوع" : "\(d.ar) يوماً")
                            .font(.footnote.weight(.heavy))
                            .frame(maxWidth: .infinity)
                    }
                    .glassButton()
                    .controlSize(.large)
                }
            }
        }
    }

    private var plannerActive: some View {
        let done = QuranPointsLevel.juzDone(store)
        let expected = QuranPointsLevel.expectedJuz(store)
        let perDay = 30.0 / Double(QuranPointsLevel.plannerDays(store))
        let onTrack = done >= expected
        let badge = onTrack ? Brand.good : Brand.bad
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("\(done.ar) / ٣٠ جزءاً").font(.counter(18)).foregroundStyle(Brand.emerald)
                Spacer()
                Text(onTrack ? "في الموعد ✓" : "متأخّر قليلاً")
                    .font(.caption.weight(.heavy))
                    .foregroundStyle(badge)
                    .padding(.horizontal, 12).padding(.vertical, 5)
                    .background(badge.opacity(0.16), in: Capsule())
            }
            ProgressView(value: min(1, Double(done) / 30)).tint(Brand.emerald)
            Text("هدفك اليومي \(String(format: "%.1f", perDay).arabicDigits) جزء · المتوقّع حتى اليوم \(expected.ar) جزءاً")
                .font(.caption)
                .foregroundStyle(.secondary)
            HStack(spacing: 8) {
                Button {
                    QuranPointsLevel.setJuz(store, done - 1)
                    Haptic.tick()
                } label: {
                    Text("− جزء").font(.subheadline.weight(.heavy)).frame(maxWidth: .infinity)
                }
                .glassButton()
                .controlSize(.large)
                Button {
                    QuranPointsLevel.setJuz(store, done + 1)
                    Haptic.tick()
                } label: {
                    Text("+ جزء").font(.subheadline.weight(.heavy)).frame(maxWidth: .infinity)
                }
                .glassButton(prominent: true)
                .controlSize(.large)
            }
            Button(role: .destructive) {
                QuranPointsLevel.cancelPlanner(store)
            } label: {
                Text("إلغاء المخطّط").font(.caption.weight(.bold)).frame(maxWidth: .infinity)
            }
            .buttonStyle(.plain)
            .foregroundStyle(Brand.bad)
            .padding(.top, 2)
        }
    }

    private var rulesCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("كيف تُجمع النقاط").font(.headline)
            pointRule("إتمام سورة عادية", "+10")
            pointRule("إتمام سورة مميّزة (الفاتحة، يس، الكهف، الملك، الرحمن...)", "+15")
            pointRule("ختم القرآن كاملاً", "+500")
        }
        .card(20)
    }

    private func pointRule(_ label: String, _ pts: String) -> some View {
        HStack(spacing: 12) {
            Text(pts.arabicDigits)
                .font(.footnote.weight(.heavy))
                .foregroundStyle(Brand.goldDeep)
                .padding(.horizontal, 10).padding(.vertical, 4)
                .background(Brand.gold.opacity(0.16), in: Capsule())
            Text(label).font(.footnote).fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
    }

    @ViewBuilder private var nextSurahCard: some View {
        let done = QuranPointsLevel.doneSet(store)
        if done.count < total, let next = suras.first(where: { !done.contains($0.id) }) {
            Button {
                nav.openReader("quran", next.id)
            } label: {
                HStack(spacing: 14) {
                    Image(systemName: "book.fill").font(.system(size: 22, weight: .semibold))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("تابع نحو الختمة").font(.caption.weight(.heavy)).opacity(0.82)
                        Text(next.title).font(.headline)
                    }
                    Spacer(minLength: 0)
                    Text("+\(QuranPointsLevel.surahPoints(next.id).ar)").font(.counter(17)).foregroundStyle(Brand.gold)
                }
                .foregroundStyle(.white)
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(LinearGradient(colors: Brand.categoryColors("quran"), startPoint: .topLeading, endPoint: .bottomTrailing),
                            in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
    }
}
