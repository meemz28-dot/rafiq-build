import SwiftUI

// MARK: - ختمتي ونقاط القرآن: verse-level progress linked to real reading

/// Compatibility layer for Journey and Home (now backed by QuranProgress).
enum QuranPointsLevel {
    static func points(_ s: Store) -> Int { QuranProgress.migrate(s); return QuranProgress.lifetime(s) }
    static func level(_ p: Int) -> (name: String, num: Int) { let l = QuranProgress.level(p); return (l.name, l.num) }
    static func doneSet(_ s: Store) -> Set<String> {
        let r = QuranProgress.reach(s)
        return Set((1...114).filter { (r[$0] ?? 0) >= QuranProgress.verseCounts[$0 - 1] }.map { String(format: "q-%03d", $0) })
    }
}

struct QuranPointsView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @State private var confirmReset = false
    @State private var showPlan = false

    private var surahs: [DuaaItem] { Library.category("quran")?.items ?? [] }

    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                header
                VStack(alignment: .leading, spacing: 14) {
                    statTiles.padding(.top, -44)
                    weekCard
                    juzCard
                    todayCard
                    planCard
                    paceCard
                    surahGrid
                    statsCard
                    hadithCard
                    Button(role: .destructive) { confirmReset = true } label: {
                        Label("ابدأ ختمةً جديدة من الفاتحة", systemImage: "arrow.counterclockwise")
                            .font(.footnote.weight(.semibold))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 4)
                }
                .padding(.horizontal, 16).padding(.bottom, 28)
                .readableWidth()
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Brand.canvas)
        .toolbar(.hidden, for: .navigationBar)
        .safeAreaInset(edge: .bottom, spacing: 0) { continueButton }
        .onAppear { QuranProgress.migrate(store) }
        .confirmationDialog("بدء ختمة جديدة؟", isPresented: $confirmReset, titleVisibility: .visible) {
            Button("ابدأ من جديد", role: .destructive) { QuranProgress.resetKhatma(store) }
            Button("إلغاء", role: .cancel) {}
        } message: {
            Text("يُصفَّر تقدّم الختمة الحالية فقط؛ تبقى نقاطك وإحصاءاتك كما هي.")
        }
        .sheet(isPresented: $showPlan) {
            NavigationStack { QuranPlanSheet() }
                .environment(store)
                .environment(\.layoutDirection, .rightToLeft)
                .presentationDetents([.medium, .large])
        }
    }

    // MARK: Header: full-bleed teal with the khatma ring

    private var header: some View {
        let frac = QuranProgress.khatmaFraction(store)
        let verses = QuranProgress.khatmaVerses(store)
        let number = QuranProgress.khatmas(store) + 1
        return ZStack(alignment: .top) {
            Brand.heroGradient
            GirihPattern().foregroundStyle(.white.opacity(0.07))
            VStack(spacing: 14) {
                HStack {
                    RoundIconButton(symbol: "chevron.backward", label: "رجوع", translucent: true) { dismiss() }
                    Spacer()
                    Text("ختمتي").font(.display(26)).foregroundStyle(.white)
                    Spacer()
                    RoundIconButton(symbol: "calendar", label: "خطّة الختمة", translucent: true) { showPlan = true }
                }
                .padding(.top, 54)
                ZStack {
                    Circle().stroke(Color.white.opacity(0.18), lineWidth: 12)
                    Circle().trim(from: 0, to: max(0.004, frac))
                        .stroke(Brand.goldSoft, style: StrokeStyle(lineWidth: 12, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                    VStack(spacing: 2) {
                        if verses == 0 {
                            Text("ابدأ").font(.display(34)).foregroundStyle(.white)
                        } else {
                            Text(verbatim: "٪\(Int((frac * 100).rounded()).ar)").font(.display(40)).foregroundStyle(.white)
                        }
                        Text(verbatim: verses == 0 ? "\(QuranProgress.totalVerses.ar) آية أمامك" : "من الختمة \(QuranPointsView.ordinal(number))").font(.caption).foregroundStyle(.white.opacity(0.85))
                    }
                }
                .frame(width: 150, height: 150)
                Spacer(minLength: 60)
            }
            .padding(.horizontal, 16)
        }
        .frame(height: 350)
        .clipped()
        .environment(\.colorScheme, .dark)
    }

    static func ordinal(_ n: Int) -> String {
        let names = ["الأولى", "الثانية", "الثالثة", "الرابعة", "الخامسة", "السادسة", "السابعة", "الثامنة", "التاسعة", "العاشرة"]
        return (1...10).contains(n) ? names[n - 1] : "رقم \(n.ar)"
    }

    private var statTiles: some View {
        let today = QuranProgress.today(store), goal = QuranProgress.goal(store)
        let streak = QuranProgress.streak(store)
        let pace = Int(QuranPace.current(store).rounded())
        return HStack(spacing: 10) {
            statTile(value: today.ar, suffix: "/\(goal.ar)", label: "آيات اليوم", color: today >= goal ? Brand.emerald : Brand.ink)
            statTile(value: streak.ar, suffix: nil, label: "يوماً متتالياً", color: Brand.goldDeep)
            statTile(value: pace.ar, suffix: nil, label: "حرفاً/ثانية", color: Brand.emerald)
        }
    }

    private func statTile(value: String, suffix: String?, label: String, color: Color) -> some View {
        VStack(spacing: 4) {
            HStack(alignment: .firstTextBaseline, spacing: 2) {
                Text(value).font(.display(24)).foregroundStyle(color)
                if let suffix { Text(suffix).font(.caption).foregroundStyle(Brand.muted) }
            }
            Text(label).font(.caption).foregroundStyle(Brand.muted)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 84)
        .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .shadow(color: Color(hex: 0x10322D).opacity(0.1), radius: 12, y: 6)
    }

    // MARK: This week

    private var weekCard: some View {
        let vals: [Int] = (0..<7).reversed().map { store.seriesValue("qpAyatHist", offset: $0) }
        let labels: [String] = (0..<7).reversed().map { off in
            let d = Calendar.current.date(byAdding: .day, value: -off, to: Date()) ?? Date()
            let wd = max(0, min(6, Calendar.current.component(.weekday, from: d) - 1))
            let w = Hijri.weekDays[wd]
            return off == 0 ? "اليوم" : (w.hasPrefix("ال") ? String(w.dropFirst(2)) : w)
        }
        let top = max(1, vals.max() ?? 1)
        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("هذا الأسبوع").font(.subheadline.weight(.bold)).foregroundStyle(Brand.ink)
                Spacer()
                Text(verbatim: "\(vals.reduce(0, +).ar) آية").font(.caption).foregroundStyle(Brand.muted)
            }
            HStack(alignment: .bottom, spacing: 8) {
                ForEach(0..<7, id: \.self) { k in
                    VStack(spacing: 6) {
                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                            .fill(k == 6 ? Brand.emerald : (vals[k] == 0 ? Color(hex: 0xEAE4D6) : Brand.emerald.opacity(0.35)))
                            .frame(height: max(6, 64 * CGFloat(vals[k]) / CGFloat(top)))
                        Text(labels[k]).font(.caption2.weight(k == 6 ? .bold : .regular)).foregroundStyle(k == 6 ? Brand.ink : Brand.muted).lineLimit(1).minimumScaleFactor(0.7)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .frame(height: 90, alignment: .bottom)
        }
        .card()
        .accessibilityElement(children: .combine)
    }

    // MARK: Continue button (gold)

    private var continueButton: some View {
        let nx = QuranProgress.next(store)
        let juz = QuranPointsView.juz(of: nx.surah, verse: nx.verse)
        return Button {
            openSurah(nx.surah, verse: nx.verse)
        } label: {
            HStack(spacing: 10) {
                Image(systemName: "play.fill").font(.system(size: 14, weight: .bold))
                Text(verbatim: nx.verse <= 1 && nx.surah == 1 ? "ابدأ من الفاتحة" : "تابع من الجزء \(juz.ar) · \(QuranAudio.surahTitle(nx.surah).replacingOccurrences(of: "سورة ", with: "")) \(nx.verse.ar)")
                    .font(.subheadline.weight(.bold)).lineLimit(1).minimumScaleFactor(0.8)
            }
            .foregroundStyle(Color(hex: 0x10322D))
            .frame(maxWidth: .infinity).frame(height: 56)
            .background(Brand.goldSoft, in: Capsule())
            .shadow(color: Brand.gold.opacity(0.3), radius: 14, y: 6)
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 16).padding(.vertical, 10)
        .background(LinearGradient(colors: [Brand.canvas.opacity(0), Brand.canvas], startPoint: .top, endPoint: .bottom).allowsHitTesting(false))
    }

    /// Juz number (1…30) that holds a verse.
    static func juz(of surah: Int, verse: Int) -> Int {
        let starts = Library.shared.juz
        guard starts.sura.count == 30, starts.aya.count == 30 else { return 1 }
        var j = 1
        for k in 0..<30 where (starts.sura[k] < surah) || (starts.sura[k] == surah && starts.aya[k] <= verse) { j = k + 1 }
        return j
    }

    // MARK: Today vs goal

    private var todayCard: some View {
        let today = QuranProgress.today(store)
        let goal = QuranProgress.goal(store)
        let frac = min(1, Double(today) / Double(max(1, goal)))
        let streak = QuranProgress.streak(store)
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("اليوم", systemImage: "sun.max.fill").font(.headline)
                Spacer()
                if streak > 0 {
                    Label("\(streak.ar) يوماً متتالياً", systemImage: "flame.fill")
                        .font(.caption.weight(.bold)).foregroundStyle(Brand.gold)
                }
            }
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(today.ar).font(.counter(30)).foregroundStyle(Brand.emerald)
                Text(verbatim: "/ \(goal.ar) آية").font(.subheadline).foregroundStyle(.secondary)
                Spacer()
                if today >= goal { Label("أتممتَ وِرد اليوم", systemImage: "checkmark.seal.fill").font(.caption.weight(.bold)).foregroundStyle(Brand.good) }
            }
            ProgressView(value: frac).tint(today >= goal ? Brand.good : Brand.emerald)
            Stepper(value: Binding(get: { QuranProgress.goal(store) }, set: { store.put(QuranProgress.goalKey, max(5, min(700, $0))) }),
                    in: 5...700, step: 5) {
                Text("هدفي اليومي: \(goal.ar) آية").font(.footnote)
            }
            if QuranProgress.listenedToday(store) > 0 {
                Label("استمعتَ اليوم إلى \(QuranProgress.listenedToday(store).ar) سورة (لا تُحسب قراءة)", systemImage: "headphones")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .card()
    }

    // MARK: Reading pace

    private var paceCard: some View {
        let mode = QuranPace.mode(store)
        let pace = QuranPace.current(store)
        let perMinute = Int((pace * 60).rounded())
        return VStack(alignment: .leading, spacing: 10) {
            Label("سرعة قراءتي", systemImage: "speedometer").font(.headline)
            Picker("سرعة القراءة", selection: Binding(get: { QuranPace.mode(store) }, set: { store.put(QuranPace.modeKey, $0) })) {
                ForEach(QuranPace.modes, id: \.key) { m in Text(m.name).tag(m.key) }
            }
            .pickerStyle(.segmented)
            if let m = QuranPace.modes.first(where: { $0.key == mode }) {
                Text(m.detail).font(.caption).foregroundStyle(.secondary)
            }
            if mode == "auto" && QuranPace.learned(store) == nil {
                Text("يتعلّم التطبيق سرعتك بعد بضع صفحات (\(QuranPace.sampleCount(store).ar) من ٥)؛ وحتّى ذلك تُعتمد سرعةٌ متوسّطة.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Text("نحو \(perMinute.ar) حرفاً في الدقيقة. تُحسب الآية بعد أن تظهر على الشاشة ويمضي وقتٌ يكفي لقراءة حروفها بسرعتك؛ فالآية الطويلة تحتاج وقتاً أطول، والتمرير السريع لا يُحتسب.")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .card()
    }

    // MARK: Plan

    private var planCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let p = QuranProgress.planDaily(store) {
                HStack {
                    Label("خطّة الختمة", systemImage: "calendar").font(.headline)
                    Spacer()
                    Text(p.onTrack ? "على المسار" : "متأخّر قليلاً")
                        .font(.caption.weight(.heavy))
                        .foregroundStyle(p.onTrack ? Brand.good : Brand.gold)
                }
                Text("باقٍ \(p.daysLeft.ar) يوماً · اقرأ نحو \(p.perDay.ar) آية يومياً لتختم في موعدك")
                    .font(.subheadline)
                Button("تعديل الخطّة") { showPlan = true }.font(.footnote.weight(.bold))
            } else {
                Label("ضع خطّةً للختمة", systemImage: "calendar.badge.plus").font(.headline)
                Text("اختر مدّة الختمة فيُحسب لك وِردٌ يوميّ بالآيات، ويتقدّم تلقائياً كلّما قرأت.")
                    .font(.footnote).foregroundStyle(.secondary)
                Button("اختر المدّة") { showPlan = true }.buttonStyle(.borderedProminent).tint(Brand.emerald)
            }
        }
        .card()
    }

    // MARK: Juz grid (auto from reading)

    private var juzCard: some View {
        let fr = QuranProgress.juzFractions(store)
        let done = fr.filter { $0 >= 0.999 }.count
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("الأجزاء").font(.headline)
                Spacer()
                Text(verbatim: "\(done.ar) من ٣٠").font(.caption.weight(.bold)).foregroundStyle(.secondary)
            }
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 6), count: 6), spacing: 6) {
                ForEach(0..<30, id: \.self) { j in
                    QuranFillCell(label: (j + 1).ar, fraction: fr.indices.contains(j) ? fr[j] : 0, height: 40)
                }
            }
        }
        .card()
    }

    // MARK: Surah grid (tap to read)

    private var surahGrid: some View {
        let r = QuranProgress.reach(store)
        let doneCount = (1...114).filter { (r[$0] ?? 0) >= QuranProgress.verseCounts[$0 - 1] }.count
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("السور").font(.headline)
                Spacer()
                Text(verbatim: "\(doneCount.ar) من ١١٤").font(.caption.weight(.bold)).foregroundStyle(.secondary)
            }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 34), spacing: 5)], spacing: 5) {
                ForEach(1...114, id: \.self) { n in
                    Button { openSurah(n, verse: min((r[n] ?? 0) + 1, QuranProgress.verseCounts[n - 1])) } label: {
                        QuranFillCell(label: n.ar, fraction: Double(min(r[n] ?? 0, QuranProgress.verseCounts[n - 1])) / Double(QuranProgress.verseCounts[n - 1]), height: 34)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(QuranAudio.surahTitle(n))
                }
            }
            Text("تمتلئ الخانات تلقائياً بحسب ما تقرؤه فعلاً في القارئ، آيةً آية.")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .card()
    }

    // MARK: Stats

    private var statsCard: some View {
        let pts = QuranProgress.lifetime(store)
        let lv = QuranProgress.level(pts)
        let week = (0..<7).reduce(0) { $0 + store.seriesValue("qpAyatHist", offset: $1) }
        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("المستوى \(lv.num.ar): \(lv.name)", systemImage: "rosette").font(.headline)
                Spacer()
            }
            if let next = lv.next {
                ProgressView(value: Double(pts), total: Double(next)).tint(Brand.gold)
                Text(verbatim: "\(pts.ar) نقطة · بقي \((next - pts).ar) للمستوى التالي").font(.caption).foregroundStyle(.secondary)
            }
            HStack(spacing: 10) {
                QuranStat(value: pts.ar, label: "آية قرأتها (نقطة لكلّ آية)")
                QuranStat(value: QuranProgress.khatmas(store).ar, label: "ختمة مكتملة")
                QuranStat(value: week.ar, label: "آية هذا الأسبوع")
            }
            if QuranProgress.listenedTotal(store) > 0 {
                Text("واستمعتَ إلى \(QuranProgress.listenedTotal(store).ar) سورة كاملة.").font(.caption).foregroundStyle(.secondary)
            }
        }
        .card()
    }

    private var hadithCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("عن الإمام الصادق (ع): «ما يمنعُ التاجرَ منكم… أن لا ينام حتّى يقرأ سورةً من القرآن، فتُكتب له مكانَ كلّ آيةٍ يقرؤها عشرُ حسنات، ويُمحى عنه عشرُ سيّئات».")
                .font(.scripture(17)).lineSpacing(6)
            Text("الكافي ٢، كتاب فضل القرآن، باب ثواب قراءة القرآن · صحيح")
                .font(.caption2).foregroundStyle(.secondary)
            Divider()
            Text("«ينبغي للمرء المسلم أن ينظر في عهده، وأن يقرأ منه في كلّ يومٍ خمسين آية».")
                .font(.scripture(16))
            Text("الكافي ٢، باب في قراءته · حسن. ولهذا كان الهدف اليومي الافتراضي ٥٠ آية.")
                .font(.caption2).foregroundStyle(.secondary)
            Text("التحفيز وسيلةٌ لا غاية؛ المقصود تدبّر كتاب الله والمداومة عليه.")
                .font(.footnote).foregroundStyle(.secondary).padding(.top, 2)
        }
        .card()
    }

    private func openSurah(_ n: Int, verse: Int) {
        if verse > 1 { nav.pendingFind = "(\(verse))" }
        nav.openReader("quran", String(format: "q-%03d", n))
    }
}

/// A small cell that fills from the bottom with the reading fraction.
private struct QuranFillCell: View {
    let label: String
    let fraction: Double
    let height: CGFloat
    var body: some View {
        let done = fraction >= 0.999
        ZStack(alignment: .bottom) {
            RoundedRectangle(cornerRadius: 8, style: .continuous).fill(Color(hex: 0xEAE4D6))
            GeometryReader { g in
                VStack { Spacer(minLength: 0)
                    Rectangle().fill(done ? Brand.deeper : Brand.gold.opacity(0.7))
                        .frame(height: g.size.height * CGFloat(min(1, max(0, fraction))))
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            Text(label)
                .font(.caption2.weight(.bold))
                .foregroundStyle(done ? Color.white : Brand.ink)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(height: height)
    }
}

private struct QuranStat: View {
    let value: String
    let label: String
    var body: some View {
        VStack(spacing: 2) {
            Text(value).font(.title3.weight(.heavy)).foregroundStyle(Brand.emerald)
            Text(label).font(.caption2).foregroundStyle(.secondary).multilineTextAlignment(.center).lineLimit(2)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(Brand.emerald.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

// MARK: - Khatma plan sheet

private struct QuranPlanSheet: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var days = 30

    private let presets = [30, 40, 60, 90, 120, 180, 365]

    var body: some View {
        Form {
            Section {
                Picker("المدّة", selection: $days) {
                    ForEach(presets, id: \.self) { d in Text(verbatim: "\(d.ar) يوماً").tag(d) }
                }
                .pickerStyle(.wheel)
                let perDay = Int((Double(QuranProgress.totalVerses - QuranProgress.khatmaVerses(store)) / Double(days)).rounded(.up))
                Label("نحو \(max(1, perDay).ar) آية يومياً (قرابة \(max(1, perDay / 10).ar) دقيقة)", systemImage: "book")
            } footer: {
                Text("عن الإمام الصادق (ع) حين سُئل: أقرأ القرآن في ليلة؟ قال: «لا يعجبني أن تقرأه في أقلّ من شهر» (الكافي ٢، حسن). ولذلك تبدأ الخطط من ٣٠ يوماً.")
            }
            if store.int(QuranProgress.planDaysKey, 0) > 0 {
                Section {
                    Button("إلغاء الخطّة", role: .destructive) {
                        QuranProgress.startPlan(store, days: 0)
                        dismiss()
                    }
                }
            }
        }
        .navigationTitle("خطّة الختمة")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("إلغاء") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("ابدأ") {
                    QuranProgress.startPlan(store, days: days)
                    Haptic.confirm()
                    dismiss()
                }
                .fontWeight(.bold)
            }
        }
        .onAppear {
            let d = store.int(QuranProgress.planDaysKey, 0)
            if presets.contains(d) { days = d }
        }
    }
}
