import SwiftUI

// MARK: - Trait of the month (ported from Android ui/TraitJourneyScreen.kt + Settings trait keys)

/// Shared trait-journey state (Android keys: trActive, trId, trStart, trTarget, trLog, trHist).
enum TraitProgress {
    static func isActive(_ s: Store) -> Bool { s.bool("trActive", false) }
    static func current(_ s: Store) -> Trait? {
        let id = s.string("trId")
        return Library.shared.traits.first { $0.id == id }
    }
    static func startDay(_ s: Store) -> Int { s.int("trStart", 0) }
    static func target(_ s: Store) -> Int { s.int("trTarget", 30) }
    static func doneToday(_ s: Store) -> Bool { (s.series("trLog")[s.today] ?? 0) > 0 }
    static func doneCount(_ s: Store) -> Int {
        let st = startDay(s)
        return s.series("trLog").filter { $0.key >= st && $0.value > 0 }.count
    }
    static func dayNumber(_ s: Store) -> Int { max(1, s.today - startDay(s) + 1) }
    static func setToday(_ s: Store, done: Bool) {
        s.setSeries("trLog", day: s.today, value: done ? 1 : 0, keepDays: 70)
    }
    static func begin(_ s: Store, id: String, days: Int) {
        s.put("trActive", true)
        s.put("trId", id)
        s.put("trStart", s.today)
        s.put("trTarget", max(7, min(60, days)))
        s.put("trLog", "")
    }
    static func history(_ s: Store) -> [String] { s.strings("trHist") }
    static func complete(_ s: Store) {
        var h = history(s)
        let entry = "\(s.string("trId"))|\(target(s))|\(s.today)"
        if !h.contains(entry) { h.append(entry) }
        s.put("trHist", h)
        s.put("trActive", false)
    }
    static func abandon(_ s: Store) {
        s.put("trActive", false)
        s.put("trLog", "")
    }
}

struct TraitView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @State private var selected: String?
    @State private var chosenDays = 30

    var body: some View {
        ScreenScroll {
            Text("تهذيب النفس على منهج جامع السعادات — تخليةٌ وتحلية")
                .font(.footnote.weight(.bold))
                .foregroundStyle(.secondary)
            if TraitProgress.isActive(store), let t = TraitProgress.current(store) {
                activeJourney(t)
            } else {
                chooser
            }
            historySection
        }
        .navigationTitle("صفة الشهر")
        .navigationBarTitleDisplayMode(.large)
    }

    // MARK: Active journey

    @ViewBuilder private func activeJourney(_ t: Trait) -> some View {
        let day = TraitProgress.dayNumber(store)
        let target = max(1, TraitProgress.target(store))
        let done = TraitProgress.doneCount(store)
        let graduated = done >= target
        heroCard(t, day: day, target: target, done: done, graduated: graduated)
        if graduated {
            VStack(alignment: .leading, spacing: 12) {
                Text("قال النراقي: الخُلق يُكتسب بتكرار الفعل حتى يصير مَلَكة. ثبّتك الله على ما بلغت.")
                    .font(.subheadline)
                    .lineSpacing(5)
                    .fixedSize(horizontal: false, vertical: true)
                Button {
                    TraitProgress.complete(store)
                    Haptic.confirm()
                } label: {
                    Text("اختم الرحلة وسجّلها").font(.headline).frame(maxWidth: .infinity)
                }
                .glassButton(prominent: true)
                .controlSize(.large)
            }
            .card(20)
        } else {
            SectionTitle(text: "عمل اليوم بالضدّ")
            todayCard(t)
            HStack(spacing: 10) {
                if Library.item("akhlaq", t.clinicId) != nil {
                    Button {
                        nav.openReader("akhlaq", t.clinicId)
                    } label: {
                        Text("عيادة الصفة").font(.subheadline.weight(.bold)).frame(maxWidth: .infinity)
                    }
                    .glassButton()
                    .controlSize(.large)
                }
                Button {
                    nav.openTool(.muhasaba)
                } label: {
                    Text("محاسبة النفس").font(.subheadline.weight(.bold)).frame(maxWidth: .infinity)
                }
                .glassButton()
                .controlSize(.large)
            }
            Button(role: .destructive) {
                TraitProgress.abandon(store)
            } label: {
                Text("إنهاء الرحلة دون إتمام").font(.footnote).frame(maxWidth: .infinity)
            }
            .buttonStyle(.plain)
            .foregroundStyle(.secondary)
            .padding(.vertical, 8)
        }
    }

    private func heroCard(_ t: Trait, day: Int, target: Int, done: Int, graduated: Bool) -> some View {
        let frac = min(1, Double(done) / Double(target))
        return HStack(spacing: 18) {
            ZStack {
                Circle().stroke(Color.white.opacity(0.18), lineWidth: 9)
                Circle()
                    .trim(from: 0, to: CGFloat(frac))
                    .stroke(Brand.gold, style: StrokeStyle(lineWidth: 9, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                Text(done.ar).font(.counter(28)).foregroundStyle(Brand.gold)
            }
            .frame(width: 96, height: 96)
            VStack(alignment: .leading, spacing: 6) {
                Text(graduated ? "أتممتَ الرحلة — هنيئاً" : "رحلتك الجارية")
                    .font(.caption.weight(.heavy))
                    .foregroundStyle(Brand.gold)
                Text("تخلية «\(t.vice)» وتحلية «\(t.virtue)»")
                    .font(.headline)
                    .lineLimit(2)
                Text("أتممتَ \(done.ar) من \(target.ar) يوماً — اليوم رقم \(day.ar)")
                    .font(.caption.weight(.bold))
                    .opacity(0.85)
            }
            Spacer(minLength: 0)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .hero()
    }

    private func todayCard(_ t: Trait) -> some View {
        let doneToday = TraitProgress.doneToday(store)
        return VStack(alignment: .leading, spacing: 8) {
            Text(t.commitment)
                .font(.body.weight(.bold))
                .lineSpacing(5)
                .fixedSize(horizontal: false, vertical: true)
            Text(t.hint).font(.caption).foregroundStyle(.secondary)
            if doneToday {
                Text("أتممتَ عمل اليوم ✓")
                    .font(.subheadline.weight(.heavy))
                    .foregroundStyle(Brand.emerald)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(Brand.emerald.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .padding(.top, 4)
            } else {
                Button {
                    TraitProgress.setToday(store, done: true)
                    Haptic.confirm()
                } label: {
                    Text("أتممتُ عمل اليوم").font(.headline).frame(maxWidth: .infinity)
                }
                .glassButton(prominent: true)
                .controlSize(.large)
                .padding(.top, 4)
            }
        }
        .card(20)
    }

    // MARK: Choosing a trait

    @ViewBuilder private var chooser: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("طريق التهذيب خطوتان: تخليةٌ من الرذيلة بالعمل بضدّها، ثم تحليةٌ بالفضيلة حتى تصير مَلَكة. اختر صفةً واحدة، والتزم عملها اليوميّ الصغير ٣٠ أو ٤٠ يوماً.")
                .font(.footnote)
                .lineSpacing(5)
                .fixedSize(horizontal: false, vertical: true)
            if Library.item("akhlaq", "ak-naraqi-manhaj") != nil {
                Button {
                    nav.openReader("akhlaq", "ak-naraqi-manhaj")
                } label: {
                    Text("اقرأ المنهج كاملاً").font(.caption.weight(.bold)).foregroundStyle(Brand.emerald)
                }
                .buttonStyle(.plain)
                .padding(.vertical, 6)
            }
        }
        .card(20)
        SectionTitle(text: "اختر صفةً تعالجها")
        ForEach(Library.shared.traits, id: \.id) { t in
            traitRow(t)
        }
        if let id = selected, let t = Library.shared.traits.first(where: { $0.id == id }) {
            SectionTitle(text: "مدّة الرحلة")
            Picker("مدّة الرحلة", selection: $chosenDays) {
                Text("٣٠ يوماً").tag(30)
                Text("٤٠ يوماً").tag(40)
            }
            .pickerStyle(.segmented)
            Button {
                TraitProgress.begin(store, id: t.id, days: chosenDays)
                selected = nil
                Haptic.confirm()
            } label: {
                Text("ابدأ رحلة «\(t.vice)»").font(.headline).frame(maxWidth: .infinity)
            }
            .glassButton(prominent: true)
            .controlSize(.large)
        }
    }

    private func traitRow(_ t: Trait) -> some View {
        let sel = selected == t.id
        return Button {
            withAnimation(.easeInOut(duration: 0.2)) { selected = sel ? nil : t.id }
        } label: {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 8) {
                    Image(systemName: sel ? "checkmark.circle.fill" : "circle")
                        .foregroundStyle(sel ? Brand.emerald : Color.secondary)
                    Text(t.vice).font(.headline).foregroundStyle(.primary).lineLimit(1)
                    Spacer(minLength: 8)
                    Text("ضدّها: \(t.virtue)").font(.caption.weight(.bold)).foregroundStyle(Brand.goldDeep).lineLimit(1)
                }
                if sel {
                    Text(t.commitment)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.leading)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .card(18, padding: 14)
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(sel ? Brand.emerald.opacity(0.5) : Color.clear, lineWidth: 1))
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    // MARK: Completed journeys

    @ViewBuilder private var historySection: some View {
        let hist = TraitProgress.history(store)
        if !hist.isEmpty {
            SectionTitle(text: "رحلات أتممتها")
            VStack(alignment: .leading, spacing: 6) {
                ForEach(Array(hist.enumerated()), id: \.offset) { pair in
                    Text(historyLine(pair.element))
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(Brand.emerald)
                }
            }
            .card(18, padding: 14)
        }
    }

    private func historyLine(_ h: String) -> String {
        let parts = h.split(separator: "|", omittingEmptySubsequences: false).map { String($0) }
        let first = parts.first ?? ""
        let name = Library.shared.traits.first(where: { $0.id == first })?.vice ?? first
        let days = parts.count > 1 ? (Int(parts[1])?.ar ?? parts[1]) : "?"
        return "✓ \(name) — \(days) يوماً"
    }
}
