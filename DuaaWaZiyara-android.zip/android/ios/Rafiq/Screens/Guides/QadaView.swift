import SwiftUI

// MARK: - Missed prayers and fasts (ported from Android ui/QadaScreen.kt + Settings qada keys)

/// Shared qada state (Android keys: qFajr... remaining, qdFajr... done, qadaHist daily completions).
enum QadaKeys {
    struct Prayer: Hashable { let key: String; let label: String }

    static let prayers: [Prayer] = [
        Prayer(key: "fajr", label: "صلاة الصبح"), Prayer(key: "dhuhr", label: "صلاة الظهر"),
        Prayer(key: "asr", label: "صلاة العصر"), Prayer(key: "maghrib", label: "صلاة المغرب"),
        Prayer(key: "isha", label: "صلاة العشاء")
    ]

    private static func cap(_ k: String) -> String { k.prefix(1).uppercased() + String(k.dropFirst()) }

    static func remaining(_ s: Store, _ k: String) -> Int { s.int("q" + cap(k), 0) }
    static func done(_ s: Store, _ k: String) -> Int { s.int("qd" + cap(k), 0) }
    static func setRemaining(_ s: Store, _ k: String, _ v: Int) { s.put("q" + cap(k), max(0, v)) }

    static func complete(_ s: Store, _ k: String) {
        let rem = remaining(s, k)
        if rem <= 0 { return }
        setRemaining(s, k, rem - 1)
        s.put("qd" + cap(k), done(s, k) + 1)
        s.setSeries("qadaHist", day: s.today, value: s.seriesValue("qadaHist", offset: 0) + 1, keepDays: 90)
    }

    static func totalRemaining(_ s: Store) -> Int {
        prayers.reduce(0) { $0 + remaining(s, $1.key) } + remaining(s, "fast")
    }

    static func completedLast(_ s: Store, window: Int) -> Int {
        let t = s.today
        return s.series("qadaHist").filter { $0.key > t - window }.reduce(0) { $0 + $1.value }
    }

    static func dailyRate(_ s: Store) -> Double { Double(completedLast(s, window: 30)) / 30.0 }
}

struct QadaView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(Store.self) private var store

    private var remSalat: Int { QadaKeys.prayers.reduce(0) { $0 + QadaKeys.remaining(store, $1.key) } }
    private var doneSalat: Int { QadaKeys.prayers.reduce(0) { $0 + QadaKeys.done(store, $1.key) } }
    private var remFast: Int { QadaKeys.remaining(store, "fast") }
    private var doneFast: Int { QadaKeys.done(store, "fast") }
    private var totalAll: Int { remSalat + doneSalat + remFast + doneFast }
    private var doneAll: Int { doneSalat + doneFast }

    var body: some View {
        ScreenScroll {
            ScreenHeader("تتبّع القضاء", subtitle: "ما فاتك من صلاةٍ وصيام، حتى تبرأ الذمّة") {
                RoundIconButton(symbol: "chevron.backward", label: "رجوع") { dismiss() }
            }
            MarjaNote()
            if totalAll == 0 { emptyHero } else { dashboard }
            if remSalat + remFast > 0 { paceCard }
            SectionTitle(text: "الصلوات")
            ForEach(QadaKeys.prayers, id: \.key) { p in
                QadaBarCard(label: p.label, key: p.key)
            }
            SectionTitle(text: "الصيام")
            QadaBarCard(label: "أيام الصيام", key: "fast")
            Text("استخدم ﹣ ＋ لضبط ما عليك من فوائت، واضغط «قضيت» كلّما أدّيت واحدة لتنتقل إلى المُنجَز. اجعل لك ورداً يومياً ولو صلاةً واحدة حتى تبرأ ذمّتك.")
                .font(.ui(.footnote))
                .foregroundStyle(Brand.emerald)
                .multilineTextAlignment(.center)
                .lineSpacing(4)
                .padding(14)
                .frame(maxWidth: .infinity)
                .background(Brand.emerald.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    private var emptyHero: some View {
        VStack(spacing: 8) {
            Image(systemName: "checkmark.seal.fill").font(.system(size: 34)).foregroundStyle(Brand.gold)
            Text("لا قضاء عليك").font(.ui(.title2, .heavy))
            Text("الحمد لله على العافية. وإن كان عليك فوائتُ صلاةٍ أو صيام، أضِفها من البطاقات أدناه لتتابع قضاءها بيُسر.")
                .font(.ui(.footnote))
                .opacity(0.88)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 26)
        .padding(.horizontal, 20)
        .frame(maxWidth: .infinity)
        .hero()
    }

    private var dashboard: some View {
        let frac = totalAll > 0 ? Double(doneAll) / Double(totalAll) : 0
        let pct = Int((frac * 100).rounded())
        return VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 18) {
                ZStack {
                    Circle().stroke(Color.white.opacity(0.18), lineWidth: 10)
                    Circle()
                        .trim(from: 0, to: CGFloat(frac))
                        .stroke(Brand.gold, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                    Text(verbatim: "\(pct.ar)٪").font(.counter(24)).foregroundStyle(Brand.gold)
                }
                .frame(width: 104, height: 104)
                VStack(alignment: .leading, spacing: 4) {
                    Text("لوحة القضاء").font(.ui(.subheadline, .bold)).opacity(0.85)
                    Text("مُنجَز من إجمالي القضاء").font(.ui(.footnote)).opacity(0.8)
                }
                Spacer(minLength: 0)
            }
            HStack(spacing: 10) {
                miniStat("مُنجَز", doneAll, color: Brand.gold)
                miniStat("متبقٍّ", remSalat + remFast, color: .white)
                miniStat("الإجمالي", totalAll, color: .white.opacity(0.7))
            }
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .hero()
    }

    private func miniStat(_ label: String, _ value: Int, color: Color) -> some View {
        VStack(spacing: 2) {
            Text(value.ar).font(.counter(22)).foregroundStyle(color)
            Text(label).font(.ui(.caption2, .bold)).opacity(0.75)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .glass(14)
    }

    private func etaText(_ daysLeft: Int) -> String {
        let months = daysLeft / 30
        let daysRem = daysLeft % 30
        if daysLeft <= 30 { return "خلال \(daysLeft.ar) يوماً تقريباً" }
        if months < 12 {
            let unit = months == 1 ? "شهر" : "أشهر"
            let extra = daysRem > 5 ? " و\(daysRem.ar) يوماً" : ""
            return "خلال \(months.ar) \(unit)\(extra) تقريباً"
        }
        let years = months / 12
        let yUnit = years == 1 ? "سنة" : "سنوات"
        return "خلال \(years.ar) \(yUnit) تقريباً"
    }

    private var paceCard: some View {
        let remTotal = remSalat + remFast
        let rate = QadaKeys.dailyRate(store)
        let last7 = QadaKeys.completedLast(store, window: 7)
        let last30 = QadaKeys.completedLast(store, window: 30)
        return VStack(alignment: .leading, spacing: 14) {
            Text("وتيرتك والإسقاط").font(.ui(.subheadline, .heavy))
            if rate > 0.01 {
                let daysLeft = Int((Double(remTotal) / rate).rounded(.up))
                paceRow(symbol: "star.fill", tint: Brand.emerald,
                        title: "تنتهي \(etaText(daysLeft))",
                        sub: "بمعدّلك الحاليّ: \(String(format: "%.1f", rate).arabicDigits) فريضة/يوم")
            } else {
                paceRow(symbol: "clock.fill", tint: Brand.gold,
                        title: "ابدأ القضاء لترى إسقاط الانتهاء",
                        sub: "كلّ فريضةٍ تُسجّلها تقرّبك من الهدف")
            }
            paceBars
            HStack {
                Text("هذا الأسبوع: \(last7.ar) فريضة").fontWeight(.bold)
                Spacer()
                Text("آخر ٣٠ يوماً: \(last30.ar)")
            }
            .font(.ui(.caption2))
            .foregroundStyle(.secondary)
        }
        .card(20, padding: 18)
    }

    private func paceRow(symbol: String, tint: Color, title: String, sub: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 19, weight: .semibold))
                .foregroundStyle(tint)
                .frame(width: 44, height: 44)
                .background(tint.opacity(0.13), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.ui(.subheadline, .bold)).fixedSize(horizontal: false, vertical: true)
                Text(sub).font(.ui(.caption)).foregroundStyle(.secondary)
            }
        }
    }

    /// Completions over the last 14 days, today at the leading edge.
    private var paceBars: some View {
        let values = (0..<14).map { store.seriesValue("qadaHist", offset: $0) }
        let maxDay = max(1, values.max() ?? 1)
        return HStack(alignment: .bottom, spacing: 3) {
            ForEach(0..<14, id: \.self) { idx in
                let v = values[idx]
                let frac = min(1, Double(v) / Double(maxDay))
                RoundedRectangle(cornerRadius: 3, style: .continuous)
                    .fill(v == 0 ? Color(.tertiarySystemFill) : Brand.emerald)
                    .frame(height: max(3, 50 * CGFloat(frac)))
                    .frame(maxWidth: .infinity)
            }
        }
        .frame(height: 50, alignment: .bottom)
    }
}

fileprivate struct QadaBarCard: View {
    let label: String
    let key: String
    @Environment(Store.self) private var store

    var body: some View {
        let rem = QadaKeys.remaining(store, key)
        let done = QadaKeys.done(store, key)
        let total = done + rem
        let frac = total > 0 ? Double(done) / Double(total) : 0
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(label).font(.ui(.headline))
                Spacer()
                Text(verbatim: "\(done.ar) / \(total.ar)").font(.ui(.caption, .bold)).foregroundStyle(.secondary)
            }
            ProgressView(value: frac)
                .tint(Brand.good)
            HStack(spacing: 10) {
                Button {
                    QadaKeys.complete(store, key)
                    Haptic.confirm()
                } label: {
                    Label("قضيت", systemImage: "checkmark")
                        .font(.ui(.subheadline, .heavy))
                        .frame(maxWidth: .infinity)
                }
                .glassButton(prominent: true)
                .disabled(rem <= 0)
                stepButton("minus", label: "إنقاص") { QadaKeys.setRemaining(store, key, rem - 1) }
                Text(rem.ar)
                    .font(.counter(20))
                    .foregroundStyle(Brand.emerald)
                    .frame(minWidth: 40)
                stepButton("plus", label: "زيادة") { QadaKeys.setRemaining(store, key, rem + 1) }
            }
        }
        .card(16, padding: 14)
    }

    private func stepButton(_ symbol: String, label: String, action: @escaping () -> Void) -> some View {
        Button {
            action()
            Haptic.tick()
        } label: {
            Image(systemName: symbol)
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(Brand.emerald)
                .frame(width: 36, height: 36)
                .contentShape(Circle())
        }
        .buttonStyle(.plain)
        .glassCircle(tint: Brand.emerald, interactive: true)
        .accessibilityLabel(label)
    }
}
