import SwiftUI

// MARK: - Night prayer step-by-step guide (ported from Android ui/LaylGuideScreen.kt)

fileprivate enum LaylPose { case info, stand, bow, prostrate, sit, done }

fileprivate enum LaylSurah {
    static let ikhlas = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ هُوَ اللَّهُ أَحَدٌ ﴿١﴾ اللَّهُ الصَّمَدُ ﴿٢﴾ لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ ﴿٤﴾"
    static let kafirun = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ يَا أَيُّهَا الْكَافِرُونَ ﴿١﴾ لَا أَعْبُدُ مَا تَعْبُدُونَ ﴿٢﴾ وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ ﴿٣﴾ وَلَا أَنَا عَابِدٌ مَّا عَبَدتُّمْ ﴿٤﴾ وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ ﴿٥﴾ لَكُمْ دِينُكُمْ وَلِيَ دِينِ ﴿٦﴾"
    static let falaq = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ﴿١﴾ مِن شَرِّ مَا خَلَقَ ﴿٢﴾ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ﴿٣﴾ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ﴿٤﴾ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ ﴿٥﴾"
    static let nas = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ أَعُوذُ بِرَبِّ النَّاسِ ﴿١﴾ مَلِكِ النَّاسِ ﴿٢﴾ إِلَٰهِ النَّاسِ ﴿٣﴾ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ﴿٤﴾ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ﴿٥﴾ مِنَ الْجِنَّةِ وَالنَّاسِ ﴿٦﴾"
}

fileprivate struct LaylSurahRef { let name: String; let text: String }

fileprivate struct LaylStep {
    let pose: LaylPose
    let phase: String
    let title: String
    let how: String
    var say: String? = nil
    var sayNote: String? = nil
    var counter: Int? = nil
    var counterLabel: String? = nil
    var surahs: [LaylSurahRef] = []
}

fileprivate let laylSteps: [LaylStep] = [
    LaylStep(pose: .info, phase: "تمهيد", title: "ما هي صلاة الليل؟",
             how: "صلاة الليل إحدى عشرة ركعة، وقتها من منتصف الليل إلى أذان الفجر، وأفضله السحر (قبيل الفجر). تنقسم إلى:\n\n• ٨ ركعات «نافلة الليل» — تُصلّى ركعتين ركعتين (أربع صلوات).\n• ركعتان تُسمّيان «الشفع».\n• ركعة واحدة تُسمّى «الوتر».\n\nكلها تُصلّى كصلاة الصبح في الكيفية. سنمشي معك خطوة بخطوة من البداية."),

    LaylStep(pose: .stand, phase: "نافلة الليل · الصلاة ١", title: "النيّة",
             how: "قف مستقبلاً القبلة، واخطر بقلبك أنك تصلّي ركعتين من نافلة الليل قربةً إلى الله. لا يلزم التلفّظ، لكن يجوز أن تقول بقلبك أو لسانك:",
             say: "أُصَلّي رَكعَتَينِ مِن نافِلَةِ اللَّيلِ قُربَةً إلى اللهِ تَعالى."),
    LaylStep(pose: .stand, phase: "نافلة الليل · الصلاة ١", title: "تكبيرة الإحرام",
             how: "ارفع يديك إلى حذاء أُذنيك، ثم قل وأنت قائم:",
             say: "اللَّهُ أَكْبَر",
             sayNote: "بهذه التكبيرة تدخل في الصلاة، فلا تلتفت ولا تتكلّم بغير الصلاة بعدها."),
    LaylStep(pose: .stand, phase: "نافلة الليل · الصلاة ١", title: "قراءة الفاتحة",
             how: "وأنت قائم، اقرأ سورة الفاتحة:",
             say: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ﴿١﴾ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ﴿٢﴾ الرَّحْمَٰنِ الرَّحِيمِ ﴿٣﴾ مَالِكِ يَوْمِ الدِّينِ ﴿٤﴾ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ﴿٥﴾ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ﴿٦﴾ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ ﴿٧﴾"),
    LaylStep(pose: .stand, phase: "نافلة الليل · الصلاة ١", title: "قراءة سورة بعد الفاتحة",
             how: "ثم اقرأ سورةً قصيرة. يُستحب «قل هو الله أحد». وإن ضاق وقتك يجوز الاقتصار على الفاتحة وحدها.",
             say: "قُلْ هُوَ اللَّهُ أَحَدٌ ﴿١﴾ اللَّهُ الصَّمَدُ ﴿٢﴾ لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ ﴿٤﴾"),
    LaylStep(pose: .bow, phase: "نافلة الليل · الصلاة ١", title: "الركوع",
             how: "كبِّر (اللَّهُ أَكْبَر)، ثم انحنِ راكعاً وضع يديك على ركبتيك، وقل ثلاثاً (أو مرة):",
             say: "سُبْحَانَ رَبِّيَ الْعَظِيمِ وَبِحَمْدِهِ",
             sayNote: "ثم ارفع رأسك من الركوع قائماً وقل: سَمِعَ اللَّهُ لِمَنْ حَمِدَه.",
             counter: 3, counterLabel: "سُبْحَانَ رَبِّيَ الْعَظِيمِ وَبِحَمْدِهِ"),
    LaylStep(pose: .prostrate, phase: "نافلة الليل · الصلاة ١", title: "السجدة الأولى",
             how: "كبِّر، ثم اسجد على الأرض (الجبهة واليدان والركبتان وأطراف القدمين)، وقل ثلاثاً (أو مرة):",
             say: "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ",
             counter: 3, counterLabel: "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ"),
    LaylStep(pose: .sit, phase: "نافلة الليل · الصلاة ١", title: "الجلوس بين السجدتين",
             how: "ارفع رأسك من السجود واجلس مطمئناً، وقل:",
             say: "أَسْتَغْفِرُ اللَّهَ رَبِّي وَأَتُوبُ إِلَيْهِ"),
    LaylStep(pose: .prostrate, phase: "نافلة الليل · الصلاة ١", title: "السجدة الثانية",
             how: "كبِّر واسجد ثانيةً، وقل ثلاثاً (أو مرة):",
             say: "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ",
             sayNote: "بهذا تمّت الركعة الأولى. قُم للركعة الثانية.",
             counter: 3, counterLabel: "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ"),
    LaylStep(pose: .stand, phase: "نافلة الليل · الصلاة ١", title: "الركعة الثانية",
             how: "قُم للركعة الثانية، واقرأ الفاتحة ثم سورة (يُستحب «قل يا أيها الكافرون»)، ثم اركع واسجد سجدتين كما فعلت تماماً في الركعة الأولى.",
             sayNote: "بعد السجدة الثانية من الركعة الثانية، اجلس للتشهّد.",
             surahs: [LaylSurahRef(name: "سورة الكافرون", text: LaylSurah.kafirun)]),
    LaylStep(pose: .sit, phase: "نافلة الليل · الصلاة ١", title: "التشهّد",
             how: "اجلس بعد السجدتين وقل:",
             say: "أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ. اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَآلِ مُحَمَّد"),
    LaylStep(pose: .sit, phase: "نافلة الليل · الصلاة ١", title: "التسليم",
             how: "ثم سلِّم لإنهاء الصلاة، وتقول:",
             say: "السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُه",
             sayNote: "بهذا تمّت أوّل صلاتين (ركعتان). تبقّى ٦ ركعات من نافلة الليل بنفس الكيفية."),

    LaylStep(pose: .info, phase: "نافلة الليل · الصلوات ٢–٤", title: "أكمل بقية النافلة",
             how: "كرّر نفس ما فعلتَه ثلاث مرّات أخرى — أي ٦ ركعات (كل ركعتين بتسليم مستقل) — حتى تُتمّ ثماني ركعات نافلة الليل.\n\nفي كل ركعة: نيّة، تكبيرة، فاتحة، سورة، ركوع، سجدتان، ثم التشهّد والتسليم في الركعة الثانية. يجوز الاقتصار على الفاتحة عند ضيق الوقت."),

    LaylStep(pose: .stand, phase: "صلاة الشفع", title: "نيّة الشفع",
             how: "بعد إتمام الثماني، قف لصلاة الشفع (ركعتان). انوِ:",
             say: "أُصَلّي رَكعَتَيِ الشَّفعِ قُربَةً إلى اللهِ تَعالى."),
    LaylStep(pose: .stand, phase: "صلاة الشفع", title: "قراءة الشفع",
             how: "كبّر تكبيرة الإحرام، ثم في الركعة الأولى اقرأ الفاتحة و«قل أعوذ برب الناس»، وفي الثانية الفاتحة و«قل أعوذ برب الفلق». بلا قنوت. ثم أكمل الركوع والسجود والتشهّد والتسليم كالمعتاد.",
             sayNote: "بعد التسليم، قُم لركعة الوتر.",
             surahs: [LaylSurahRef(name: "سورة الناس (الركعة الأولى)", text: LaylSurah.nas),
                      LaylSurahRef(name: "سورة الفلق (الركعة الثانية)", text: LaylSurah.falaq)]),

    LaylStep(pose: .stand, phase: "صلاة الوتر", title: "نيّة الوتر",
             how: "قُم لركعة الوتر (ركعة واحدة). انوِ:",
             say: "أُصَلّي رَكعَةَ الوَترِ قُربَةً إلى اللهِ تَعالى."),
    LaylStep(pose: .stand, phase: "صلاة الوتر", title: "قراءة الوتر",
             how: "كبّر، ثم اقرأ الفاتحة، ثم «قل هو الله أحد» ثلاث مرّات (ويُستحب معها الفلق والناس مرّة).",
             say: "قُلْ هُوَ اللَّهُ أَحَدٌ... (ثلاث مرّات)",
             counter: 3, counterLabel: "سورة الإخلاص",
             surahs: [LaylSurahRef(name: "سورة الإخلاص", text: LaylSurah.ikhlas),
                      LaylSurahRef(name: "سورة الفلق", text: LaylSurah.falaq),
                      LaylSurahRef(name: "سورة الناس", text: LaylSurah.nas)]),
    LaylStep(pose: .stand, phase: "صلاة الوتر", title: "القنوت",
             how: "قبل الركوع، ارفع يديك للقنوت. القنوت مستحب. أبسط صورة أن تستغفر وتدعو:",
             say: "أَسْتَغْفِرُ اللَّهَ رَبِّي وَأَتُوبُ إِلَيْه (سبعين مرّة إن استطعت)\nرَبِّ اغْفِرْ لِي وَارْحَمْنِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيم",
             sayNote: "يُستحب أيضاً قول «العَفوَ» ٣٠٠ مرّة، والاستغفار لأربعين مؤمناً. ومن لم يحفظ يكفيه الاستغفار والدعاء بما تيسّر.",
             counter: 300, counterLabel: "العَفوَ"),
    LaylStep(pose: .bow, phase: "صلاة الوتر", title: "الركوع",
             how: "بعد القنوت، كبّر واركع وقل ثلاثاً (أو مرة):",
             say: "سُبْحَانَ رَبِّيَ الْعَظِيمِ وَبِحَمْدِهِ"),
    LaylStep(pose: .prostrate, phase: "صلاة الوتر", title: "السجدتان",
             how: "اسجد سجدتين (بينهما جلوس واستغفار) كما تعلّمت، قائلاً في كل سجدة:",
             say: "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ"),
    LaylStep(pose: .sit, phase: "صلاة الوتر", title: "التشهّد والتسليم",
             how: "اجلس بعد السجدتين، تشهّد ثم سلِّم:",
             say: "أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ... اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَآلِ مُحَمَّد\nالسَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُه"),
    LaylStep(pose: .done, phase: "تمّت", title: "تقبّل الله صلاتك",
             how: "بهذا أتممتَ صلاة الليل كاملةً (١١ ركعة). إن كان الوقت ضيّقاً في ليلةٍ ما، يجوز الاقتصار على الشفع والوتر، بل على الوتر وحدها.\n\nواظِب عليها ولو ركعةً واحدة، فثوابها عظيم وأثرها في القلب كبير.")
]

fileprivate func laylPoseLabel(_ p: LaylPose) -> String {
    switch p {
    case .stand: return "قيام"
    case .bow: return "ركوع"
    case .prostrate: return "سجود"
    case .sit: return "جلوس"
    case .done: return "تمّ"
    case .info: return "تمهيد"
    }
}

fileprivate func laylPoseSymbol(_ p: LaylPose) -> String {
    switch p {
    case .stand: return "figure.stand"
    case .bow: return "figure.cooldown"
    case .prostrate: return "drop.fill"
    case .sit: return "circle.dotted.circle"
    case .done: return "star.fill"
    case .info: return "scroll.fill"
    }
}

struct LaylView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.dismiss) private var dismiss
    @State private var i = 0
    @State private var count = 0
    @State private var qunut: [Int] = [0, 0, 0]

    private var scale: CGFloat { CGFloat(store.fontSize / 21.0) }
    private var isLast: Bool { i >= laylSteps.count - 1 }
    private var step: LaylStep { laylSteps[max(0, min(laylSteps.count - 1, i))] }

    /// Which of the eleven rak'ahs the step belongs to (1…11), from its phase.
    private var rakah: Int {
        let ph = step.phase
        if ph.contains("الوتر") { return 11 }
        if ph.contains("الشفع") { return step.title.contains("قراءة") ? 10 : 9 }
        if ph.contains("٢–٤") { return 5 }
        if ph.contains("الصلاة ١") { return step.title == "الركعة الثانية" || step.title == "التشهّد" || step.title == "التسليم" ? 2 : 1 }
        if step.pose == .done { return 11 }
        return 0
    }

    private var fajrLeft: String {
        let now = Date()
        let t = store.times(for: now)
        var dt = PrayerTimes.norm(t.fajr) - PrayerTimes.nowHours(now)
        if dt < 0 { dt += 24 }
        let h = Int(dt), m = Int((dt - Double(h)) * 60)
        return "بقي على الفجر \(h.ar):\(m < 10 ? "٠" : "")\(m.ar)"
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                hero
                stepCard
                    .contentShape(Rectangle())
                    .onTapGesture { if step.counter == nil { advance() } }
                if step.phase.contains("الوتر") && step.title == "القنوت" { qunutCounters }
                if let it = Library.item("ramadan", "r-qunut-layl"), step.phase.contains("الوتر") || step.pose == .done {
                    Button { nav.openReader("ramadan", it.id) } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "headphones").font(.system(size: 18, weight: .semibold)).foregroundStyle(Brand.goldSoft)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(it.title).font(.ui(.subheadline, .bold)).foregroundStyle(.white)
                                Text("نصّ وصوت · الشاشة تبقى مضاءة").font(.ui(.caption)).foregroundStyle(.white.opacity(0.7))
                            }
                            Spacer()
                            Image(systemName: "chevron.backward").font(.caption.weight(.bold)).foregroundStyle(.white.opacity(0.7))
                        }
                        .padding(14)
                        .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
                Text("انقر على البطاقة للانتقال إلى الخطوة التالية")
                    .font(.ui(.caption)).foregroundStyle(.white.opacity(0.55))
                    .frame(maxWidth: .infinity)
            }
            .padding(.horizontal, 16).padding(.top, 6).padding(.bottom, 24)
            .readableWidth()
        }
        .scrollBounceBehavior(.basedOnSize)
        .safeAreaInset(edge: .top, spacing: 0) { topBar }
        .safeAreaInset(edge: .bottom, spacing: 0) { navBar }
        .tealScreen()
        .toolbar(.hidden, for: .navigationBar)
        .toolbar(.hidden, for: .tabBar)
        .keepScreenAwake(true)
        .animation(.easeInOut(duration: 0.2), value: i)
        .onChange(of: i) { _, _ in count = 0; qunut = [0, 0, 0] }
    }

    private func advance() {
        Haptic.tick()
        if isLast { dismiss() } else { i += 1 }
    }

    // MARK: Top bar

    private var topBar: some View {
        HStack {
            RoundIconButton(symbol: "chevron.backward", label: "رجوع", translucent: true) { dismiss() }
            Spacer()
            Text(fajrLeft).font(.ui(.caption, .semibold)).foregroundStyle(.white)
                .padding(.horizontal, 14).frame(height: 36)
                .background(Color.white.opacity(0.12), in: Capsule())
            Spacer()
            Menu {
                Button { store.fontSize = min(40, store.fontSize + 2) } label: { Label("تكبير الخط", systemImage: "textformat.size.larger") }
                Button { store.fontSize = max(15, store.fontSize - 2) } label: { Label("تصغير الخط", systemImage: "textformat.size.smaller") }
            } label: {
                Image(systemName: "textformat.size").font(.system(size: 16, weight: .semibold)).foregroundStyle(.white)
                    .frame(width: 42, height: 42).background(Color.white.opacity(0.14), in: Circle())
            }
            .accessibilityLabel("حجم الخط")
        }
        .padding(.horizontal, 16).padding(.vertical, 8)
    }

    // MARK: Hero: moon, title, rak'ah dashes

    private var hero: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("الثلث الأخير من الليل · ١١ ركعة").font(.ui(.caption)).foregroundStyle(.white.opacity(0.75))
                    Text("صلاة الليل").font(.display(32)).foregroundStyle(.white)
                }
                Spacer()
                CrescentMoon(size: 56)
            }
            HStack(spacing: 4) {
                ForEach(1...11, id: \.self) { r in
                    Capsule()
                        .fill(r < rakah ? Brand.goldSoft : (r == rakah ? Brand.mint : Color.white.opacity(0.18)))
                        .frame(height: 8)
                }
            }
            HStack {
                Text("الوتر · ١").font(.ui(.caption2)).foregroundStyle(.white.opacity(0.6))
                Spacer()
                Text("الشفع · ٢").font(.ui(.caption2)).foregroundStyle(.white.opacity(0.6))
                Spacer()
                Text("نافلة الليل · ٨ ركعات (٤ × ٢)").font(.ui(.caption2)).foregroundStyle(.white.opacity(0.6))
            }
            .environment(\.layoutDirection, .leftToRight)
        }
        .padding(.top, 4)
    }

    // MARK: Step card

    private var stepCard: some View {
        let s = step
        return VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(rakah > 0 ? "الآن · الركعة \(rakah.ar) من ١١ · \(s.phase)" : s.phase).font(.ui(.caption)).foregroundStyle(Brand.mint).lineLimit(1).minimumScaleFactor(0.8)
                    Text(s.title).font(.display(26 * scale)).foregroundStyle(.white).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 8)
                ZStack {
                    Circle().stroke(Brand.mint, lineWidth: 2)
                    Text(verbatim: "\((i + 1).ar)").font(.display(18)).foregroundStyle(.white)
                }
                .frame(width: 56, height: 56)
            }
            Text(s.how)
                .font(.ui(size: 16 * scale))
                .lineSpacing(7 * scale)
                .foregroundStyle(.white.opacity(0.9))
                .fixedSize(horizontal: false, vertical: true)
            if let say = s.say { sayCard(say) }
            ForEach(Array(s.surahs.enumerated()), id: \.offset) { pair in surahCard(pair.element) }
            if let target = s.counter, !(s.phase.contains("الوتر") && s.title == "القنوت") {
                counterCard(target: target, label: s.counterLabel)
            }
            HStack(spacing: 8) {
                if s.pose != .info && s.pose != .done {
                    chip(laylPoseLabel(s.pose), symbol: laylPoseSymbol(s.pose))
                }
                if let note = s.sayNote, note.count < 40 { chip(note, symbol: nil) }
                chip("المصدر: منهاج الصالحين", symbol: nil)
            }
            if let note = s.sayNote, note.count >= 40 {
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "sparkle").foregroundStyle(Brand.goldSoft)
                    Text(note).font(.ui(size: 14 * scale)).lineSpacing(5 * scale).foregroundStyle(.white.opacity(0.8)).fixedSize(horizontal: false, vertical: true)
                }
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Color.white.opacity(0.1), lineWidth: 1))
    }

    private func chip(_ text: String, symbol: String?) -> some View {
        HStack(spacing: 5) {
            if let symbol { Image(systemName: symbol).font(.caption2) }
            Text(text).font(.ui(.caption2, .semibold)).lineLimit(1).minimumScaleFactor(0.8)
        }
        .foregroundStyle(.white.opacity(0.9))
        .padding(.horizontal, 10).padding(.vertical, 6)
        .background(Color.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }

    private func sayCard(_ say: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("تقول:").font(.ui(.caption, .bold)).foregroundStyle(Brand.goldSoft)
            Text(say)
                .font(.scripture(24 * scale))
                .lineSpacing(12 * scale)
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.black.opacity(0.18), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func surahCard(_ ref: LaylSurahRef) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Label(ref.name, systemImage: "book.fill").font(.ui(.caption, .bold)).foregroundStyle(Brand.goldSoft)
            Text(ref.text)
                .font(.scripture(21 * scale))
                .lineSpacing(10 * scale)
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Brand.goldSoft.opacity(0.1), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func counterCard(target: Int, label: String?) -> some View {
        let full = count >= target
        return VStack(spacing: 10) {
            if let label {
                Text(label).font(.scripture(17 * scale)).foregroundStyle(.white).multilineTextAlignment(.center).frame(maxWidth: .infinity)
            }
            Button {
                if count < target {
                    count += 1
                    if count == target { Haptic.confirm() } else { Haptic.tick() }
                }
            } label: {
                VStack(spacing: 2) {
                    Text(verbatim: full ? "تمّ ✓" : "\(count.ar) / \(target.ar)")
                        .font(.display(30)).foregroundStyle(full ? Brand.mint : Brand.goldSoft)
                        .minimumScaleFactor(0.5).lineLimit(1)
                    Text(full ? "اكتمل العدد" : "انقر لكلّ مرّة").font(.ui(.caption)).foregroundStyle(.white.opacity(0.7))
                }
                .frame(width: 150, height: 150)
                .background(Color.white.opacity(0.1), in: Circle())
                .overlay(Circle().stroke(full ? Brand.mint : Brand.goldSoft.opacity(0.6), lineWidth: 2))
                .contentShape(Circle())
            }
            .buttonStyle(.plain)
            if count > 0 && !full {
                Button { count = 0 } label: { Text("إعادة").font(.ui(.caption, .bold)).foregroundStyle(.white.opacity(0.8)) }
                    .buttonStyle(.plain)
            }
        }
        .frame(maxWidth: .infinity)
    }

    /// Witr qunut: the three recommended counts, each a tap counter.
    private var qunutCounters: some View {
        let items: [(Int, String)] = [(70, "أستغفر الله ربّي وأتوب إليه"), (300, "العفو"), (40, "الدعاء لأربعين مؤمناً")]
        return VStack(alignment: .leading, spacing: 10) {
            Text("قنوت الوتر · عدّادات جاهزة").font(.ui(.caption)).foregroundStyle(.white.opacity(0.75))
            HStack(spacing: 10) {
                ForEach(Array(items.enumerated()), id: \.offset) { k, it in
                    let full = qunut[k] >= it.0
                    Button {
                        if qunut[k] < it.0 { qunut[k] += 1; if qunut[k] == it.0 { Haptic.confirm() } else { Haptic.tick() } }
                    } label: {
                        VStack(spacing: 6) {
                            Text(verbatim: full ? "✓" : (qunut[k] == 0 ? it.0.ar : "\(qunut[k].ar)/\(it.0.ar)"))
                                .font(.display(22)).foregroundStyle(full ? Brand.mint : Brand.goldSoft).lineLimit(1).minimumScaleFactor(0.6)
                            Text(it.1).font(.ui(.caption2, .semibold)).foregroundStyle(.white).multilineTextAlignment(.center).lineLimit(2).minimumScaleFactor(0.8)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 96)
                        .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    }
                    .buttonStyle(.plain)
                    .accessibilityValue("\(qunut[k].ar) من \(it.0.ar)")
                }
            }
        }
    }

    // MARK: Bottom

    private var navBar: some View {
        let nextTitle = laylSteps.indices.contains(i + 1) ? laylSteps[i + 1].title : nil
        return HStack(spacing: 10) {
            Button { if i > 0 { i -= 1; Haptic.tick() } } label: {
                Text("السابقة").font(.ui(.subheadline, .semibold)).foregroundStyle(.white)
                    .frame(maxWidth: .infinity).frame(height: 54)
                    .background(Color.white.opacity(0.12), in: Capsule())
                    .overlay(Capsule().stroke(Color.white.opacity(0.3), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .disabled(i == 0).opacity(i == 0 ? 0.5 : 1)
            Button { advance() } label: {
                Text(nextTitle.map { "أتممتها · التالية: \($0)" } ?? "تمّ · إغلاق")
                    .font(.ui(.subheadline, .bold)).foregroundStyle(Color(hex: 0x10322D))
                    .lineLimit(1).minimumScaleFactor(0.75)
                    .padding(.horizontal, 12)
                    .frame(maxWidth: .infinity).frame(height: 54)
                    .background(Brand.goldSoft, in: Capsule())
            }
            .buttonStyle(.plain)
            .layoutPriority(1)
        }
        .padding(.horizontal, 16).padding(.vertical, 10)
    }
}
