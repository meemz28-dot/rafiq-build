import SwiftUI

// MARK: - Night prayer step-by-step guide (ported from Android ui/LaylGuideScreen.kt)

fileprivate enum LaylPose { case info, stand, bow, prostrate, sit, done }

fileprivate enum LaylSurah {
    static let ikhlas = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ هُوَ اللَّهُ أَحَدٌ ﴿١﴾ اللَّهُ الصَّمَدُ ﴿٢﴾ لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ ﴿٤﴾"
    static let kafirun = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ يَا أَيُّهَا الْكَافِرُونَ ﴿١﴾ لَا أَعْبُدُ مَا تَعْبُدُونَ ﴿٢﴾ وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ ﴿٣﴾ وَلَا أَنَا عَابِدٌ مَّا عَبَدتُّمْ ﴿٤﴾ وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ ﴿٥﴾ لَكُمْ دِينُكُمْ وَلِيَ دِينِ ﴿٦﴾"
    static let falaq = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ﴿١﴾ مِن شَرِّ مَا خَلَقَ ﴿٢﴾ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ﴿٣﴾ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ﴿٤﴾ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ ﴿٥﴾"
    static let nas = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ أَعُوذُ بِرَبِّ النَّاسِ ﴿١﴾ مَلِكِ النَّاسِ ﴿٢﴾ إِلَٰهِ النَّاسِ ﴿٣﴾ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ﴿٤﴾ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ﴿٥﴾ مِنَ الْجِنَّةِ وَالنَّاسِ ﴿٦﴾"
}

fileprivate struct LaylSurahRef { let name: String; let text: String }

fileprivate struct LaylStep {
    let pose: LaylPose
    let phase: String
    let title: String
    let how: String
    var say: String? = nil
    var sayNote: String? = nil
    var counter: Int? = nil
    var counterLabel: String? = nil
    var surahs: [LaylSurahRef] = []
}

fileprivate let laylSteps: [LaylStep] = [
    LaylStep(pose: .info, phase: "تمهيد", title: "ما هي صلاة الليل؟",
             how: "صلاة الليل إحدى عشرة ركعة، وقتها من منتصف الليل إلى أذان الفجر، وأفضله السحر (قبيل الفجر). تنقسم إلى:\n\n• ٨ ركعات «نافلة الليل» — تُصلّى ركعتين ركعتين (أربع صلوات).\n• ركعتان تُسمّيان «الشفع».\n• ركعة واحدة تُسمّى «الوتر».\n\nكلها تُصلّى كصلاة الصبح في الكيفية. سنمشي معك خطوة بخطوة من البداية."),

    LaylStep(pose: .stand, phase: "نافلة الليل · الصلاة ١", title: "النيّة",
             how: "قف مستقبلاً القبلة، واخطر بقلبك أنك تصلّي ركعتين من نافلة الليل قربةً إلى الله. لا يلزم التلفّظ، لكن يجوز أن تقول بقلبك أو لسانك:",
             say: "أُصَلّي رَكعَتَينِ مِن نافِلَةِ اللَّيلِ قُربَةً إلى اللهِ تَعالى."),
    LaylStep(pose: .stand, phase: "نافلة الليل · الصلاة ١", title: "تكبيرة الإحرام",
             how: "ارفع يديك إلى حذاء أُذنيك، ثم قل وأنت قائم:",
             say: "اللَّهُ أَكْبَر",
             sayNote: "بهذه التكبيرة تدخل في الصلاة، فلا تلتفت ولا تتكلّم بغير الصلاة بعدها."),
    LaylStep(pose: .stand, phase: "نافلة الليل · الصلاة ١", title: "قراءة الفاتحة",
             how: "وأنت قائم، اقرأ سورة الفاتحة:",
             say: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ﴿١﴾ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ﴿٢﴾ الرَّحْمَٰنِ الرَّحِيمِ ﴿٣﴾ مَالِكِ يَوْمِ الدِّينِ ﴿٤﴾ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ﴿٥﴾ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ﴿٦﴾ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ ﴿٧﴾"),
    LaylStep(pose: .stand, phase: "نافلة الليل · الصلاة ١", title: "قراءة سورة بعد الفاتحة",
             how: "ثم اقرأ سورةً قصيرة. يُستحب «قل هو الله أحد». وإن ضاق وقتك يجوز الاقتصار على الفاتحة وحدها.",
             say: "قُلْ هُوَ اللَّهُ أَحَدٌ ﴿١﴾ اللَّهُ الصَّمَدُ ﴿٢﴾ لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ ﴿٤﴾"),
    LaylStep(pose: .bow, phase: "نافلة الليل · الصلاة ١", title: "الركوع",
             how: "كبِّر (اللَّهُ أَكْبَر)، ثم انحنِ راكعاً وضع يديك على ركبتيك، وقل ثلاثاً (أو مرة):",
             say: "سُبْحَانَ رَبِّيَ الْعَظِيمِ وَبِحَمْدِهِ",
             sayNote: "ثم ارفع رأسك من الركوع قائماً وقل: سَمِعَ اللَّهُ لِمَنْ حَمِدَه.",
             counter: 3, counterLabel: "سُبْحَانَ رَبِّيَ الْعَظِيمِ وَبِحَمْدِهِ"),
    LaylStep(pose: .prostrate, phase: "نافلة الليل · الصلاة ١", title: "السجدة الأولى",
             how: "كبِّر، ثم اسجد على الأرض (الجبهة واليدان والركبتان وأطراف القدمين)، وقل ثلاثاً (أو مرة):",
             say: "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ",
             counter: 3, counterLabel: "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ"),
    LaylStep(pose: .sit, phase: "نافلة الليل · الصلاة ١", title: "الجلوس بين السجدتين",
             how: "ارفع رأسك من السجود واجلس مطمئناً، وقل:",
             say: "أَسْتَغْفِرُ اللَّهَ رَبِّي وَأَتُوبُ إِلَيْهِ"),
    LaylStep(pose: .prostrate, phase: "نافلة الليل · الصلاة ١", title: "السجدة الثانية",
             how: "كبِّر واسجد ثانيةً، وقل ثلاثاً (أو مرة):",
             say: "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ",
             sayNote: "بهذا تمّت الركعة الأولى. قُم للركعة الثانية.",
             counter: 3, counterLabel: "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ"),
    LaylStep(pose: .stand, phase: "نافلة الليل · الصلاة ١", title: "الركعة الثانية",
             how: "قُم للركعة الثانية، واقرأ الفاتحة ثم سورة (يُستحب «قل يا أيها الكافرون»)، ثم اركع واسجد سجدتين كما فعلت تماماً في الركعة الأولى.",
             sayNote: "بعد السجدة الثانية من الركعة الثانية، اجلس للتشهّد.",
             surahs: [LaylSurahRef(name: "سورة الكافرون", text: LaylSurah.kafirun)]),
    LaylStep(pose: .sit, phase: "نافلة الليل · الصلاة ١", title: "التشهّد",
             how: "اجلس بعد السجدتين وقل:",
             say: "أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ. اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَآلِ مُحَمَّد"),
    LaylStep(pose: .sit, phase: "نافلة الليل · الصلاة ١", title: "التسليم",
             how: "ثم سلِّم لإنهاء الصلاة، وتقول:",
             say: "السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُه",
             sayNote: "بهذا تمّت أوّل صلاتين (ركعتان). تبقّى ٦ ركعات من نافلة الليل بنفس الكيفية."),

    LaylStep(pose: .info, phase: "نافلة الليل · الصلوات ٢–٤", title: "أكمل بقية النافلة",
             how: "كرّر نفس ما فعلتَه ثلاث مرّات أخرى — أي ٦ ركعات (كل ركعتين بتسليم مستقل) — حتى تُتمّ ثماني ركعات نافلة الليل.\n\nفي كل ركعة: نيّة، تكبيرة، فاتحة، سورة، ركوع، سجدتان، ثم التشهّد والتسليم في الركعة الثانية. يجوز الاقتصار على الفاتحة عند ضيق الوقت."),

    LaylStep(pose: .stand, phase: "صلاة الشفع", title: "نيّة الشفع",
             how: "بعد إتمام الثماني، قف لصلاة الشفع (ركعتان). انوِ:",
             say: "أُصَلّي رَكعَتَيِ الشَّفعِ قُربَةً إلى اللهِ تَعالى."),
    LaylStep(pose: .stand, phase: "صلاة الشفع", title: "قراءة الشفع",
             how: "كبّر تكبيرة الإحرام، ثم في الركعة الأولى اقرأ الفاتحة و«قل أعوذ برب الناس»، وفي الثانية الفاتحة و«قل أعوذ برب الفلق». بلا قنوت. ثم أكمل الركوع والسجود والتشهّد والتسليم كالمعتاد.",
             sayNote: "بعد التسليم، قُم لركعة الوتر.",
             surahs: [LaylSurahRef(name: "سورة الناس (الركعة الأولى)", text: LaylSurah.nas),
                      LaylSurahRef(name: "سورة الفلق (الركعة الثانية)", text: LaylSurah.falaq)]),

    LaylStep(pose: .stand, phase: "صلاة الوتر", title: "نيّة الوتر",
             how: "قُم لركعة الوتر (ركعة واحدة). انوِ:",
             say: "أُصَلّي رَكعَةَ الوَترِ قُربَةً إلى اللهِ تَعالى."),
    LaylStep(pose: .stand, phase: "صلاة الوتر", title: "قراءة الوتر",
             how: "كبّر، ثم اقرأ الفاتحة، ثم «قل هو الله أحد» ثلاث مرّات (ويُستحب معها الفلق والناس مرّة).",
             say: "قُلْ هُوَ اللَّهُ أَحَدٌ... (ثلاث مرّات)",
             counter: 3, counterLabel: "سورة الإخلاص",
             surahs: [LaylSurahRef(name: "سورة الإخلاص", text: LaylSurah.ikhlas),
                      LaylSurahRef(name: "سورة الفلق", text: LaylSurah.falaq),
                      LaylSurahRef(name: "سورة الناس", text: LaylSurah.nas)]),
    LaylStep(pose: .stand, phase: "صلاة الوتر", title: "القنوت",
             how: "قبل الركوع، ارفع يديك للقنوت. القنوت مستحب. أبسط صورة أن تستغفر وتدعو:",
             say: "أَسْتَغْفِرُ اللَّهَ رَبِّي وَأَتُوبُ إِلَيْه (سبعين مرّة إن استطعت)\nرَبِّ اغْفِرْ لِي وَارْحَمْنِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيم",
             sayNote: "يُستحب أيضاً قول «العَفوَ» ٣٠٠ مرّة، والاستغفار لأربعين مؤمناً. ومن لم يحفظ يكفيه الاستغفار والدعاء بما تيسّر.",
             counter: 300, counterLabel: "العَفوَ"),
    LaylStep(pose: .bow, phase: "صلاة الوتر", title: "الركوع",
             how: "بعد القنوت، كبّر واركع وقل ثلاثاً (أو مرة):",
             say: "سُبْحَانَ رَبِّيَ الْعَظِيمِ وَبِحَمْدِهِ"),
    LaylStep(pose: .prostrate, phase: "صلاة الوتر", title: "السجدتان",
             how: "اسجد سجدتين (بينهما جلوس واستغفار) كما تعلّمت، قائلاً في كل سجدة:",
             say: "سُبْحَانَ رَبِّيَ الْأَعْلَىٰ وَبِحَمْدِهِ"),
    LaylStep(pose: .sit, phase: "صلاة الوتر", title: "التشهّد والتسليم",
             how: "اجلس بعد السجدتين، تشهّد ثم سلِّم:",
             say: "أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ... اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَآلِ مُحَمَّد\nالسَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُه"),
    LaylStep(pose: .done, phase: "تمّت", title: "تقبّل الله صلاتك",
             how: "بهذا أتممتَ صلاة الليل كاملةً (١١ ركعة). إن كان الوقت ضيّقاً في ليلةٍ ما، يجوز الاقتصار على الشفع والوتر، بل على الوتر وحدها.\n\nواظِب عليها ولو ركعةً واحدة، فثوابها عظيم وأثرها في القلب كبير.")
]

fileprivate func laylPoseLabel(_ p: LaylPose) -> String {
    switch p {
    case .stand: return "قيام"
    case .bow: return "ركوع"
    case .prostrate: return "سجود"
    case .sit: return "جلوس"
    case .done: return "تمّ"
    case .info: return "تمهيد"
    }
}

fileprivate func laylPoseSymbol(_ p: LaylPose) -> String {
    switch p {
    case .stand: return "figure.stand"
    case .bow: return "figure.cooldown"
    case .prostrate: return "drop.fill"
    case .sit: return "circle.dotted.circle"
    case .done: return "star.fill"
    case .info: return "scroll.fill"
    }
}

struct LaylView: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var i = 0
    @State private var count = 0

    private var scale: CGFloat { CGFloat(store.fontSize / 21.0) }
    private var isLast: Bool { i >= laylSteps.count - 1 }

    var body: some View {
        ScreenScroll {
            if laylSteps.indices.contains(i) {
                header(laylSteps[i])
                VStack(alignment: .leading, spacing: 14) {
                    stepBody(laylSteps[i])
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
                .onTapGesture { advance() }
                Text("انقر في أيّ مكان للانتقال للخطوة التالية")
                    .font(.caption.weight(.medium))
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 6)
                    .onTapGesture { advance() }
            }
        }
        .safeAreaInset(edge: .bottom) { navBar }
        .navigationTitle("دليل صلاة الليل")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { store.fontSize = max(15, store.fontSize - 2) } label: { Text("أ−").font(.headline) }
                Button { store.fontSize = min(40, store.fontSize + 2) } label: { Text("أ+").font(.headline) }
            }
        }
        .keepScreenAwake(true)
        .animation(.easeInOut(duration: 0.2), value: i)
        .onChange(of: i) { _, _ in count = 0 }
    }

    private func advance() {
        if isLast { dismiss() } else { i += 1 }
    }

    private func header(_ s: LaylStep) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(s.phase)
                    .font(.caption.weight(.heavy))
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .glassCapsule()
                Spacer(minLength: 8)
                if s.pose != .info && s.pose != .done {
                    Label(laylPoseLabel(s.pose), systemImage: laylPoseSymbol(s.pose))
                        .font(.caption.weight(.heavy))
                        .foregroundStyle(Brand.gold)
                        .padding(.horizontal, 12).padding(.vertical, 6)
                        .glassCapsule(tint: Brand.gold)
                }
            }
            Text(s.title)
                .font(.system(size: 26 * scale, weight: .heavy))
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 3) {
                ForEach(0..<laylSteps.count, id: \.self) { idx in
                    Capsule()
                        .fill(idx <= i ? Brand.gold : Color.white.opacity(0.22))
                        .frame(height: 4)
                }
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .hero()
    }

    @ViewBuilder private func stepBody(_ s: LaylStep) -> some View {
        Text(s.how)
            .font(.system(size: 18 * scale))
            .lineSpacing(10 * scale)
            .fixedSize(horizontal: false, vertical: true)
        if let say = s.say {
            sayCard(say)
        }
        ForEach(Array(s.surahs.enumerated()), id: \.offset) { pair in
            surahCard(pair.element)
        }
        if let target = s.counter {
            counterCard(target: target, label: s.counterLabel)
        }
        if let note = s.sayNote {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "sparkle").foregroundStyle(.secondary)
                Text(note)
                    .font(.system(size: 15 * scale))
                    .lineSpacing(6 * scale)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .card(14, padding: 14)
        }
    }

    private func sayCard(_ say: String) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Circle().fill(Brand.gold).frame(width: 8, height: 8)
                Text("تقول:").font(.system(size: 14 * scale, weight: .heavy)).foregroundStyle(Brand.gold)
            }
            Text(say)
                .font(.scripture(26 * scale))
                .lineSpacing(14 * scale)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Brand.emerald.opacity(0.11), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }

    private func surahCard(_ ref: LaylSurahRef) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Label(ref.name, systemImage: "book.fill")
                .font(.system(size: 14 * scale, weight: .heavy))
                .foregroundStyle(Brand.gold)
            Text(ref.text)
                .font(.scripture(23 * scale))
                .lineSpacing(12 * scale)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Brand.gold.opacity(0.10), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Brand.gold.opacity(0.25), lineWidth: 1))
    }

    private func counterCard(target: Int, label: String?) -> some View {
        let full = count >= target
        return VStack(spacing: 12) {
            if let label {
                Text(label)
                    .font(.scripture(18 * scale))
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity)
            }
            Button {
                if count < target {
                    count += 1
                    if count == target { Haptic.confirm() } else { Haptic.tick() }
                }
            } label: {
                VStack(spacing: 4) {
                    Text(full ? "تمّ ✓  (\(target.ar))" : "\(count.ar) / \(target.ar)")
                        .font(.counter(34 * scale))
                        .foregroundStyle(Brand.gold)
                        .minimumScaleFactor(0.5)
                        .lineLimit(1)
                    Text(full ? "اكتمل العدد" : "انقر هنا لكلّ مرّة")
                        .font(.system(size: 13 * scale, weight: .medium))
                        .opacity(0.8)
                }
                .foregroundStyle(.white)
                .frame(width: 190, height: 190)
                .contentShape(Circle())
            }
            .buttonStyle(.plain)
            .glassCircle(tint: full ? Brand.good : Brand.emerald, interactive: true)
            if count > 0 && !full {
                Button {
                    count = 0
                } label: {
                    Text("إعادة").font(.caption.weight(.bold)).padding(.horizontal, 6)
                }
                .glassButton()
            }
        }
        .padding(20)
        .frame(maxWidth: .infinity)
        .environment(\.colorScheme, .dark)
        .hero(22)
    }

    private var navBar: some View {
        HStack(spacing: 12) {
            if i > 0 {
                Button {
                    i -= 1
                } label: {
                    Label("السابق", systemImage: "chevron.backward").font(.headline).frame(maxWidth: .infinity, minHeight: 34)
                }
                .glassButton()
                .controlSize(.large)
            }
            Button {
                advance()
            } label: {
                Text(isLast ? "تمّ — إغلاق" : "التالي").font(.headline).frame(maxWidth: .infinity, minHeight: 34)
            }
            .glassButton(prominent: true)
            .controlSize(.large)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }
}
