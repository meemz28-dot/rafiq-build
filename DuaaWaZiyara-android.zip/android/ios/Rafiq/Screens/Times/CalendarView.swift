import SwiftUI

// MARK: - التقويم (ported from Android ui/MoreScreens.kt CalendarScreen)

struct CalendarView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    /// Shown month (y, m) and selected day; nil until the user navigates (then follows today).
    @State private var shownY: Int?
    @State private var shownM: Int?
    @State private var selDay: Int?

    private var today: Hijri.HDate { store.hijriToday() }
    private var calY: Int { shownY ?? today.y }
    private var calM: Int { max(1, min(12, shownM ?? today.m)) }
    private var days: Int { Hijri.monthLength(calY, calM, adj: store.hijriAdj) }
    private var day: Int {
        let isCurrent = calY == today.y && calM == today.m
        return max(1, min(days, selDay ?? (isCurrent ? today.d : 1)))
    }

    var body: some View {
        ScreenScroll {
            CalendarMonthHeader(title: "\(Hijri.months[calM - 1]) \(calY.ar) هـ",
                                onPrev: { step(-1) }, onNext: { step(1) })
            CalendarGrid(y: calY, m: calM, today: today, selected: day, adj: store.hijriAdj) { d in
                selDay = d
                Haptic.tick()
            }
            CalendarLegend()
            CalendarDayPanel(y: calY, m: calM, d: day)
            PersonalOccasionsSection()
        }
        .navigationTitle("التقويم")
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    nav.openTool(.converter)
                } label: {
                    Image(systemName: Tool.converter.symbol)
                }
                .accessibilityLabel(Tool.converter.title)
            }
        }
    }

    private func step(_ delta: Int) {
        var m = calM + delta, y = calY
        if m < 1 { m = 12; y -= 1 }
        if m > 12 { m = 1; y += 1 }
        withAnimation(.snappy) {
            shownY = y
            shownM = m
            selDay = 1
        }
    }
}

// MARK: - Header and legend

private struct CalendarMonthHeader: View {
    let title: String
    let onPrev: () -> Void
    let onNext: () -> Void

    var body: some View {
        HStack {
            navButton("chevron.backward", label: "الشهر السابق", action: onPrev)
            Spacer()
            Text(title).font(.title3.weight(.heavy)).contentTransition(.numericText())
            Spacer()
            navButton("chevron.forward", label: "الشهر التالي", action: onNext)
        }
        .padding(.vertical, 4)
    }

    private func navButton(_ symbol: String, label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.body.weight(.bold))
                .foregroundStyle(Brand.emerald)
                .frame(width: 44, height: 44)
                .glassCircle(interactive: true)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

private struct CalendarLegend: View {
    var body: some View {
        HStack(spacing: 16) {
            dot("عيد", CalendarKind.color("eid"))
            dot("ولادة", CalendarKind.color("birth"))
            dot("وفاة", CalendarKind.color("death"))
        }
        .frame(maxWidth: .infinity)
    }

    private func dot(_ label: String, _ c: Color) -> some View {
        HStack(spacing: 5) {
            Circle().fill(c).frame(width: 8, height: 8)
            Text(label).font(.caption).foregroundStyle(.secondary)
        }
    }
}

/// Occasion kind colours and labels.
private enum CalendarKind {
    static func color(_ k: String) -> Color {
        switch k {
        case "birth": return Brand.gold
        case "death": return Color.primary.opacity(0.8)
        case "eid": return Brand.emerald
        default: return Color.gray
        }
    }
    static func label(_ k: String) -> String {
        switch k {
        case "eid": return "عيد"
        case "birth": return "ولادة"
        case "death": return "وفاة"
        default: return "مناسبة"
        }
    }
}

// MARK: - Month grid

private struct CalendarGrid: View {
    let y: Int
    let m: Int
    let today: Hijri.HDate
    let selected: Int
    let adj: Int
    let onSelect: (Int) -> Void

    let columns = Array(repeating: GridItem(.flexible(), spacing: 6), count: 7)

    private var jd1: Int { Hijri.hijriToJd(y, m, 1, adj: adj) }
    private var lead: Int { Hijri.weekday(ofJd: jd1) }
    private var length: Int { Hijri.monthLength(y, m, adj: adj) }
    /// -1 marks an empty leading cell.
    private var cells: [Int] { Array(repeating: -1, count: lead) + Array(1...max(1, length)) }

    var body: some View {
        LazyVGrid(columns: columns, spacing: 6) {
            ForEach(0..<7, id: \.self) { i in
                Text(shortDay(i))
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
            ForEach(Array(cells.enumerated()), id: \.offset) { _, d in
                if d < 0 {
                    Color.clear.frame(height: 50)
                } else {
                    cell(d)
                }
            }
        }
        .padding(10)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private func shortDay(_ i: Int) -> String {
        let w = Hijri.weekDays[i]
        return w.hasPrefix("ال") ? String(w.dropFirst(2)) : w
    }

    private func cell(_ d: Int) -> some View {
        let isToday = y == today.y && m == today.m && d == today.d
        let isSel = d == selected
        let g = Hijri.jdToGreg(jd1 + d - 1)
        let occ = Library.occasions(m: m, d: d)
        return Button {
            onSelect(d)
        } label: {
            CalendarDayCell(hDay: d, gDay: g.d, isToday: isToday, isSelected: isSel, dotKind: occ.first?.k)
        }
        .buttonStyle(.plain)
        .accessibilityLabel("\(d.ar) \(Hijri.months[m - 1])")
    }
}

private struct CalendarDayCell: View {
    let hDay: Int
    let gDay: Int
    let isToday: Bool
    let isSelected: Bool
    let dotKind: String?

    var body: some View {
        VStack(spacing: 1) {
            Text(hDay.ar)
                .font(.system(size: 17, weight: .bold, design: .rounded))
                .foregroundStyle(isSelected ? Color.white : (isToday ? Brand.gold : Color.primary))
            Text(gDay.ar)
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(isSelected ? Color.white.opacity(0.8) : Color.secondary)
            Circle()
                .fill(dotFill)
                .frame(width: 5, height: 5)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 50)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(isSelected ? Brand.emerald : Color(.tertiarySystemGroupedBackground))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .stroke(isToday ? Brand.gold : Color.clear, lineWidth: 2)
        )
        .contentShape(Rectangle())
    }

    private var dotFill: Color {
        guard let k = dotKind else { return Color.clear }
        if isSelected && k == "eid" { return Color.white }
        return CalendarKind.color(k)
    }
}

// MARK: - Selected day panel

/// Gusl for the Hijri day, as an item id in the nawafil category.
private func calendarGhusl(_ m: Int, _ d: Int) -> String? {
    if m == 10 && d == 1 { return "nf-ghusl-eid" }
    if m == 12 && d == 10 { return "nf-ghusl-eid" }
    if m == 12 && d == 9 { return "nf-ghusl-times" }
    if m == 12 && d == 18 { return "nf-ghusl-times" }
    if m == 7 && d == 27 { return "nf-ghusl-times" }
    if m == 1 && d == 10 { return "nf-ghusl-times" }
    if m == 11 && d == 25 { return "nf-ghusl-times" }
    if m == 9 && (d == 19 || d == 21 || d == 23) { return "nf-ghusl-times" }
    if m == 7 && (d == 1 || d == 15) { return "nf-ghusl-times" }
    if m == 8 && d == 15 { return "nf-ghusl-times" }
    return nil
}

private let calendarZiyaraNames = [
    "أمير المؤمنين (ع)", "الحسنان (ع)", "السجاد والباقر والصادق (ع)",
    "الكاظم والرضا والجواد والهادي (ع)", "العسكري (ع)", "صاحب الزمان (عج)", "النبي الأعظم (ص)"
]
private let calendarZiyaraIds = ["z-amin", "z-mutlaqa", "z-baqi", "z-kadhim", "z-askari", "z-yasin", "z-nabi"]

private struct CalendarDayPanel: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    let y: Int
    let m: Int
    let d: Int

    private var jd: Int { Hijri.hijriToJd(y, m, d, adj: store.hijriAdj) }
    private var g: Hijri.GDate { Hijri.jdToGreg(jd) }
    private var wd: Int { max(0, min(6, Hijri.weekday(ofJd: jd))) }
    private var dayTimes: PrayerTimes.Times { store.times(for: Hijri.date(fromJd: jd)) }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            occasionsCard
            let sg = Recommend.now(hMonth: m, hDay: d, weekday: wd, hour: 9)
            if Library.item(sg.catId, sg.itemId) != nil {
                dayWorkCard(sg)
                nawafilCard
                worksList
                amaalLink
            }
        }
    }

    // MARK: Date and occasions

    private var occasionsCard: some View {
        let occ = Library.occasions(m: m, d: d)
        let white = (13...15).contains(d)
        return VStack(alignment: .leading, spacing: 10) {
            Text("\(d.ar) \(Hijri.months[m - 1]) \(y.ar) هـ — \(g.d.ar)/\(g.m.ar)/\(g.y.ar)م")
                .font(.headline.weight(.heavy))
                .foregroundStyle(Brand.emerald)
            Text(Hijri.weekDays[wd]).font(.subheadline).foregroundStyle(.secondary)
            if white {
                Tag(text: "من الأيام البيض — يُستحب صيامها ودعاء المجير", color: Brand.gold)
            }
            if occ.isEmpty && !white {
                Text("لا توجد مناسبة مسجّلة في هذا اليوم.").foregroundStyle(.secondary)
            } else {
                ForEach(Array(occ.enumerated()), id: \.offset) { _, o in
                    HStack(alignment: .firstTextBaseline, spacing: 10) {
                        Tag(text: CalendarKind.label(o.k), color: CalendarKind.color(o.k))
                        Text(o.t).font(.subheadline)
                        Spacer(minLength: 0)
                    }
                }
            }
        }
        .card()
    }

    // MARK: Times, dua, ziyara, ghusl, fasting

    private func dayWorkCard(_ sg: Recommend.Suggestion) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("دعاء وأعمال اليوم").font(.headline.weight(.heavy)).foregroundStyle(Brand.emerald)
            timesStrip
            Button {
                nav.openReader(sg.catId, sg.itemId)
            } label: {
                CalendarLinkRow(symbol: Brand.categorySymbol(sg.catId), colors: Brand.categoryColors(sg.catId),
                                title: sg.label, subtitle: sg.reason, subtitleColor: .secondary, chevron: true)
            }
            .buttonStyle(.plain)
            ziyaraRow
            ghuslRow
            fastingRow
        }
        .card()
    }

    private var timesStrip: some View {
        let keys: [(String, String)] = [("الفجر", "fajr"), ("الظهر", "dhuhr"), ("العصر", "asr"), ("المغرب", "maghrib"), ("العشاء", "isha")]
        let t = dayTimes
        return HStack(spacing: 2) {
            ForEach(Array(keys.enumerated()), id: \.offset) { _, k in
                VStack(spacing: 2) {
                    Text(k.0).font(.caption2.weight(.bold)).foregroundStyle(.secondary).lineLimit(1)
                    Text(PrayerTimes.fmt(PrayerTimes.value(t, k.1)))
                        .font(.caption.weight(.heavy).monospacedDigit())
                        .foregroundStyle(Brand.emerald)
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                }
                .frame(maxWidth: .infinity)
            }
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 4)
        .background(Color(.tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    @ViewBuilder private var ziyaraRow: some View {
        let name = calendarZiyaraNames[wd]
        let zid = calendarZiyaraIds[wd]
        if Library.item("ziyarat", zid) != nil {
            Button {
                nav.openReader("ziyarat", zid)
            } label: {
                CalendarLinkRow(symbol: "building.columns.fill", colors: [Brand.goldDeep, Brand.gold],
                                title: "زيارة اليوم: \(name)", subtitle: "اضغط لقراءة زيارة هذا اليوم",
                                subtitleColor: Brand.gold, chevron: true)
            }
            .buttonStyle(.plain)
        } else {
            CalendarLinkRow(symbol: "building.columns.fill", colors: [Brand.goldDeep, Brand.gold],
                            title: "زيارة اليوم: \(name)", subtitle: "لكلّ يومٍ من الأسبوع معصومٌ يُستحبّ زيارته",
                            subtitleColor: .secondary, chevron: false)
        }
    }

    @ViewBuilder private var ghuslRow: some View {
        if let gid = calendarGhusl(m, d), Library.item("nawafil", gid) != nil {
            Button {
                nav.openReader("nawafil", gid)
            } label: {
                CalendarLinkRow(symbol: "drop.fill", colors: [Brand.emerald, Brand.mint],
                                title: "غسل اليوم مستحبّ", subtitle: "اضغط لمعرفة كيفيّته وأحكامه",
                                subtitleColor: Brand.emerald, chevron: true)
            }
            .buttonStyle(.plain)
        }
    }

    private var fastingRow: some View {
        let fast = Fasting.rec(hm: m, hd: d, weekday: wd)
        return HStack(spacing: 12) {
            Image(systemName: "moon.fill")
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(fast.recommended ? Brand.good : Color.secondary)
                .frame(width: 40, height: 40)
                .background((fast.recommended ? Brand.good : Color.gray).opacity(0.16),
                            in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(fast.recommended ? "صيام هذا اليوم مستحبّ" : "صيام اليوم")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(fast.recommended ? Brand.good : Color.primary)
                Text(fast.reason).font(.caption).foregroundStyle(.secondary).lineLimit(3)
            }
            Spacer(minLength: 0)
        }
        .padding(10)
        .background((fast.recommended ? Brand.good : Color.gray).opacity(0.08),
                    in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    // MARK: Nawafil

    private var nawafilCard: some View {
        let note = "وقت صلاة الليل: من منتصف الليل الشرعي (\(PrayerTimes.fmt(dayTimes.midnight))) حتى أذان الفجر."
            + (wd == 5 ? "\nهذا اليوم جمعة — تُزاد ٤ ركعات على النوافل." : " ويُزاد يوم الجمعة ٤ ركعات على النوافل.")
        return VStack(alignment: .leading, spacing: 9) {
            Text("الصلوات والنوافل اليومية — ٣٤ ركعة").font(.subheadline.weight(.heavy)).foregroundStyle(Brand.emerald)
            ForEach(Array(PrayerNawafil.rows.enumerated()), id: \.offset) { _, r in
                PrayerNafilaRow(name: r.0, detail: r.1)
            }
            Text(note)
                .font(.caption.weight(.bold))
                .foregroundStyle(Brand.emerald)
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Brand.emerald.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .card()
    }

    // MARK: Works of the day

    @ViewBuilder private var worksList: some View {
        let works = Library.works(m: m, d: d)
        if !works.isEmpty {
            ForEach(Array(works.enumerated()), id: \.offset) { _, w in
                CalendarWorkCard(work: w)
            }
        }
    }

    private var amaalLink: some View {
        Button {
            nav.openTool(.amaal)
        } label: {
            HStack {
                Text("كلّ الأعمال والمستحبّات — تصفّح حسب الشهر")
                    .font(.subheadline.weight(.bold))
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                Spacer(minLength: 4)
                Image(systemName: "chevron.forward").font(.footnote.weight(.bold))
            }
            .foregroundStyle(Brand.goldDeep)
            .padding(.horizontal, 14).padding(.vertical, 12)
            .background(Brand.gold.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}

private struct CalendarLinkRow: View {
    let symbol: String
    let colors: [Color]
    let title: String
    let subtitle: String
    let subtitleColor: Color
    let chevron: Bool

    var body: some View {
        HStack(spacing: 12) {
            IconChip(symbol: symbol, colors: colors, size: 40)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline.weight(.bold)).foregroundStyle(.primary).lineLimit(1)
                Text(subtitle).font(.caption.weight(.medium)).foregroundStyle(subtitleColor)
            }
            Spacer(minLength: 0)
            if chevron {
                Image(systemName: "chevron.forward").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
            }
        }
        .contentShape(Rectangle())
    }
}

/// Expandable work card (Android WorkCard).
private struct CalendarWorkCard: View {
    let work: Work
    @State private var expanded = false

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Button {
                withAnimation(.snappy) { expanded.toggle() }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "sparkles").foregroundStyle(Brand.gold)
                    Text(work.title).font(.subheadline.weight(.bold)).foregroundStyle(.primary)
                        .multilineTextAlignment(.leading)
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.down")
                        .font(.footnote.weight(.bold))
                        .foregroundStyle(.secondary)
                        .rotationEffect(.degrees(expanded ? 180 : 0))
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if expanded {
                Text(work.body)
                    .font(.scripture(18))
                    .lineSpacing(6)
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .card()
    }
}
