import SwiftUI
import CoreLocation

// MARK: - اختر الموقع (ported from Android ui/Sheets.kt LocationSheet, plus device location)

struct LocationView: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var service = LocationService()
    @State private var query = ""
    @State private var locating = false

    private var usingCustom: Bool { store.has("lat") && store.has("lng") }

    private var cities: [City] { Library.shared.cities }

    /// Indices into `cities` matching the search query.
    private var filtered: [Int] {
        let all = Array(cities.indices)
        let q = ArabicSearch.normalize(query)
        if q.isEmpty { return all }
        return all.filter { ArabicSearch.normalize(cities[$0].n).contains(q) }
    }

    var body: some View {
        List {
            deviceSection
            Section {
                ForEach(filtered, id: \.self) { i in
                    cityRow(i, cities[i])
                }
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Brand.canvas)
        .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always))
        .navigationTitle("اختر الموقع")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("تم") { dismiss() }
            }
        }
        .onChange(of: service.location) { _, loc in
            guard locating, let loc else { return }
            Task { await applyDevice(loc) }
        }
        .onChange(of: service.errorText) { _, err in
            if err != nil { locating = false }
        }
    }

    // MARK: Device location

    private var deviceSection: some View {
        Section {
            if usingCustom {
                HStack {
                    Label(store.string("cityName", "موقعي"), systemImage: "location.fill")
                        .font(.ui(.body, .heavy))
                        .foregroundStyle(Brand.emerald)
                    Spacer()
                    Image(systemName: "checkmark").foregroundStyle(Brand.emerald).fontWeight(.bold)
                }
            }
            Button {
                locating = true
                service.requestLocation()
            } label: {
                HStack {
                    Label("استخدام موقعي الحالي", systemImage: "location")
                    Spacer()
                    if locating { ProgressView() }
                }
            }
            .disabled(locating)
        } footer: {
            if let err = service.errorText {
                Text(err).foregroundStyle(Brand.bad)
            }
        }
    }

    @MainActor
    private func applyDevice(_ loc: CLLocation) async {
        let name = await service.cityName(for: loc)
        let tz = Double(TimeZone.current.secondsFromGMT()) / 3600
        store.setCustomLocation(name: name, lat: loc.coordinate.latitude, lng: loc.coordinate.longitude, tz: tz)
        locating = false
        PrayerRoutines.refreshTimed(store: store)
        Haptic.confirm()
        dismiss()
    }

    // MARK: Cities

    private func cityRow(_ i: Int, _ c: City) -> some View {
        let on = !usingCustom && store.cityIdx == i
        return Button {
            store.selectCity(i)
            PrayerRoutines.refreshTimed(store: store)
            Haptic.tick()
            dismiss()
        } label: {
            HStack {
                Text(c.n)
                    .font(on ? .ui(.body, .heavy) : .ui(.body))
                    .foregroundStyle(on ? Brand.emerald : Color.primary)
                Spacer()
                if on {
                    Image(systemName: "checkmark").foregroundStyle(Brand.emerald).fontWeight(.bold)
                }
            }
            .contentShape(Rectangle())
        }
    }
}

// MARK: - طريقة حساب المواقيت (ported from Android ui/Sheets.kt MethodSheet)

struct MethodView: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        List {
            Section {
                ForEach(PrayerTimes.methods, id: \.key) { m in
                    methodRow(m)
                }
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Brand.canvas)
        .navigationTitle("طريقة حساب المواقيت")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("تم") { dismiss() }
            }
        }
    }

    private func methodRow(_ m: PrayerTimes.Method) -> some View {
        let on = m.key == store.method
        return Button {
            store.method = m.key
            PrayerRoutines.refreshTimed(store: store)
            Haptic.tick()
            dismiss()
        } label: {
            HStack {
                Text(m.name)
                    .font(on ? .ui(.body, .heavy) : .ui(.body))
                    .foregroundStyle(on ? Brand.emerald : Color.primary)
                Spacer()
                if on {
                    Image(systemName: "checkmark").foregroundStyle(Brand.emerald).fontWeight(.bold)
                }
            }
            .contentShape(Rectangle())
        }
    }
}
