import SwiftUI

/// Recommended times for grooming (nails, moustache, hair, head-wash, nura),
/// drawn only from al-Kafi with al-Majlisi's isnad grading in Mir'at al-'Uqul.
struct GroomingTip: Identifiable {
    let id: String
    let symbol: String
    let title: String
    let hadith: String
    let source: String
    let grade: String

    var gradeColor: Color {
        if grade.contains("صحيح") || grade.hasPrefix("موثق") || grade.hasPrefix("حسن") { return Brand.good }
        if grade.hasPrefix("مجهول") { return Brand.mid }
        return Color.secondary
    }
}

enum Grooming {
    static let friday: [GroomingTip] = [
        GroomingTip(id: "fri-nails-moustache", symbol: "hand.raised.fingers.spread",
                    title: "تقليم الأظفار وأخذ الشارب",
                    hadith: "«تقليمُ الأظفار وأخذُ الشارب في كلّ جمعةٍ أمانٌ من البرص والجنون»",
                    source: "الكافي ٦، باب قصّ الأظفار، ح٤", grade: "موثّق"),
        GroomingTip(id: "fri-nails", symbol: "sparkles",
                    title: "وإن لم تحتج إلى التقليم",
                    hadith: "«تقليمُ الأظفار يومَ الجمعة يُؤمِّن من الجذام والبرص والعمى، وإن لم تحتج فحُكَّها»",
                    source: "الكافي ٦، باب قصّ الأظفار، ح٢", grade: "حسن"),
        GroomingTip(id: "fri-khitmi", symbol: "drop.fill",
                    title: "غسل الرأس بالخطميّ",
                    hadith: "«غَسلُ الرأس بالخطميّ في كلّ جمعةٍ أمانٌ من البرص والجنون»",
                    source: "الكافي ٦، باب غسل الرأس، ح٢", grade: "موثّق كالصحيح"),
        GroomingTip(id: "fri-adorn", symbol: "tshirt.fill",
                    title: "التزيّن والتطيّب ولبس النظيف",
                    hadith: "«ليتزيّن أحدُكم يومَ الجمعة… ويتنظّف ثيابه وليتهيّأ للجمعة»",
                    source: "الكافي ٣، باب التزيّن يوم الجمعة، ح١", grade: "صحيح"),
    ]

    static let thursday: [GroomingTip] = [
        GroomingTip(id: "thu-nails", symbol: "eye.fill",
                    title: "تقليم الأظفار يوم الخميس",
                    hadith: "«مَن أدمن أخذَ أظفاره كلَّ خميسٍ لم تَرمَد عينُه»",
                    source: "الكافي ٦، باب قصّ الأظفار، ح١٤ (ونحوه ح١٣ عن الإمام الرضا ع)", grade: "مجهول"),
    ]

    static let hajj = GroomingTip(id: "hajj-hair", symbol: "scissors",
                                  title: "توفير شعر الرأس لمن أراد الحجّ",
                                  hadith: "«مَن أراد الحجَّ وفَّر شعرَه إذا نظر إلى هلال ذي القعدة، ومَن أراد العمرة وفَّر شعرَه شهراً»",
                                  source: "الكافي ٤، باب توفير الشعر لمن أراد الحجّ والعمرة، ح١", grade: "حسن")

    static let general: [GroomingTip] = [
        GroomingTip(id: "gen-order", symbol: "hand.point.up.left.fill",
                    title: "ترتيب قصّ الأظفار",
                    hadith: "«تبدأ بخِنصر الأيسر، ثمّ تختم باليمين»",
                    source: "الكافي ٦، باب قصّ الأظفار، ح١٦", grade: "موقوف"),
        GroomingTip(id: "gen-weekly", symbol: "calendar",
                    title: "من الجمعة إلى الجمعة",
                    hadith: "«أخذُ الشارب والأظفار من الجمعة إلى الجمعة أمانٌ من الجذام»",
                    source: "الكافي ٣، باب التزيّن يوم الجمعة، ح٧", grade: "مجهول كالصحيح"),
    ]

    static let note = "تقييم الأسانيد للعلّامة المجلسي في «مرآة العقول». ما كان سنده مجهولاً يُؤتى به رجاءَ المطلوبيّة. والأحكام التفصيليّة تُرجع فيها إلى رسالة المرجع."

    /// Tips that apply to this specific Hijri day.
    static func tips(m: Int, d: Int, weekday wd: Int) -> [GroomingTip] {
        var out: [GroomingTip] = []
        if m == 11 || (m == 12 && d <= 10) { out.append(hajj) }
        if wd == 5 { out += friday }
        if wd == 4 { out += thursday }
        return out
    }
}

/// Card shown inside the calendar day panel.
struct GroomingDayCard: View {
    let m: Int
    let d: Int
    let wd: Int
    @State private var showGuide = false

    private var daysToFriday: Int { (5 - wd + 7) % 7 }

    var body: some View {
        let tips = Grooming.tips(m: m, d: d, weekday: wd)
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("التجمّل والنظافة").font(.ui(.headline, .heavy)).foregroundStyle(Brand.emerald)
                Spacer(minLength: 0)
                Button("الدليل والمصادر") { showGuide = true }
                    .font(.ui(.caption, .bold))
                    .foregroundStyle(Brand.gold)
            }
            if tips.isEmpty {
                HStack(spacing: 12) {
                    Image(systemName: "scissors")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(Brand.gold)
                        .frame(width: 40, height: 40)
                        .background(Brand.gold.opacity(0.14), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("أفضل وقت للأظفار والشارب: يوم الجمعة").font(.ui(.subheadline, .bold))
                        Text(verbatim: daysToFriday == 1 ? "الجمعة غداً — ويُستحبّ الخميس أيضاً" : "بعد \(daysToFriday.ar) أيام — ويُستحبّ الخميس أيضاً")
                            .font(.ui(.caption)).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
            } else {
                ForEach(tips) { GroomingTipRow(tip: $0) }
            }
        }
        .card()
        .sheet(isPresented: $showGuide) { GroomingGuideSheet() }
    }
}

struct GroomingTipRow: View {
    let tip: GroomingTip

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: tip.symbol)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(Brand.emerald)
                .frame(width: 38, height: 38)
                .background(Brand.emerald.opacity(0.12), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
            VStack(alignment: .leading, spacing: 5) {
                Text(tip.title).font(.ui(.subheadline, .bold))
                Text(tip.hadith)
                    .font(.scripture(15))
                    .foregroundStyle(Brand.ink.opacity(0.85))
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 6) {
                    Text(tip.grade)
                        .font(.ui(.caption2, .bold))
                        .foregroundStyle(tip.gradeColor)
                        .padding(.horizontal, 7).padding(.vertical, 2)
                        .background(tip.gradeColor.opacity(0.14), in: Capsule())
                    Text(tip.source).font(.ui(.caption2)).foregroundStyle(.secondary)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(10)
        .background(Brand.soft.opacity(0.6), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

struct GroomingGuideSheet: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    section("يوم الجمعة — الأفضل", Grooming.friday)
                    section("يوم الخميس", Grooming.thursday)
                    section("موسم الحجّ — من هلال ذي القعدة", [Grooming.hajj])
                    section("آداب عامّة", Grooming.general)
                    Text(Grooming.note)
                        .font(.ui(.caption))
                        .foregroundStyle(.secondary)
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Brand.gold.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .padding(16)
            }
            .background(Brand.canvas)
            .navigationTitle("أوقات التجمّل والنظافة")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("تم") { dismiss() } }
            }
        }
        .presentationDetents([.large])
    }

    private func section(_ title: String, _ tips: [GroomingTip]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.ui(.headline, .heavy)).foregroundStyle(Brand.emerald)
            ForEach(tips) { GroomingTipRow(tip: $0) }
        }
    }
}
