import Foundation
import UserNotifications

/// Reminder scheduling for the Times group (ported from Android notify/*Scheduler.kt).
/// Prayer alerts go through the core `Notifier`; the routine reminders (taqibat, night prayer,
/// occasions, dhikr, sadaqa) are scheduled here with the same Android preference keys.
enum PrayerRoutines {
    static let startHour = 8      // DhikrScheduler.START_HOUR
    static let endHour = 22       // DhikrScheduler.END_HOUR
    private static let taqibDelayMin = 6

    static let adhkar: [(String, String)] = [
        ("صلِّ على محمد وآل محمد", "اللّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَآلِ مُحَمَّدٍ"),
        ("استغفر الله", "أَسْتَغْفِرُ اللهَ رَبِّي وَأَتُوبُ إِلَيْهِ"),
        ("سبحان الله", "سُبْحَانَ اللهِ وَبِحَمْدِهِ، سُبْحَانَ اللهِ الْعَظِيمِ"),
        ("لا إله إلا الله", "لاَ إِلٰهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ"),
        ("الحمد لله", "الْحَمْدُ لِلّٰهِ رَبِّ الْعَالَمِينَ"),
        ("ذِكر الله", "وَاذْكُرْ رَبَّكَ كَثِيراً وَسَبِّحْ بِالْعَشِيِّ وَالْإِبْكَارِ"),
        ("اللهم عجّل لوليّك الفرج", "اللّهُمَّ عَجِّلْ لِوَلِيِّكَ الْفَرَجَ وَالْعَافِيَةَ وَالنَّصْرَ"),
        ("حسبنا الله", "حَسْبُنَا اللهُ وَنِعْمَ الْوَكِيلُ"),
        ("لا حول ولا قوة إلا بالله", "لاَ حَوْلَ وَلاَ قُوَّةَ إِلاَّ بِاللهِ الْعَلِيِّ الْعَظِيمِ"),
        ("اللهم صلِّ على فاطمة", "اللّهُمَّ صَلِّ عَلَى فَاطِمَةَ وَأَبِيهَا وَبَعْلِهَا وَبَنِيهَا")
    ]

    static let sadaqaFadl: [(String, String)] = [
        ("تصدّق ولو بشِقّ تمرة", "الصدقة تدفع البلاء وتُطفئ غضب الرب، وتزيد في العمر والرزق."),
        ("صدقة اليوم", "قال الصادق (ع): الصدقة باليد تقي مِيتة السوء وتدفع سبعين نوعاً من البلاء."),
        ("باكِر بالصدقة", "بكّروا بالصدقة فإنّ البلاء لا يتخطّاها — داوِم ولو على القليل."),
        ("صدقة تُظلّك", "كلّ امرئٍ في ظلّ صدقته يوم القيامة — لا تَدَع يومك بلا صدقة."),
        ("الصدقة دواء", "داووا مرضاكم بالصدقة، وادفعوا البلاء بالدعاء والصدقة.")
    ]

    /// Everything that depends on today's prayer times (safe to call on every appearance).
    static func refreshTimed(store: Store) {
        Notifier.schedulePrayers(store: store)
        refreshRoutines(store: store)
    }

    /// Everything, including the fixed-hour daily reminders.
    static func refreshAll(store: Store) {
        refreshTimed(store: store)
        refreshDhikr(store: store)
        refreshSadaqa(store: store)
    }

    // MARK: Taqibat, night prayer and occasion reminders (today and tomorrow, as on Android)

    private static func routineIds() -> [String] {
        var ids: [String] = []
        for d in 0...1 {
            for i in 0..<5 { ids.append("r-taqib-\(d)-\(i)") }
            ids.append("r-layl-\(d)")
            ids.append("r-occ-\(d)-0")
            ids.append("r-occ-\(d)-1")
        }
        return ids
    }

    static func refreshRoutines(store: Store) {
        Notifier.cancel(routineIds())
        let taqib = store.bool("taqibOn", false)
        let layl = store.bool("laylOn", false)
        let occ = store.bool("occasionOn", true)
        if !taqib && !layl && !occ { return }
        let city = store.location()
        let adj = store.hijriAdj
        let now = Date()
        for d in 0...1 {
            guard let day = Calendar.current.date(byAdding: .day, value: d, to: now) else { continue }
            let t = PrayerTimes.compute(date: day, lat: city.lat, lng: city.lng, tz: city.tz, methodKey: store.method)

            if taqib {
                for (i, key) in PrayerTimes.prayerKeys.enumerated() {
                    let total = Int(PrayerTimes.norm(PrayerTimes.value(t, key)) * 60) + taqibDelayMin
                    let when = fireDate(day, totalMinutes: total)
                    if when > now {
                        add(id: "r-taqib-\(d)-\(i)", at: when,
                            title: "تعقيب صلاة \(PrayerTimes.name(key))",
                            body: "لا تنسَ تسبيح الزهراء (ع) والتعقيب بعد صلاتك")
                    }
                }
            }

            if occ {
                let jd = Hijri.jd(of: day)
                let h = Hijri.jdToHijri(jd, adj: adj)
                let hNext = Hijri.jdToHijri(jd + 1, adj: adj)
                let nights = Library.works(m: hNext.m, d: hNext.d).filter { $0.d == hNext.d && $0.title.hasPrefix("الليلة") }
                if let first = nights.first {
                    let mg = PrayerTimes.norm(PrayerTimes.value(t, "maghrib"))
                    let when = fireDate(day, totalMinutes: Int(mg * 60) + 10)
                    if when > now {
                        add(id: "r-occ-\(d)-0", at: when,
                            title: "الليلة ليلة \(hNext.d) \(monthName(hNext.m))",
                            body: "لها أعمالٌ مأثورة: " + shortTitle(first.title) + " — افتح التقويم")
                    }
                }
                let days = Library.works(m: h.m, d: h.d).filter { $0.d == h.d && !$0.title.hasPrefix("الليلة") }
                if let first = days.first {
                    let sr = PrayerTimes.norm(PrayerTimes.value(t, "sunrise"))
                    let when = fireDate(day, totalMinutes: Int(sr * 60) + 60)
                    if when > now {
                        add(id: "r-occ-\(d)-1", at: when,
                            title: "اليوم \(h.d) \(monthName(h.m))",
                            body: shortTitle(first.title) + (days.count > 1 ? " وأعمالٌ أخرى" : ""))
                    }
                }
            }

            if layl {
                let fajr = PrayerTimes.norm(PrayerTimes.value(t, "fajr"))
                let total = Int(fajr * 60) - store.int("laylBefore", 60)
                if total >= 0 {
                    let when = fireDate(day, totalMinutes: total)
                    if when > now {
                        add(id: "r-layl-\(d)", at: when,
                            title: "وقت صلاة الليل",
                            body: "اقترب الفجر — أحيِ ليلك بصلاة الليل ولو ركعة الوتر")
                    }
                }
            }
        }
    }

    // MARK: Dhikr reminders (spread over the waking window) and the daily sadaqa reminder

    static func refreshDhikr(store: Store) {
        Notifier.cancel((0..<12).map { "dhikr-\($0)" })
        guard store.bool("dhikrOn", false) else { return }
        let count = max(1, min(12, store.int("dhikrCount", 5)))
        let windowMin = (endHour - startHour) * 60
        let slot = windowMin / count
        for i in 0..<count {
            let offset = slot > 1 ? Int.random(in: 0..<slot) : 0
            let total = startHour * 60 + i * slot + offset
            let pick = adhkar[Int.random(in: 0..<adhkar.count)]
            Notifier.scheduleDaily(id: "dhikr-\(i)", hour: min(23, total / 60), minute: total % 60, title: pick.0, body: pick.1)
        }
    }

    static func refreshSadaqa(store: Store) {
        Notifier.cancel(["sadaqa"])
        guard store.bool("sadaqaOn", false) else { return }
        let hour = max(5, min(22, store.int("sadaqaHour", 9)))
        let doy = Calendar.current.ordinality(of: .day, in: .year, for: Date()) ?? 0
        let pick = sadaqaFadl[doy % sadaqaFadl.count]
        Notifier.scheduleDaily(id: "sadaqa", hour: hour, minute: 0, title: pick.0, body: pick.1)
    }

    // MARK: Helpers

    private static func monthName(_ m: Int) -> String { Hijri.months[max(0, min(11, m - 1))] }

    private static func shortTitle(_ t: String) -> String { t.components(separatedBy: " · ").first ?? t }

    private static func fireDate(_ day: Date, totalMinutes: Int) -> Date {
        let clamped = max(0, min(23 * 60 + 59, totalMinutes))
        return Calendar.current.startOfDay(for: day).addingTimeInterval(Double(clamped) * 60)
    }

    private static func add(id: String, at when: Date, title: String, body: String) {
        let c = UNMutableNotificationContent()
        c.title = title
        c.body = body
        c.sound = .default
        let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: when)
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: id, content: c,
                                                                     trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
    }
}
