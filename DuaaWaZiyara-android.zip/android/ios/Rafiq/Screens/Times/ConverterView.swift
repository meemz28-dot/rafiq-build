import SwiftUI

// MARK: - محوّل التاريخ (ported from Android ui/MoreScreens.kt DateConverterScreen)

private let converterGregMonths = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
                                   "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]

struct ConverterView: View {
    @Environment(Store.self) private var store

    @State private var mode = "h2g"
    @State private var didInit = false
    @State private var hY = Hijri.today().y
    @State private var hM = Hijri.today().m
    @State private var hD = Hijri.today().d
    @State private var gY = Hijri.jdToGreg(Hijri.jd(of: Date())).y
    @State private var gM = Hijri.jdToGreg(Hijri.jd(of: Date())).m
    @State private var gD = Hijri.jdToGreg(Hijri.jd(of: Date())).d

    var body: some View {
        List {
            Section {
                Picker("", selection: $mode) {
                    Text("هجري ← ميلادي").tag("h2g")
                    Text("ميلادي ← هجري").tag("g2h")
                }
                .pickerStyle(.segmented)
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets())
            }
            if mode == "h2g" { hijriInputs } else { gregInputs }
            resultSection
        }
        .listStyle(.insetGrouped)
        .navigationTitle(Tool.converter.title)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: initOnce)
    }

    private func initOnce() {
        guard !didInit else { return }
        didInit = true
        let adj = store.hijriAdj
        let t = store.hijriToday()
        hY = t.y; hM = t.m; hD = t.d
        let g = Hijri.jdToGreg(Hijri.hijriToJd(t.y, t.m, t.d, adj: adj))
        gY = g.y; gM = g.m; gD = g.d
    }

    // MARK: Inputs

    private var hijriInputs: some View {
        Section("التاريخ الهجري") {
            ConverterStepperRow(label: "اليوم", value: hD.ar,
                                onMinus: { hD = max(1, hD - 1) }, onPlus: { hD = min(30, hD + 1) })
            ConverterStepperRow(label: "الشهر", value: Hijri.months[max(0, min(11, hM - 1))],
                                onMinus: { hM = hM <= 1 ? 12 : hM - 1 }, onPlus: { hM = hM >= 12 ? 1 : hM + 1 })
            ConverterStepperRow(label: "السنة", value: hY.ar,
                                onMinus: { hY -= 1 }, onPlus: { hY += 1 })
        }
    }

    private var gregInputs: some View {
        Section("التاريخ الميلادي") {
            ConverterStepperRow(label: "اليوم", value: gD.ar,
                                onMinus: { gD = max(1, gD - 1) }, onPlus: { gD = min(31, gD + 1) })
            ConverterStepperRow(label: "الشهر", value: converterGregMonths[max(0, min(11, gM - 1))],
                                onMinus: { gM = gM <= 1 ? 12 : gM - 1 }, onPlus: { gM = gM >= 12 ? 1 : gM + 1 })
            ConverterStepperRow(label: "السنة", value: gY.ar,
                                onMinus: { gY -= 1 }, onPlus: { gY += 1 })
        }
    }

    // MARK: Result

    private var result: (from: String, to: String, weekday: String) {
        let adj = store.hijriAdj
        if mode == "h2g" {
            let jd = Hijri.hijriToJd(hY, max(1, min(12, hM)), hD, adj: adj)
            let g = Hijri.jdToGreg(jd)
            return ("\(hD.ar) \(Hijri.months[max(0, min(11, hM - 1))]) \(hY.ar) هـ",
                    "\(g.d.ar) / \(g.m.ar) / \(g.y.ar) م",
                    Hijri.weekDays[max(0, min(6, Hijri.weekday(ofJd: jd)))])
        } else {
            let jd = Hijri.gToJd(gY, gM, gD)
            let h = Hijri.jdToHijri(jd, adj: adj)
            return ("\(gD.ar) / \(gM.ar) / \(gY.ar) م",
                    "\(h.d.ar) \(Hijri.months[max(0, min(11, h.m - 1))]) \(h.y.ar) هـ",
                    Hijri.weekDays[max(0, min(6, Hijri.weekday(ofJd: jd)))])
        }
    }

    private var resultSection: some View {
        let r = result
        return Section {
            VStack(spacing: 8) {
                Text(r.weekday).font(.footnote.weight(.bold)).foregroundStyle(.white.opacity(0.82))
                Text(r.from).font(.subheadline.weight(.bold)).foregroundStyle(.white.opacity(0.85))
                Image(systemName: "arrow.down").font(.footnote.weight(.bold)).foregroundStyle(.white.opacity(0.6))
                Text(r.to)
                    .font(.title2.weight(.heavy))
                    .foregroundStyle(Brand.gold)
                    .contentTransition(.numericText())
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(22)
            .hero(22)
            .listRowInsets(EdgeInsets())
            .listRowBackground(Color.clear)
        } footer: {
            Text("التحويل تقريبي حسابياً وقد يختلف يوماً عن الرؤية الهلالية المحلية.")
        }
    }
}

private struct ConverterStepperRow: View {
    let label: String
    let value: String
    let onMinus: () -> Void
    let onPlus: () -> Void

    var body: some View {
        Stepper(onIncrement: increment, onDecrement: decrement) {
            HStack {
                Text(label).foregroundStyle(.secondary)
                Spacer(minLength: 8)
                Text(value).font(.body.weight(.heavy)).contentTransition(.numericText())
            }
        }
    }

    private func increment() {
        onPlus()
        Haptic.tick()
    }

    private func decrement() {
        onMinus()
        Haptic.tick()
    }
}
