import SwiftUI

// MARK: - الأوقات (ported from Android ui/MoreScreens.kt PrayerScreen)

struct PrayerView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    var body: some View {
        TimelineView(.periodic(from: .now, by: 30)) { context in
            PrayerContent(now: context.date)
        }
        .navigationTitle("الأوقات")
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                let live = store.bool("liveActivity", false)
                Button {
                    store.put("liveActivity", !live)
                    if live { PrayerLive.stop() } else { PrayerLive.start(store: store) }
                    Haptic.tick()
                } label: {
                    Image(systemName: live ? "timer.circle.fill" : "timer")
                }
                .accessibilityLabel(live ? "إيقاف العدّاد على شاشة القفل" : "عدّاد الصلاة على شاشة القفل")
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    nav.openTool(.ptable)
                } label: {
                    Image(systemName: Tool.ptable.symbol)
                }
                .accessibilityLabel(Tool.ptable.title)
            }
        }
        .onAppear { PrayerRoutines.refreshTimed(store: store) }
    }
}

private struct PrayerContent: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    let now: Date

    private var times: PrayerTimes.Times { store.times(for: now) }
    private var nextInfo: (key: String, hours: Double) { PrayerTimes.next(times, nowHours: PrayerTimes.nowHours(now)) }

    var body: some View {
        List {
            heroSection
            timesSection
            fadlSection
            nawafilSection
            calendarBridge
        }
        .listStyle(.insetGrouped)
    }

    // MARK: Hero

    private var countdownText: String {
        let total = max(0, Int(ceil(nextInfo.hours * 60)))
        let hh = total / 60, mm = total % 60
        if hh > 0 { return "بعد \(hh.ar)س \(mm.ar)د" }
        if mm > 0 { return "بعد \(mm.ar)د" }
        return "الآن"
    }

    private var heroSection: some View {
        Section {
            PrayerHeroCard(nextName: PrayerTimes.name(nextInfo.key),
                           timeText: PrayerTimes.fmt(PrayerTimes.value(times, nextInfo.key)),
                           countdown: countdownText,
                           city: store.location().n,
                           method: PrayerTimes.method(store.method).name,
                           onCity: { nav.present(.location) },
                           onMethod: { nav.present(.method) })
                .listRowInsets(EdgeInsets())
                .listRowBackground(Color.clear)
        }
    }

    // MARK: Seven times

    private var timesSection: some View {
        Section {
            ForEach(PrayerTimes.slots, id: \.key) { s in
                PrayerTimeRow(slot: s, time: PrayerTimes.fmt(PrayerTimes.value(times, s.key)), isNext: s.key == nextInfo.key)
            }
        } header: {
            Label(store.location().n, systemImage: "mappin.and.ellipse")
        }
    }

    // MARK: Virtue and disliked times

    private var fadlSection: some View {
        Section("أوقات الفضيلة والكراهة") {
            PrayerFadlRow(name: "وقت فضيلة الفجر", detail: "من الطلوع الصادق حتى الإسفار (قبيل الشروق)", preferred: true)
            PrayerFadlRow(name: "وقت فضيلة الظهر", detail: "من الزوال إلى أن يصير ظلّ الشيء مثله", preferred: true)
            PrayerFadlRow(name: "وقت فضيلة العصر", detail: "بعد أداء الظهر إلى أن يصير الظلّ مثليه", preferred: true)
            PrayerFadlRow(name: "وقت فضيلة المغرب", detail: "أوّل دخول الوقت بعد ذهاب الحمرة المشرقية", preferred: true)
            PrayerFadlRow(name: "وقت فضيلة العشاء", detail: "من ذهاب الشفق إلى ثلث الليل", preferred: true)
            PrayerFadlRow(name: "يُكره النافلة المبتدأة", detail: "بعد صلاة الصبح حتى الشروق، وبعد العصر حتى الغروب", preferred: false)
            PrayerFadlRow(name: "عند طلوع الشمس وغروبها", detail: "يُكره التنفّل عند الشروق والاستواء والغروب", preferred: false)
        }
    }

    // MARK: Nawafil

    private var nawafilSection: some View {
        Section {
            ForEach(Array(PrayerNawafil.rows.enumerated()), id: \.offset) { _, r in
                PrayerNafilaRow(name: r.0, detail: r.1)
            }
        } header: {
            Text("الصلوات والنوافل اليومية — ٣٤ ركعة")
        } footer: {
            Text("وقت صلاة الليل: من منتصف الليل الشرعي (\(PrayerTimes.fmt(times.midnight))) حتى أذان الفجر. ويُزاد يوم الجمعة ٤ ركعات على النوافل.")
        }
    }

    private var calendarBridge: some View {
        Section {
            Button {
                nav.openTool(.calendar)
            } label: {
                HStack(spacing: 12) {
                    IconChip(symbol: "moon.fill", size: 40)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("الصلوات والنوافل وأعمال كلّ يوم").font(.subheadline.weight(.bold)).foregroundStyle(.primary)
                        Text("في التقويم — اختر أيّ يومٍ لترى عمله كاملاً").font(.caption).foregroundStyle(Brand.emerald)
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.forward").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                }
            }
        } footer: {
            Text("الأوقات محسوبة فلكياً بحسب موقعك وتقريبية، وقد تختلف دقائق عن التقويم المحلي. يُحتاط في أوّل الوقت وآخره.")
                .frame(maxWidth: .infinity)
                .multilineTextAlignment(.center)
        }
    }
}

/// Shared nawafil rows (also used by the calendar day panel).
enum PrayerNawafil {
    static let rows: [(String, String)] = [
        ("نافلة الفجر", "ركعتان قبل الفريضة"),
        ("نافلة الظهر", "٨ ركعات قبلها"),
        ("نافلة العصر", "٨ ركعات قبلها"),
        ("نافلة المغرب", "٤ ركعات بعدها"),
        ("الوتيرة (العشاء)", "ركعتان من جلوس بعدها"),
        ("صلاة الليل", "١١ ركعة: ٨ + الشفع ركعتان + الوتر ركعة")
    ]
}

// MARK: - Subviews

private struct PrayerHeroCard: View {
    let nextName: String
    let timeText: String
    let countdown: String
    let city: String
    let method: String
    let onCity: () -> Void
    let onMethod: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("الصلاة القادمة")
                .font(.footnote.weight(.bold))
                .foregroundStyle(.white.opacity(0.85))
            Text(nextName)
                .font(.system(size: 38, weight: .heavy))
                .foregroundStyle(Brand.gold)
            HStack(spacing: 8) {
                Text(timeText).font(.title3.weight(.bold))
                Text("·").foregroundStyle(.white.opacity(0.6))
                Text(countdown).font(.headline.weight(.semibold)).foregroundStyle(.white.opacity(0.92))
            }
            pills.padding(.top, 10)
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .hero()
    }

    private var pills: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) { cityPill; methodPill }
            VStack(alignment: .leading, spacing: 8) { cityPill; methodPill }
        }
    }

    private var cityPill: some View {
        Button(action: onCity) {
            Label(city, systemImage: "mappin.and.ellipse")
                .font(.subheadline.weight(.semibold))
                .lineLimit(1)
                .padding(.horizontal, 14).padding(.vertical, 8)
                .foregroundStyle(.white)
                .glassCapsule(interactive: true)
        }
        .buttonStyle(.plain)
        .accessibilityLabel("تغيير الموقع")
    }

    private var methodPill: some View {
        Button(action: onMethod) {
            Label(method, systemImage: "slider.horizontal.3")
                .font(.subheadline.weight(.semibold))
                .lineLimit(1)
                .padding(.horizontal, 14).padding(.vertical, 8)
                .foregroundStyle(.white)
                .glassCapsule(tint: Brand.gold, interactive: true)
        }
        .buttonStyle(.plain)
        .accessibilityLabel("طريقة الحساب: \(method)")
    }
}

private struct PrayerTimeRow: View {
    let slot: PrayerTimes.Slot
    let time: String
    let isNext: Bool

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: slot.symbol)
                .font(.body.weight(.semibold))
                .foregroundStyle(isNext ? Brand.gold : Brand.emerald)
                .frame(width: 28)
            Text(slot.name)
                .font(isNext ? .body.weight(.heavy) : .body.weight(.semibold))
            if isNext { Tag(text: "القادمة", color: Brand.gold) }
            Spacer(minLength: 8)
            Text(time)
                .font(.body.weight(.bold).monospacedDigit())
                .foregroundStyle(isNext ? Brand.gold : .primary)
        }
        .padding(.vertical, 4)
        .listRowBackground(isNext ? Brand.gold.opacity(0.14) : Color(.secondarySystemGroupedBackground))
    }
}

private struct PrayerFadlRow: View {
    let name: String
    let detail: String
    let preferred: Bool

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Circle()
                .fill(preferred ? Brand.good : Brand.bad)
                .frame(width: 8, height: 8)
                .padding(.top, 6)
            VStack(alignment: .leading, spacing: 2) {
                Text(name).font(.subheadline.weight(.bold))
                Text(detail).font(.footnote).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 2)
    }
}

struct PrayerNafilaRow: View {
    let name: String
    let detail: String

    var body: some View {
        HStack(spacing: 9) {
            Circle().fill(Brand.gold).frame(width: 7, height: 7)
            Text(name).font(.subheadline.weight(.bold))
            Spacer(minLength: 8)
            Text(detail).font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.trailing)
        }
    }
}

// MARK: - مواقيت الأسبوع (ported from PrayerTableScreen)

struct PrayerTableView: View {
    @Environment(Store.self) private var store

    private static let cols: [(String, String)] = [
        ("fajr", "الفجر"), ("sunrise", "الشروق"), ("dhuhr", "الظهر"),
        ("asr", "العصر"), ("maghrib", "المغرب"), ("isha", "العشاء")
    ]

    var body: some View {
        ScreenScroll {
            Label(store.location().n, systemImage: "mappin.and.ellipse")
                .font(.headline.weight(.heavy))
                .foregroundStyle(Brand.emerald)
            ForEach(0..<7, id: \.self) { offset in
                dayCard(offset)
            }
            Text("الأوقات محسوبة فلكياً بحسب موقعك وتقريبية؛ يُحتاط في أوّل الوقت وآخره.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .navigationTitle(Tool.ptable.title)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func dayDate(_ offset: Int) -> Date {
        Calendar.current.date(byAdding: .day, value: offset, to: Date()) ?? Date()
    }

    private func dayCard(_ offset: Int) -> some View {
        let date = dayDate(offset)
        let t = store.times(for: date)
        let wd = Hijri.weekday(ofJd: Hijri.jd(of: date))
        let label = offset == 0 ? "اليوم" : Hijri.weekDays[max(0, min(6, wd))]
        let h = Hijri.jdToHijri(Hijri.jd(of: date), adj: store.hijriAdj)
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(label)
                    .font(.subheadline.weight(.heavy))
                    .foregroundStyle(offset == 0 ? Brand.gold : .primary)
                Spacer()
                Text(Hijri.format(h)).font(.caption).foregroundStyle(.secondary)
            }
            HStack(spacing: 2) {
                ForEach(Array(Self.cols.enumerated()), id: \.offset) { _, c in
                    VStack(spacing: 3) {
                        Text(c.1).font(.caption2.weight(.bold)).foregroundStyle(.secondary).lineLimit(1)
                        Text(PrayerTimes.fmt(PrayerTimes.value(t, c.0)))
                            .font(.caption.weight(.heavy).monospacedDigit())
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
        }
        .card(18, padding: 14)
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(offset == 0 ? Brand.gold : Color.clear, lineWidth: 1.5)
        )
    }
}
