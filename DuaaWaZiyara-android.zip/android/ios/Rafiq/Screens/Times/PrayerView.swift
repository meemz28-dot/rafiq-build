import SwiftUI

// MARK: - مواقيت الصلاة (v2): sky header with the city, the day's times in one card, the week strip, adhan cards.

struct PrayerView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.dismiss) private var dismiss
    @State private var dayOffset = 0        // -1 أمس · 0 اليوم · 1 غداً

    var body: some View {
        TimelineView(.periodic(from: .now, by: 30)) { context in
            PrayerContent(now: context.date, dayOffset: $dayOffset)
        }
        .toolbar(.hidden, for: .navigationBar)
        .onAppear { PrayerRoutines.refreshTimed(store: store) }
    }
}

private struct PrayerContent: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme
    let now: Date
    @Binding var dayOffset: Int

    private var day: Date { Calendar.current.date(byAdding: .day, value: dayOffset, to: now) ?? now }
    private var times: PrayerTimes.Times { store.times(for: day) }
    private var nextInfo: (key: String, hours: Double) { PrayerTimes.next(store.times(for: now), nowHours: PrayerTimes.nowHours(now)) }
    private var nextKey: String? { dayOffset == 0 ? nextInfo.key : nil }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                header
                VStack(alignment: .leading, spacing: 14) {
                    timesCard.padding(.top, -70)
                    weekStrip
                    adhanRow
                    fadlCard
                    nawafilCard
                    calendarBridge
                    Text("الأوقات محسوبة فلكياً بحسب موقعك وتقريبية، وقد تختلف دقائق عن التقويم المحلي. يُحتاط في أوّل الوقت وآخره.")
                        .font(.ui(.caption)).foregroundStyle(Brand.muted).multilineTextAlignment(.center).frame(maxWidth: .infinity)
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 28)
                .readableWidth()
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Brand.canvas)
    }

    // MARK: Header

    private var header: some View {
        let h = Hijri.jdToHijri(Hijri.jd(of: day), adj: store.hijriAdj)
        let wd = Hijri.weekday(ofJd: Hijri.jd(of: day))
        return ZStack(alignment: .top) {
            Brand.skyGradient(hour: 10, dark: scheme == .dark)
            GirihPattern().foregroundStyle(.white.opacity(scheme == .dark ? 0.06 : 0.22))
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    RoundIconButton(symbol: "chevron.backward", label: "رجوع", translucent: true) { dismiss() }
                    Spacer()
                    daySegments
                    Spacer()
                    RoundIconButton(symbol: "tablecells", label: Tool.ptable.title, translucent: true) { nav.openTool(.ptable) }
                }
                .padding(.top, 54)
                Spacer(minLength: 12)
                Button { nav.present(.location) } label: {
                    Text(store.location().n).font(.display(34)).foregroundStyle(scheme == .dark ? Color.white : Color(hex: 0x0F3B35)).lineLimit(1).minimumScaleFactor(0.6)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("تغيير الموقع")
                Button { nav.present(.method) } label: {
                    Text(verbatim: "\(Hijri.weekDays[max(0, min(6, wd))]) \(Hijri.format(h)) · \(PrayerTimes.method(store.method).name)")
                        .font(.ui(.footnote)).foregroundStyle(scheme == .dark ? Color.white.opacity(0.8) : Color(hex: 0x24524B)).lineLimit(1).minimumScaleFactor(0.8)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("طريقة الحساب")
                Spacer(minLength: 80)
            }
            .padding(.horizontal, 20)
        }
        .frame(height: 286)
        .clipped()
    }

    private var daySegments: some View {
        HStack(spacing: 2) {
            ForEach([(-1, "أمس"), (0, "اليوم"), (1, "غداً")], id: \.0) { t in
                Button { withAnimation(.snappy) { dayOffset = t.0 }; Haptic.tick() } label: {
                    Text(t.1).font(.ui(.caption, .bold))
                        .foregroundStyle(dayOffset == t.0 ? Brand.deeper : Color(hex: 0x0F3B35))
                        .padding(.horizontal, 12).frame(height: 34)
                        .background(dayOffset == t.0 ? Color.white : Color.clear, in: Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(dayOffset == t.0 ? .isSelected : [])
            }
        }
        .padding(3)
        .background(Color.white.opacity(0.35), in: Capsule())
        .overlay(Capsule().stroke(Color.white.opacity(0.6), lineWidth: 1))
    }

    // MARK: Times card

    private var countdownText: String {
        let total = max(0, Int(ceil(nextInfo.hours * 60)))
        let hh = total / 60, mm = total % 60
        if hh > 0 { return "بعد \(hh.ar):\(mm < 10 ? "٠" : "")\(mm.ar)" }
        if mm > 0 { return "بعد \(mm.ar) د" }
        return "الآن"
    }

    private var timesCard: some View {
        let live = store.bool("liveActivity", false)
        return VStack(spacing: 0) {
            ForEach(PrayerTimes.slots, id: \.key) { s in
                PrayerTimeRow(slot: s, time: PrayerTimes.fmt(PrayerTimes.value(times, s.key)),
                              isNext: s.key == nextKey, countdown: countdownText,
                              adhanOn: !store.strings("adhanOff").contains(s.key),
                              notify: store.bool("notify", false)) {
                    toggleAdhan(s.key)
                }
            }
            Divider().overlay(Brand.line)
            Button {
                store.put("liveActivity", !live)
                if live { PrayerLive.stop() } else { PrayerLive.start(store: store) }
                Haptic.tick()
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: live ? "timer.circle.fill" : "timer").foregroundStyle(live ? Brand.gold : Brand.accent)
                    Text(live ? "العدّاد على شاشة القفل مفعّل" : "أظهر العدّاد على شاشة القفل").font(.ui(.footnote, .semibold)).foregroundStyle(Brand.ink)
                    Spacer()
                    Image(systemName: live ? "checkmark.circle.fill" : "circle").foregroundStyle(live ? Brand.good : Brand.muted)
                }
                .padding(.horizontal, 18).padding(.vertical, 12)
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 6)
        .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        .shadow(color: Color(hex: 0x10322D).opacity(0.14), radius: 16, y: 8)
    }

    private func toggleAdhan(_ key: String) {
        guard PrayerTimes.prayerKeys.contains(key) else { return }
        var off = store.strings("adhanOff")
        if let i = off.firstIndex(of: key) { off.remove(at: i) } else { off.append(key) }
        store.put("adhanOff", off)
        Notifier.schedulePrayers(store: store)
        Haptic.tick()
    }

    // MARK: Week strip

    private var weekStrip: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("الأسبوع · المغرب").font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink)
                Spacer()
                Text(weekDrift).font(.ui(.caption)).foregroundStyle(Brand.muted)
            }
            HStack(spacing: 6) {
                ForEach(0..<7, id: \.self) { i in
                    let d = Calendar.current.date(byAdding: .day, value: i, to: now) ?? now
                    let t = store.times(for: d)
                    let wd = Hijri.weekday(ofJd: Hijri.jd(of: d))
                    VStack(spacing: 4) {
                        Text(Hijri.weekDays[max(0, min(6, wd))]).font(.ui(.caption2, .semibold)).lineLimit(1).minimumScaleFactor(0.7)
                        Text(PrayerTimes.fmt(t.maghrib).replacingOccurrences(of: " م", with: "")).font(.ui(.caption, .bold)).monospacedDigit().lineLimit(1).minimumScaleFactor(0.7)
                    }
                    .foregroundStyle(i == 0 ? Color.white : Brand.ink)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(i == 0 ? Brand.deeper : Brand.soft, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
            }
        }
        .card(22, padding: 14)
        .onTapGesture { nav.openTool(.ptable) }
    }

    private var weekDrift: String {
        let a = store.times(for: now).maghrib
        let b = store.times(for: Calendar.current.date(byAdding: .day, value: 6, to: now) ?? now).maghrib
        let perDay = (b - a) * 60 / 6
        if abs(perDay) < 0.3 { return "ثابت تقريباً" }
        return perDay > 0 ? "يتأخّر \(Int(perDay.rounded()).ar) دقيقة كلّ يوم" : "يتقدّم \(Int((-perDay).rounded()).ar) دقيقة كلّ يوم"
    }

    // MARK: Adhan cards

    private var adhanRow: some View {
        let on = store.bool("notify", false)
        let sound = Notifier.adhanSounds.first { $0.key == store.string("adhanSound", "takbir") }?.name ?? "أذان"
        let pre = store.int("preAdhan", 0)
        return HStack(spacing: 10) {
            Button { nav.present(.settings) } label: {
                HStack(spacing: 10) {
                    Image(systemName: "speaker.wave.2").foregroundStyle(Brand.accent)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("صوت الأذان").font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink)
                        Text(on ? "\(sound)\(pre > 0 ? " · تذكير قبل \(pre.ar) د" : "")" : "التنبيهات متوقّفة").font(.ui(.caption)).foregroundStyle(Brand.muted).lineLimit(1).minimumScaleFactor(0.8)
                    }
                    Spacer(minLength: 0)
                }
                .padding(14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            }
            .buttonStyle(.plain)
            Button {
                if on {
                    Notifier.previewAdhan(store.string("adhanSound", "takbir"))
                } else {
                    Task {
                        if await Notifier.requestPermission() {
                            store.put("notify", true)
                            Notifier.schedulePrayers(store: store)
                            Haptic.confirm()
                        }
                    }
                }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: on ? "checkmark" : "bell.badge").foregroundStyle(Brand.gold)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(on ? "اختبر التنبيه" : "فعّل الأذان").font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink)
                        Text(on ? "التنبيهات تعمل ✓" : "يصلك في وقته").font(.ui(.caption)).foregroundStyle(Brand.muted).lineLimit(1)
                    }
                    Spacer(minLength: 0)
                }
                .padding(14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: Virtue and disliked times

    private var fadlCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeading("أوقات الفضيلة والكراهة")
            VStack(alignment: .leading, spacing: 10) {
                PrayerFadlRow(name: "وقت فضيلة الفجر", detail: "من الطلوع الصادق حتى الإسفار (قبيل الشروق)", preferred: true)
                PrayerFadlRow(name: "وقت فضيلة الظهر", detail: "من الزوال إلى أن يصير ظلّ الشيء مثله", preferred: true)
                PrayerFadlRow(name: "وقت فضيلة العصر", detail: "بعد أداء الظهر إلى أن يصير الظلّ مثليه", preferred: true)
                PrayerFadlRow(name: "وقت فضيلة المغرب", detail: "أوّل دخول الوقت بعد ذهاب الحمرة المشرقية", preferred: true)
                PrayerFadlRow(name: "وقت فضيلة العشاء", detail: "من ذهاب الشفق إلى ثلث الليل", preferred: true)
                PrayerFadlRow(name: "يُكره النافلة المبتدأة", detail: "بعد صلاة الصبح حتى الشروق، وبعد العصر حتى الغروب", preferred: false)
                PrayerFadlRow(name: "عند طلوع الشمس وغروبها", detail: "يُكره التنفّل عند الشروق والاستواء والغروب", preferred: false)
            }
            .card()
        }
    }

    // MARK: Nawafil

    private var nawafilCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeading("الصلوات والنوافل اليومية") { Text("٣٤ ركعة").foregroundStyle(Brand.muted) }
            VStack(alignment: .leading, spacing: 10) {
                ForEach(Array(PrayerNawafil.rows.enumerated()), id: \.offset) { _, r in
                    PrayerNafilaRow(name: r.0, detail: r.1)
                }
                Text("وقت صلاة الليل: من منتصف الليل الشرعي (\(PrayerTimes.fmt(times.midnight))) حتى أذان الفجر. ويُزاد يوم الجمعة ٤ ركعات على النوافل.")
                    .font(.ui(.caption)).foregroundStyle(Brand.muted)
            }
            .card()
        }
    }

    private var calendarBridge: some View {
        Button { nav.openTool(.calendar) } label: {
            HStack(spacing: 12) {
                IconChip(symbol: "moon.fill", size: 40)
                VStack(alignment: .leading, spacing: 2) {
                    Text("الصلوات والنوافل وأعمال كلّ يوم").font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink)
                    Text("في التقويم — اختر أيّ يومٍ لترى عمله كاملاً").font(.ui(.caption)).foregroundStyle(Brand.accent)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.backward").font(.footnote.weight(.semibold)).foregroundStyle(Brand.muted)
            }
            .card()
        }
        .buttonStyle(.plain)
    }
}

/// Shared nawafil rows (also used by the calendar day panel).
enum PrayerNawafil {
    static let rows: [(String, String)] = [
        ("نافلة الفجر", "ركعتان قبل الفريضة"),
        ("نافلة الظهر", "٨ ركعات قبلها"),
        ("نافلة العصر", "٨ ركعات قبلها"),
        ("نافلة المغرب", "٤ ركعات بعدها"),
        ("الوتيرة (العشاء)", "ركعتان من جلوس بعدها"),
        ("صلاة الليل", "١١ ركعة: ٨ + الشفع ركعتان + الوتر ركعة")
    ]
}

// MARK: - Subviews

private struct PrayerTimeRow: View {
    let slot: PrayerTimes.Slot
    let time: String
    let isNext: Bool
    let countdown: String
    let adhanOn: Bool
    let notify: Bool
    let onBell: () -> Void

    private var isPrayer: Bool { PrayerTimes.prayerKeys.contains(slot.key) }

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: slot.symbol)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(isNext ? Color.white : (slot.key == "midnight" ? Brand.goldDeep : Brand.accent))
                .frame(width: 26)
            VStack(alignment: .leading, spacing: 1) {
                Text(slot.name)
                    .font(isNext ? .ui(.body, .heavy) : .ui(.body, .semibold))
                    .foregroundStyle(isNext ? Color.white : (slot.key == "midnight" ? Brand.goldDeep : Brand.ink))
                if isNext { Text(countdown).font(.ui(.caption2)).foregroundStyle(.white.opacity(0.85)) }
            }
            Spacer(minLength: 8)
            Text(time)
                .font(.ui(.body, .bold).monospacedDigit())
                .foregroundStyle(isNext ? Brand.goldSoft : (slot.key == "midnight" ? Brand.goldDeep : Brand.ink))
            if isPrayer {
                Button(action: onBell) {
                    Image(systemName: isNext ? "bell.fill" : (notify && adhanOn ? "bell" : "bell.slash"))
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(isNext ? Brand.goldSoft : (notify && adhanOn ? Brand.accent : Brand.muted.opacity(0.6)))
                        .frame(width: 32, height: 32)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(adhanOn ? "الأذان الكامل لصلاة \(slot.name) مفعّل" : "صوت التنبيه الافتراضي لصلاة \(slot.name)")
            } else {
                Color.clear.frame(width: 32, height: 32)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, isNext ? 12 : 9)
        .background(isNext ? Brand.heroGradient : LinearGradient(colors: [.clear], startPoint: .top, endPoint: .bottom),
                    in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .padding(.horizontal, isNext ? 6 : 0)
        .padding(.vertical, isNext ? 4 : 0)
    }
}

private struct PrayerFadlRow: View {
    let name: String
    let detail: String
    let preferred: Bool

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Circle()
                .fill(preferred ? Brand.good : Brand.bad)
                .frame(width: 8, height: 8)
                .padding(.top, 6)
            VStack(alignment: .leading, spacing: 2) {
                Text(name).font(.ui(.subheadline, .bold))
                Text(detail).font(.ui(.footnote)).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 2)
    }
}

struct PrayerNafilaRow: View {
    let name: String
    let detail: String

    var body: some View {
        HStack(spacing: 9) {
            Circle().fill(Brand.gold).frame(width: 7, height: 7)
            Text(name).font(.ui(.subheadline, .bold))
            Spacer(minLength: 8)
            Text(detail).font(.ui(.footnote)).foregroundStyle(.secondary).multilineTextAlignment(.trailing)
        }
    }
}

// MARK: - مواقيت الأسبوع (ported from PrayerTableScreen)

struct PrayerTableView: View {
    @Environment(Store.self) private var store

    private static let cols: [(String, String)] = [
        ("fajr", "الفجر"), ("sunrise", "الشروق"), ("dhuhr", "الظهر"),
        ("asr", "العصر"), ("maghrib", "المغرب"), ("isha", "العشاء")
    ]

    var body: some View {
        ScreenScroll {
            Label(store.location().n, systemImage: "mappin.and.ellipse")
                .font(.ui(.headline, .heavy))
                .foregroundStyle(Brand.emerald)
            ForEach(0..<7, id: \.self) { offset in
                dayCard(offset)
            }
            Text("الأوقات محسوبة فلكياً بحسب موقعك وتقريبية؛ يُحتاط في أوّل الوقت وآخره.")
                .font(.ui(.footnote))
                .foregroundStyle(.secondary)
        }
        .navigationTitle(Tool.ptable.title)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func dayDate(_ offset: Int) -> Date {
        Calendar.current.date(byAdding: .day, value: offset, to: Date()) ?? Date()
    }

    private func dayCard(_ offset: Int) -> some View {
        let date = dayDate(offset)
        let t = store.times(for: date)
        let wd = Hijri.weekday(ofJd: Hijri.jd(of: date))
        let label = offset == 0 ? "اليوم" : Hijri.weekDays[max(0, min(6, wd))]
        let h = Hijri.jdToHijri(Hijri.jd(of: date), adj: store.hijriAdj)
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(label)
                    .font(.ui(.subheadline, .heavy))
                    .foregroundStyle(offset == 0 ? Brand.gold : .primary)
                Spacer()
                Text(Hijri.format(h)).font(.ui(.caption)).foregroundStyle(.secondary)
            }
            HStack(spacing: 2) {
                ForEach(Array(Self.cols.enumerated()), id: \.offset) { _, c in
                    VStack(spacing: 3) {
                        Text(c.1).font(.ui(.caption2, .bold)).foregroundStyle(.secondary).lineLimit(1)
                        Text(PrayerTimes.fmt(PrayerTimes.value(t, c.0)))
                            .font(.ui(.caption, .heavy).monospacedDigit())
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
        }
        .card(18, padding: 14)
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(offset == 0 ? Brand.gold : Color.clear, lineWidth: 1.5)
        )
    }
}
