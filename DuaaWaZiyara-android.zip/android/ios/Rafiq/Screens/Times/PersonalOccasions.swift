import SwiftUI
import UserNotifications

// MARK: - مناسباتي: personal yearly Hijri occasions (death anniversaries, births, vows…)

enum PersonalKind: String, Codable, CaseIterable, Identifiable {
    case death, birth, vow, marriage, other
    var id: String { rawValue }

    var title: String {
        switch self {
        case .death: return "ذكرى وفاة"
        case .birth: return "مولد"
        case .vow: return "نذر"
        case .marriage: return "زواج"
        case .other: return "مناسبة"
        }
    }

    var symbol: String {
        switch self {
        case .death: return "leaf.fill"
        case .birth: return "gift.fill"
        case .vow: return "hand.raised.fill"
        case .marriage: return "heart.fill"
        case .other: return "star.fill"
        }
    }

    var color: Color {
        switch self {
        case .death: return Color(red: 0.36, green: 0.42, blue: 0.47)
        case .birth: return Brand.gold
        case .vow: return Brand.emerald
        case .marriage: return Color(red: 0.75, green: 0.36, blue: 0.42)
        case .other: return Brand.deep
        }
    }

    /// What is usually done on the day, with a reader shortcut (category, item).
    var deeds: [(String, String, String)] {
        switch self {
        case .death:
            return [("اقرأ الفاتحة وأهدِ ثوابها", "quran", "q-001"),
                    ("سورة يس", "quran", "q-036"),
                    ("سورة الملك", "quran", "q-067")]
        case .birth, .marriage:
            return [("سورة الفاتحة شكراً لله", "quran", "q-001")]
        case .vow, .other:
            return []
        }
    }
}

struct PersonalOccasion: Codable, Identifiable, Hashable {
    var id: String = UUID().uuidString
    var name: String
    var kind: PersonalKind
    var month: Int          // Hijri 1...12
    var day: Int            // 1...30
    var year: Int?          // Hijri year of the original event (optional, for "the Nth anniversary")
    var remind: Bool = true
    var daysBefore: Int = 1 // 0 = on the day only
    var note: String = ""
}

enum PersonalOccasions {
    static let key = "personalOccasions"

    static func load(_ store: Store) -> [PersonalOccasion] {
        guard let data = store.string(key).data(using: .utf8),
              let list = try? JSONDecoder().decode([PersonalOccasion].self, from: data) else { return [] }
        return list
    }

    static func save(_ store: Store, _ list: [PersonalOccasion]) {
        if let data = try? JSONEncoder().encode(list), let s = String(data: data, encoding: .utf8) {
            store.put(key, s)
        }
        reschedule(store)
    }

    static func upsert(_ store: Store, _ o: PersonalOccasion) {
        var list = load(store)
        if let i = list.firstIndex(where: { $0.id == o.id }) { list[i] = o } else { list.append(o) }
        save(store, list)
    }

    static func remove(_ store: Store, _ id: String) { save(store, load(store).filter { $0.id != id }) }

    /// Next occurrence (today counts) as a Julian day, clamping day 30 to 29 in short months.
    static func nextJd(_ o: PersonalOccasion, store: Store) -> Int {
        let adj = store.hijriAdj
        let t = store.hijriToday()
        let todayJd = Hijri.jd(of: Date())
        for y in [t.y, t.y + 1] {
            let d = min(o.day, Hijri.monthLength(y, o.month, adj: adj))
            let jd = Hijri.hijriToJd(y, o.month, d, adj: adj)
            if jd >= todayJd { return jd }
        }
        return todayJd
    }

    static func daysLeft(_ o: PersonalOccasion, store: Store) -> Int { nextJd(o, store: store) - Hijri.jd(of: Date()) }

    static func dateText(_ o: PersonalOccasion) -> String {
        "\(o.day.ar) \(Hijri.months[max(0, min(11, o.month - 1))])"
    }

    static func countdown(_ n: Int) -> String {
        switch n {
        case 0: return "اليوم"
        case 1: return "غداً"
        case 2: return "بعد يومين"
        default: return "بعد \(n.ar) يوماً"
        }
    }

    /// The anniversary number, if the original year is known ("الذكرى الخامسة" style as a number).
    static func anniversary(_ o: PersonalOccasion, store: Store) -> Int? {
        guard let y0 = o.year else { return nil }
        let h = Hijri.jdToHijri(nextJd(o, store: store), adj: store.hijriAdj)
        let n = h.y - y0
        return n > 0 ? n : nil
    }

    static func upcoming(_ store: Store) -> [PersonalOccasion] {
        load(store).sorted { daysLeft($0, store: store) < daysLeft($1, store: store) }
    }

    // MARK: Reminders (next occurrence only, re-armed whenever the app becomes active)

    static func reschedule(_ store: Store) {
        let center = UNUserNotificationCenter.current()
        center.getPendingNotificationRequests { reqs in
            let old = reqs.map { $0.identifier }.filter { $0.hasPrefix("po-") }
            center.removePendingNotificationRequests(withIdentifiers: old)
            DispatchQueue.main.async { scheduleAll(store) }
        }
    }

    private static func scheduleAll(_ store: Store) {
        let list = load(store).filter { $0.remind }
        let center = UNUserNotificationCenter.current()
        for o in list.prefix(8) {
            let jd = nextJd(o, store: store)
            var offsets = [0]
            if o.daysBefore > 0 { offsets.append(o.daysBefore) }
            for off in offsets {
                let day = Hijri.date(fromJd: jd - off)
                var dc = Calendar.current.dateComponents([.year, .month, .day], from: day)
                dc.hour = off == 0 ? 8 : 20
                dc.minute = 0
                guard let when = Calendar.current.date(from: dc), when > Date() else { continue }
                let c = UNMutableNotificationContent()
                c.title = off == 0 ? "\(o.kind.title): \(o.name)" : "\(countdown(off)): \(o.kind.title) \(o.name)"
                c.body = off == 0
                    ? (o.kind == .death ? "اليوم ذكرى \(o.name)، فلا تنسَه من الفاتحة والدعاء." : "اليوم \(dateText(o)). \(o.note)")
                    : "\(dateText(o)) هـ. \(o.note)"
                c.sound = .default
                center.add(UNNotificationRequest(identifier: "po-\(o.id)-\(off)", content: c,
                                                 trigger: UNCalendarNotificationTrigger(dateMatching: dc, repeats: false)))
            }
        }
    }
}

// MARK: - Section shown in the Calendar

struct PersonalOccasionsSection: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @State private var editing: PersonalOccasion?
    @State private var showAll = false

    var body: some View {
        let list = PersonalOccasions.upcoming(store)
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("مناسباتي", systemImage: "person.2.fill").font(.headline)
                Spacer()
                Button {
                    let h = store.hijriToday()
                    editing = PersonalOccasion(name: "", kind: .death, month: h.m, day: h.d)
                } label: {
                    Label("إضافة", systemImage: "plus.circle.fill").font(.subheadline.weight(.bold))
                }
            }
            if list.isEmpty {
                Text("أضف ذكرى وفاة عزيز، أو مولداً، أو موعد نذر؛ تتكرّر كلّ عام بالتاريخ الهجري ويذكّرك التطبيق بها.")
                    .font(.footnote).foregroundStyle(.secondary)
            } else {
                ForEach(showAll ? list : Array(list.prefix(4))) { o in
                    Button { editing = o } label: { PersonalOccasionRow(o: o) }
                        .buttonStyle(.plain)
                }
                if list.count > 4 {
                    Button(showAll ? "عرض أقل" : "عرض الكلّ (\(list.count.ar))") { withAnimation { showAll.toggle() } }
                        .font(.footnote.weight(.bold))
                }
            }
        }
        .card()
        .sheet(item: $editing) { o in
            NavigationStack { PersonalOccasionEditor(original: o) }
                .environment(store).environment(nav)
                .environment(\.layoutDirection, .rightToLeft)
        }
    }
}

struct PersonalOccasionRow: View {
    @Environment(Store.self) private var store
    let o: PersonalOccasion

    var body: some View {
        let left = PersonalOccasions.daysLeft(o, store: store)
        HStack(spacing: 12) {
            Image(systemName: o.kind.symbol)
                .font(.system(size: 15, weight: .bold)).foregroundStyle(.white)
                .frame(width: 38, height: 38)
                .background(RoundedRectangle(cornerRadius: 11).fill(o.kind.color))
            VStack(alignment: .leading, spacing: 2) {
                Text(o.name.isEmpty ? o.kind.title : o.name).font(.subheadline.weight(.semibold))
                HStack(spacing: 4) {
                    Text(verbatim: "\(o.kind.title) · \(PersonalOccasions.dateText(o))")
                    if let n = PersonalOccasions.anniversary(o, store: store), o.kind != .vow {
                        Text("· الـ\(n.ar)")
                    }
                }
                .font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Text(PersonalOccasions.countdown(left))
                .font(.caption.weight(.heavy))
                .foregroundStyle(left <= 1 ? Color.white : Brand.emerald)
                .padding(.horizontal, 10).padding(.vertical, 5)
                .background(Capsule().fill(left <= 1 ? Brand.gold : Brand.emerald.opacity(0.12)))
        }
        .contentShape(Rectangle())
    }
}

// MARK: - Home banner when an occasion is today or tomorrow

struct PersonalOccasionsHomeBanner: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    var body: some View {
        let soon = PersonalOccasions.upcoming(store).filter { PersonalOccasions.daysLeft($0, store: store) <= 1 }
        if let o = soon.first {
            let left = PersonalOccasions.daysLeft(o, store: store)
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 10) {
                    Image(systemName: o.kind.symbol).foregroundStyle(Brand.gold)
                    Text(verbatim: "\(PersonalOccasions.countdown(left)): \(o.kind.title) \(o.name)")
                        .font(.subheadline.weight(.heavy))
                    Spacer()
                }
                if let d = o.kind.deeds.first {
                    Button {
                        nav.openReader(d.1, d.2)
                    } label: {
                        Label(d.0, systemImage: "book.fill").font(.footnote.weight(.bold))
                    }
                    .glassButton()
                }
            }
            .padding(16)
            .hero(22)
        }
    }
}

// MARK: - Editor

struct PersonalOccasionEditor: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.dismiss) private var dismiss
    let original: PersonalOccasion
    @State private var o: PersonalOccasion
    @State private var knowsYear = false
    @State private var fromGregorian = false
    @State private var gDate = Date()

    init(original: PersonalOccasion) {
        self.original = original
        _o = State(initialValue: original)
        _knowsYear = State(initialValue: original.year != nil)
    }

    private var isNew: Bool { PersonalOccasions.load(store).first { $0.id == original.id } == nil }

    var body: some View {
        Form {
            Section {
                Picker("النوع", selection: $o.kind) {
                    ForEach(PersonalKind.allCases) { k in Label(k.title, systemImage: k.symbol).tag(k) }
                }
                TextField(o.kind == .death ? "اسم الفقيد (مثلاً: الوالد رحمه الله)" : "الاسم أو الوصف", text: $o.name)
            }

            Section {
                Toggle("أعرف التاريخ الميلادي فقط", isOn: $fromGregorian)
                if fromGregorian {
                    DatePicker("التاريخ الميلادي", selection: $gDate, displayedComponents: .date)
                        .environment(\.calendar, Calendar(identifier: .gregorian))
                        .onChange(of: gDate) { _, d in applyGregorian(d) }
                    Text("يُحوَّل إلى: " + convertedText)
                        .font(.footnote).foregroundStyle(.secondary)
                } else {
                    Picker("الشهر الهجري", selection: $o.month) {
                        ForEach(1...12, id: \.self) { m in Text(Hijri.months[m - 1]).tag(m) }
                    }
                    Picker("اليوم", selection: $o.day) {
                        ForEach(1...30, id: \.self) { d in Text(d.ar).tag(d) }
                    }
                    Toggle("أعرف السنة الهجرية", isOn: $knowsYear)
                    if knowsYear {
                        Stepper(value: Binding(get: { o.year ?? store.hijriToday().y }, set: { o.year = $0 }),
                                in: 1300...store.hijriToday().y) {
                            Text("السنة: \((o.year ?? store.hijriToday().y).ar) هـ")
                        }
                    }
                }
            } header: {
                Text("التاريخ")
            } footer: {
                Text("تتكرّر المناسبة كلّ عام في التاريخ الهجري نفسه؛ ويُعتمد تعديل الهلال من الإعدادات.")
            }

            Section("التذكير") {
                Toggle("ذكّرني", isOn: $o.remind)
                if o.remind {
                    Picker("قبلها بـ", selection: $o.daysBefore) {
                        Text("في اليوم نفسه فقط").tag(0)
                        Text("يوم").tag(1)
                        Text("ثلاثة أيام").tag(3)
                        Text("أسبوع").tag(7)
                    }
                }
                TextField("ملاحظة (اختياري)", text: $o.note, axis: .vertical)
            }

            if !o.kind.deeds.isEmpty {
                Section("ممّا يُستحبّ في هذا اليوم") {
                    ForEach(Array(o.kind.deeds.enumerated()), id: \.offset) { _, d in
                        Button {
                            dismiss()
                            nav.openReader(d.1, d.2)
                        } label: { Label(d.0, systemImage: "book") }
                    }
                }
            }

            if !isNew {
                Section {
                    Button("حذف المناسبة", role: .destructive) {
                        PersonalOccasions.remove(store, o.id)
                        dismiss()
                    }
                }
            }
        }
        .navigationTitle(isNew ? "مناسبة جديدة" : "تعديل المناسبة")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("إلغاء") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("حفظ") {
                    var v = o
                    if !knowsYear && !fromGregorian { v.year = nil }
                    v.name = v.name.trimmingCharacters(in: .whitespacesAndNewlines)
                    PersonalOccasions.upsert(store, v)
                    if v.remind { Task { _ = await Notifier.requestPermission() } }
                    Haptic.confirm()
                    dismiss()
                }
                .fontWeight(.bold)
            }
        }
    }

    private var convertedText: String {
        let y = o.year.map { " " + $0.ar + " هـ" } ?? ""
        return o.day.ar + " " + Hijri.months[max(0, min(11, o.month - 1))] + y
    }

    private func applyGregorian(_ d: Date) {
        let h = Hijri.jdToHijri(Hijri.jd(of: d), adj: store.hijriAdj)
        o.month = h.m
        o.day = h.d
        o.year = h.y
        knowsYear = true
    }
}
