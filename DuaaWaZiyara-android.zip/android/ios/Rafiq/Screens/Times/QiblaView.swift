import SwiftUI
import CoreLocation

// MARK: - اتجاه القبلة (ported from Android ui/QiblaScreen.kt)

struct QiblaView: View {
    @Environment(Store.self) private var store
    @State private var service = LocationService()
    @State private var hasCompass = CLLocationManager.headingAvailable()

    @State private var sunToday: [Qibla.SunAlignment] = []
    @State private var sunNext: Date?

    private var city: City { store.location() }
    /// A live GPS fix (within 3 km) beats the saved city; preset cities can be tens of km off.
    private var gps: CLLocation? {
        guard let l = service.location, l.horizontalAccuracy >= 0, l.horizontalAccuracy <= 3000 else { return nil }
        return l
    }
    private var originLat: Double { gps?.coordinate.latitude ?? city.lat }
    private var originLng: Double { gps?.coordinate.longitude ?? city.lng }
    private var originName: String { gps != nil ? "موقعك الحالي" : city.n }
    private var bearing: Double { Qibla.bearing(lat: originLat, lng: originLng) }
    private var heading: Double { service.heading ?? 0 }
    /// Angle of the Qibla relative to the top of the device, 0..360.
    private var needle: Double {
        let v = (bearing - heading).truncatingRemainder(dividingBy: 360)
        return v < 0 ? v + 360 : v
    }
    /// Same angle without wrapping, so the needle never spins the long way round.
    private var needleContinuous: Double { bearing - service.continuousHeading }
    private var aligned: Bool { service.heading != nil && (needle < 3 || needle > 357) }
    private var distanceKm: Int { Int(Qibla.distanceKm(lat: originLat, lng: originLng).rounded()) }
    private var sunKey: String { "\(Int(originLat * 20))_\(Int(originLng * 20))" }

    var body: some View {
        ZStack {
            QiblaBackground()
            if hasCompass {
                compassContent
            } else {
                noSensor
            }
        }
        .navigationTitle(Tool.qibla.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .keepScreenAwake(true)
        .onAppear { if hasCompass { service.startHeading() } }
        .onDisappear { service.stopHeading() }
        .onChange(of: aligned) { _, isAligned in
            if isAligned { Haptic.confirm() }
        }
        .task(id: sunKey) {
            let lat = originLat, lng = originLng
            sunToday = Qibla.sunAlignments(on: Date(), lat: lat, lng: lng)
            sunNext = sunToday.isEmpty ? Qibla.nextAlignmentDay(after: Date(), lat: lat, lng: lng) : nil
        }
    }

    private var noSensor: some View {
        Text("جهازك لا يحتوي مُستشعِر البوصلة اللازم لتحديد القبلة.")
            .font(.body.weight(.semibold))
            .multilineTextAlignment(.center)
            .foregroundStyle(.white)
            .padding(22)
            .glass(22)
            .padding(24)
    }

    private var compassContent: some View {
        ScrollView {
            VStack(spacing: 14) {
                Text("اتجاه القبلة من \(originName): \(String(format: "%.1f", bearing).arabicDigits)°")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white.opacity(0.85))
                statusRow
                guidance
                QiblaCompass(dialAngle: service.continuousHeading, needle: needleContinuous, aligned: aligned)
                    .animation(.easeOut(duration: 0.2), value: service.continuousHeading)
                    .frame(width: 300, height: 300)
                    .padding(.vertical, 12)
                Text("الكعبة المشرّفة تبعد نحو \(Khums.money(Double(distanceKm))) كم")
                    .font(.footnote.weight(.bold))
                    .foregroundStyle(Brand.gold)
                VStack(spacing: 2) {
                    Text("\(Int(heading.rounded()).ar)°")
                        .font(.counter(40))
                        .foregroundStyle(.white)
                        .contentTransition(.numericText())
                    Text("اتجاه جهازك عن الشمال").font(.caption).foregroundStyle(.white.opacity(0.7))
                }
                .padding(.top, 6)
                sunCheck
                Text("أمسك الجهاز مسطّحاً وابتعد عن المعادن والشواحن لدقّةٍ أعلى. إن بدا الاتجاه خاطئاً فعاير البوصلة بتحريك الجهاز على شكل ٨.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.85))
                    .multilineTextAlignment(.center)
                    .padding(14)
                    .frame(maxWidth: .infinity)
                    .glass(18)
                    .padding(.top, 10)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 20)
        }
    }

    /// Where the bearing comes from and how much to trust the compass right now.
    private var statusRow: some View {
        HStack(spacing: 8) {
            Label(gps != nil ? "GPS" : "المدينة المحفوظة", systemImage: gps != nil ? "location.fill" : "building.2")
            if service.heading != nil {
                Text(service.trueNorth ? "شمال حقيقي" : "شمال مغناطيسي")
                if service.headingAccuracy >= 0 {
                    Text("دقّة ±\(Int(service.headingAccuracy.rounded()).ar)°")
                }
            }
        }
        .font(.caption2.weight(.bold))
        .foregroundStyle(.white)
        .padding(.horizontal, 12).padding(.vertical, 6)
        .glassCapsule()
    }

    private static let timeFmt: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "ar"); f.dateFormat = "h:mm a"; return f
    }()
    private static let dayFmt: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "ar"); f.dateFormat = "EEEE d MMMM"; return f
    }()

    /// Compass-free check: moments when the sun itself points to the Qibla.
    private var sunCheck: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("تحقّق بالشمس دون بوصلة", systemImage: "sun.max.fill")
                .font(.subheadline.weight(.heavy))
                .foregroundStyle(Brand.gold)
            if sunToday.isEmpty {
                Text("لا تمرّ الشمس اليوم باتجاه القبلة من \(originName).")
                    .font(.footnote).foregroundStyle(.white.opacity(0.85))
                if let next = sunNext {
                    Text("أقرب موعد: \(Self.dayFmt.string(from: next))")
                        .font(.footnote.weight(.bold)).foregroundStyle(.white)
                }
            } else {
                ForEach(Array(sunToday.enumerated()), id: \.offset) { _, a in
                    HStack(alignment: .top, spacing: 8) {
                        Text(Self.timeFmt.string(from: a.date))
                            .font(.footnote.weight(.heavy)).foregroundStyle(.white)
                            .frame(minWidth: 64, alignment: .leading)
                        Text(a.toward ? "الشمس في جهة القبلة تماماً: استقبِلها تكن مستقبلاً للقبلة."
                                      : "الشمس خلف القبلة تماماً: ظلّ أيّ شاخصٍ قائمٍ يشير إلى القبلة.")
                            .font(.footnote).foregroundStyle(.white.opacity(0.85))
                    }
                }
            }
            Text("وفي كلّ عام تتعامد الشمس على الكعبة يومي ٢٧ و٢٨ مايو الساعة ١٢:١٨ ظهراً، و١٥ و١٦ يوليو الساعة ١٢:٢٧ ظهراً بتوقيت مكة؛ فظلّ أيّ عمودٍ حينها يشير إلى عكس القبلة في كلّ بلدٍ تكون فيه الشمس ظاهرة.")
                .font(.caption2).foregroundStyle(.white.opacity(0.7))
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(18)
        .padding(.top, 6)
    }

    @ViewBuilder private var guidance: some View {
        if aligned {
            Label("أنت موجَّه نحو القبلة الآن", systemImage: "checkmark.circle.fill")
                .font(.subheadline.weight(.heavy))
                .foregroundStyle(.white)
                .padding(.horizontal, 16).padding(.vertical, 8)
                .glassCapsule(tint: Brand.good)
        } else if service.heading == nil {
            Text(service.errorText ?? "جارٍ قراءة البوصلة…")
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.75))
        } else if service.needsCalibration {
            Text("⚠ البوصلة تحتاج معايرة — حرّك جهازك على شكل ٨ بعيداً عن المعادن والشواحن، وإلا فالاتجاه غير دقيق.")
                .font(.footnote.weight(.semibold))
                .multilineTextAlignment(.center)
                .foregroundStyle(.white)
                .padding(.horizontal, 14).padding(.vertical, 10)
                .glass(16, tint: Brand.gold)
        } else {
            Text("أدِر جهازك حتى تستقيم الكعبة لأعلى")
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.75))
        }
    }
}

private struct QiblaBackground: View {
    var body: some View {
        ZStack {
            Brand.heroGradient
            StarPattern().foregroundStyle(.white.opacity(0.06))
        }
        .ignoresSafeArea()
    }
}

/// Glass dial that turns against the device heading, with the Kaaba marker and a gold needle.
private struct QiblaCompass: View {
    let dialAngle: Double
    let needle: Double
    let aligned: Bool

    var body: some View {
        GeometryReader { geo in
            let size = min(geo.size.width, geo.size.height)
            let radius = size / 2
            ZStack {
                Circle()
                    .fill(Color.white.opacity(0.001))
                    .glassCircle(tint: aligned ? Brand.good : nil)
                QiblaDial()
                    .foregroundStyle(.white)
                    .rotationEffect(.degrees(-dialAngle))
                QiblaNeedle(color: aligned ? Brand.good : Brand.gold)
                    .rotationEffect(.degrees(needle))
                QiblaKaaba(highlight: aligned ? Brand.good : Brand.gold)
                    .frame(width: 44, height: 44)
                    .offset(x: CGFloat(sin(needle * .pi / 180)) * radius * 0.70,
                            y: -CGFloat(cos(needle * .pi / 180)) * radius * 0.70)
                Circle().fill(Brand.emerald).frame(width: 18, height: 18)
                Circle().fill(Color.white).frame(width: 7, height: 7)
            }
            .frame(width: size, height: size)
            .position(x: geo.size.width / 2, y: geo.size.height / 2)
        }
        // Geometry is absolute (north up); keep it unaffected by the RTL layout.
        .environment(\.layoutDirection, .leftToRight)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(aligned ? "أنت موجَّه نحو القبلة الآن" : "أدِر جهازك حتى تستقيم الكعبة لأعلى")
    }
}

private struct QiblaDial: View {
    var body: some View {
        GeometryReader { geo in
            let s = min(geo.size.width, geo.size.height)
            ZStack {
                Canvas { ctx, size in
                    let r = min(size.width, size.height) / 2 - 2
                    let c = CGPoint(x: size.width / 2, y: size.height / 2)
                    var outer = Path()
                    outer.addEllipse(in: CGRect(x: c.x - r, y: c.y - r, width: 2 * r, height: 2 * r))
                    ctx.stroke(outer, with: .color(Color.white.opacity(0.35)), lineWidth: 1.5)
                    var inner = Path()
                    let ri = r * 0.72
                    inner.addEllipse(in: CGRect(x: c.x - ri, y: c.y - ri, width: 2 * ri, height: 2 * ri))
                    ctx.stroke(inner, with: .color(Color.white.opacity(0.18)), lineWidth: 1)
                    for i in 0..<72 {
                        let a = Double(i) * 5 * .pi / 180
                        let long = i % 6 == 0
                        let rIn = r - (long ? 16 : 8)
                        var p = Path()
                        p.move(to: CGPoint(x: c.x + CGFloat(sin(a)) * rIn, y: c.y - CGFloat(cos(a)) * rIn))
                        p.addLine(to: CGPoint(x: c.x + CGFloat(sin(a)) * r, y: c.y - CGFloat(cos(a)) * r))
                        ctx.stroke(p, with: .color(long ? Brand.gold : Color.white.opacity(0.4)), lineWidth: long ? 2.5 : 1)
                    }
                }
                Text("ش")
                    .font(.caption.weight(.heavy))
                    .foregroundStyle(Brand.gold)
                    .position(x: s / 2, y: 28)
            }
        }
    }
}

private struct QiblaNeedle: View {
    let color: Color

    var body: some View {
        GeometryReader { geo in
            let s = min(geo.size.width, geo.size.height)
            Capsule()
                .fill(LinearGradient(colors: [color, color.opacity(0.35)], startPoint: .top, endPoint: .bottom))
                .frame(width: 6, height: s * 0.24)
                .position(x: geo.size.width / 2, y: geo.size.height / 2 - s * 0.15)
        }
    }
}

/// Kaaba glyph: black cube with a gold kiswa band and door, framed in the highlight colour.
private struct QiblaKaaba: View {
    let highlight: Color

    var body: some View {
        GeometryReader { geo in
            let s = min(geo.size.width, geo.size.height)
            let gold = Color(red: 0xC9 / 255, green: 0xA8 / 255, blue: 0x6A / 255)
            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: s * 0.08)
                    .fill(Color(red: 0.08, green: 0.08, blue: 0.08))
                Rectangle().fill(gold)
                    .frame(width: s, height: s * 0.10)
                    .offset(y: s * 0.26)
                Rectangle().fill(gold)
                    .frame(width: s * 0.16, height: s * 0.36)
                    .offset(x: s * 0.42, y: s * 0.58)
                RoundedRectangle(cornerRadius: s * 0.08)
                    .stroke(highlight, lineWidth: s * 0.06)
            }
            .frame(width: s, height: s)
            .clipShape(RoundedRectangle(cornerRadius: s * 0.08))
            .shadow(color: .black.opacity(0.35), radius: 4, y: 2)
        }
    }
}
