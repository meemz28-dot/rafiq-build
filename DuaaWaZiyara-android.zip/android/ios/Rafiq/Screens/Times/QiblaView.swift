import SwiftUI
import CoreLocation

// MARK: - اتجاه القبلة (ported from Android ui/QiblaScreen.kt)

/// A shrine for ziyara from afar (coordinates of the holy shrine, to about 100 m).
struct ShrineTarget: Hashable { let name: String; let place: String; let lat: Double; let lng: Double }

let shrineTargets: [ShrineTarget] = [
    ShrineTarget(name: "حرم الإمام الحسين (ع)", place: "كربلاء", lat: 32.6164, lng: 44.0322),
    ShrineTarget(name: "حرم أبي الفضل العباس (ع)", place: "كربلاء", lat: 32.6176, lng: 44.0353),
    ShrineTarget(name: "حرم أمير المؤمنين (ع)", place: "النجف الأشرف", lat: 31.9961, lng: 44.3143),
    ShrineTarget(name: "حرم الإمامين الكاظمين (ع)", place: "الكاظمية", lat: 33.3800, lng: 44.3378),
    ShrineTarget(name: "حرم الإمامين العسكريين (ع)", place: "سامراء", lat: 34.1986, lng: 43.8736),
    ShrineTarget(name: "حرم الإمام الرضا (ع)", place: "مشهد", lat: 36.2880, lng: 59.6155),
    ShrineTarget(name: "المسجد النبوي الشريف", place: "المدينة المنورة", lat: 24.4672, lng: 39.6112),
    ShrineTarget(name: "البقيع الغرقد", place: "المدينة المنورة", lat: 24.4673, lng: 39.6164),
    ShrineTarget(name: "حرم السيدة زينب (ع)", place: "دمشق", lat: 33.4443, lng: 36.3409),
    ShrineTarget(name: "حرم السيدة المعصومة (ع)", place: "قم", lat: 34.6418, lng: 50.8788)
]

struct QiblaView: View {
    /// Shrine mode turns the Qibla compass into a ziyara compass pointing to a chosen shrine.
    let shrineMode: Bool
    init(shrineMode: Bool = false) { self.shrineMode = shrineMode }

    @Environment(Store.self) private var store
    @State private var shrineIdx = 0
    @State private var sheet: QiblaSheet?
    @State private var service = LocationService()
    @State private var hasCompass = CLLocationManager.headingAvailable()

    @State private var sunToday: [Qibla.SunAlignment] = []
    @State private var sunNext: Date?

    private var city: City { store.location() }
    /// A live GPS fix (within 3 km) beats the saved city; preset cities can be tens of km off.
    private var gps: CLLocation? {
        guard let l = service.location, l.horizontalAccuracy >= 0, l.horizontalAccuracy <= 3000 else { return nil }
        return l
    }
    private var originLat: Double { gps?.coordinate.latitude ?? city.lat }
    private var originLng: Double { gps?.coordinate.longitude ?? city.lng }
    private var originName: String { gps != nil ? "موقعك الحالي" : city.n }
    private var shrine: ShrineTarget { shrineTargets[max(0, min(shrineTargets.count - 1, shrineIdx))] }
    private var targetName: String { shrineMode ? shrine.name : "القبلة" }
    private var bearing: Double {
        shrineMode ? Qibla.bearing(lat: originLat, lng: originLng, toLat: shrine.lat, toLng: shrine.lng)
                   : Qibla.bearing(lat: originLat, lng: originLng)
    }
    private var heading: Double { service.heading ?? 0 }
    /// Angle of the Qibla relative to the top of the device, 0..360.
    private var needle: Double {
        let v = (bearing - heading).truncatingRemainder(dividingBy: 360)
        return v < 0 ? v + 360 : v
    }
    /// Same angle without wrapping, so the needle never spins the long way round.
    private var needleContinuous: Double { bearing - service.continuousHeading }
    private var aligned: Bool { service.heading != nil && (needle < 3 || needle > 357) }
    private var distanceKm: Int {
        let d = shrineMode ? Qibla.distanceKm(lat: originLat, lng: originLng, toLat: shrine.lat, toLng: shrine.lng)
                           : Qibla.distanceKm(lat: originLat, lng: originLng)
        return Int(d.rounded())
    }
    private var sunKey: String { "\(Int(originLat * 20))_\(Int(originLng * 20))" }

    var body: some View {
        ZStack {
            QiblaBackground()
            if hasCompass {
                compassContent
            } else {
                noSensor
            }
        }
        .navigationTitle(shrineMode ? Tool.shrine.title : Tool.qibla.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar)
        .sheet(item: $sheet) { kind in
            NavigationStack {
                ScrollView {
                    VStack(alignment: .leading, spacing: 14) {
                        if kind == .sun { sunCheck } else { tipsContent }
                    }
                    .padding(16)
                }
                .scrollBounceBehavior(.basedOnSize)
                .navigationTitle(kind == .sun ? "التحقّق بالشمس" : "الدقّة والمعايرة")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("تم") { sheet = nil } } }
                .tealScreen()
            }
            .presentationDetents([.medium, .large])
            .presentationBackground(Brand.deeper)
            .environment(\.layoutDirection, .rightToLeft)
        }
        .keepScreenAwake(true)
        .onAppear { if hasCompass { service.startHeading() } }
        .onDisappear { service.stopHeading() }
        .onChange(of: aligned) { _, isAligned in
            if isAligned { Haptic.confirm() }
        }
        .task(id: sunKey) {
            let lat = originLat, lng = originLng
            sunToday = Qibla.sunAlignments(on: Date(), lat: lat, lng: lng)
            sunNext = sunToday.isEmpty ? Qibla.nextAlignmentDay(after: Date(), lat: lat, lng: lng) : nil
        }
    }

    /// No magnetometer (iPad, simulator): the bearing, a static north-up dial and the sun check still work.
    private var noSensor: some View {
        GeometryReader { geo in
            let side = min(geo.size.width - 56, geo.size.height * 0.44, 320)
            VStack(spacing: 12) {
                if shrineMode { shrinePicker }
                Text(verbatim: "اتجاه \(targetName) من \(originName)").font(.display(22)).foregroundStyle(Brand.ink)
                Text(verbatim: "\(Int(bearing.rounded()).ar)° من الشمال · \(Khums.money(Double(distanceKm))) كم")
                    .font(.footnote).foregroundStyle(Brand.muted)
                Spacer(minLength: 4)
                QiblaCompass(dialAngle: 0, needle: bearing, aligned: false, shrineMode: shrineMode)
                    .frame(width: side, height: side)
                Spacer(minLength: 4)
                Text("جهازك بلا مُستشعِر بوصلة، فالقرص ثابت والشمال إلى الأعلى. استخدم التحقّق بالشمس أو بوصلةً يدوية.")
                    .font(.footnote).foregroundStyle(Brand.muted).multilineTextAlignment(.center)
                    .padding(14)
                    .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                HStack(spacing: 10) {
                    if !shrineMode { SoftPill(symbol: "sun.max.fill", title: "تحقّق بالشمس") { sheet = .sun } }
                    SoftPill(symbol: "scope", title: "الدقّة والمعايرة") { sheet = .tips }
                }
                .padding(.bottom, 8)
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .frame(width: geo.size.width, height: geo.size.height)
        }
    }

    /// Fixed layout, like the system Compass app: nothing scrolls; extra help opens in sheets.
    private var compassContent: some View {
        GeometryReader { geo in
            let side = min(geo.size.width - 56, geo.size.height * 0.48, 340)
            VStack(spacing: 12) {
                if shrineMode { shrinePicker }
                Text("اتجاه \(targetName) من \(originName): \(String(format: "%.1f", bearing).arabicDigits)°")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(Brand.muted)
                    .lineLimit(1).minimumScaleFactor(0.8)
                statusRow
                guidance
                Spacer(minLength: 4)
                QiblaCompass(dialAngle: service.continuousHeading, needle: needleContinuous, aligned: aligned, shrineMode: shrineMode)
                    .animation(.easeOut(duration: 0.2), value: service.continuousHeading)
                    .frame(width: side, height: side)
                Spacer(minLength: 4)
                HStack(alignment: .firstTextBaseline, spacing: 18) {
                    VStack(spacing: 0) {
                        Text(verbatim: "\(Int(heading.rounded()).ar)°")
                            .font(.counter(34))
                            .foregroundStyle(Brand.ink)
                            .contentTransition(.numericText())
                        Text("اتجاه جهازك").font(.caption2).foregroundStyle(Brand.muted)
                    }
                    VStack(spacing: 0) {
                        Text(verbatim: "\(Khums.money(Double(distanceKm))) كم")
                            .font(.display(22))
                            .foregroundStyle(Brand.goldDeep)
                        Text(shrineMode ? "المسافة إلى المقام" : "المسافة إلى الكعبة").font(.caption2).foregroundStyle(Brand.muted)
                    }
                }
                HStack(spacing: 10) {
                    if !shrineMode {
                        SoftPill(symbol: "sun.max.fill", title: "تحقّق بالشمس") { sheet = .sun }
                    }
                    SoftPill(symbol: "scope", title: "الدقّة والمعايرة") { sheet = .tips }
                }
                .padding(.bottom, 8)
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .frame(width: geo.size.width, height: geo.size.height)
        }
    }

    private var tipsContent: some View {
        VStack(alignment: .leading, spacing: 12) {
            if shrineMode {
                Text("يُستحبّ لمن زار من بُعد أن يتوجّه نحو القبر الشريف، فاجعل القبّة أعلى الشاشة ثم اقرأ الزيارة.")
                    .font(.subheadline)
            }
            Label("أمسك الجهاز مسطّحاً موازياً للأرض.", systemImage: "iphone")
            Label("ابتعد عن المعادن والمغناطيس والشواحن والسيارة.", systemImage: "bolt.slash")
            Label("إن بدا الاتجاه خاطئاً فحرّك الجهاز في الهواء على شكل الرقم ٨ لمعايرة البوصلة.", systemImage: "infinity")
            Label("يُحسب الاتجاه من موقعك الحالي عبر GPS حين يتوفّر، وإلا فمن المدينة المحفوظة.", systemImage: "location.fill")
            Label("على «شمال حقيقي» يكون الاتجاه أدقّ؛ «مغناطيسي» يعني أن الموقع لم يُحدَّد بعد.", systemImage: "safari")
        }
        .font(.subheadline)
        .foregroundStyle(.white)
    }

    private var shrinePicker: some View {
        Menu {
            Picker("المقام", selection: $shrineIdx) {
                ForEach(Array(shrineTargets.enumerated()), id: \.offset) { i, t in
                    Text(verbatim: "\(t.name) · \(t.place)").tag(i)
                }
            }
        } label: {
            HStack(spacing: 8) {
                Image(systemName: "building.columns.fill")
                Text(shrine.name).font(.subheadline.weight(.heavy))
                Image(systemName: "chevron.down").font(.caption.weight(.bold))
            }
            .foregroundStyle(Brand.ink)
            .padding(.horizontal, 16).padding(.vertical, 9)
            .background(Brand.cardFill, in: Capsule())
            .overlay(Capsule().stroke(Brand.gold.opacity(0.6), lineWidth: 1))
        }
    }

    /// Where the bearing comes from and how much to trust the compass right now.
    private var statusRow: some View {
        HStack(spacing: 8) {
            Label(gps != nil ? "GPS" : "المدينة المحفوظة", systemImage: gps != nil ? "location.fill" : "building.2")
            if service.heading != nil {
                Text(service.trueNorth ? "شمال حقيقي" : "شمال مغناطيسي")
                if service.headingAccuracy >= 0 {
                    Text("دقّة ±\(Int(service.headingAccuracy.rounded()).ar)°")
                }
            }
        }
        .font(.caption2.weight(.bold))
        .foregroundStyle(Brand.ink)
        .padding(.horizontal, 12).padding(.vertical, 6)
        .background(Brand.cardFill, in: Capsule())
    }

    private static let timeFmt: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "ar"); f.dateFormat = "h:mm a"; return f
    }()
    private static let dayFmt: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "ar"); f.dateFormat = "EEEE d MMMM"; return f
    }()

    /// Compass-free check: moments when the sun itself points to the Qibla.
    private var sunCheck: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("تحقّق بالشمس دون بوصلة", systemImage: "sun.max.fill")
                .font(.subheadline.weight(.heavy))
                .foregroundStyle(Brand.gold)
            if sunToday.isEmpty {
                Text("لا تمرّ الشمس اليوم باتجاه القبلة من \(originName).")
                    .font(.footnote).foregroundStyle(.white.opacity(0.85))
                if let next = sunNext {
                    Text("أقرب موعد: \(Self.dayFmt.string(from: next))")
                        .font(.footnote.weight(.bold)).foregroundStyle(.white)
                }
            } else {
                ForEach(Array(sunToday.enumerated()), id: \.offset) { _, a in
                    HStack(alignment: .top, spacing: 8) {
                        Text(Self.timeFmt.string(from: a.date))
                            .font(.footnote.weight(.heavy)).foregroundStyle(.white)
                            .frame(minWidth: 64, alignment: .leading)
                        Text(a.toward ? "الشمس في جهة القبلة تماماً: استقبِلها تكن مستقبلاً للقبلة."
                                      : "الشمس خلف القبلة تماماً: ظلّ أيّ شاخصٍ قائمٍ يشير إلى القبلة.")
                            .font(.footnote).foregroundStyle(.white.opacity(0.85))
                    }
                }
            }
            Text("وفي كلّ عام تتعامد الشمس على الكعبة يومي ٢٧ و٢٨ مايو الساعة ١٢:١٨ ظهراً، و١٥ و١٦ يوليو الساعة ١٢:٢٧ ظهراً بتوقيت مكة؛ فظلّ أيّ عمودٍ حينها يشير إلى عكس القبلة في كلّ بلدٍ تكون فيه الشمس ظاهرة.")
                .font(.caption2).foregroundStyle(.white.opacity(0.7))
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(18)
        .padding(.top, 6)
    }

    @ViewBuilder private var guidance: some View {
        if aligned {
            Label(shrineMode ? "أنت متوجّه نحو \(shrine.name)" : "أنت موجَّه نحو القبلة الآن", systemImage: "checkmark.circle.fill")
                .font(.subheadline.weight(.heavy))
                .foregroundStyle(Brand.ink)
                .padding(.horizontal, 16).padding(.vertical, 8)
                .foregroundStyle(Color.white)
                .background(Brand.good, in: Capsule())
        } else if service.heading == nil {
            Text(service.errorText ?? "جارٍ قراءة البوصلة…")
                .font(.footnote)
                .foregroundStyle(Brand.muted)
        } else if service.needsCalibration {
            Text("⚠ البوصلة تحتاج معايرة — حرّك جهازك على شكل ٨ بعيداً عن المعادن والشواحن، وإلا فالاتجاه غير دقيق.")
                .font(.footnote.weight(.semibold))
                .multilineTextAlignment(.center)
                .foregroundStyle(Brand.ink)
                .padding(.horizontal, 14).padding(.vertical, 10)
                .background(Brand.gold.opacity(0.18), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        } else {
            Text((shrineMode ? "أدِر جهازك حتى تستقيم القبّة لأعلى" : "أدِر جهازك حتى تستقيم الكعبة لأعلى"))
                .font(.footnote)
                .foregroundStyle(Brand.muted)
        }
    }
}

private struct QiblaBackground: View {
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        ZStack {
            if scheme == .dark {
                Brand.nightGradient
            } else {
                LinearGradient(colors: [Color(hex: 0xDCEFEA), Color(hex: 0xF5F2EA)], startPoint: .top, endPoint: .bottom)
            }
            GirihPattern().foregroundStyle(scheme == .dark ? Color.white.opacity(0.05) : Brand.deeper.opacity(0.06))
        }
        .ignoresSafeArea()
    }
}

/// Glass dial that turns against the device heading, with the Kaaba marker and a gold needle.
private struct QiblaCompass: View {
    let dialAngle: Double
    let needle: Double
    let aligned: Bool
    var shrineMode: Bool = false

    var body: some View {
        GeometryReader { geo in
            let size = min(geo.size.width, geo.size.height)
            let radius = size / 2
            ZStack {
                Circle()
                    .fill(Color.white)
                    .shadow(color: Color(hex: 0x10322D).opacity(aligned ? 0.25 : 0.12), radius: 24, y: 10)
                Circle().stroke(aligned ? Brand.good.opacity(0.5) : Brand.deeper.opacity(0.12), lineWidth: 2)
                QiblaDial()
                    .rotationEffect(.degrees(-dialAngle))
                QiblaNeedle(color: aligned ? Brand.good : Brand.gold)
                    .rotationEffect(.degrees(needle))
                Group {
                    if shrineMode {
                        Image(systemName: "building.columns.fill")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundStyle(aligned ? Brand.good : Brand.gold)
                            .frame(width: 44, height: 44)
                            .background(Circle().fill(Color.black.opacity(0.35)))
                    } else {
                        QiblaKaaba(highlight: aligned ? Brand.good : Brand.gold)
                    }
                }
                    .frame(width: 44, height: 44)
                    .offset(x: CGFloat(sin(needle * .pi / 180)) * radius * 0.70,
                            y: -CGFloat(cos(needle * .pi / 180)) * radius * 0.70)
                Circle().fill(Brand.deeper).frame(width: 18, height: 18)
                Circle().fill(Brand.goldSoft).frame(width: 7, height: 7)
            }
            .frame(width: size, height: size)
            .position(x: geo.size.width / 2, y: geo.size.height / 2)
        }
        // Geometry is absolute (north up); keep it unaffected by the RTL layout.
        .environment(\.layoutDirection, .leftToRight)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(aligned ? "أنت موجَّه نحو القبلة الآن" : (shrineMode ? "أدِر جهازك حتى تستقيم القبّة لأعلى" : "أدِر جهازك حتى تستقيم الكعبة لأعلى"))
    }
}

private struct QiblaDial: View {
    var body: some View {
        GeometryReader { geo in
            let s = min(geo.size.width, geo.size.height)
            ZStack {
                Canvas { ctx, size in
                    let r = min(size.width, size.height) / 2 - 2
                    let c = CGPoint(x: size.width / 2, y: size.height / 2)
                    var outer = Path()
                    outer.addEllipse(in: CGRect(x: c.x - r, y: c.y - r, width: 2 * r, height: 2 * r))
                    ctx.stroke(outer, with: .color(Brand.deeper.opacity(0.25)), lineWidth: 1.5)
                    var inner = Path()
                    let ri = r * 0.72
                    inner.addEllipse(in: CGRect(x: c.x - ri, y: c.y - ri, width: 2 * ri, height: 2 * ri))
                    ctx.stroke(inner, with: .color(Brand.deeper.opacity(0.12)), lineWidth: 1)
                    for i in 0..<72 {
                        let a = Double(i) * 5 * .pi / 180
                        let long = i % 6 == 0
                        let rIn = r - (long ? 16 : 8)
                        var p = Path()
                        p.move(to: CGPoint(x: c.x + CGFloat(sin(a)) * rIn, y: c.y - CGFloat(cos(a)) * rIn))
                        p.addLine(to: CGPoint(x: c.x + CGFloat(sin(a)) * r, y: c.y - CGFloat(cos(a)) * r))
                        ctx.stroke(p, with: .color(long ? Brand.goldDeep : Brand.deeper.opacity(0.3)), lineWidth: long ? 2.5 : 1)
                    }
                }
                Text("ش")
                    .font(.caption.weight(.heavy))
                    .foregroundStyle(Brand.goldDeep)
                    .position(x: s / 2, y: 28)
                Text("ج").font(.caption2.weight(.bold)).foregroundStyle(Brand.muted).position(x: s / 2, y: s - 28)
                Text("شرق").font(.caption2.weight(.bold)).foregroundStyle(Brand.muted).position(x: s - 34, y: s / 2)
                Text("غرب").font(.caption2.weight(.bold)).foregroundStyle(Brand.muted).position(x: 34, y: s / 2)
            }
        }
    }
}

private struct QiblaNeedle: View {
    let color: Color

    var body: some View {
        GeometryReader { geo in
            let s = min(geo.size.width, geo.size.height)
            Capsule()
                .fill(LinearGradient(colors: [color, color.opacity(0.45)], startPoint: .top, endPoint: .bottom))
                .frame(width: 6, height: s * 0.30)
                .position(x: geo.size.width / 2, y: geo.size.height / 2 - s * 0.15)
        }
    }
}

/// Kaaba glyph: black cube with a gold kiswa band and door, framed in the highlight colour.
private struct QiblaKaaba: View {
    let highlight: Color

    var body: some View {
        GeometryReader { geo in
            let s = min(geo.size.width, geo.size.height)
            let gold = Color(red: 0xC9 / 255, green: 0xA8 / 255, blue: 0x6A / 255)
            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: s * 0.08)
                    .fill(Color(red: 0.08, green: 0.08, blue: 0.08))
                Rectangle().fill(gold)
                    .frame(width: s, height: s * 0.10)
                    .offset(y: s * 0.26)
                Rectangle().fill(gold)
                    .frame(width: s * 0.16, height: s * 0.36)
                    .offset(x: s * 0.42, y: s * 0.58)
                RoundedRectangle(cornerRadius: s * 0.08)
                    .stroke(highlight, lineWidth: s * 0.06)
            }
            .frame(width: s, height: s)
            .clipShape(RoundedRectangle(cornerRadius: s * 0.08))
            .shadow(color: .black.opacity(0.35), radius: 4, y: 2)
        }
    }
}


private enum QiblaSheet: String, Identifiable {
    case sun, tips
    var id: String { rawValue }
}
