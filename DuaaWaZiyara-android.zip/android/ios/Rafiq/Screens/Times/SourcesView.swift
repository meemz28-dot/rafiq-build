import SwiftUI

// MARK: - عن النصوص والمصادر (trust: where every text comes from, and how to report an error)

struct SourcesView: View {
    @Environment(\.openURL) private var openURL

    private struct Ref: Identifiable { let id = UUID(); let title: String; let detail: String }

    private let references: [Ref] = [
        Ref(title: "القرآن الكريم", detail: "نصّ المصحف بالرسم العثماني من مشروع تنزيل (tanzil.net)، رخصة CC BY 3.0، مع ترقيم الآيات وتقسيم الأجزاء والصفحات."),
        Ref(title: "مفاتيح الجنان", detail: "للشيخ عبّاس القمّي: الأدعية المشهورة والزيارات وأعمال الشهور والأيام."),
        Ref(title: "الصحيفة السجّادية", detail: "أدعية الإمام زين العابدين علي بن الحسين (ع)، بترتيبها المعروف (٥٤ دعاءً)."),
        Ref(title: "نهج البلاغة ورسالة الحقوق", detail: "من خطب أمير المؤمنين (ع) وكتبه وحكمه، ورسالة الحقوق للإمام السجّاد (ع)."),
        Ref(title: "الكافي", detail: "للشيخ الكليني: أحاديث كتاب الإيمان والكفر والدعاء وفضل القرآن والعِشرة، من بيانات مشروع ثقلين (thaqalayn.net، رخصة CC0) مع درجة كلّ حديث كما وردت فيها."),
        Ref(title: "التقويم والمناسبات", detail: "التقويم الهجري الجدولي مع إمكانية التعديل ±يومين لرؤية الهلال، والمناسبات مراجَعة مع بيانات تطبيق Shia Companion (رخصة MIT)."),
        Ref(title: "مواقيت الصلاة والقبلة", detail: "حساب فلكي محلي على جهازك (الطريقة الجعفرية وغيرها)، ومعادلة القبلة وإحداثيات الكعبة مطابقة لمكتبة adhan-swift.")
    ]

    /// The named sources inside the library, counted from the texts themselves.
    private var namedSources: [(String, Int)] {
        var counts: [String: Int] = [:]
        for c in Library.categories {
            for it in c.items {
                guard let s = it.src?.trimmingCharacters(in: .whitespaces), !s.isEmpty else { continue }
                let key = s.components(separatedBy: CharacterSet(charactersIn: "،,؛:(")).first?
                    .trimmingCharacters(in: .whitespaces) ?? s
                if key.count >= 3 { counts[key, default: 0] += 1 }
            }
        }
        return counts.sorted { $0.value > $1.value }.prefix(15).map { ($0.key, $0.value) }
    }

    private var totalTexts: Int { Library.categories.reduce(0) { $0 + $1.items.count } }

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 8) {
                    Label("من أين النصوص؟", systemImage: "checkmark.seal.fill")
                        .font(.headline).foregroundStyle(Brand.emerald)
                    Text("يضمّ التطبيق \(totalTexts.ar) نصّاً، نُقلت من الكتب المعتمدة أدناه، ويظهر مصدر كلّ دعاء أو زيارة أعلى نصّه في القارئ.")
                        .font(.subheadline)
                }
                .padding(.vertical, 4)
            }

            Section("المراجع") {
                ForEach(references) { r in
                    VStack(alignment: .leading, spacing: 3) {
                        Text(r.title).font(.subheadline.weight(.bold))
                        Text(r.detail).font(.caption).foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 2)
                }
            }

            if !namedSources.isEmpty {
                Section("المصادر المذكورة في النصوص") {
                    ForEach(Array(namedSources.enumerated()), id: \.offset) { _, s in
                        HStack {
                            Text(s.0).font(.subheadline)
                            Spacer()
                            Text("\(s.1.ar) نصّ").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }

            Section {
                Text("لم تخضع النصوص بعدُ لمراجعةٍ رسمية من عالمٍ أو حوزة، ونعمل على ذلك. إن وجدت خطأً في حرفٍ أو تشكيلٍ أو مصدر فأخبرنا وسنصحّحه في التحديث التالي.")
                    .font(.footnote)
                Button {
                    if let u = URL(string: "mailto:feedback@rafiqalmumin.app?subject=" + ("تصحيح نص".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")) {
                        openURL(u)
                    }
                } label: {
                    Label("أبلغ عن خطأ في نص", systemImage: "exclamationmark.bubble")
                }
            } header: {
                Text("حالة المراجعة")
            }

            Section {
                Text("الأحكام (الخمس، القضاء، المواقيت) تقريبية وتختلف بحسب المرجع؛ اختر مرجعك من الإعدادات، وارجع إلى رسالته العملية في المسائل.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Brand.canvas)
        .navigationTitle("عن النصوص والمصادر")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Marja (reference authority) preference

enum Marja {
    static let key = "marja"
    /// Living maraji most followed in the app's regions, in alphabetical order (no ranking implied).
    static let names: [String] = [
        "الشيخ بشير النجفي",
        "الشيخ محمد إسحاق الفيّاض",
        "الشيخ ناصر مكارم الشيرازي",
        "السيد صادق الشيرازي",
        "السيد علي الحسيني السيستاني",
        "السيد علي الخامنئي",
        "السيد كاظم الحائري"
    ].sorted()

    static func current(_ store: Store) -> String { store.string(key, "") }
}

/// A one-line reminder on the fiqh tools (khums, qada) of whose rulings the user follows.
struct MarjaNote: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    var body: some View {
        let m = Marja.current(store)
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "books.vertical").foregroundStyle(Brand.emerald)
            Text(m.isEmpty
                 ? "الحساب تقريبي؛ تختلف التفاصيل بين المراجع. حدّد مرجعك من الإعدادات وارجع إلى رسالته العملية."
                 : "مرجعك: \(m). الحساب تقريبي؛ ارجع إلى رسالته العملية في التفاصيل.")
                .font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct MarjaPickerSection: View {
    @Environment(Store.self) private var store

    var body: some View {
        Section {
            Picker("مرجع التقليد", selection: Binding(get: { Marja.current(store) }, set: { store.put(Marja.key, $0) })) {
                Text("لم أحدّد").tag("")
                ForEach(Marja.names, id: \.self) { Text($0).tag($0) }
            }
            NavigationLink {
                SourcesView()
            } label: {
                Label("عن النصوص والمصادر", systemImage: "checkmark.seal")
            }
        } header: {
            Text("المرجع والمصادر")
        } footer: {
            Text("يظهر مرجعك في حاسبة الخمس وقضاء الصلوات للتذكير بالرجوع إلى رسالته؛ ولا يغيّر التطبيق الأحكام تلقائياً.")
        }
    }
}
