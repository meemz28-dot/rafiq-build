import SwiftUI

/// One category (باب): filter, number jump, Quran juz chips, read progress, continue reading, items.
struct CategoryView: View {
    let catId: String
    @State private var filter = ""

    init(catId: String) { self.catId = catId }

    var body: some View {
        Group {
            if let c = Library.category(catId) {
                CategoryBody(cat: c, filter: $filter)
                    .navigationTitle(c.name)
            } else {
                EmptyStateView(symbol: "exclamationmark.triangle", title: "تعذّر العرض",
                               message: "تعذّر فتح هذا المحتوى، قد يكون غير متوفّر حالياً.")
                    .navigationTitle("تعذّر العرض")
            }
        }
        .navigationBarTitleDisplayMode(.large)
    }
}

private struct CategoryBody: View {
    let cat: DuaaCategory
    @Binding var filter: String
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private var numberJump: Bool { cat.id == "sahifa" || cat.id == "quran" || cat.id == "ramadan" }
    private var filterBlank: Bool { filter.trimmingCharacters(in: .whitespaces).isEmpty }

    private var shown: [DuaaItem] {
        let f = filter.trimmingCharacters(in: .whitespaces)
        if f.isEmpty { return cat.items }
        if numberJump, let n = Int(f.westernDigits) {
            return cat.items.filter { LibraryText.jumpNumber(catId: cat.id, itemId: $0.id) == n }
        }
        let nq = ArabicSearch.normalize(f)
        return cat.items.filter {
            ArabicSearch.normalize($0.title).contains(nq) || ArabicSearch.normalize($0.src ?? "").contains(nq)
        }
    }

    private var placeholder: String {
        switch cat.id {
        case "sahifa": return "تصفية، أو رقم الدعاء (١–٥٤)…"
        case "quran": return "تصفية، أو رقم السورة (١–١١٤)…"
        case "ramadan": return "تصفية، أو رقم اليوم (١–٣٠)…"
        default: return "تصفية في \(cat.name)…"
        }
    }

    private var readInCat: Int { cat.items.filter { store.isRead(cat.id, $0.id) }.count }

    private var lastInCat: DuaaItem? {
        guard let pair = store.recentReads.first(where: { $0.0 == cat.id }) else { return nil }
        return cat.items.first { $0.id == pair.1 }
    }

    var body: some View {
        let items = shown
        return List {
            headerSection
            if cat.items.count >= 12 { toolsSection }
            if cat.id == "quran" && cat.items.count >= 12 && filterBlank { juzSection }
            if let last = lastInCat, filterBlank { continueSection(last) }
            itemsSection(items)
        }
        .listStyle(.insetGrouped)
    }

    // MARK: Sections

    private var headerSection: some View {
        Section {
            HStack(spacing: 12) {
                IconChip(symbol: Brand.categorySymbol(cat.id), colors: Brand.categoryColors(cat.id), size: 50)
                VStack(alignment: .leading, spacing: 3) {
                    Text(LibraryText.arabicCount(cat.items.count, one: "نصٌّ واحد", two: "نصّان", plural: "نصوص", many: "نصّاً"))
                        .font(.subheadline.weight(.bold)).foregroundStyle(Brand.emerald)
                    if !cat.desc.isEmpty {
                        Text(cat.desc).font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            .padding(.vertical, 4)
        }
    }

    private var toolsSection: some View {
        Section {
            HStack(spacing: 8) {
                Image(systemName: "line.3.horizontal.decrease.circle").foregroundStyle(.secondary)
                    .accessibilityLabel("تصفية داخل الباب")
                TextField(placeholder, text: $filter)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .submitLabel(.search)
                if !filter.isEmpty {
                    Button { filter = "" } label: {
                        Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("مسح التصفية")
                }
            }
            if readInCat > 0 { progressRow }
        }
    }

    private var progressRow: some View {
        HStack(spacing: 10) {
            ProgressView(value: Double(readInCat), total: Double(max(1, cat.items.count)))
                .tint(Brand.good)
            Text("قرأتَ \(readInCat.ar) من \(cat.items.count.ar)")
                .font(.caption.weight(.bold)).foregroundStyle(.secondary)
                .fixedSize()
        }
    }

    private var juzSection: some View {
        Section("الأجزاء") {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(0..<30, id: \.self) { j in juzChip(j) }
                }
                .padding(.horizontal, 16).padding(.vertical, 8)
            }
            .listRowInsets(EdgeInsets())
            .listRowBackground(Color.clear)
        }
    }

    @ViewBuilder private func juzChip(_ j: Int) -> some View {
        let juz = Library.shared.juz
        if j < juz.sura.count && j < juz.aya.count {
            let num = String(juz.sura[j])
            let sid = "q-" + String(repeating: "0", count: max(0, 3 - num.count)) + num
            let sname = (cat.items.first(where: { $0.id == sid })?.title ?? "").replacingOccurrences(of: "سورة ", with: "")
            Button {
                Haptic.tick()
                nav.openReader("quran", sid)
            } label: {
                VStack(spacing: 2) {
                    Text("الجزء \((j + 1).ar)").font(.footnote.weight(.heavy)).foregroundStyle(Brand.emerald)
                    Text("\(sname) \(juz.aya[j].ar)").font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                }
                .padding(.horizontal, 14).padding(.vertical, 8)
                .glassCapsule(interactive: true)
            }
            .buttonStyle(.plain)
        }
    }

    private func continueSection(_ last: DuaaItem) -> some View {
        let resumed = store.scroll(cat.id, last.id) > 0
        return Section {
            NavigationLink(value: Route.reader(cat.id, last.id)) {
                HStack(spacing: 10) {
                    Image(systemName: "book.fill").foregroundStyle(Brand.gold)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(resumed ? "تابِع من موضعك" : "آخر ما قرأت")
                            .font(.caption.weight(.bold)).foregroundStyle(Brand.gold)
                        Text(last.title).font(.subheadline.weight(.bold)).foregroundStyle(.primary).lineLimit(1)
                    }
                }
            }
            .listRowBackground(Brand.gold.opacity(0.12))
        }
    }

    @ViewBuilder private func itemsSection(_ items: [DuaaItem]) -> some View {
        if items.isEmpty {
            Section {
                Text("لا نتائج داخل هذا الباب لـ «\(filter)»")
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .multilineTextAlignment(.center)
            }
        } else {
            Section {
                ForEach(items) { it in
                    NavigationLink(value: Route.reader(cat.id, it.id)) {
                        LibraryItemRow(title: it.title,
                                       subtitle: LibraryText.listSubtitle(catName: cat.name, src: it.src, text: it.text),
                                       read: store.isRead(cat.id, it.id),
                                       fav: store.isFav(cat.id, it.id))
                    }
                }
            }
        }
    }
}
