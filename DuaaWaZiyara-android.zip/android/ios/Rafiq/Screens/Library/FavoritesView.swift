import SwiftUI

/// المفضلة sheet (port of Android FavSheet). Presented inside a NavigationStack by the router.
struct FavoritesView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.dismiss) private var dismiss

    private struct Entry { let cat: DuaaCategory; let item: DuaaItem; var key: String { cat.id + "|" + item.id } }

    private var entries: [Entry] {
        store.favorites.compactMap { pair in
            guard let c = Library.category(pair.0), let i = c.items.first(where: { $0.id == pair.1 }) else { return nil }
            return Entry(cat: c, item: i)
        }
    }

    var body: some View {
        let list = entries
        return Group {
            if list.isEmpty {
                EmptyStateView(symbol: "star", title: "لا مفضّلات بعد",
                               message: "افتح أيّ دعاءٍ واضغط نجمة الحفظ لإضافته هنا والرجوع إليه بسرعة.")
                    .frame(maxHeight: .infinity)
                    .background(Brand.canvas)
            } else {
                List {
                    ForEach(list, id: \.key) { e in
                        Button { open(e) } label: { row(e) }
                            .swipeActions(edge: .trailing) {
                                Button(role: .destructive) { store.toggleFav(e.cat.id, e.item.id) } label: {
                                    Label("إزالة من المفضّلة", systemImage: "star.slash")
                                }
                            }
                    }
                }
                .listStyle(.insetGrouped)
                .scrollContentBackground(.hidden)
                .background(Brand.canvas)
            }
        }
        .navigationTitle("المفضلة")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button("تم") { dismiss() } }
        }
    }

    private func row(_ e: Entry) -> some View {
        HStack(spacing: 12) {
            IconChip(symbol: Brand.categorySymbol(e.cat.id), colors: Brand.categoryColors(e.cat.id), size: 36)
            VStack(alignment: .leading, spacing: 2) {
                Text(e.item.title).font(.body.weight(.semibold)).foregroundStyle(.primary).lineLimit(2)
                Text(e.cat.name).font(.footnote).foregroundStyle(.secondary)
            }
            Spacer(minLength: 4)
            Image(systemName: "chevron.forward").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
        }
        .contentShape(Rectangle())
    }

    private func open(_ e: Entry) {
        dismiss()
        nav.openReader(e.cat.id, e.item.id)
    }
}

/// العلامات المرجعية sheet (port of Android BookmarksSheet).
struct BookmarksView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        let marks = store.bookmarks.filter { Library.category($0.catId) != nil }
        return Group {
            if marks.isEmpty {
                EmptyStateView(symbol: "bookmark", title: "لا علامات بعد",
                               message: "أثناء القراءة اضغط «ضع علامة» لحفظ موضعك في النصوص الطويلة والرجوع إليه لاحقاً.")
                    .frame(maxHeight: .infinity)
                    .background(Brand.canvas)
            } else {
                List {
                    ForEach(Array(marks.enumerated()), id: \.offset) { _, b in
                        row(b)
                            .swipeActions(edge: .trailing) {
                                Button(role: .destructive) { store.removeBookmark(b) } label: {
                                    Label("حذف", systemImage: "trash")
                                }
                            }
                    }
                }
                .listStyle(.insetGrouped)
                .scrollContentBackground(.hidden)
                .background(Brand.canvas)
            }
        }
        .navigationTitle("العلامات المرجعية")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button("تم") { dismiss() } }
        }
    }

    private func row(_ b: Store.Bookmark) -> some View {
        let catName = Library.category(b.catId)?.name ?? ""
        return HStack(spacing: 12) {
            Button { open(b) } label: {
                HStack(spacing: 12) {
                    IconChip(symbol: Brand.categorySymbol(b.catId), colors: Brand.categoryColors(b.catId), size: 36)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(b.title).font(.body.weight(.semibold)).foregroundStyle(.primary).lineLimit(2)
                        Text(verbatim: "\(catName) · علامة محفوظة").font(.footnote).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 4)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.borderless)
            Button { store.removeBookmark(b) } label: {
                Image(systemName: "trash").font(.footnote).foregroundStyle(Brand.bad)
            }
            .buttonStyle(.borderless)
            .accessibilityLabel("حذف العلامة")
        }
        .contentShape(Rectangle())
    }

    private func open(_ b: Store.Bookmark) {
        store.saveScroll(b.catId, b.itemId, Double(b.para))
        dismiss()
        nav.openReader(b.catId, b.itemId)
    }
}
