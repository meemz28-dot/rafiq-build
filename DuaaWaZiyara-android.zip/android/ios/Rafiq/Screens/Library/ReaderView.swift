import SwiftUI
import UIKit

/// The reader (port of Android ReaderScreen): scripture text by paragraphs with reading tools.
struct ReaderView: View {
    let catId: String
    let itemId: String

    init(catId: String, itemId: String) {
        self.catId = catId
        self.itemId = itemId
    }

    var body: some View {
        if let c = Library.category(catId), let it = c.items.first(where: { $0.id == itemId }) {
            ReaderPage(cat: c, item: it)
                .id(c.id + "|" + it.id)
        } else {
            EmptyStateView(symbol: "exclamationmark.triangle", title: "تعذّر العرض",
                           message: "تعذّر فتح هذا المحتوى، قد يكون غير متوفّر حالياً.")
                .navigationTitle("تعذّر العرض")
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// MARK: - Scroll metrics

private struct ReaderScrollMetrics: Equatable {
    var pct: Int = 0          // 0...100 scroll progress
    var longText: Bool = false // more than about three screens
    var fits: Bool = false     // whole text visible without scrolling
}

private let readerSepiaBg = Color(red: 0xF4 / 255, green: 0xEC / 255, blue: 0xD8 / 255)
private let readerSepiaInk = Color(red: 0x3A / 255, green: 0x2E / 255, blue: 0x1A / 255)
private let readerSupportEmail = "feedback@rafiqalmumin.app"

// MARK: - Page

private struct ReaderPage: View {
    let cat: DuaaCategory
    let item: DuaaItem

    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.openURL) private var openURL

    @State private var paras: [String] = []
    @State private var topPara: Int?
    @State private var interactive = false
    @State private var current = 0
    @State private var metrics = ReaderScrollMetrics()
    @State private var started = false
    @State private var flash: String?
    @State private var flashTick = 0
    @State private var award = 0            // verses just credited (shown in the banner)
    @State private var awardKhatma = false
    @State private var awardSurah = false
    @State private var tracker: QuranReadingTracker?   // Quran only: credits verses at the reader's own pace
    @Environment(\.scenePhase) private var scenePhase
    @State private var goTopTick = 0
    @State private var found: Int?

    // MARK: Derived

    private var idx: Int { cat.items.firstIndex(where: { $0.id == item.id }) ?? 0 }
    private var prevItem: DuaaItem? { idx > 0 ? cat.items[idx - 1] : nil }
    private var nextItem: DuaaItem? { idx + 1 < cat.items.count ? cat.items[idx + 1] : nil }
    private var fs: CGFloat { CGFloat(store.fontSize) }
    private var lh: CGFloat { CGFloat(store.lineSpacing) }
    private var sepia: Bool { store.sepia }
    private var ink: Color { sepia ? readerSepiaInk : Color.primary }
    private var faded: Color { sepia ? readerSepiaInk.opacity(0.5) : Color.secondary.opacity(0.6) }
    private var cardBg: Color { sepia ? Brand.paper : Color(.secondarySystemGroupedBackground) }
    private var pageBg: Color { sepia ? readerSepiaBg : Color(.systemGroupedBackground) }
    private var isFav: Bool { store.isFav(cat.id, item.id) }
    private var hasBookmark: Bool { store.bookmarks.contains { $0.catId == cat.id && $0.itemId == item.id } }

    private var fraction: Double {
        if interactive && paras.count > 1 { return Double(current + 1) / Double(paras.count) }
        return Double(metrics.pct) / 100.0
    }

    private var spacingLabel: String {
        if store.lineSpacing >= 2.35 { return "٣" }
        if store.lineSpacing >= 2.05 { return "٢" }
        return "١"
    }

    private var shareText: String { item.title + "\n\n" + item.text + "\n\n" + AppLinks.signature }

    // MARK: Body

    var body: some View {
        ScrollViewReader { proxy in
            scroller
                .onAppear { start(proxy) }
                .onChange(of: current) { _, v in
                    if interactive {
                        withAnimation(.easeInOut(duration: 0.3)) { proxy.scrollTo(v, anchor: .center) }
                        store.saveScroll(cat.id, item.id, Double(v))
                    }
                    checkAward()
                }
                .onChange(of: goTopTick) { _, _ in
                    withAnimation(.easeInOut(duration: 0.35)) { proxy.scrollTo("readerTop", anchor: .top) }
                }
        }
        .background(pageBg.ignoresSafeArea())
        .overlay(alignment: .top) { progressLine }
        .overlay(alignment: .bottom) { banners }
        .safeAreaInset(edge: .bottom) { bottomBars }
        .navigationTitle(item.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.hidden, for: .tabBar)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) { optionsMenu }
            ToolbarItem(placement: .topBarTrailing) { listenMenu }
        }
        .keepScreenAwake(store.keepAwake)
        .onChange(of: store.keepAwake) { _, v in UIApplication.shared.isIdleTimerDisabled = v }
        .onChange(of: store.tashkeel) { _, v in
            paras = LibraryText.paragraphs(item.text, tashkeel: v)
            tracker?.layout(fullText: item.text, paragraphs: paras)
        }
        .onChange(of: metrics) { _, _ in checkAward() }
        .task(id: flashTick) {
            guard flash != nil else { return }
            try? await Task.sleep(nanoseconds: 1_800_000_000)
            if !Task.isCancelled { withAnimation { flash = nil } }
        }
        .task {
            // Quran: once a second, convert on-screen reading time into verses at the reader's pace.
            guard cat.id == "quran" else { return }
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                if Task.isCancelled { return }
                recordQuran()
            }
        }
    }

    private var scroller: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                header.id("readerTop")
                textCard
                if !interactive && metrics.longText { backToTop }
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 20)
            .readableWidth(760)
        }
        .scrollPosition(id: $topPara, anchor: .top)
        .onScrollGeometryChange(for: ReaderScrollMetrics.self, of: { geo in
            let maxY = geo.contentSize.height + geo.contentInsets.top + geo.contentInsets.bottom - geo.containerSize.height
            let off = geo.contentOffset.y + geo.contentInsets.top
            var m = ReaderScrollMetrics()
            if maxY > 1 {
                m.pct = Int(max(0, min(100, (off / maxY) * 100)))
            }
            m.longText = maxY > 1400
            m.fits = maxY <= 1
            return m
        }, action: { _, newValue in
            metrics = newValue
        })
        .onChange(of: topPara) { _, p in
            if !interactive, let p { store.saveScroll(cat.id, item.id, Double(p)) }
        }
    }

    // MARK: Lifecycle

    private func start(_ proxy: ScrollViewProxy) {
        if started { return }
        started = true
        paras = LibraryText.paragraphs(item.text, tashkeel: store.tashkeel)
        if let n = QuranProgress.surahNumber(item.id) {
            QuranProgress.migrate(store)
            let t = QuranReadingTracker(surah: n, alreadyRead: QuranProgress.reach(store)[n] ?? 0)
            t.layout(fullText: item.text, paragraphs: paras)
            tracker = t
        }
        store.recordRead(cat.id, item.id)
        if let q = nav.pendingFind {
            nav.pendingFind = nil
            let terms = ArabicSearch.normalize(q).split(separator: " ").map(String.init)
            let hit = terms.isEmpty ? nil : paras.firstIndex { p in
                let n = ArabicSearch.normalize(p)
                return terms.allSatisfy { n.contains($0) }
            } ?? paras.firstIndex { p in
                let n = ArabicSearch.normalize(p)
                return terms.contains { n.contains($0) }
            }
            if let hit {
                found = hit
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    withAnimation(.easeInOut(duration: 0.4)) { proxy.scrollTo(hit, anchor: .center) }
                }
                show("وُجد «\(q)» في المقطع \((hit + 1).ar)")
                DispatchQueue.main.asyncAfter(deadline: .now() + 6) { withAnimation { found = nil } }
                return
            }
        }
        let saved = Int(store.scroll(cat.id, item.id))
        if saved > 0 && saved < paras.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                proxy.scrollTo(saved, anchor: .top)
            }
            show("استُؤنِفت القراءة من موضعك الأخير ✓")
        }
    }

    private func show(_ msg: String) {
        withAnimation { flash = msg }
        flashTick += 1
    }

    private func checkAward() {}

    /// Credits newly read verses (Quran only) and celebrates a finished surah or khatma.
    private func recordQuran() {
        guard let t = tracker else { return }
        let gained = t.tick(store: store, active: scenePhase == .active)
        guard gained > 0 else { return }
        let ev = QuranProgress.record(store, surah: t.surah, upTo: t.credited)
        if ev.surahDone || ev.khatmaDone {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                award = max(ev.verses, 1)
                awardSurah = ev.surahDone
                awardKhatma = ev.khatmaDone
            }
            Haptic.confirm()
        }
    }

    // MARK: Actions

    private func go(_ target: DuaaItem?) {
        guard let target else { return }
        Haptic.tick()
        var p = nav.path(nav.tab)
        if !p.isEmpty { p.removeLast() }
        p.append(.reader(cat.id, target.id))
        nav.paths[nav.tab] = p
    }

    private func changeFont(_ delta: Double) {
        store.fontSize = max(15, min(40, store.fontSize + delta))
        Haptic.tick()
    }

    private func cycleSpacing() {
        store.lineSpacing = store.lineSpacing >= 2.4 ? 1.7 : store.lineSpacing + 0.2
    }

    private func addBookmark() {
        let para = interactive ? current : (topPara ?? 0)
        store.addBookmark(Store.Bookmark(catId: cat.id, itemId: item.id, para: para, title: item.title))
        show("حُفظت العلامة ✓")
        Haptic.confirm()
    }

    private func copyText() {
        UIPasteboard.general.string = item.title + "\n\n" + item.text
        show("نُسِخ النصّ ✓")
    }

    private func reportError() {
        let subject = "بلاغ عن خطأ في نصّ: \(item.title) [\(cat.id)/\(item.id)]"
        let body = "السلام عليكم،\nلاحظتُ ما يلي في نصّ «\(item.title)» (المعرّف: \(cat.id)/\(item.id)):\n\n(صِف الخطأ هنا)\n\nوجزاكم الله خيراً."
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~")
        let s = subject.addingPercentEncoding(withAllowedCharacters: allowed) ?? ""
        let b = body.addingPercentEncoding(withAllowedCharacters: allowed) ?? ""
        if let url = URL(string: "mailto:\(readerSupportEmail)?subject=\(s)&body=\(b)") { openURL(url) }
    }

    // MARK: Header

    @ViewBuilder private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("\(cat.name) · \((idx + 1).ar) من \(cat.items.count.ar)")
                .font(.footnote.weight(.semibold))
                .foregroundStyle(sepia ? readerSepiaInk.opacity(0.7) : Color.secondary)
            if cat.id == "quran" {
                quranMedallion
            } else {
                Text(item.title).font(.title2.weight(.bold)).foregroundStyle(ink)
                if let src = item.src { sourceTag(src) }
                if let intro = item.intro { introCard(intro) }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var quranMedallion: some View {
        VStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .fill(Brand.emerald.opacity(0.08))
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .strokeBorder(Brand.emerald.opacity(0.35), lineWidth: 1.5)
                StarShape().stroke(Brand.emerald.opacity(0.12), lineWidth: 1.5).frame(width: 130, height: 130)
                Text(item.title.replacingOccurrences(of: "سورة ", with: ""))
                    .font(.system(size: 26, weight: .heavy))
                    .foregroundStyle(Brand.emerald)
                    .multilineTextAlignment(.center)
                    .padding(8)
            }
            .frame(width: 150, height: 150)
            if let intro = item.intro {
                Text(intro.replacingOccurrences(of: "\n", with: " · "))
                    .font(.footnote)
                    .foregroundStyle(sepia ? readerSepiaInk.opacity(0.7) : Color.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
            }
        }
        .frame(maxWidth: .infinity)
        .accessibilityElement(children: .combine)
    }

    private func sourceTag(_ src: String) -> some View {
        HStack(spacing: 6) {
            Image(systemName: "book.fill").font(.caption)
            Text("\(src) · \(LibraryText.readLabel(LibraryText.readMinutes(item.text)))")
                .font(.caption.weight(.bold))
        }
        .foregroundStyle(Brand.goldDeep)
        .padding(.horizontal, 13).padding(.vertical, 7)
        .background(Brand.gold.opacity(0.14), in: Capsule())
        .overlay(Capsule().strokeBorder(Brand.gold.opacity(0.25), lineWidth: 1))
    }

    private func introCard(_ intro: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            RoundedRectangle(cornerRadius: 2).fill(Brand.emerald).frame(width: 3, height: 36)
            VStack(alignment: .leading, spacing: 4) {
                Text("نبذة").font(.caption.weight(.heavy)).foregroundStyle(Brand.emerald)
                Text(intro).font(.subheadline).foregroundStyle(sepia ? readerSepiaInk.opacity(0.8) : Color.secondary)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Brand.emerald.opacity(0.07), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    // MARK: Text

    private var textCard: some View {
        VStack(alignment: .leading, spacing: interactive ? 8 : fs * 0.55) {
            ForEach(Array(paras.enumerated()), id: \.offset) { i, p in
                paragraph(i, p)
                    .background(found == i ? Brand.gold.opacity(0.2) : Color.clear,
                                in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .onScrollVisibilityChange(threshold: 0.35) { v in tracker?.setVisible(i, v, store: store) }
                    .id(i)
            }
        }
        .scrollTargetLayout()
        .textSelection(.enabled)
        .padding(.horizontal, interactive ? 14 : 20)
        .padding(.vertical, interactive ? 14 : 22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(cardBg, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(Color.primary.opacity(0.06), lineWidth: 1))
        .environment(\.layoutDirection, .rightToLeft)
    }

    @ViewBuilder private func paragraph(_ i: Int, _ p: String) -> some View {
        let spacing = max(2, fs * (lh - 1.45))
        if interactive {
            let isCur = i == current
            let isDone = i < current
            Text(p)
                .font(Font.scripture(fs))
                .fontWeight(isCur ? Font.Weight.bold : Font.Weight.regular)
                .lineSpacing(spacing)
                .foregroundStyle(isDone ? faded : ink)
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(isCur ? 14 : 6)
                .background(isCur ? Brand.gold.opacity(0.14) : Color.clear,
                            in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .contentShape(Rectangle())
                .onTapGesture { current = i }
        } else if LibraryText.isBasmala(p) {
            Text(p)
                .font(Font.scripture(fs * 0.98))
                .fontWeight(.bold)
                .lineSpacing(spacing)
                .foregroundStyle(Brand.gold)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity, alignment: .center)
                .padding(.bottom, 4)
        } else {
            Text(p)
                .font(Font.scripture(fs))
                .lineSpacing(spacing)
                .foregroundStyle(ink)
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var backToTop: some View {
        Button { goTopTick += 1 } label: {
            Label("العودة إلى البداية", systemImage: "arrow.up")
                .font(.footnote.weight(.bold))
                .padding(.horizontal, 18).padding(.vertical, 10)
        }
        .glassButton()
        .frame(maxWidth: .infinity)
        .padding(.top, 4)
    }

    // MARK: Progress

    @ViewBuilder private var progressLine: some View {
        let f = fraction
        if f > 0 {
            GeometryReader { g in
                Capsule().fill(Brand.gold)
                    .frame(width: g.size.width * CGFloat(min(1, f)), height: 3)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(height: 3)
            .allowsHitTesting(false)
            .animation(.easeOut(duration: 0.2), value: f)
            .accessibilityHidden(true)
        }
    }

    // MARK: Overlays

    @ViewBuilder private var banners: some View {
        VStack(spacing: 10) {
            if award > 0 { awardBanner.transition(.scale(scale: 0.85).combined(with: .opacity)) }
            if let flash {
                Text(flash)
                    .font(.footnote.weight(.bold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 20).padding(.vertical, 12)
                    .background(Brand.emerald, in: Capsule())
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .padding(.horizontal, 18)
        .padding(.bottom, 12)
    }

    private var awardBanner: some View {
        let khatma = awardKhatma
        return Button { withAnimation { award = 0 } } label: {
            HStack(spacing: 14) {
                Image(systemName: "rosette").font(.system(size: 28, weight: .semibold))
                VStack(alignment: .leading, spacing: 2) {
                    Text(khatma ? "ختمتَ القرآن الكريم! تقبّل الله 🎉" : "أحسنت، أتممتَ السورة")
                        .font(.headline.weight(.heavy))
                    Text("اليوم \(QuranProgress.today(store).ar) من \(QuranProgress.goal(store).ar) آية · الختمة \(Int((QuranProgress.khatmaFraction(store) * 100).rounded()).ar)٪")
                        .font(.footnote.weight(.bold)).opacity(0.92)
                }
                Spacer(minLength: 6)
                Text("\(QuranProgress.lifetime(store).ar) نقطة").font(.caption.weight(.bold))
            }
            .foregroundStyle(.white)
            .padding(16)
            .background(LinearGradient(colors: [Brand.gold, Color(red: 0xD8 / 255, green: 0xA7 / 255, blue: 0x4E / 255)],
                                       startPoint: .leading, endPoint: .trailing),
                        in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    // MARK: Bottom glass toolbar

    private var bottomBars: some View {
        VStack(spacing: 8) {
            if interactive && paras.count > 1 { segmentBar }
            mainBar
        }
        .padding(.horizontal, 14)
        .padding(.bottom, 6)
    }

    private var segmentBar: some View {
        HStack(spacing: 6) {
            ReaderBarButton(symbol: "chevron.backward", label: "المقطع السابق", enabled: current > 0) {
                if current > 0 { current -= 1 }
            }
            Text("\((current + 1).ar)/\(paras.count.ar)")
                .font(.footnote.weight(.heavy)).foregroundStyle(Brand.emerald)
                .frame(minWidth: 64)
            ReaderBarButton(symbol: "chevron.forward", label: "المقطع التالي", enabled: current < paras.count - 1) {
                if current < paras.count - 1 { current += 1 }
            }
        }
        .padding(6)
        .glassCapsule()
    }

    private var mainBar: some View {
        HStack(spacing: 2) {
            ReaderBarButton(symbol: "chevron.backward", label: "النصّ السابق", enabled: prevItem != nil) { go(prevItem) }
            Spacer(minLength: 0)
            ReaderBarButton(symbol: "textformat.size.smaller", label: "تصغير الخط", enabled: store.fontSize > 15) { changeFont(-2) }
            ReaderBarButton(symbol: "textformat.size.larger", label: "تكبير الخط", enabled: store.fontSize < 40) { changeFont(2) }
            tashkeelButton
            ReaderBarButton(symbol: hasBookmark ? "bookmark.fill" : "bookmark", label: "ضع علامة", active: hasBookmark) { addBookmark() }
            ReaderBarButton(symbol: isFav ? "star.fill" : "star", label: isFav ? "إزالة من المفضّلة" : "حفظ في المفضّلة", active: isFav) {
                store.toggleFav(cat.id, item.id)
                Haptic.tick()
            }
            Menu {
                Button {
                    ShareCard.present(title: item.title, text: item.text, source: item.src)
                } label: { Label("مشاركة كبطاقة", systemImage: "photo") }
                ShareLink(item: shareText) { Label("مشاركة النصّ", systemImage: "text.alignright") }
            } label: {
                Image(systemName: "square.and.arrow.up")
                    .font(.system(size: 17, weight: .semibold))
                    .frame(width: 38, height: 38)
                    .contentShape(Rectangle())
            }
            .accessibilityLabel("مشاركة")
            Spacer(minLength: 0)
            ReaderBarButton(symbol: "chevron.forward", label: "النصّ التالي", enabled: nextItem != nil) { go(nextItem) }
        }
        .padding(.horizontal, 6).padding(.vertical, 4)
        .glassCapsule()
    }

    private var tashkeelButton: some View {
        Button {
            store.tashkeel.toggle()
            Haptic.tick()
        } label: {
            Text("حَ")
                .font(Font.scripture(20))
                .fontWeight(.bold)
                .foregroundStyle(store.tashkeel ? Brand.gold : Color.secondary)
                .frame(width: 38, height: 38)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(Text(store.tashkeel ? "التشكيل ✓" : "التشكيل"))
    }

    // MARK: Audio

    /// Plays the recording linked to this dua, or opens Listen to find and link one.
    private var quranSurah: Int? {
        guard cat.id == "quran" else { return nil }
        return Int(item.id.replacingOccurrences(of: "q-", with: ""))
    }

    @ViewBuilder private var listenMenu: some View {
        if let n = quranSurah {
            Button {
                Task { await QuranAudio.play(from: n) }
            } label: {
                Image(systemName: "play.circle.fill")
            }
            .accessibilityLabel("استمع للسورة")
        } else {
            duaListenMenu
        }
    }

    private var duaListenMenu: some View {
        let linked = AudioLibrary.shared.linked(catId: cat.id, itemId: item.id)
        return Menu {
            if let a = linked {
                Button { AudioPlayer.shared.play(a) } label: { Label("استمع: \(a.subtitle)", systemImage: "play.fill") }
            }
            Button {
                nav.pendingListen = item.title
                nav.pendingLinkTarget = "\(cat.id)|\(item.id)"
                nav.openTool(.listen)
            } label: {
                Label(linked == nil ? "ابحث عن تسجيل صوتي" : "تغيير التسجيل", systemImage: "magnifyingglass")
            }
        } label: {
            Image(systemName: linked == nil ? "headphones" : "play.circle.fill")
        } primaryAction: {
            if let a = linked {
                AudioPlayer.shared.play(a)
            } else {
                nav.pendingListen = item.title
                nav.pendingLinkTarget = "\(cat.id)|\(item.id)"
                nav.openTool(.listen)
            }
        }
        .accessibilityLabel("الاستماع")
    }

    // MARK: Navigation bar menu

    private var optionsMenu: some View {
        Menu {
            Section {
                Toggle(isOn: Binding(get: { interactive }, set: { v in interactive = v; current = 0 })) {
                    Label("تفاعلي", systemImage: "hand.tap")
                }
                Toggle(isOn: Binding(get: { store.tashkeel }, set: { v in store.tashkeel = v })) {
                    Label("التشكيل", systemImage: "character")
                }
                Toggle(isOn: Binding(get: { store.sepia }, set: { v in store.sepia = v })) {
                    Label("ورقي", systemImage: "doc.richtext")
                }
                Toggle(isOn: Binding(get: { store.keepAwake }, set: { v in store.keepAwake = v })) {
                    Label("الشاشة مضاءة", systemImage: "sun.max")
                }
                Button { cycleSpacing() } label: {
                    Label("تباعد \(spacingLabel)", systemImage: "arrow.up.and.down.text.horizontal")
                }
            }
            Section {
                Button { addBookmark() } label: { Label("ضع علامة", systemImage: "bookmark") }
                Button { copyText() } label: { Label("نسخ النصّ", systemImage: "doc.on.doc") }
                Button { reportError() } label: { Label("بلاغ عن خطأ", systemImage: "flag") }
            }
        } label: {
            Image(systemName: "textformat")
        }
        .accessibilityLabel("خيارات القراءة")
    }
}

// MARK: - Bar button

private struct ReaderBarButton: View {
    let symbol: String
    let label: String
    var enabled: Bool = true
    var active: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(active ? Brand.gold : (enabled ? Color.primary : Color.secondary.opacity(0.5)))
                .frame(width: 38, height: 38)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
        .accessibilityLabel(label)
    }
}
