import SwiftUI
import UIKit

/// The reader (v2 immersive): scripture on paper with an ornament title, a gold progress thread, read-along
/// highlighting while audio or auto-scroll runs, and a floating panel (listen · Aa · bookmark).
struct ReaderView: View {
    let catId: String
    let itemId: String

    init(catId: String, itemId: String) {
        self.catId = catId
        self.itemId = itemId
    }

    var body: some View {
        if let c = Library.category(catId), let it = c.items.first(where: { $0.id == itemId }) {
            ReaderPage(cat: c, item: it)
                .id(c.id + "|" + it.id)
        } else {
            EmptyStateView(symbol: "exclamationmark.triangle", title: "تعذّر العرض",
                           message: "تعذّر فتح هذا المحتوى، قد يكون غير متوفّر حالياً.")
                .navigationTitle("تعذّر العرض")
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// MARK: - Scroll metrics

private struct ReaderScrollMetrics: Equatable {
    var pct: Int = 0          // 0...100 scroll progress
    var longText: Bool = false // more than about three screens
    var fits: Bool = false     // whole text visible without scrolling
}

private let readerSupportEmail = "feedback@rafiqalmumin.app"

/// Reader colour modes: فاتح، ورقي، ليلي.
enum ReaderMode: String, CaseIterable, Identifiable {
    case light, paper, night
    var id: String { rawValue }
    var title: String {
        switch self {
        case .light: return "فاتح"
        case .paper: return "ورقي"
        case .night: return "ليلي"
        }
    }
}

// MARK: - Page

private struct ReaderPage: View {
    let cat: DuaaCategory
    let item: DuaaItem

    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.openURL) private var openURL
    @Environment(\.dismiss) private var dismiss
    @State private var player = AudioPlayer.shared

    @State private var paras: [String] = []
    @State private var topPara: Int?
    @State private var interactive = false
    @State private var current = 0
    @State private var metrics = ReaderScrollMetrics()
    @State private var started = false
    @State private var flash: String?
    @State private var flashTick = 0
    @State private var award = 0            // verses just credited (shown in the banner)
    @State private var awardKhatma = false
    @State private var awardSurah = false
    @State private var tracker: QuranReadingTracker?   // Quran only: credits verses at the reader's own pace
    @Environment(\.scenePhase) private var scenePhase
    @State private var goTopTick = 0
    @State private var found: Int?
    @State private var showSettings = false
    /// «سطراً سطراً»: one clause per line (duas only; the Quran keeps its verses).
    @AppStorage("readerPhrases") private var phraseMode = false
    /// Auto-scroll: moves on passage by passage at a reading pace (letters per second).
    @State private var autoScroll = false
    @State private var autoIndex: Int?
    @AppStorage("autoScrollSpeed") private var autoSpeed = 4      // 1…10
    /// Night look inside the reader only.
    @AppStorage("readerNight") private var night = false
    /// The highlighted line follows the linked recording while it plays.
    @AppStorage("readerFollowAudio") private var followAudio = true
    private var lettersPerSecond: Double { 3 * pow(1.25, Double(autoSpeed - 1)) }   // 3 … ~22
    /// Instructions and narration shown quieter, only in fully vowelled texts.
    private var styleRubrics: Bool { store.tashkeel && LibraryText.vowelled(item.text) }

    private func split(_ tashkeel: Bool) -> [String] {
        phraseMode && cat.id != "quran" ? LibraryText.phrases(item.text, tashkeel: tashkeel)
                                        : LibraryText.paragraphs(item.text, tashkeel: tashkeel, keepNumbers: cat.id == "quran")
    }

    // MARK: Derived

    private var idx: Int { cat.items.firstIndex(where: { $0.id == item.id }) ?? 0 }
    private var prevItem: DuaaItem? { idx > 0 ? cat.items[idx - 1] : nil }
    private var nextItem: DuaaItem? { idx + 1 < cat.items.count ? cat.items[idx + 1] : nil }
    private var fs: CGFloat { CGFloat(store.fontSize) }
    private var lh: CGFloat { CGFloat(store.lineSpacing) }
    private var mode: ReaderMode { night ? .night : (store.sepia ? .paper : .light) }
    private var ink: Color {
        switch mode {
        case .night: return Color(hex: 0xECE6D6)
        case .paper: return Color(hex: 0x1F2A28)
        case .light: return Color(hex: 0x10322D)
        }
    }
    private var faded: Color { ink.opacity(0.42) }
    private var subInk: Color { ink.opacity(0.62) }
    private var pageBg: Color {
        switch mode {
        case .night: return Brand.night
        case .paper: return Color(hex: 0xF7F0E1)
        case .light: return Color(hex: 0xFBFAF7)
        }
    }
    private var lineCard: Color { mode == .night ? Brand.nightCard : Color.white }
    private var isFav: Bool { store.isFav(cat.id, item.id) }
    private var hasBookmark: Bool { store.bookmarks.contains { $0.catId == cat.id && $0.itemId == item.id } }
    private var linkedAudio: AudioItem? { AudioLibrary.shared.linked(catId: cat.id, itemId: item.id) }
    private var audioActive: Bool {
        guard let a = linkedAudio, let c = player.current else { return false }
        return a.id == c.id && player.isPlaying
    }
    /// Paragraph the recording is probably at (letter-weighted share of elapsed time).
    private var audioPara: Int? {
        guard audioActive && followAudio && player.duration > 0 && !paras.isEmpty else { return nil }
        let f = max(0, min(1, player.position / player.duration))
        let counts = paras.map { max(1, ArabicSearch.stripTashkeel($0).filter { $0.isLetter }.count) }
        let total = Double(counts.reduce(0, +))
        var acc = 0.0
        for (i, c) in counts.enumerated() {
            acc += Double(c)
            if acc / total >= f { return i }
        }
        return paras.count - 1
    }
    /// Read-along highlight: auto-scroll, playing audio or the interactive mode.
    private var focusPara: Int? {
        if interactive { return current }
        if autoScroll { return autoIndex }
        return audioPara
    }
    private var readAlong: Bool { focusPara != nil }

    private var fraction: Double {
        if interactive && paras.count > 1 { return Double(current + 1) / Double(paras.count) }
        return Double(metrics.pct) / 100.0
    }

    private var minutesLeft: Int {
        max(1, Int(ceil(Double(LibraryText.readMinutes(item.text)) * (1 - fraction))))
    }

    private var spacingLabel: String {
        if store.lineSpacing >= 2.35 { return "٣" }
        if store.lineSpacing >= 2.05 { return "٢" }
        return "١"
    }

    private var shareText: String { item.title + "\n\n" + item.text + "\n\n" + AppLinks.signature }

    // MARK: Body

    var body: some View {
        ScrollViewReader { proxy in
            scroller
                .onAppear { start(proxy) }
                .onChange(of: current) { _, v in
                    if interactive {
                        withAnimation(.easeInOut(duration: 0.3)) { proxy.scrollTo(v, anchor: .center) }
                        store.saveScroll(cat.id, item.id, Double(v))
                    }
                    checkAward()
                }
                .onChange(of: audioPara) { _, p in
                    if let p { withAnimation(.easeInOut(duration: 0.5)) { proxy.scrollTo(p, anchor: .center) } }
                }
                .onChange(of: goTopTick) { _, _ in
                    withAnimation(.easeInOut(duration: 0.35)) { proxy.scrollTo("readerTop", anchor: .top) }
                }
                .task(id: autoScroll) {
                    guard autoScroll else { autoIndex = nil; return }
                    UIApplication.shared.isIdleTimerDisabled = true
                    defer { if !store.keepAwake { UIApplication.shared.isIdleTimerDisabled = false } }
                    var i = topPara ?? 0
                    while autoScroll && !Task.isCancelled && i < paras.count {
                        autoIndex = i
                        withAnimation(.easeInOut(duration: 0.8)) { proxy.scrollTo(i, anchor: .center) }
                        // Time to read this passage at the chosen pace (letters only, tashkeel ignored).
                        let letters = ArabicSearch.stripTashkeel(paras[i]).filter { $0.isLetter }.count
                        let secs = max(2.5, Double(letters) / lettersPerSecond)
                        var waited = 0.0
                        while waited < secs && autoScroll && !Task.isCancelled {
                            try? await Task.sleep(nanoseconds: 250_000_000)
                            waited += 0.25
                        }
                        // The reader may have scrolled by hand: continue from where they are.
                        if let t = topPara, t > i + 1 { i = t } else { i += 1 }
                    }
                    autoIndex = nil
                    if i >= paras.count { autoScroll = false }
                }
        }
        .background(pageBackground.ignoresSafeArea())
        .overlay(alignment: .trailing) { progressThread }
        .overlay(alignment: .bottom) { banners }
        .safeAreaInset(edge: .top, spacing: 0) { topBar }
        .safeAreaInset(edge: .bottom, spacing: 0) { bottomBars }
        .toolbar(.hidden, for: .navigationBar)
        .toolbar(.hidden, for: .tabBar)
        .environment(\.colorScheme, mode == .night ? .dark : .light)
        .keepScreenAwake(store.keepAwake)
        .onChange(of: store.keepAwake) { _, v in UIApplication.shared.isIdleTimerDisabled = v }
        .onChange(of: store.tashkeel) { _, v in
            paras = split(v)
            tracker?.layout(fullText: item.text, paragraphs: paras)
        }
        .onChange(of: phraseMode) { _, _ in
            paras = split(store.tashkeel)
            current = 0
        }
        .onChange(of: metrics) { _, _ in checkAward() }
        .task(id: flashTick) {
            guard flash != nil else { return }
            try? await Task.sleep(nanoseconds: 1_800_000_000)
            if !Task.isCancelled { withAnimation { flash = nil } }
        }
        .task {
            // Quran: once a second, convert on-screen reading time into verses at the reader's pace.
            guard cat.id == "quran" else { return }
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                if Task.isCancelled { return }
                recordQuran()
            }
        }
        .sheet(isPresented: $showSettings) { settingsSheet }
    }

    private var pageBackground: some View {
        ZStack {
            pageBg
            if mode != .light {
                GirihPattern(cell: 64).foregroundStyle(ink.opacity(mode == .night ? 0.05 : 0.045))
            }
        }
    }

    private var scroller: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                header.id("readerTop")
                textBody
                if !interactive && metrics.longText { backToTop }
            }
            .padding(.horizontal, 20)
            .padding(.top, 4)
            .padding(.bottom, 24)
            .readableWidth(760)
        }
        .scrollPosition(id: $topPara, anchor: .top)
        .onScrollGeometryChange(for: ReaderScrollMetrics.self, of: { geo in
            let maxY = geo.contentSize.height + geo.contentInsets.top + geo.contentInsets.bottom - geo.containerSize.height
            let off = geo.contentOffset.y + geo.contentInsets.top
            var m = ReaderScrollMetrics()
            if maxY > 1 {
                m.pct = Int(max(0, min(100, (off / maxY) * 100)))
            }
            m.longText = maxY > 1400
            m.fits = maxY <= 1
            return m
        }, action: { _, newValue in
            metrics = newValue
        })
        .onChange(of: topPara) { _, p in
            if !interactive, let p { store.saveScroll(cat.id, item.id, Double(p)) }
        }
    }

    // MARK: Lifecycle

    private func start(_ proxy: ScrollViewProxy) {
        if started { return }
        started = true
        paras = split(store.tashkeel)
        if let n = QuranProgress.surahNumber(item.id) {
            QuranProgress.migrate(store)
            let t = QuranReadingTracker(surah: n, alreadyRead: QuranProgress.reach(store)[n] ?? 0)
            t.layout(fullText: item.text, paragraphs: paras)
            tracker = t
        }
        store.recordRead(cat.id, item.id)
        if let q = nav.pendingFind {
            nav.pendingFind = nil
            let terms = ArabicSearch.normalize(q).split(separator: " ").map(String.init)
            let hit = terms.isEmpty ? nil : paras.firstIndex { p in
                let n = ArabicSearch.normalize(p)
                return terms.allSatisfy { n.contains($0) }
            } ?? paras.firstIndex { p in
                let n = ArabicSearch.normalize(p)
                return terms.contains { n.contains($0) }
            }
            if let hit {
                found = hit
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    withAnimation(.easeInOut(duration: 0.4)) { proxy.scrollTo(hit, anchor: .center) }
                }
                show("وُجد «\(q)» في المقطع \((hit + 1).ar)")
                DispatchQueue.main.asyncAfter(deadline: .now() + 6) { withAnimation { found = nil } }
                return
            }
        }
        let saved = Int(store.scroll(cat.id, item.id))
        if saved > 0 && saved < paras.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                proxy.scrollTo(saved, anchor: .top)
            }
            show("استُؤنِفت القراءة من موضعك الأخير ✓")
        }
    }

    private func show(_ msg: String) {
        withAnimation { flash = msg }
        flashTick += 1
    }

    private func checkAward() {}

    /// Credits newly read verses (Quran only) and celebrates a finished surah or khatma.
    private func recordQuran() {
        guard let t = tracker else { return }
        let gained = t.tick(store: store, active: scenePhase == .active)
        guard gained > 0 else { return }
        let ev = QuranProgress.record(store, surah: t.surah, upTo: t.credited)
        if ev.surahDone || ev.khatmaDone {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                award = max(ev.verses, 1)
                awardSurah = ev.surahDone
                awardKhatma = ev.khatmaDone
            }
            Haptic.confirm()
        }
    }

    // MARK: Actions

    private func go(_ target: DuaaItem?) {
        guard let target else { return }
        Haptic.tick()
        showSettings = false
        var p = nav.path(nav.tab)
        if !p.isEmpty { p.removeLast() }
        p.append(.reader(cat.id, target.id))
        nav.paths[nav.tab] = p
    }

    private func changeFont(_ delta: Double) {
        store.fontSize = max(15, min(40, store.fontSize + delta))
        Haptic.tick()
    }

    private func cycleSpacing() {
        store.lineSpacing = store.lineSpacing >= 2.4 ? 1.7 : store.lineSpacing + 0.2
    }

    private func addBookmark() {
        let para = interactive ? current : (topPara ?? 0)
        store.addBookmark(Store.Bookmark(catId: cat.id, itemId: item.id, para: para, title: item.title))
        show("حُفظت العلامة ✓")
        Haptic.confirm()
    }

    private func copyText() {
        UIPasteboard.general.string = item.title + "\n\n" + item.text
        show("نُسِخ النصّ ✓")
    }

    private func reportError() {
        let subject = "بلاغ عن خطأ في نصّ: \(item.title) [\(cat.id)/\(item.id)]"
        let body = "السلام عليكم،\nلاحظتُ ما يلي في نصّ «\(item.title)» (المعرّف: \(cat.id)/\(item.id)):\n\n(صِف الخطأ هنا)\n\nوجزاكم الله خيراً."
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~")
        let s = subject.addingPercentEncoding(withAllowedCharacters: allowed) ?? ""
        let b = body.addingPercentEncoding(withAllowedCharacters: allowed) ?? ""
        if let url = URL(string: "mailto:\(readerSupportEmail)?subject=\(s)&body=\(b)") { openURL(url) }
    }

    private var quranSurah: Int? {
        guard cat.id == "quran" else { return nil }
        return Int(item.id.replacingOccurrences(of: "q-", with: ""))
    }

    private func findRecording() {
        nav.pendingListen = item.title
        nav.pendingLinkTarget = "\(cat.id)|\(item.id)"
        nav.openTool(.listen)
    }

    /// The panel's play button: the surah, the linked recording, or Listen to find one.
    private func playTapped() {
        Haptic.tick()
        if let n = quranSurah { Task { await QuranAudio.play(from: n) }; return }
        guard let a = linkedAudio else { findRecording(); return }
        if player.current?.id == a.id { player.toggle() } else { player.play(a) }
    }

    // MARK: Top bar: back, progress chip, options

    private var topBar: some View {
        HStack {
            RoundIconButton(symbol: "chevron.backward", label: "رجوع", translucent: mode == .night) { dismiss() }
            Spacer()
            Text("\(Int(fraction * 100).ar)٪ · نحو \(minutesLeft.ar) \(minutesLeft == 1 ? "دقيقة" : (minutesLeft <= 10 ? "دقائق" : "دقيقة")) متبقية")
                .font(.caption.weight(.semibold))
                .foregroundStyle(subInk)
                .lineLimit(1)
            Spacer()
            optionsMenu
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(pageBg.opacity(0.92))
    }

    // MARK: Header: ornament, title, source line

    @ViewBuilder private var header: some View {
        VStack(spacing: 8) {
            OrnamentDivider(color: Brand.gold)
            if cat.id == "quran" {
                quranMedallion
            } else {
                Text(item.title)
                    .font(.display(28))
                    .foregroundStyle(mode == .night ? Brand.goldSoft : Color(hex: 0x7D5A20))
                    .multilineTextAlignment(.center)
                Text(sourceLine)
                    .font(.caption)
                    .foregroundStyle(subInk)
                    .multilineTextAlignment(.center)
                if let intro = item.intro { introCard(intro) }
            }
            Text("\(cat.name) · \((idx + 1).ar) من \(cat.items.count.ar)")
                .font(.caption2.weight(.semibold))
                .foregroundStyle(subInk.opacity(0.8))
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 6)
    }

    private var sourceLine: String {
        let read = LibraryText.readLabel(LibraryText.readMinutes(item.text))
        if let src = item.src { return "\(src) · \(read)" }
        return read
    }

    private var quranMedallion: some View {
        VStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .fill(Brand.emerald.opacity(0.08))
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .strokeBorder(Brand.emerald.opacity(0.35), lineWidth: 1.5)
                StarShape().stroke(Brand.emerald.opacity(0.12), lineWidth: 1.5).frame(width: 130, height: 130)
                Text(item.title.replacingOccurrences(of: "سورة ", with: ""))
                    .font(.display(26))
                    .foregroundStyle(mode == .night ? Brand.goldSoft : Brand.deeper)
                    .multilineTextAlignment(.center)
                    .padding(8)
            }
            .frame(width: 150, height: 150)
            if let intro = item.intro {
                Text(intro.replacingOccurrences(of: "\n", with: " · "))
                    .font(.footnote)
                    .foregroundStyle(subInk)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
            }
        }
        .frame(maxWidth: .infinity)
        .accessibilityElement(children: .combine)
    }

    private func introCard(_ intro: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            RoundedRectangle(cornerRadius: 2).fill(Brand.gold).frame(width: 3, height: 36)
            VStack(alignment: .leading, spacing: 4) {
                Text("نبذة").font(.caption.weight(.heavy)).foregroundStyle(Brand.goldDeep)
                Text(intro).font(.subheadline).foregroundStyle(subInk)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Brand.gold.opacity(0.1), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .padding(.top, 6)
    }

    // MARK: Text

    private var textBody: some View {
        VStack(alignment: .leading, spacing: readAlong ? 6 : (phraseMode && cat.id != "quran" ? fs * 0.3 : fs * 0.5)) {
            ForEach(Array(paras.enumerated()), id: \.offset) { i, p in
                paragraph(i, p)
                    .background(found == i ? Brand.gold.opacity(0.2) : Color.clear,
                                in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .onScrollVisibilityChange(threshold: 0.35) { v in tracker?.setVisible(i, v, store: store) }
                    .id(i)
            }
        }
        .scrollTargetLayout()
        .textSelection(.enabled)
        .padding(.top, 8)
        .frame(maxWidth: .infinity, alignment: .leading)
        .environment(\.layoutDirection, .rightToLeft)
    }

    /// Quran verses get gold ornate verse markers; other texts are shown as written.
    private func verseText(_ p: String) -> Text {
        cat.id == "quran" ? Text(LibraryText.quranAttributed(p, tint: Brand.goldDeep)) : Text(p)
    }

    @ViewBuilder private func paragraph(_ i: Int, _ p: String) -> some View {
        let spacing = max(2, fs * (lh - 1.45))
        if styleRubrics && LibraryText.isRubric(p) {
            HStack(alignment: .top, spacing: 8) {
                Image(systemName: "info.circle").font(.caption).foregroundStyle(Brand.gold)
                Text(p)
                    .font(.system(size: max(13, fs * 0.6), weight: .medium))
                    .lineSpacing(4)
                    .foregroundStyle(subInk)
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(.vertical, 6)
        } else if LibraryText.isBasmala(p) {
            Text(p)
                .font(Font.scripture(fs * 0.98))
                .fontWeight(.bold)
                .lineSpacing(spacing)
                .foregroundStyle(Brand.goldDeep)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity, alignment: .center)
                .padding(.bottom, 4)
        } else if readAlong {
            // Read-along: the current line sits on a white card, the rest fade back.
            let isCur = i == focusPara
            let isDone = (focusPara ?? 0) > i
            verseText(p)
                .font(Font.scripture(fs))
                .fontWeight(isCur ? Font.Weight.bold : Font.Weight.regular)
                .lineSpacing(spacing)
                .foregroundStyle(isCur ? (mode == .night ? Brand.goldSoft : Brand.deeper) : (isDone ? faded : ink.opacity(0.55)))
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, isCur ? 14 : 4)
                .padding(.vertical, isCur ? 12 : 4)
                .background(isCur ? lineCard : Color.clear, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .shadow(color: isCur ? Color.black.opacity(mode == .night ? 0.3 : 0.08) : .clear, radius: 10, y: 4)
                .contentShape(Rectangle())
                .onTapGesture { if interactive { current = i } }
                .animation(.easeInOut(duration: 0.25), value: isCur)
        } else {
            verseText(p)
                .font(Font.scripture(fs))
                .lineSpacing(spacing)
                .foregroundStyle(ink)
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var backToTop: some View {
        Button { goTopTick += 1 } label: {
            Label("العودة إلى البداية", systemImage: "arrow.up")
                .font(.footnote.weight(.bold))
                .foregroundStyle(Brand.accent)
                .padding(.horizontal, 18).padding(.vertical, 10)
                .background(Brand.soft, in: Capsule())
        }
        .buttonStyle(.plain)
        .frame(maxWidth: .infinity)
        .padding(.top, 4)
    }

    // MARK: Progress thread (gold, along the trailing edge)

    @ViewBuilder private var progressThread: some View {
        let f = fraction
        GeometryReader { g in
            ZStack(alignment: .top) {
                Capsule().fill(Brand.gold.opacity(0.18)).frame(width: 3)
                Capsule().fill(Brand.gold).frame(width: 3, height: max(8, g.size.height * CGFloat(min(1, f))))
            }
            .frame(width: 3)
            .frame(maxWidth: .infinity, alignment: .trailing)
        }
        .padding(.trailing, 6)
        .padding(.vertical, 120)
        .allowsHitTesting(false)
        .animation(.easeOut(duration: 0.2), value: f)
        .accessibilityHidden(true)
    }

    // MARK: Overlays

    @ViewBuilder private var banners: some View {
        VStack(spacing: 10) {
            if award > 0 { awardBanner.transition(.scale(scale: 0.85).combined(with: .opacity)) }
            if let flash {
                Text(flash)
                    .font(.footnote.weight(.bold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 20).padding(.vertical, 12)
                    .background(Brand.emerald, in: Capsule())
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .padding(.horizontal, 18)
        .padding(.bottom, 12)
    }

    private var awardBanner: some View {
        let khatma = awardKhatma
        return Button { withAnimation { award = 0 } } label: {
            HStack(spacing: 14) {
                Image(systemName: "rosette").font(.system(size: 28, weight: .semibold))
                VStack(alignment: .leading, spacing: 2) {
                    Text(khatma ? "ختمتَ القرآن الكريم! تقبّل الله 🎉" : "أحسنت، أتممتَ السورة")
                        .font(.headline.weight(.heavy))
                    Text("اليوم \(QuranProgress.today(store).ar) من \(QuranProgress.goal(store).ar) آية · الختمة \(Int((QuranProgress.khatmaFraction(store) * 100).rounded()).ar)٪")
                        .font(.footnote.weight(.bold)).opacity(0.92)
                }
                Spacer(minLength: 6)
                Text("\(QuranProgress.lifetime(store).ar) نقطة").font(.caption.weight(.bold))
            }
            .foregroundStyle(.white)
            .padding(16)
            .background(LinearGradient(colors: [Brand.gold, Color(hex: 0xD8A74E)], startPoint: .leading, endPoint: .trailing),
                        in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    // MARK: Bottom: floating panel (+ auto-scroll and segment bars when active)

    private var bottomBars: some View {
        VStack(spacing: 8) {
            if autoScroll { autoBar }
            if interactive && paras.count > 1 { segmentBar }
            panel
        }
        .padding(.horizontal, 14)
        .padding(.bottom, 8)
        .padding(.top, 4)
    }

    private var autoBar: some View {
        HStack(spacing: 6) {
            ReaderBarButton(symbol: "tortoise", label: "أبطأ", enabled: autoSpeed > 1) { autoSpeed -= 1 }
            Text("السرعة \(autoSpeed.ar)")
                .font(.footnote.weight(.heavy)).foregroundStyle(Brand.accent)
                .frame(minWidth: 72)
            ReaderBarButton(symbol: "hare", label: "أسرع", enabled: autoSpeed < 10) { autoSpeed += 1 }
            ReaderBarButton(symbol: "stop.fill", label: "إيقاف التمرير", active: true) { autoScroll = false }
        }
        .padding(6)
        .background(lineCard, in: Capsule())
        .shadow(color: Color.black.opacity(0.08), radius: 10, y: 4)
    }

    private var segmentBar: some View {
        HStack(spacing: 6) {
            ReaderBarButton(symbol: "chevron.backward", label: "المقطع السابق", enabled: current > 0) {
                if current > 0 { current -= 1 }
            }
            Text("\((current + 1).ar)/\(paras.count.ar)")
                .font(.footnote.weight(.heavy)).foregroundStyle(Brand.accent)
                .frame(minWidth: 64)
            ReaderBarButton(symbol: "chevron.forward", label: "المقطع التالي", enabled: current < paras.count - 1) {
                if current < paras.count - 1 { current += 1 }
            }
        }
        .padding(6)
        .background(lineCard, in: Capsule())
        .shadow(color: Color.black.opacity(0.08), radius: 10, y: 4)
    }

    private var panelTitle: String {
        if quranSurah != nil { return "استمع للسورة" }
        if audioActive { return "يُقرأ معك الآن" }
        return linkedAudio == nil ? "ابحث عن تسجيل صوتي" : "استمع واقرأ معه"
    }

    private var panelSubtitle: String {
        if quranSurah != nil { return QuranAudio.reciterName }
        guard let a = linkedAudio else { return "اربط تسجيلاً من «استمع»" }
        return a.subtitle + (followAudio ? " · يتبع السطر" : "")
    }

    private var panel: some View {
        HStack(spacing: 10) {
            Button(action: playTapped) {
                Image(systemName: audioActive ? "pause.fill" : (linkedAudio == nil && quranSurah == nil ? "magnifyingglass" : "play.fill"))
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 56, height: 56)
                    .background(Brand.deeper, in: Circle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel(panelTitle)
            Menu {
                if let a = linkedAudio {
                    Button { player.play(a) } label: { Label("استمع: \(a.subtitle)", systemImage: "play.fill") }
                }
                if quranSurah == nil {
                    Button { findRecording() } label: {
                        Label(linkedAudio == nil ? "ابحث عن تسجيل صوتي" : "تغيير التسجيل", systemImage: "magnifyingglass")
                    }
                    Toggle(isOn: $followAudio) { Label("الصوت يتبع السطر", systemImage: "text.line.first.and.arrowtriangle.forward") }
                }
            } label: {
                VStack(alignment: .leading, spacing: 2) {
                    Text(panelTitle).font(.subheadline.weight(.bold)).foregroundStyle(Brand.ink).lineLimit(1)
                    Text(panelSubtitle).font(.caption).foregroundStyle(Brand.muted).lineLimit(1)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
            }
            .accessibilityLabel("خيارات الاستماع")
            Button { showSettings = true; Haptic.tick() } label: {
                Text("Aa").font(.system(size: 15, weight: .bold))
                    .foregroundStyle(Brand.ink)
                    .frame(width: 44, height: 44)
                    .background(Brand.soft, in: Circle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("خيارات القراءة")
            Button { addBookmark() } label: {
                Image(systemName: hasBookmark ? "bookmark.fill" : "bookmark")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(hasBookmark ? Brand.gold : Brand.ink)
                    .frame(width: 44, height: 44)
                    .background(Brand.soft, in: Circle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("ضع علامة")
        }
        .padding(10)
        .padding(.leading, 2)
        .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 30, style: .continuous))
        .shadow(color: Color(hex: 0x10322D).opacity(mode == .night ? 0.4 : 0.14), radius: 16, y: 8)
    }

    // MARK: "…" menu

    private var optionsMenu: some View {
        Menu {
            Section {
                Button { store.toggleFav(cat.id, item.id); Haptic.tick() } label: {
                    Label(isFav ? "إزالة من المفضّلة" : "حفظ في المفضّلة", systemImage: isFav ? "star.fill" : "star")
                }
                Button { addBookmark() } label: { Label("ضع علامة", systemImage: "bookmark") }
                Button { ShareCard.present(title: item.title, text: item.text, source: item.src) } label: { Label("مشاركة كبطاقة", systemImage: "photo") }
                ShareLink(item: shareText) { Label("مشاركة النصّ", systemImage: "square.and.arrow.up") }
                Button { copyText() } label: { Label("نسخ النصّ", systemImage: "doc.on.doc") }
            }
            Section {
                Button { go(prevItem) } label: { Label("النصّ السابق", systemImage: "chevron.backward") }.disabled(prevItem == nil)
                Button { go(nextItem) } label: { Label("النصّ التالي", systemImage: "chevron.forward") }.disabled(nextItem == nil)
            }
            Section {
                Toggle(isOn: Binding(get: { store.keepAwake }, set: { v in store.keepAwake = v })) {
                    Label("الشاشة مضاءة", systemImage: "sun.max")
                }
                Button { cycleSpacing() } label: { Label("تباعد \(spacingLabel)", systemImage: "arrow.up.and.down.text.horizontal") }
                Button { reportError() } label: { Label("بلاغ عن خطأ", systemImage: "flag") }
            }
        } label: {
            Image(systemName: "ellipsis")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(mode == .night ? Color.white : Brand.ink)
                .frame(width: 42, height: 42)
                .background(mode == .night ? Color.white.opacity(0.14) : Color.white, in: Circle())
        }
        .accessibilityLabel("المزيد")
    }

    // MARK: Aa sheet

    private var settingsSheet: some View {
        ReaderSettingsSheet(
            sample: paras.first ?? item.title,
            isQuran: cat.id == "quran",
            mode: Binding(get: { mode }, set: { m in
                switch m {
                case .night: night = true
                case .paper: night = false; store.sepia = true
                case .light: night = false; store.sepia = false
                }
            }),
            interactive: Binding(get: { interactive }, set: { v in interactive = v; current = 0 }),
            phraseMode: $phraseMode,
            autoScroll: $autoScroll,
            autoSpeed: $autoSpeed,
            followAudio: $followAudio,
            hasPrev: prevItem != nil, hasNext: nextItem != nil,
            onPrev: { go(prevItem) }, onNext: { go(nextItem) }, onReport: { showSettings = false; reportError() }
        )
        .environment(store)
        .environment(\.layoutDirection, .rightToLeft)
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
        .presentationBackground(Brand.canvas)
    }
}

// MARK: - Aa sheet

struct ReaderSettingsSheet: View {
    let sample: String
    let isQuran: Bool
    @Binding var mode: ReaderMode
    @Binding var interactive: Bool
    @Binding var phraseMode: Bool
    @Binding var autoScroll: Bool
    @Binding var autoSpeed: Int
    @Binding var followAudio: Bool
    var hasPrev: Bool
    var hasNext: Bool
    var onPrev: () -> Void
    var onNext: () -> Void
    var onReport: () -> Void

    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text("القراءة").font(.display(22)).foregroundStyle(Brand.ink)
                    Spacer()
                    Button("تمّ") { dismiss() }.font(.subheadline.weight(.bold)).foregroundStyle(Brand.accent)
                }
                .padding(.top, 4)
                fontCard
                modeRow
                togglesCard
                HStack(spacing: 10) {
                    sheetButton("الدعاء السابق", enabled: hasPrev, action: onPrev)
                    sheetButton("الدعاء التالي", enabled: hasNext, action: onNext)
                    sheetButton("أبلغ عن خطأ", enabled: true, tint: Brand.goldDeep, action: onReport)
                }
            }
            .padding(.horizontal, 20).padding(.bottom, 24)
        }
        .background(Brand.canvas)
        .toggleStyle(ReaderCheckToggle())
    }

    private var fontCard: some View {
        VStack(spacing: 10) {
            Text(sample)
                .font(.scripture(CGFloat(store.fontSize)))
                .foregroundStyle(Brand.ink)
                .lineLimit(1)
                .minimumScaleFactor(0.4)
                .frame(maxWidth: .infinity)
                .frame(height: 52)
            HStack(spacing: 10) {
                Button { store.fontSize = max(15, store.fontSize - 2); Haptic.tick() } label: {
                    Text("أ").font(.scripture(16)).foregroundStyle(Brand.ink).frame(width: 52, height: 40).background(Brand.soft, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
                .buttonStyle(.plain).accessibilityLabel("تصغير الخط")
                Slider(value: Binding(get: { store.fontSize }, set: { store.fontSize = $0 }), in: 15...40, step: 1)
                    .tint(Brand.deeper)
                    .accessibilityLabel("حجم الخط")
                Button { store.fontSize = min(40, store.fontSize + 2); Haptic.tick() } label: {
                    Text("أ").font(.scripture(26)).foregroundStyle(Brand.ink).frame(width: 52, height: 40).background(Brand.soft, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
                .buttonStyle(.plain).accessibilityLabel("تكبير الخط")
            }
        }
        .card(22, padding: 14)
    }

    private var modeRow: some View {
        HStack(spacing: 10) {
            ForEach(ReaderMode.allCases) { m in
                Button { mode = m; Haptic.tick() } label: {
                    Text(mode == m ? "\(m.title) ✓" : m.title)
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(m == .night ? Color.white : Brand.ink)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(m == .night ? Brand.night : (m == .paper ? Color(hex: 0xF7F0E1) : Brand.cardFill),
                                    in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(mode == m ? Brand.deeper : Brand.line, lineWidth: mode == m ? 2 : 1))
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(mode == m ? .isSelected : [])
            }
        }
    }

    private var togglesCard: some View {
        VStack(spacing: 0) {
            toggleRow("التشكيل", sub: nil, isOn: Binding(get: { store.tashkeel }, set: { store.tashkeel = $0 }))
            Divider().overlay(Brand.line)
            if !isQuran {
                toggleRow("سطراً سطراً", sub: "كلّ عبارة في سطر", isOn: $phraseMode)
                Divider().overlay(Brand.line)
            }
            toggleRow("تمرير تلقائي", sub: "السرعة \(autoSpeed.ar) من ١٠", isOn: $autoScroll)
            Divider().overlay(Brand.line)
            toggleRow("مقطعاً مقطعاً", sub: "للمجالس", isOn: $interactive)
            if !isQuran {
                Divider().overlay(Brand.line)
                toggleRow("الصوت يتبع السطر", sub: "عند التشغيل", isOn: $followAudio)
            }
            Divider().overlay(Brand.line)
            toggleRow("الشاشة مضاءة", sub: "أثناء القراءة", isOn: Binding(get: { store.keepAwake }, set: { store.keepAwake = $0 }))
        }
        .card(22, padding: 0)
    }

    private func toggleRow(_ title: String, sub: String?, isOn: Binding<Bool>) -> some View {
        Toggle(isOn: isOn) {
            HStack(spacing: 6) {
                Text(title).font(.subheadline.weight(.bold)).foregroundStyle(Brand.ink)
                if let sub { Text("· \(sub)").font(.caption).foregroundStyle(Brand.muted) }
            }
        }
        .padding(.horizontal, 16).padding(.vertical, 12)
    }

    private func sheetButton(_ title: String, enabled: Bool, tint: Color = Brand.accent, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title).font(.caption.weight(.bold))
                .foregroundStyle(tint)
                .frame(maxWidth: .infinity)
                .frame(height: 50)
                .background(Brand.soft, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
        .opacity(enabled ? 1 : 0.45)
    }
}

/// Square check box toggle (as in the Aa sheet mockup).
struct ReaderCheckToggle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        Button { configuration.isOn.toggle(); Haptic.tick() } label: {
            HStack {
                configuration.label
                Spacer()
                ZStack {
                    RoundedRectangle(cornerRadius: 6, style: .continuous)
                        .fill(configuration.isOn ? Brand.deeper : Color.clear)
                    RoundedRectangle(cornerRadius: 6, style: .continuous)
                        .stroke(configuration.isOn ? Brand.deeper : Brand.muted, lineWidth: 1.5)
                    if configuration.isOn {
                        Image(systemName: "checkmark").font(.system(size: 12, weight: .bold)).foregroundStyle(.white)
                    }
                }
                .frame(width: 24, height: 24)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(configuration.isOn ? .isSelected : [])
    }
}

// MARK: - Bar button

private struct ReaderBarButton: View {
    let symbol: String
    let label: String
    var enabled: Bool = true
    var active: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(active ? Brand.gold : (enabled ? Brand.ink : Brand.muted.opacity(0.5)))
                .frame(width: 38, height: 38)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
        .accessibilityLabel(label)
    }
}
