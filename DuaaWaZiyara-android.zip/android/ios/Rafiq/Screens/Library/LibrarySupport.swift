import SwiftUI

// Shared helpers for the Library group (ported from Screens.kt, DataPart03c.kt and Settings.kt).

enum LibraryText {
    /// Approximate reading time at recitation pace (about 100 words per minute).
    static func readMinutes(_ text: String) -> Int {
        let words = text.split(whereSeparator: { $0.isWhitespace || $0.isNewline }).count
        return max(1, Int(ceil(Double(words) / 100.0)))
    }

    static func readLabel(_ m: Int) -> String {
        switch m {
        case 1: return "نحو دقيقة"
        case 2: return "نحو دقيقتين"
        case 3...10: return "نحو \(m.ar) دقائق"
        default: return "نحو \(m.ar) دقيقة"
        }
    }

    /// List subtitle: drops a repeated category name from the source and appends the reading time.
    static func listSubtitle(catName: String, src: String?, text: String) -> String {
        var core: String? = nil
        if let src {
            if src.hasPrefix(catName) {
                let rest = String(src.dropFirst(catName.count))
                let trimSet: Set<Character> = [" ", "—", "-", "،", ":"]
                let trimmed = String(rest.drop(while: { trimSet.contains($0) }))
                core = trimmed.trimmingCharacters(in: .whitespaces).isEmpty ? nil : trimmed
            } else {
                core = src
            }
        }
        let time = readLabel(readMinutes(text))
        if let core { return "\(core) · \(time)" }
        return time
    }

    /// Arabic counted noun: 1 singular, 2 dual, 3 to 10 plural, 11+ accusative singular.
    static func arabicCount(_ n: Int, one: String, two: String, plural: String, many: String) -> String {
        if n == 1 { return one }
        if n == 2 { return two }
        let r = n % 100
        if r >= 3 && r <= 10 { return "\(n.ar) \(plural)" }
        return "\(n.ar) \(many)"
    }

    /// Dua number inside al-Sahifa al-Sajjadiyya (some duas have non-numeric ids).
    static func sahifaOrder(_ id: String) -> Int {
        switch id {
        case "saj-mohimmat": return 7
        case "mu-makarim": return 20
        default:
            if id.hasPrefix("saj-"), let n = Int(id.dropFirst(4)) { return n }
            return 999
        }
    }

    /// Number used by the "number jump" filter for sahifa, ramadan and quran.
    static func jumpNumber(catId: String, itemId: String) -> Int? {
        switch catId {
        case "sahifa": return sahifaOrder(itemId)
        case "ramadan":
            guard itemId.hasPrefix("r-day-") else { return nil }
            return Int(itemId.dropFirst(6))
        default:
            guard itemId.hasPrefix("q-") else { return nil }
            return Int(itemId.dropFirst(2))
        }
    }

    /// Splits a text into trimmed, non-empty paragraphs (blank-line separated), with or without tashkeel.
    /// `keepNumbers`: the Quran's verse numbers «(١)» look like footnote marks and must stay.
    static func paragraphs(_ text: String, tashkeel: Bool, keepNumbers: Bool = false) -> [String] {
        let raw = tashkeel ? text : ArabicSearch.stripTashkeel(text)
        // Split on every line break, then break very long passages at commas: iOS stops shaping
        // Arabic correctly inside a single text run of many thousand characters (Kumayl is one 20k paragraph).
        return raw.components(separatedBy: "\n")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .map { keepNumbers ? $0 : dropFootnoteMarks($0) }
            .flatMap { chunk($0) }
    }

    /// Splits a passage longer than ~600 characters into pieces of 250–600 characters at "،" / "." / "؛" boundaries.
    static func chunk(_ p: String) -> [String] {
        if p.count <= 600 { return [p] }
        var out: [String] = []
        var cur = ""
        for word in p.split(separator: " ", omittingEmptySubsequences: true) {
            cur += cur.isEmpty ? String(word) : " " + word
            let endsClause = word.hasSuffix("،") || word.hasSuffix(".") || word.hasSuffix("؛") || word.hasSuffix(":")
            if (endsClause && cur.count >= 250) || cur.count >= 600 {
                out.append(cur); cur = ""
            }
        }
        if !cur.isEmpty { out.append(cur) }
        return out
    }

    /// «سطراً سطراً»: each clause on its own line (split at ، ؛ . :), short clauses kept together,
    /// so long duas read in breaths, as they are recited.
    static func phrases(_ text: String, tashkeel: Bool) -> [String] {
        paragraphs(text, tashkeel: tashkeel).flatMap { p -> [String] in
            if isBasmala(p) || isRubric(p) || p.count < 90 { return [p] }
            var out: [String] = []
            var cur = ""
            for word in p.split(separator: " ", omittingEmptySubsequences: true) {
                cur += cur.isEmpty ? String(word) : " " + word
                let ends = word.hasSuffix("،") || word.hasSuffix("؛") || word.hasSuffix(".") || word.hasSuffix(":")
                if ends && cur.count >= 28 { out.append(cur); cur = "" }
            }
            if !cur.isEmpty {
                if cur.count < 20, let last = out.popLast() { out.append(last + " " + cur) } else { out.append(cur) }
            }
            return out
        }
    }

    /// Narration and instructions inside a dua («روى…»، «ثمّ تقول…»، «(ويذكر حاجته)»): mostly unvowelled
    /// text. Shown smaller and quieter so the words to recite stand out.
    static func isRubric(_ p: String) -> Bool {
        let t = p.trimmingCharacters(in: .whitespaces)
        if t.hasPrefix("(") && t.hasSuffix(")") && t.count < 160 { return true }
        let letters = t.unicodeScalars.filter { (0x0621...0x064A).contains($0.value) }.count
        guard letters >= 8 else { return false }
        let marks = t.unicodeScalars.filter { (0x064B...0x0652).contains($0.value) }.count
        return Double(marks) / Double(letters) < 0.12
    }

    /// True for texts written with full tashkeel (most duas); narration in them is the unvowelled part.
    static func vowelled(_ text: String) -> Bool {
        let sample = text.prefix(3000).unicodeScalars
        let letters = sample.filter { (0x0621...0x064A).contains($0.value) }.count
        let marks = sample.filter { (0x064B...0x0652).contains($0.value) }.count
        return letters > 0 && Double(marks) / Double(letters) > 0.3
    }

    /// Editorial footnote markers such as «(2)» that point nowhere in the app.
    static func dropFootnoteMarks(_ p: String) -> String {
        p.replacingOccurrences(of: #"\s?\([0-9٠-٩]{1,3}\)"#, with: "", options: .regularExpression)
    }

    /// Quran passage with each verse number «(12)» drawn as a gold ornate marker «﴿١٢﴾».
    static func quranAttributed(_ p: String, tint: Color) -> AttributedString {
        var out = AttributedString()
        var rest = Substring(p)
        while let r = rest.range(of: #"\(([0-9]{1,3})\)"#, options: .regularExpression) {
            out += AttributedString(String(rest[rest.startIndex..<r.lowerBound]))
            let digits = rest[r].dropFirst().dropLast()
            var mark = AttributedString("\u{FD3F}" + String(digits).arabicDigits + "\u{FD3E}")
            mark.foregroundColor = tint
            out += mark
            rest = rest[r.upperBound...]
        }
        out += AttributedString(String(rest))
        return out
    }

    static func isBasmala(_ para: String) -> Bool {
        ArabicSearch.stripTashkeel(para).hasPrefix("بسم الله الرحمن الرحيم") && para.count < 60
    }
}

/// Quran reading points (same keys as the Android Settings: quranDone, quranPoints, khatmaAwarded).
/// Small trailing indicator used in item rows: gold star for favourites, check mark for read texts.
struct LibraryItemRow: View {
    let title: String
    let subtitle: String?
    var read: Bool = false
    var fav: Bool = false

    var body: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.ui(.body, .semibold)).foregroundStyle(.primary).lineLimit(2)
                if let subtitle, !subtitle.isEmpty {
                    Text(subtitle).font(.ui(.footnote)).foregroundStyle(.secondary).lineLimit(2)
                }
            }
            Spacer(minLength: 4)
            if fav {
                Image(systemName: "star.fill").font(.footnote).foregroundStyle(Brand.gold)
                    .accessibilityLabel("في المفضّلة")
            } else if read {
                Image(systemName: "checkmark").font(.footnote.weight(.bold)).foregroundStyle(Brand.good.opacity(0.75))
                    .accessibilityLabel("مقروء")
            }
        }
        .padding(.vertical, 2)
    }
}
