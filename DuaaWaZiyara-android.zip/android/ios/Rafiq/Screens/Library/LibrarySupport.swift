import SwiftUI

// Shared helpers for the Library group (ported from Screens.kt, DataPart03c.kt and Settings.kt).

enum LibraryText {
    /// Approximate reading time at recitation pace (about 100 words per minute).
    static func readMinutes(_ text: String) -> Int {
        let words = text.split(whereSeparator: { $0.isWhitespace || $0.isNewline }).count
        return max(1, Int(ceil(Double(words) / 100.0)))
    }

    static func readLabel(_ m: Int) -> String {
        switch m {
        case 1: return "نحو دقيقة"
        case 2: return "نحو دقيقتين"
        case 3...10: return "نحو \(m.ar) دقائق"
        default: return "نحو \(m.ar) دقيقة"
        }
    }

    /// List subtitle: drops a repeated category name from the source and appends the reading time.
    static func listSubtitle(catName: String, src: String?, text: String) -> String {
        var core: String? = nil
        if let src {
            if src.hasPrefix(catName) {
                let rest = String(src.dropFirst(catName.count))
                let trimSet: Set<Character> = [" ", "—", "-", "،", ":"]
                let trimmed = String(rest.drop(while: { trimSet.contains($0) }))
                core = trimmed.trimmingCharacters(in: .whitespaces).isEmpty ? nil : trimmed
            } else {
                core = src
            }
        }
        let time = readLabel(readMinutes(text))
        if let core { return "\(core) · \(time)" }
        return time
    }

    /// Arabic counted noun: 1 singular, 2 dual, 3 to 10 plural, 11+ accusative singular.
    static func arabicCount(_ n: Int, one: String, two: String, plural: String, many: String) -> String {
        if n == 1 { return one }
        if n == 2 { return two }
        let r = n % 100
        if r >= 3 && r <= 10 { return "\(n.ar) \(plural)" }
        return "\(n.ar) \(many)"
    }

    /// Dua number inside al-Sahifa al-Sajjadiyya (some duas have non-numeric ids).
    static func sahifaOrder(_ id: String) -> Int {
        switch id {
        case "saj-mohimmat": return 7
        case "mu-makarim": return 20
        default:
            if id.hasPrefix("saj-"), let n = Int(id.dropFirst(4)) { return n }
            return 999
        }
    }

    /// Number used by the "number jump" filter for sahifa, ramadan and quran.
    static func jumpNumber(catId: String, itemId: String) -> Int? {
        switch catId {
        case "sahifa": return sahifaOrder(itemId)
        case "ramadan":
            guard itemId.hasPrefix("r-day-") else { return nil }
            return Int(itemId.dropFirst(6))
        default:
            guard itemId.hasPrefix("q-") else { return nil }
            return Int(itemId.dropFirst(2))
        }
    }

    /// Splits a text into trimmed, non-empty paragraphs (blank-line separated), with or without tashkeel.
    static func paragraphs(_ text: String, tashkeel: Bool) -> [String] {
        let raw = tashkeel ? text : ArabicSearch.stripTashkeel(text)
        // Split on every line break, then break very long passages at commas: iOS stops shaping
        // Arabic correctly inside a single text run of many thousand characters (Kumayl is one 20k paragraph).
        return raw.components(separatedBy: "\n")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .flatMap { chunk($0) }
    }

    /// Splits a passage longer than ~600 characters into pieces of 250–600 characters at "،" / "." / "؛" boundaries.
    static func chunk(_ p: String) -> [String] {
        if p.count <= 600 { return [p] }
        var out: [String] = []
        var cur = ""
        for word in p.split(separator: " ", omittingEmptySubsequences: true) {
            cur += cur.isEmpty ? String(word) : " " + word
            let endsClause = word.hasSuffix("،") || word.hasSuffix(".") || word.hasSuffix("؛") || word.hasSuffix(":")
            if (endsClause && cur.count >= 250) || cur.count >= 600 {
                out.append(cur); cur = ""
            }
        }
        if !cur.isEmpty { out.append(cur) }
        return out
    }

    static func isBasmala(_ para: String) -> Bool {
        ArabicSearch.stripTashkeel(para).hasPrefix("بسم الله الرحمن الرحيم") && para.count < 60
    }
}

/// Quran reading points (same keys as the Android Settings: quranDone, quranPoints, khatmaAwarded).
enum LibraryQuranPoints {
    private static let featured: Set<String> = [
        "q-001", "q-002", "q-018", "q-036", "q-048", "q-055", "q-056",
        "q-067", "q-044", "q-076", "q-062", "q-112", "q-113", "q-114"
    ]

    static func points(_ itemId: String) -> Int { featured.contains(itemId) ? 15 : 10 }

    private static func doneSet(_ store: Store) -> [String] {
        store.string("quranDone").split(separator: ",").map(String.init).filter { !$0.isEmpty }
    }

    static func isDone(_ store: Store, _ itemId: String) -> Bool { doneSet(store).contains(itemId) }

    static func total(_ store: Store) -> Int { store.int("quranPoints", 0) }

    /// Records a completed surah once. Returns the points granted (0 if already done, -1 if not a surah).
    static func complete(_ store: Store, _ itemId: String) -> Int {
        if !itemId.hasPrefix("q-") { return -1 }
        var done = doneSet(store)
        if done.contains(itemId) { return 0 }
        let pts = points(itemId)
        done.append(itemId)
        var total = store.int("quranPoints", 0) + pts
        var bonus = 0
        if done.count >= 114 && !store.bool("khatmaAwarded", false) {
            bonus = 500
            total += bonus
            store.put("khatmaAwarded", true)
        }
        store.put("quranDone", done.joined(separator: ","))
        store.put("quranPoints", total)
        return pts + bonus
    }
}

/// Small trailing indicator used in item rows: gold star for favourites, check mark for read texts.
struct LibraryItemRow: View {
    let title: String
    let subtitle: String?
    var read: Bool = false
    var fav: Bool = false

    var body: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.body.weight(.semibold)).foregroundStyle(.primary).lineLimit(2)
                if let subtitle, !subtitle.isEmpty {
                    Text(subtitle).font(.footnote).foregroundStyle(.secondary).lineLimit(2)
                }
            }
            Spacer(minLength: 4)
            if fav {
                Image(systemName: "star.fill").font(.footnote).foregroundStyle(Brand.gold)
                    .accessibilityLabel("في المفضّلة")
            } else if read {
                Image(systemName: "checkmark").font(.footnote.weight(.bold)).foregroundStyle(Brand.good.opacity(0.75))
                    .accessibilityLabel("مقروء")
            }
        }
        .padding(.vertical, 2)
    }
}
