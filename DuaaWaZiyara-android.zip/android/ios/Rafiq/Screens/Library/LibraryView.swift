import SwiftUI

/// الفهرس: the category list with full-library search (port of Android LibraryScreen).
struct LibraryView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @State private var query = ""
    @State private var hits: [ArabicSearch.Hit] = []

    var body: some View {
        LibraryContent(query: query, hits: hits)
            .navigationTitle("الفهرس")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $query, prompt: "ابحث في الأدعية والزيارات…")
            .task(id: query) {
                let q = query
                if q.trimmingCharacters(in: .whitespaces).isEmpty { hits = []; return }
                try? await Task.sleep(nanoseconds: 180_000_000)
                if Task.isCancelled { return }
                hits = ArabicSearch.search(q)
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { menu }
            }
    }

    private var menu: some View {
        Menu {
            Button { nav.present(.favorites) } label: { Label("المفضلة", systemImage: "star") }
            Button { nav.present(.bookmarks) } label: { Label("العلامات المرجعية", systemImage: "bookmark") }
            Button { nav.present(.settings) } label: { Label("الإعدادات", systemImage: "gearshape") }
        } label: {
            Image(systemName: "ellipsis.circle")
        }
        .accessibilityLabel("المزيد")
    }
}

/// Body of the library; a child of `.searchable` so it can read `isSearching`.
private struct LibraryContent: View {
    let query: String
    let hits: [ArabicSearch.Hit]
    @Environment(\.isSearching) private var isSearching
    @Environment(AppNav.self) private var nav
    @Environment(Store.self) private var store

    private var trimmed: String { query.trimmingCharacters(in: .whitespaces) }

    var body: some View {
        List {
            if trimmed.isEmpty {
                if isSearching { quickSection } else { continueSection }
                categoriesSection
            } else {
                resultsSection
            }
        }
        .listStyle(.insetGrouped)
    }

    // "Most requested" picks, shown only while the search field is focused (as on Android).
    private static let quick: [(String, String, String)] = [
        ("كميل", "mashhura", "m-kumayl"),
        ("زيارة عاشوراء", "ziyarat", "z-ashura"),
        ("الندبة", "mashhura", "m-nudba"),
        ("التوسّل", "mashhura", "m-tawassul"),
        ("الجوشن الكبير", "ramadan", "r-jawshan"),
        ("أبو حمزة", "ramadan", "r-abuhamza"),
        ("تسبيح الزهراء", "nawafil", "nf-tasbih-fatima"),
        ("الزيارة الجامعة", "ziyarat", "z-jamia")
    ]

    private var quickSection: some View {
        Section("الأكثر طلباً") {
            ForEach(Array(Self.quick.enumerated()), id: \.offset) { _, q in
                if Library.item(q.1, q.2) != nil {
                    NavigationLink(value: Route.reader(q.1, q.2)) {
                        Label {
                            Text(q.0).font(.body.weight(.semibold))
                        } icon: {
                            Image(systemName: Brand.categorySymbol(q.1)).foregroundStyle(Brand.emerald)
                        }
                    }
                }
            }
        }
    }

    /// Where the reader left off, plus what fits now (Kumail on Thursday evening…).
    @ViewBuilder private var continueSection: some View {
        let recent = store.recentReads.filter { Library.item($0.0, $0.1) != nil }.prefix(3)
        let now = ListenDiscover.today(store.hijriToday()).first
        if !recent.isEmpty || now != nil {
            Section("تابع القراءة") {
                if let now {
                    NavigationLink(value: Route.reader(now.item.catId, now.item.itemId)) {
                        HStack(spacing: 12) {
                            Image(systemName: now.item.symbol)
                                .font(.system(size: 16, weight: .semibold)).foregroundStyle(.white)
                                .frame(width: 40, height: 40)
                                .background(RoundedRectangle(cornerRadius: 11).fill(Brand.gold.gradient))
                            VStack(alignment: .leading, spacing: 2) {
                                Text(now.item.title).font(.body.weight(.semibold))
                                Text("مقترح الآن · \(now.why)").font(.caption).foregroundStyle(Brand.goldDeep)
                            }
                        }
                    }
                }
                ForEach(Array(recent.enumerated()), id: \.offset) { _, r in
                    if let it = Library.item(r.0, r.1), let c = Library.category(r.0) {
                        NavigationLink(value: Route.reader(r.0, r.1)) {
                            HStack(spacing: 12) {
                                IconChip(symbol: Brand.categorySymbol(c.id), colors: Brand.categoryColors(c.id), size: 40)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(it.title).font(.body.weight(.semibold)).lineLimit(1)
                                    Text(c.name).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /// The 27 sections grouped the way people look for them.
    private struct Group: Identifiable { let title: String; let ids: [String]; var id: String { title } }
    private static let groups: [Group] = [
        Group(title: "القرآن والعبادات اليومية", ids: ["quran", "taqibat", "sabah", "yawm", "osboo", "nawafil", "salawat"]),
        Group(title: "الأدعية والمناجاة", ids: ["mashhura", "munajat", "sahifa", "hawaij", "hajat"]),
        Group(title: "المواسم والزيارات", ids: ["jumaa", "ramadan", "rajab", "ziyarat", "hajj"]),
        Group(title: "الحديث والحكمة", ids: ["nahj", "khutab", "hikam", "huquq", "akhlaq", "tarbiya", "ahadith", "kafi-dua", "kafi-quran", "kafi-ishra"])
    ]

    @ViewBuilder private var categoriesSection: some View {
        let grouped = Set(Self.groups.flatMap { $0.ids })
        ForEach(Self.groups) { g in
            let cats = g.ids.compactMap { Library.category($0) }
            if !cats.isEmpty {
                Section(g.title) {
                    ForEach(cats) { c in
                        NavigationLink(value: Route.category(c.id)) { LibraryCategoryRow(cat: c) }
                    }
                }
            }
        }
        let rest = Library.categories.filter { !grouped.contains($0.id) }
        if !rest.isEmpty {
            Section("أبواب أخرى") {
                ForEach(rest) { c in
                    NavigationLink(value: Route.category(c.id)) { LibraryCategoryRow(cat: c) }
                }
            }
        }
    }

    /// Tools whose name matches the search (one search box for the whole app).
    private var toolHits: [Tool] {
        let q = ArabicSearch.normalize(trimmed)
        guard q.count >= 2 else { return [] }
        return Tool.allCases.filter { ArabicSearch.normalize($0.title).contains(q) }
    }

    @ViewBuilder private var globalSection: some View {
        Section {
            ForEach(toolHits) { t in
                Button { nav.openTool(t) } label: {
                    Label(t.title, systemImage: t.symbol)
                }
            }
            Button {
                nav.pendingListen = trimmed
                nav.openTool(.listen)
            } label: {
                Label("ابحث عن «\(trimmed)» في التسجيلات الصوتية", systemImage: "headphones")
            }
        } header: {
            Text(toolHits.isEmpty ? "استمع" : "أدوات واستماع")
        }
    }

    @ViewBuilder private var resultsSection: some View {
        globalSection
        if hits.isEmpty {
            Section {
                EmptyStateView(symbol: "magnifyingglass", title: "لا توجد نصوص لـ «\(trimmed)»", message: "")
                    .listRowBackground(Color.clear)
            }
        } else {
            Section {
                ForEach(hits) { h in
                    // The reader scrolls to and highlights the first matching passage.
                    Button {
                        nav.pendingFind = trimmed
                        nav.open(.reader(h.cat.id, h.item.id))
                    } label: {
                        HStack {
                            LibrarySearchRow(hit: h)
                            Image(systemName: "chevron.left").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
                        }
                    }
                    .buttonStyle(.plain)
                }
            } header: {
                Text("\(hits.count.ar) نتيجة")
            }
        }
    }
}

/// Category row: icon chip, name, description and item count.
private struct LibraryCategoryRow: View {
    let cat: DuaaCategory
    var body: some View {
        HStack(spacing: 12) {
            IconChip(symbol: Brand.categorySymbol(cat.id), colors: Brand.categoryColors(cat.id), size: 46)
            VStack(alignment: .leading, spacing: 2) {
                Text(cat.name).font(.headline).foregroundStyle(.primary).lineLimit(1)
                Text(cat.desc).font(.footnote).foregroundStyle(.secondary).lineLimit(2)
            }
            Spacer(minLength: 6)
            Text(cat.items.count.ar)
                .font(.footnote.weight(.heavy))
                .foregroundStyle(Brand.emerald)
                .padding(.horizontal, 10).padding(.vertical, 4)
                .background(Brand.emerald.opacity(0.10), in: Capsule())
        }
        .padding(.vertical, 4)
    }
}

/// Search result row: title, category and snippet.
private struct LibrarySearchRow: View {
    let hit: ArabicSearch.Hit
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            IconChip(symbol: Brand.categorySymbol(hit.cat.id), colors: Brand.categoryColors(hit.cat.id), size: 36)
            VStack(alignment: .leading, spacing: 3) {
                Text(hit.item.title).font(.body.weight(.semibold)).foregroundStyle(.primary).lineLimit(2)
                Text(hit.cat.name).font(.caption.weight(.bold)).foregroundStyle(Brand.emerald)
                if !hit.snippet.isEmpty {
                    Text(hit.snippet).font(.footnote).foregroundStyle(.secondary).lineLimit(2)
                }
            }
        }
        .padding(.vertical, 2)
    }
}
