import SwiftUI

/// الأدعية (v2 shelves): display title, search, filter chips, continue card, famous duas and ziyarat shelves,
/// then every section grouped the way people look for them. One search box covers texts, tools and audio.
struct LibraryView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @State private var query = ""
    @State private var hits: [ArabicSearch.Hit] = []
    @State private var filter: LibraryFilter = .all
    @FocusState private var searching: Bool

    private var trimmed: String { query.trimmingCharacters(in: .whitespaces) }
    private static let totalTexts: Int = Library.categories.reduce(0) { $0 + $1.items.count }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                ScreenHeader("الأدعية") { menu }
                LibrarySearchField(text: $query, focused: $searching, placeholder: "ابحث في \(Self.totalTexts.ar) نصّاً…")
                if trimmed.isEmpty {
                    if searching { quickPicks } else { browse }
                } else {
                    results
                }
            }
            .padding(.horizontal, 20).padding(.bottom, 28)
            .readableWidth()
        }
        .scrollDismissesKeyboard(.interactively)
        .background(Brand.canvas)
        .toolbar(.hidden, for: .navigationBar)
        .task(id: query) {
            let q = query
            if q.trimmingCharacters(in: .whitespaces).isEmpty { hits = []; return }
            try? await Task.sleep(nanoseconds: 180_000_000)
            if Task.isCancelled { return }
            hits = ArabicSearch.search(q)
        }
    }

    private var menu: some View {
        Menu {
            Button { nav.present(.favorites) } label: { Label("المفضّلة", systemImage: "star") }
            Button { nav.present(.bookmarks) } label: { Label("العلامات المرجعية", systemImage: "bookmark") }
            Button { nav.present(.settings) } label: { Label("الإعدادات", systemImage: "gearshape") }
        } label: {
            Image(systemName: "bookmark")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(Brand.gold)
                .frame(width: 42, height: 42)
                .background(Brand.cardFill, in: Circle())
        }
        .accessibilityLabel("المحفوظات والإعدادات")
    }

    // MARK: Browse

    @ViewBuilder private var browse: some View {
        chips
        if filter == .all { LibraryContinueCard() }
        if filter == .all || filter == .duas { LibraryFamousShelf() }
        if filter == .all || filter == .ziyarat { LibraryZiyaratShelf() }
        LibraryGroups(filter: filter)
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(LibraryFilter.allCases) { f in
                    Button { withAnimation(.snappy) { filter = f }; Haptic.tick() } label: { Chip(text: f.title, selected: filter == f) }
                        .buttonStyle(.plain)
                        .accessibilityAddTraits(filter == f ? .isSelected : [])
                }
            }
        }
        .scrollClipDisabled()
    }

    // "Most requested" picks, shown while the search field is focused and empty.
    private static let quick: [(String, String, String)] = [
        ("كميل", "mashhura", "m-kumayl"), ("زيارة عاشوراء", "ziyarat", "z-ashura"), ("الندبة", "mashhura", "m-nudba"),
        ("التوسّل", "mashhura", "m-tawassul"), ("الجوشن الكبير", "ramadan", "r-jawshan"), ("أبو حمزة", "ramadan", "r-abuhamza"),
        ("تسبيح الزهراء", "nawafil", "nf-tasbih-fatima"), ("الزيارة الجامعة", "ziyarat", "z-jamia")
    ]

    private var quickPicks: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeading("الأكثر طلباً")
            VStack(spacing: 0) {
                ForEach(Array(Self.quick.enumerated()), id: \.offset) { i, q in
                    if Library.item(q.1, q.2) != nil {
                        Button { searching = false; nav.openReader(q.1, q.2) } label: {
                            HStack(spacing: 12) {
                                TintIcon(symbol: Brand.categorySymbol(q.1), size: 36)
                                Text(q.0).font(.ui(.body, .semibold)).foregroundStyle(Brand.ink)
                                Spacer()
                                Image(systemName: "chevron.backward").font(.caption.weight(.semibold)).foregroundStyle(Brand.muted)
                            }
                            .padding(.horizontal, 14).padding(.vertical, 11)
                        }
                        .buttonStyle(.plain)
                        if i < Self.quick.count - 1 { Divider().overlay(Brand.line).padding(.leading, 62) }
                    }
                }
            }
            .card(22, padding: 0)
        }
    }

    // MARK: Results

    private var toolHits: [Tool] {
        let q = ArabicSearch.normalize(trimmed)
        guard q.count >= 2 else { return [] }
        return Tool.allCases.filter { $0 != .allTools && ArabicSearch.normalize($0.title).contains(q) }
    }

    @ViewBuilder private var results: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeading(toolHits.isEmpty ? "استمع" : "أدوات واستماع")
            VStack(spacing: 0) {
                ForEach(toolHits) { t in
                    Button { nav.openTool(t) } label: { resultRow(symbol: t.symbol, title: t.title, sub: "أداة") }
                        .buttonStyle(.plain)
                    Divider().overlay(Brand.line).padding(.leading, 62)
                }
                Button { nav.pendingListen = trimmed; nav.openTool(.listen) } label: {
                    resultRow(symbol: "headphones", title: "ابحث عن «\(trimmed)» في التسجيلات", sub: "استمع")
                }
                .buttonStyle(.plain)
            }
            .card(22, padding: 0)
        }
        if hits.isEmpty {
            EmptyStateView(symbol: "magnifyingglass", title: "لا توجد نصوص لـ «\(trimmed)»", message: "جرّب كلمةً أقصر أو بلا تشكيل")
        } else {
            SectionHeading("\(hits.count.ar) نتيجة")
            VStack(spacing: 0) {
                ForEach(Array(hits.enumerated()), id: \.element.id) { i, h in
                    // The reader scrolls to and highlights the first matching passage.
                    Button { nav.pendingFind = trimmed; nav.open(.reader(h.cat.id, h.item.id)) } label: {
                        HStack(alignment: .top, spacing: 12) {
                            IconChip(symbol: Brand.categorySymbol(h.cat.id), colors: Brand.categoryColors(h.cat.id), size: 36)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(h.item.title).font(.ui(.body, .semibold)).foregroundStyle(Brand.ink).lineLimit(2)
                                Text(h.cat.name).font(.ui(.caption, .bold)).foregroundStyle(Brand.accent)
                                if !h.snippet.isEmpty { Text(h.snippet).font(.ui(.footnote)).foregroundStyle(Brand.muted).lineLimit(2) }
                            }
                            Spacer(minLength: 0)
                        }
                        .padding(.horizontal, 14).padding(.vertical, 11)
                    }
                    .buttonStyle(.plain)
                    if i < hits.count - 1 { Divider().overlay(Brand.line).padding(.leading, 62) }
                }
            }
            .card(22, padding: 0)
        }
    }

    private func resultRow(symbol: String, title: String, sub: String) -> some View {
        HStack(spacing: 12) {
            TintIcon(symbol: symbol, size: 36)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.ui(.body, .semibold)).foregroundStyle(Brand.ink).lineLimit(2)
                Text(sub).font(.ui(.caption)).foregroundStyle(Brand.muted)
            }
            Spacer()
            Image(systemName: "chevron.backward").font(.caption.weight(.semibold)).foregroundStyle(Brand.muted)
        }
        .padding(.horizontal, 14).padding(.vertical, 11)
    }
}

// MARK: - Filters

enum LibraryFilter: String, CaseIterable, Identifiable {
    case all, quran, duas, ziyarat, seasons, wisdom
    var id: String { rawValue }
    var title: String {
        switch self {
        case .all: return "الكلّ"
        case .quran: return "القرآن"
        case .duas: return "الأدعية"
        case .ziyarat: return "الزيارات"
        case .seasons: return "المواسم"
        case .wisdom: return "الحكمة"
        }
    }
}

/// The 27 sections grouped the way people look for them.
struct LibraryGroup: Identifiable {
    let title: String
    let filter: LibraryFilter
    let ids: [String]
    var id: String { title }

    static let all: [LibraryGroup] = [
        LibraryGroup(title: "القرآن والعبادات اليومية", filter: .quran, ids: ["quran", "taqibat", "sabah", "yawm", "osboo", "nawafil", "salawat"]),
        LibraryGroup(title: "الأدعية والمناجاة", filter: .duas, ids: ["mashhura", "munajat", "sahifa", "hawaij", "hajat"]),
        LibraryGroup(title: "الزيارات والحجّ", filter: .ziyarat, ids: ["ziyarat", "hajj"]),
        LibraryGroup(title: "المواسم", filter: .seasons, ids: ["jumaa", "ramadan", "rajab"]),
        LibraryGroup(title: "الحديث والحكمة", filter: .wisdom, ids: ["nahj", "khutab", "hikam", "huquq", "akhlaq", "tarbiya", "ahadith", "kafi-dua", "kafi-quran", "kafi-ishra"])
    ]
}

// MARK: - Search field

struct LibrarySearchField: View {
    @Binding var text: String
    var focused: FocusState<Bool>.Binding
    var placeholder: String
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").font(.system(size: 15, weight: .semibold)).foregroundStyle(Brand.muted)
            TextField(placeholder, text: $text)
                .focused(focused)
                .submitLabel(.search)
                .font(.ui(.subheadline))
                .foregroundStyle(Brand.ink)
                .autocorrectionDisabled()
            if !text.isEmpty {
                Button { text = "" } label: {
                    Image(systemName: "xmark.circle.fill").foregroundStyle(Brand.muted)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("مسح البحث")
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 46)
        .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 23, style: .continuous))
        .shadow(color: Color(hex: 0x10322D).opacity(0.05), radius: 5, y: 2)
    }
}

// MARK: - Continue card (purple)

private struct LibraryContinueCard: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private var resume: (DuaaCategory, DuaaItem)? {
        guard let first = store.recentReads.first, let c = Library.category(first.0),
              let i = c.items.first(where: { $0.id == first.1 }) else { return nil }
        return (c, i)
    }

    var body: some View {
        if let r = resume {
            // `scroll` stores the paragraph index the reader was left at, so the share read is index / paragraph count.
            let total = max(1, LibraryText.paragraphs(r.1.text, tashkeel: store.tashkeel, keepNumbers: r.0.id == "quran").count)
            let frac = max(0, min(1, store.scroll(r.0.id, r.1.id) / Double(total)))
            let left = max(1, Int(ceil(Double(LibraryText.readMinutes(r.1.text)) * (1 - frac))))
            Button { nav.openReader(r.0.id, r.1.id) } label: {
                ZStack(alignment: .topLeading) {
                    Brand.purpleGradient
                    MosqueSilhouette().fill(Color.white.opacity(0.08)).frame(width: 200, height: 100)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("تابع من حيث توقّفت · \(Int(frac * 100).ar)٪").font(.ui(.caption, .semibold)).foregroundStyle(Brand.goldSoft)
                        Text(r.1.title).font(.display(28)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.7)
                        Text(verbatim: "\(r.0.name) · نحو \(left.ar) \(left == 1 ? "دقيقة" : (left <= 10 ? "دقائق" : "دقيقة")) متبقية")
                            .font(.ui(.footnote)).foregroundStyle(.white.opacity(0.8)).lineLimit(1)
                        Spacer(minLength: 8)
                        Capsule().fill(Color.white.opacity(0.25)).frame(height: 5)
                            .overlay(alignment: .leading) {
                                GeometryReader { g in Capsule().fill(Brand.goldSoft).frame(width: g.size.width * frac) }
                            }
                    }
                    .padding(20)
                }
                .frame(height: 150)
                .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
                .shadow(color: Color(hex: 0x3B2A5C).opacity(0.25), radius: 14, y: 8)
            }
            .buttonStyle(.plain)
        }
    }
}

// MARK: - Famous duas shelf

private struct LibraryFamousShelf: View {
    @Environment(AppNav.self) private var nav

    private static let when: [String: String] = [
        "m-kumayl": "ليلة الجمعة", "m-tawassul": "ليلة الأربعاء", "m-ahd": "بعد الصبح", "m-nudba": "يوم الجمعة",
        "m-iftitah": "ليالي رمضان", "m-arafa": "يوم عرفة", "m-samat": "عصر الجمعة", "m-mashlool": "عند الحاجة",
        "m-jawshan-saghir": "عند الخوف", "m-sabah": "الصباح"
    ]
    private static let palettes: [[Color]] = [
        [Brand.deep, Color(hex: 0x0F3B35)], [Color(hex: 0xE9B872), Color(hex: 0xC47F3A)], [Color(hex: 0x6E8FB8), Color(hex: 0x3D5F8C)],
        [Color(hex: 0x5B3F78), Color(hex: 0x3B2A5C)], [Brand.emerald, Brand.deeper], [Color(hex: 0xB07D2E), Color(hex: 0x7D5A20)]
    ]

    var body: some View {
        if let cat = Library.category("mashhura"), !cat.items.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                SectionHeading("الأدعية المشهورة") {
                    Button { nav.open(.category(cat.id)) } label: { Text("الكلّ \(cat.items.count.ar)") }.buttonStyle(.plain)
                }
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 3), spacing: 10) {
                    ForEach(Array(cat.items.prefix(3).enumerated()), id: \.element.id) { i, it in
                        Button { nav.openReader(cat.id, it.id) } label: { card(it, colors: Self.palettes[i % Self.palettes.count]) }
                            .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private func card(_ it: DuaaItem, colors: [Color]) -> some View {
        let mins = LibraryText.readMinutes(it.text)
        return VStack(alignment: .leading, spacing: 0) {
            Image(systemName: ListenDiscover.find(it.id)?.symbol ?? "sparkles")
                .font(.system(size: 15, weight: .semibold)).foregroundStyle(.white)
                .frame(width: 34, height: 34)
                .background(Color.white.opacity(0.2), in: Circle())
            Spacer(minLength: 6)
            Text(it.title.replacingOccurrences(of: "دعاء ", with: "")).font(.ui(.callout, .bold)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.7)
            Text(Self.when[it.id] ?? "مفاتيح الجنان").font(.ui(.caption2)).foregroundStyle(.white.opacity(0.85)).lineLimit(1)
            Text(verbatim: "\(mins.ar) د").font(.ui(.caption2, .semibold)).foregroundStyle(.white.opacity(0.9)).padding(.top, 2)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .frame(height: 160)
        .background(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing),
                    in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

// MARK: - Ziyarat shelf

private struct LibraryZiyaratShelf: View {
    @Environment(AppNav.self) private var nav

    private static let who: [String: String] = [
        "z-ashura": "الإمام الحسين (ع)", "z-warith": "الإمام الحسين (ع)", "z-amin": "أمير المؤمنين (ع)", "z-jamia": "الأئمّة (ع)",
        "z-yasin": "صاحب الزمان (عج)", "z-nabi": "النبيّ الأعظم (ص)", "z-mutlaqa": "الحسنان (ع)", "z-baqi": "أئمّة البقيع (ع)",
        "z-kadhim": "الكاظمان والعسكريان (ع)", "z-askari": "الإمام العسكري (ع)", "z-kisa": "أهل الكساء (ع)", "z-fatima": "الزهراء (ع)"
    ]

    var body: some View {
        if let cat = Library.category("ziyarat"), !cat.items.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                SectionHeading("الزيارات") {
                    Button { nav.open(.category(cat.id)) } label: { Text("الكلّ \(cat.items.count.ar)") }.buttonStyle(.plain)
                }
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                    ForEach(Array(cat.items.prefix(4).enumerated()), id: \.element.id) { i, it in
                        Button { nav.openReader(cat.id, it.id) } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "building.columns.fill")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundStyle(.white)
                                    .frame(width: 42, height: 42)
                                    .background(i % 2 == 0 ? Brand.gold : Brand.emerald, in: Circle())
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(it.id == "z-ashura" ? it.title : it.title.replacingOccurrences(of: "زيارة ", with: "")).font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink).lineLimit(1).minimumScaleFactor(0.8)
                                    Text(Self.who[it.id] ?? "زيارة مأثورة").font(.ui(.caption)).foregroundStyle(Brand.muted).lineLimit(1)
                                }
                                Spacer(minLength: 0)
                            }
                            .padding(.horizontal, 12)
                            .frame(height: 74)
                            .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }
}

// MARK: - Grouped sections

private struct LibraryGroups: View {
    let filter: LibraryFilter
    @Environment(AppNav.self) private var nav

    var body: some View {
        let grouped = Set(LibraryGroup.all.flatMap { $0.ids })
        ForEach(LibraryGroup.all.filter { filter == .all || $0.filter == filter }) { g in
            let cats = g.ids.compactMap { Library.category($0) }
            if !cats.isEmpty {
                VStack(alignment: .leading, spacing: 10) {
                    SectionHeading(g.title) { Text(verbatim: "\(cats.reduce(0) { $0 + $1.items.count }.ar) نصّاً").foregroundStyle(Brand.muted) }
                    rows(cats)
                }
            }
        }
        if filter == .all {
            let rest = Library.categories.filter { !grouped.contains($0.id) }
            if !rest.isEmpty {
                VStack(alignment: .leading, spacing: 10) {
                    SectionHeading("أبواب أخرى")
                    rows(rest)
                }
            }
        }
    }

    private func rows(_ cats: [DuaaCategory]) -> some View {
        VStack(spacing: 0) {
            ForEach(Array(cats.enumerated()), id: \.element.id) { i, c in
                Button { nav.open(.category(c.id)) } label: { LibraryCategoryRow(cat: c) }
                    .buttonStyle(.plain)
                if i < cats.count - 1 { Divider().overlay(Brand.line).padding(.leading, 70) }
            }
        }
        .card(22, padding: 0)
    }
}

/// Category row: icon chip, name, description and item count.
struct LibraryCategoryRow: View {
    let cat: DuaaCategory
    var body: some View {
        HStack(spacing: 12) {
            IconChip(symbol: Brand.categorySymbol(cat.id), colors: Brand.categoryColors(cat.id), size: 44)
            VStack(alignment: .leading, spacing: 2) {
                Text(cat.name).font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink).lineLimit(1)
                Text(cat.desc).font(.ui(.caption)).foregroundStyle(Brand.muted).lineLimit(2)
            }
            Spacer(minLength: 6)
            Text(cat.items.count.ar)
                .font(.ui(.caption, .bold))
                .foregroundStyle(Brand.accent)
                .padding(.horizontal, 10).padding(.vertical, 4)
                .background(Brand.soft, in: Capsule())
        }
        .padding(.horizontal, 14).padding(.vertical, 11)
        .contentShape(Rectangle())
    }
}
