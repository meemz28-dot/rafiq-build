import SwiftUI

// MARK: - المزيد: the tools hub (ported from Android ui/MoreScreens.kt MoreScreen)
// Four sections of tiles, grouped exactly as on Android.

private enum MoreAction {
    case tool(Tool)
    case sheet(SheetKind)
}

private struct MoreTile: Identifiable {
    let symbol: String
    let label: String
    let sub: String
    let gradientId: String
    let action: MoreAction
    var id: String { label }
}

private let moreWorship: [MoreTile] = [
    MoreTile(symbol: "headphones", label: "استمع", sub: "القرآن والأدعية صوتياً", gradientId: "sabah", action: .tool(.listen)),
    MoreTile(symbol: "circle.dotted.circle", label: "تسبيح الزهراء (ع)", sub: "سبحة بالمراحل", gradientId: "munajat", action: .sheet(.tasbih)),
    MoreTile(symbol: "flag.fill", label: "زيارة عاشوراء", sub: "بالخطوات واللعن والسلام", gradientId: "ziyarat", action: .tool(.ashura)),
    MoreTile(symbol: "moon.stars.fill", label: "دليل صلاة الليل", sub: "ركعة ركعة", gradientId: "ramadan", action: .tool(.layl)),
    MoreTile(symbol: "moon.fill", label: "المستحبّات", sub: "أعمال الأيام والشهور", gradientId: "jumaa", action: .tool(.amaal)),
    MoreTile(symbol: "book.fill", label: "البرنامج الأسبوعي", sub: "ورد كلّ يوم", gradientId: "jumaa", action: .tool(.weekly)),
    MoreTile(symbol: "sparkles", label: "أسماء الله", sub: "الحسنى بمعانيها", gradientId: "nawafil", action: .tool(.asma)),
    MoreTile(symbol: "building.columns.fill", label: "المعصومون (ع)", sub: "سيرٌ ومناسبات", gradientId: "rajab", action: .tool(.masoom))
]

private let moreDirection: [MoreTile] = [
    MoreTile(symbol: "location.north.line.fill", label: "اتجاه القبلة", sub: "بالبوصلة أو بالشمس", gradientId: "salawat", action: .tool(.qibla)),
    MoreTile(symbol: "building.columns.fill", label: "بوصلة الزيارة", sub: "كربلاء والنجف ومشهد", gradientId: "ziyarat", action: .tool(.shrine)),
    MoreTile(symbol: "moon.fill", label: "التقويم", sub: "الهجري ومناسباتي", gradientId: "mashhura", action: .tool(.calendar)),
    MoreTile(symbol: "clock.fill", label: "مواقيت الأسبوع", sub: "جدول سبعة أيام", gradientId: "osboo", action: .tool(.ptable)),
    MoreTile(symbol: "arrow.left.arrow.right", label: "محوّل التاريخ", sub: "هجري ↔ ميلادي", gradientId: "mashhura", action: .tool(.converter)),
    MoreTile(symbol: "location.north.circle", label: "الحجّ والعمرة", sub: "دليل المناسك", gradientId: "sahifa", action: .tool(.hajj))
]

private let moreFiqh: [MoreTile] = [
    MoreTile(symbol: "sparkle", label: "الخِيرة", sub: "بالمصحف أو بالسبحة", gradientId: "hikam", action: .tool(.khira)),
    MoreTile(symbol: "percent", label: "حاسبة الخُمس", sub: "تقديرٌ سنوي", gradientId: "hajat", action: .tool(.khums)),
    MoreTile(symbol: "doc.on.doc.fill", label: "قضاء الصلوات", sub: "عدّادٌ ووتيرة", gradientId: "osboo", action: .tool(.qada)),
    MoreTile(symbol: "figure.mind.and.body", label: "عدّاد الركعات", sub: "أثناء الصلاة", gradientId: "taqibat", action: .tool(.tracker))
]

private let moreTracking: [MoreTile] = [
    MoreTile(symbol: "star.fill", label: "رحلتي", sub: "المواظبة والتقدّم", gradientId: "tarbiya", action: .tool(.journey)),
    MoreTile(symbol: "book.closed.fill", label: "الختمة", sub: "تابع ختم القرآن", gradientId: "quran", action: .tool(.khatma)),
    MoreTile(symbol: "rosette", label: "نقاط القرآن", sub: "حسناتٌ بالقراءة", gradientId: "quran", action: .tool(.qpoints)),
    MoreTile(symbol: "checklist", label: "محاسبة النفس", sub: "مراجعة يومية", gradientId: "tarbiya", action: .tool(.muhasaba)),
    MoreTile(symbol: "leaf.fill", label: "صفة الشهر", sub: "خُلُقٌ تتمرّن عليه", gradientId: "akhlaq", action: .tool(.trait))
]

private let moreSaved: [MoreTile] = [
    MoreTile(symbol: "star", label: "المفضلة", sub: "ما حفظته", gradientId: "mashhura", action: .sheet(.favorites)),
    MoreTile(symbol: "bookmark.fill", label: "العلامات", sub: "مواضع القراءة", gradientId: "sahifa", action: .sheet(.bookmarks)),
    MoreTile(symbol: "gearshape.fill", label: "الإعدادات", sub: "التنبيهات والمرجع", gradientId: "khutab", action: .sheet(.settings)),
    MoreTile(symbol: "info.circle.fill", label: "حول التطبيق", sub: "المصادر والشكر", gradientId: "hawaij", action: .sheet(.about))
]

struct MoreView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    // 3 columns on iPhone, more on iPad
    private let columns: [GridItem] = [GridItem(.adaptive(minimum: 104, maximum: 180), spacing: 10)]

    @State private var query = ""

    private func filtered(_ tiles: [MoreTile]) -> [MoreTile] {
        let q = ArabicSearch.normalize(query.trimmingCharacters(in: .whitespaces))
        if q.isEmpty { return tiles }
        return tiles.filter { ArabicSearch.normalize($0.label + " " + $0.sub).contains(q) }
    }

    var body: some View {
        ScreenScroll {
            section("العبادة", moreWorship)
            section("الاتجاه والوقت", moreDirection)
            section("الخيرة والحساب", moreFiqh)
            section("المتابعة", moreTracking)
            section("المحفوظات والإعدادات", moreSaved)
            if !query.isEmpty && [moreWorship, moreDirection, moreFiqh, moreTracking, moreSaved].allSatisfy({ filtered($0).isEmpty }) {
                EmptyStateView(symbol: "magnifyingglass", title: "لا أداة باسم «\(query)»",
                               message: "للبحث في الأدعية والزيارات استخدم الفهرس، وللتسجيلات استخدم «استمع».")
            }
        }
        .navigationTitle("المزيد")
        .navigationBarTitleDisplayMode(.large)
        .searchable(text: $query, prompt: "ابحث في الأدوات: قبلة، خمس، ختمة…")
    }

    @ViewBuilder private func section(_ title: String, _ all: [MoreTile]) -> some View {
        let tiles = filtered(all)
        if !tiles.isEmpty {
            SectionTitle(text: title)
            LazyVGrid(columns: columns, spacing: 10) {
                ForEach(tiles) { t in
                    Button {
                        perform(t.action)
                    } label: {
                        MoreTileView(tile: t)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func perform(_ a: MoreAction) {
        Haptic.tick()
        switch a {
        case .tool(let t): nav.openTool(t)
        case .sheet(let s): nav.present(s)
        }
    }
}


/// Tool tile with a one-line explanation, so names like «رحلتي» say what they do.
private struct MoreTileView: View {
    let tile: MoreTile
    var body: some View {
        VStack(spacing: 6) {
            IconChip(symbol: tile.symbol, colors: Brand.categoryColors(tile.gradientId), size: 44)
            Text(tile.label).font(.footnote.weight(.bold)).multilineTextAlignment(.center).lineLimit(1)
                .foregroundStyle(.primary)
            Text(tile.sub).font(.caption2).multilineTextAlignment(.center).lineLimit(2)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, minHeight: 124)
        .padding(.horizontal, 6)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .accessibilityElement(children: .combine)
    }
}
