import SwiftUI

// MARK: - المزيد: the tools hub (ported from Android ui/MoreScreens.kt MoreScreen)
// Four sections of tiles, grouped exactly as on Android.

private enum MoreAction {
    case tool(Tool)
    case sheet(SheetKind)
}

private struct MoreTile: Identifiable {
    let symbol: String
    let label: String
    let gradientId: String
    let action: MoreAction
    var id: String { label }
}

private let moreWorship: [MoreTile] = [
    MoreTile(symbol: "star.fill", label: "رحلتي", gradientId: "tarbiya", action: .tool(.journey)),
    MoreTile(symbol: "sparkles", label: "أسماء الله", gradientId: "nawafil", action: .tool(.asma)),
    MoreTile(symbol: "building.columns.fill", label: "المعصومون (ع)", gradientId: "rajab", action: .tool(.masoom)),
    MoreTile(symbol: "book.fill", label: "نقاط القرآن", gradientId: "quran", action: .tool(.qpoints)),
    MoreTile(symbol: "circle.dotted.circle", label: "تسبيح الزهراء (ع)", gradientId: "munajat", action: .sheet(.tasbih)),
    MoreTile(symbol: "moon.stars.fill", label: "دليل صلاة الليل", gradientId: "ramadan", action: .tool(.layl)),
    MoreTile(symbol: "flag.fill", label: "زيارة عاشوراء", gradientId: "ziyarat", action: .tool(.ashura)),
    MoreTile(symbol: "building.columns.fill", label: "الحجّ والعمرة", gradientId: "sahifa", action: .tool(.hajj)),
    MoreTile(symbol: "moon.fill", label: "المستحبّات", gradientId: "jumaa", action: .tool(.amaal))
]

private let moreTools: [MoreTile] = [
    MoreTile(symbol: "sparkle", label: "خِيرة القرآن", gradientId: "hikam", action: .tool(.khira)),
    MoreTile(symbol: "book.fill", label: "البرنامج الأسبوعي", gradientId: "jumaa", action: .tool(.weekly)),
    MoreTile(symbol: "percent", label: "حاسبة الخُمس", gradientId: "hajat", action: .tool(.khums)),
    MoreTile(symbol: "location.north.line.fill", label: "اتجاه القبلة", gradientId: "salawat", action: .tool(.qibla)),
    MoreTile(symbol: "building.columns.fill", label: "بوصلة الزيارة", gradientId: "ziyarat", action: .tool(.shrine)),
    MoreTile(symbol: "clock.fill", label: "مواقيت الأسبوع", gradientId: "osboo", action: .tool(.ptable)),
    MoreTile(symbol: "moon.fill", label: "محوّل التاريخ", gradientId: "mashhura", action: .tool(.converter)),
    MoreTile(symbol: "clock.fill", label: "عدّاد الركعات", gradientId: "taqibat", action: .tool(.tracker))
]

private let moreTracking: [MoreTile] = [
    MoreTile(symbol: "star.fill", label: "محاسبة النفس", gradientId: "tarbiya", action: .tool(.muhasaba)),
    MoreTile(symbol: "sparkles", label: "صفة الشهر", gradientId: "akhlaq", action: .tool(.trait)),
    MoreTile(symbol: "doc.on.doc.fill", label: "قضاء الصلوات", gradientId: "osboo", action: .tool(.qada))
]

private let moreSaved: [MoreTile] = [
    MoreTile(symbol: "star", label: "المفضلة", gradientId: "mashhura", action: .sheet(.favorites)),
    MoreTile(symbol: "bookmark.fill", label: "العلامات المرجعية", gradientId: "sahifa", action: .sheet(.bookmarks)),
    MoreTile(symbol: "gearshape.fill", label: "الإعدادات", gradientId: "khutab", action: .sheet(.settings)),
    MoreTile(symbol: "info.circle.fill", label: "حول التطبيق", gradientId: "hawaij", action: .sheet(.about))
]

struct MoreView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private let columns: [GridItem] = Array(repeating: GridItem(.flexible(), spacing: 10), count: 3)

    var body: some View {
        ScreenScroll {
            section("العبادة والقراءة", moreWorship)
            section("أدوات", moreTools)
            section("المتابعة والمحاسبة", moreTracking)
            section("المحفوظات والإعدادات", moreSaved)
        }
        .navigationTitle("المزيد")
        .navigationBarTitleDisplayMode(.large)
    }

    @ViewBuilder private func section(_ title: String, _ tiles: [MoreTile]) -> some View {
        SectionTitle(text: title)
        LazyVGrid(columns: columns, spacing: 10) {
            ForEach(tiles) { t in
                Button {
                    perform(t.action)
                } label: {
                    ToolTile(symbol: t.symbol, title: t.label, colors: Brand.categoryColors(t.gradientId))
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func perform(_ a: MoreAction) {
        Haptic.tick()
        switch a {
        case .tool(let t): nav.openTool(t)
        case .sheet(let s): nav.present(s)
        }
    }
}
