import SwiftUI

// MARK: - الأدوات (v2 bento): live tiles for the tools people open most, then "كلّ الأدوات" with every tool grouped.

private enum MoreAction {
    case tool(Tool)
    case sheet(SheetKind)
}

private struct MoreTile: Identifiable {
    let symbol: String
    let label: String
    let sub: String
    let gradientId: String
    let action: MoreAction
    var id: String { label }
}

private let moreWorship: [MoreTile] = [
    MoreTile(symbol: "headphones", label: "استمع", sub: "القرآن والأدعية صوتياً", gradientId: "sabah", action: .tool(.listen)),
    MoreTile(symbol: "circle.dotted.circle", label: "تسبيح الزهراء (ع)", sub: "سبحة بالمراحل", gradientId: "munajat", action: .sheet(.tasbih)),
    MoreTile(symbol: "flag.fill", label: "زيارة عاشوراء", sub: "بالخطوات واللعن والسلام", gradientId: "ziyarat", action: .tool(.ashura)),
    MoreTile(symbol: "moon.stars.fill", label: "دليل صلاة الليل", sub: "ركعة ركعة", gradientId: "ramadan", action: .tool(.layl)),
    MoreTile(symbol: "moon.fill", label: "المستحبّات", sub: "أعمال الأيام والشهور", gradientId: "jumaa", action: .tool(.amaal)),
    MoreTile(symbol: "book.fill", label: "البرنامج الأسبوعي", sub: "ورد كلّ يوم", gradientId: "jumaa", action: .tool(.weekly)),
    MoreTile(symbol: "sparkles", label: "أسماء الله", sub: "الحسنى بمعانيها", gradientId: "nawafil", action: .tool(.asma)),
    MoreTile(symbol: "building.columns.fill", label: "المعصومون (ع)", sub: "سيرٌ ومناسبات", gradientId: "rajab", action: .tool(.masoom))
]

private let moreDirection: [MoreTile] = [
    MoreTile(symbol: "clock.fill", label: "مواقيت الصلاة", sub: "اليوم كاملاً والأذان", gradientId: "osboo", action: .tool(.prayer)),
    MoreTile(symbol: "location.north.line.fill", label: "اتجاه القبلة", sub: "بالبوصلة أو بالشمس", gradientId: "salawat", action: .tool(.qibla)),
    MoreTile(symbol: "building.columns.fill", label: "بوصلة الزيارة", sub: "كربلاء والنجف ومشهد", gradientId: "ziyarat", action: .tool(.shrine)),
    MoreTile(symbol: "moon.fill", label: "التقويم", sub: "الهجري ومناسباتي", gradientId: "mashhura", action: .tool(.calendar)),
    MoreTile(symbol: "tablecells", label: "مواقيت الأسبوع", sub: "جدول سبعة أيام", gradientId: "osboo", action: .tool(.ptable)),
    MoreTile(symbol: "arrow.left.arrow.right", label: "محوّل التاريخ", sub: "هجري ↔ ميلادي", gradientId: "mashhura", action: .tool(.converter)),
    MoreTile(symbol: "location.north.circle", label: "الحجّ والعمرة", sub: "دليل المناسك", gradientId: "sahifa", action: .tool(.hajj))
]

private let moreFiqh: [MoreTile] = [
    MoreTile(symbol: "sparkle", label: "الخِيرة", sub: "بالمصحف أو بالسبحة", gradientId: "hikam", action: .tool(.khira)),
    MoreTile(symbol: "percent", label: "حاسبة الخُمس", sub: "تقديرٌ سنوي", gradientId: "hajat", action: .tool(.khums)),
    MoreTile(symbol: "doc.on.doc.fill", label: "قضاء الصلوات", sub: "عدّادٌ ووتيرة", gradientId: "osboo", action: .tool(.qada)),
    MoreTile(symbol: "figure.mind.and.body", label: "عدّاد الركعات", sub: "أثناء الصلاة", gradientId: "taqibat", action: .tool(.tracker))
]

private let moreTracking: [MoreTile] = [
    MoreTile(symbol: "star.fill", label: "رحلتي", sub: "المواظبة والتقدّم", gradientId: "tarbiya", action: .tool(.journey)),
    MoreTile(symbol: "book.closed.fill", label: "ختمتي", sub: "تقدّمك آيةً آية ونقاطك", gradientId: "quran", action: .tool(.khatma)),
    MoreTile(symbol: "checklist", label: "محاسبة النفس", sub: "مراجعة يومية", gradientId: "tarbiya", action: .tool(.muhasaba)),
    MoreTile(symbol: "leaf.fill", label: "صفة الشهر", sub: "خُلُقٌ تتمرّن عليه", gradientId: "akhlaq", action: .tool(.trait))
]

private let moreSaved: [MoreTile] = [
    MoreTile(symbol: "star", label: "المفضلة", sub: "ما حفظته", gradientId: "mashhura", action: .sheet(.favorites)),
    MoreTile(symbol: "bookmark.fill", label: "العلامات", sub: "مواضع القراءة", gradientId: "sahifa", action: .sheet(.bookmarks)),
    MoreTile(symbol: "gearshape.fill", label: "الإعدادات", sub: "التنبيهات والمرجع", gradientId: "khutab", action: .sheet(.settings)),
    MoreTile(symbol: "info.circle.fill", label: "حول التطبيق", sub: "المصادر والشكر", gradientId: "hawaij", action: .sheet(.about))
]

// MARK: - Bento

struct MoreView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @State private var showSearch = false

    var body: some View {
        ScreenScroll(topPadding: 0) {
            ScreenHeader("الأدوات") {
                RoundIconButton(symbol: "magnifyingglass", label: "ابحث في الأدوات") { nav.openTool(.allTools) }
                RoundIconButton(symbol: "gearshape", label: "الإعدادات") { nav.present(.settings) }
            }
            topRow
            hajjBand
            smallRow([
                ("moon", "صلاة الليل", .tool(.layl)), ("star", "الخِيرة", .tool(.khira)),
                ("percent", "الخُمس", .tool(.khums)), ("arrow.counterclockwise", "قضاء الصلوات", .tool(.qada))
            ])
            journeyBand
            smallRow([
                ("star", "أسماء الله", .tool(.asma)), ("building.columns", "المعصومون", .tool(.masoom)),
                ("clock", "عدّاد الركعات", .tool(.tracker)), ("square.grid.2x2", "كلّ الأدوات", .tool(.allTools))
            ])
            savedRow
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    // MARK: Row 1: qibla (tall) + calendar + tasbih/khatma

    private var topRow: some View {
        HStack(alignment: .top, spacing: 10) {
            qiblaTile
            VStack(spacing: 10) {
                calendarTile
                HStack(spacing: 10) {
                    tasbihTile
                    khatmaTile
                }
            }
        }
        .fixedSize(horizontal: false, vertical: true)
    }

    private var qiblaTile: some View {
        let loc = store.location()
        let bearing = Qibla.bearing(lat: loc.lat, lng: loc.lng)
        let km = Qibla.distanceKm(lat: loc.lat, lng: loc.lng)
        return Button { nav.openTool(.qibla) } label: {
            VStack(alignment: .leading, spacing: 0) {
                Text("القبلة").font(.ui(.subheadline, .bold)).foregroundStyle(.white)
                Spacer(minLength: 8)
                ZStack {
                    Circle().stroke(Color.white.opacity(0.25), lineWidth: 1.5)
                    Circle().fill(Color.white.opacity(0.06))
                    Circle().stroke(Color.white.opacity(0.35), style: StrokeStyle(lineWidth: 1, dash: [1, 6])).padding(10)
                    // Needle: the Kaaba sits at the qibla bearing from the north (up).
                    ZStack(alignment: .top) {
                        Capsule().fill(Brand.goldSoft).frame(width: 5, height: 54).offset(y: 6)
                        RoundedRectangle(cornerRadius: 3).fill(Color(hex: 0x10322D)).frame(width: 18, height: 16)
                            .overlay(Rectangle().fill(Brand.goldSoft).frame(height: 3).offset(y: -2))
                    }
                    .frame(height: 118, alignment: .top)
                    .rotationEffect(.degrees(bearing))
                    Circle().fill(Brand.goldSoft).frame(width: 10, height: 10)
                }
                .frame(width: 118, height: 118)
                .frame(maxWidth: .infinity)
                Spacer(minLength: 8)
                HStack {
                    Text(verbatim: "\(Int(bearing.rounded()).ar)°").font(.ui(.caption))
                    Spacer()
                    Text(verbatim: "\(Int(km.rounded()).ar) كم").font(.ui(.caption))
                }
                .foregroundStyle(.white.opacity(0.9))
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .topLeading)
            .frame(height: 230)
            .background(LinearGradient(colors: [Brand.emerald, Brand.deeper], startPoint: .top, endPoint: .bottom),
                        in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("القبلة \(Int(bearing.rounded()).ar) درجة")
    }

    private var calendarTile: some View {
        let h = store.hijriToday()
        let next = MoreView.nextOccasion(from: h, adj: store.hijriAdj)
        return Button { nav.openTool(.calendar) } label: {
            VStack(alignment: .leading, spacing: 4) {
                Text("التقويم").font(.ui(.caption, .semibold)).foregroundStyle(Color(hex: 0x8A6D2B))
                Spacer(minLength: 0)
                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    Text(h.d.ar).font(.display(26)).foregroundStyle(Brand.ink)
                    Text(Hijri.months[max(0, min(11, h.m - 1))]).font(.ui(.caption, .semibold)).foregroundStyle(Brand.ink).lineLimit(1).minimumScaleFactor(0.8)
                }
                if let next {
                    Text(next.days == 0 ? "اليوم: \(next.title)" : "بعد \(next.days.ar) \(next.days == 1 ? "يوم" : (next.days <= 10 ? "أيام" : "يوماً")): \(next.title)")
                        .font(.ui(.caption)).foregroundStyle(Brand.muted).lineLimit(1).minimumScaleFactor(0.85)
                } else {
                    Text(verbatim: "\(h.y.ar) هـ").font(.ui(.caption)).foregroundStyle(Brand.muted)
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .topLeading)
            .frame(height: 110)
            .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private var tasbihTile: some View {
        Button { nav.present(.tasbih) } label: {
            VStack(spacing: 8) {
                RingProgress(fraction: Double(TasbihSession.count % 33) / 33.0, size: 46, lineWidth: 4, color: Brand.emerald) {
                    Text((TasbihSession.count % 33 == 0 && TasbihSession.count > 0 ? 33 : TasbihSession.count % 33).ar)
                        .font(.ui(.caption, .bold)).foregroundStyle(Brand.ink)
                }
                .overlay(Circle().stroke(Brand.emerald.opacity(0.35), style: StrokeStyle(lineWidth: 2, dash: [1, 5])).padding(-5))
                Text("السبحة").font(.ui(.footnote, .bold)).foregroundStyle(Brand.ink)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 110)
            .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private var khatmaTile: some View {
        let verses = QuranProgress.today(store), goal = max(1, QuranProgress.goal(store))
        return Button { nav.openTool(.khatma) } label: {
            VStack(spacing: 8) {
                RingProgress(fraction: Double(verses) / Double(goal), size: 46, lineWidth: 5, color: Brand.gold)
                Text("ختمتي").font(.ui(.footnote, .bold)).foregroundStyle(Brand.ink)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 110)
            .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("ختمتي \(verses.ar) من \(goal.ar) آية اليوم")
    }

    // MARK: Hajj band

    private var hajjBand: some View {
        Button { nav.openTool(.hajj) } label: {
            HStack(spacing: 14) {
                ZStack(alignment: .top) {
                    RoundedRectangle(cornerRadius: 3).fill(Color(hex: 0x1C1C1E)).frame(width: 38, height: 40)
                    Rectangle().fill(Brand.gold).frame(width: 38, height: 6).padding(.top, 9)
                }
                .frame(width: 50, height: 50)
                VStack(alignment: .leading, spacing: 3) {
                    Text("الحجّ والعمرة").font(.ui(.body, .bold)).foregroundStyle(Color(hex: 0x3A2E18))
                    Text(verbatim: "\(Library.shared.hajj.hajj.count.ar) خطوة · عدّاد الطواف والسعي · أدعية كلّ موقف")
                        .font(.ui(.caption)).foregroundStyle(Color(hex: 0x3A2E18).opacity(0.8)).lineLimit(1).minimumScaleFactor(0.8)
                }
                Spacer(minLength: 4)
                Image(systemName: "chevron.backward").font(.caption.weight(.bold)).foregroundStyle(Color(hex: 0x3A2E18).opacity(0.7))
            }
            .padding(.horizontal, 16)
            .frame(height: 92)
            .background(Brand.goldBand, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    // MARK: Journey band

    private var journeyBand: some View {
        let s = store.streak
        let trait = TraitProgress.isActive(store) ? TraitProgress.current(store) : nil
        let target = max(1, TraitProgress.target(store))
        let frac = trait == nil ? min(1, Double(s) / 30.0) : min(1, Double(TraitProgress.doneCount(store)) / Double(target))
        return Button { nav.openTool(.journey) } label: {
            HStack(spacing: 14) {
                RingProgress(fraction: frac, size: 46, lineWidth: 5, color: Brand.emerald) {
                    Text(verbatim: "\(Int(frac * 100).ar)").font(.ui(.caption2, .bold)).foregroundStyle(Brand.ink)
                }
                VStack(alignment: .leading, spacing: 3) {
                    Text("رحلتي · محاسبة النفس · صفة الشهر").font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink).lineLimit(1).minimumScaleFactor(0.8)
                    Text((s > 0 ? "\(s.ar) \(s == 1 ? "يوم" : (s <= 10 ? "أيام" : "يوماً")) متتالياً" : "ابدأ سلسلة مواظبتك") + (trait.map { " · خُلُق هذا الشهر: \($0.virtue)" } ?? ""))
                        .font(.ui(.caption)).foregroundStyle(Brand.muted).lineLimit(1).minimumScaleFactor(0.8)
                }
                Spacer(minLength: 4)
                Image(systemName: "chevron.backward").font(.caption.weight(.bold)).foregroundStyle(Brand.muted)
            }
            .padding(.horizontal, 16)
            .frame(height: 74)
            .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    // MARK: Small tiles

    private func smallRow(_ items: [(String, String, MoreAction)]) -> some View {
        HStack(spacing: 10) {
            ForEach(Array(items.enumerated()), id: \.offset) { _, t in
                Button { perform(t.2) } label: {
                    VStack(spacing: 6) {
                        TintIcon(symbol: t.0, size: 28, color: Color(hex: 0x3D5F8C))
                        Text(t.1).font(.ui(.caption, .semibold)).foregroundStyle(Brand.ink).lineLimit(1).minimumScaleFactor(0.75)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 86)
                    .padding(.horizontal, 4)
                    .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var savedRow: some View {
        HStack(spacing: 10) {
            ForEach(moreSaved) { t in
                Button { perform(t.action) } label: {
                    VStack(spacing: 6) {
                        TintIcon(symbol: t.symbol, size: 26, color: Brand.goldDeep)
                        Text(t.label).font(.ui(.caption, .semibold)).foregroundStyle(Brand.ink).lineLimit(1).minimumScaleFactor(0.75)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 86)
                    .padding(.horizontal, 4)
                    .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func perform(_ a: MoreAction) {
        Haptic.tick()
        switch a {
        case .tool(let t): nav.openTool(t)
        case .sheet(let s): nav.present(s)
        }
    }

    /// Today's occasion, or the next within 60 days.
    static func nextOccasion(from h: Hijri.HDate, adj: Int) -> (title: String, days: Int)? {
        let occ = Library.shared.occasions
        guard !occ.isEmpty else { return nil }
        let jd = Hijri.hijriToJd(h.y, h.m, h.d, adj: adj)
        for i in 0...60 {
            let d = Hijri.jdToHijri(jd + i, adj: adj)
            if let o = occ.first(where: { $0.m == d.m && $0.d == d.d }) { return (o.t, i) }
        }
        return nil
    }
}

// MARK: - All tools (grouped grid with search)

struct AllToolsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    // 3 columns on iPhone, more on iPad
    private let columns: [GridItem] = [GridItem(.adaptive(minimum: 104, maximum: 180), spacing: 10)]

    @State private var query = ""
    @FocusState private var focused: Bool

    private func filtered(_ tiles: [MoreTile]) -> [MoreTile] {
        let q = ArabicSearch.normalize(query.trimmingCharacters(in: .whitespaces))
        if q.isEmpty { return tiles }
        return tiles.filter { ArabicSearch.normalize($0.label + " " + $0.sub).contains(q) }
    }

    var body: some View {
        ScreenScroll {
            ScreenHeader("كلّ الأدوات") {
                RoundIconButton(symbol: "chevron.backward", label: "رجوع") { dismiss() }
            }
            LibrarySearchField(text: $query, focused: $focused, placeholder: "ابحث في الأدوات: قبلة، خمس، ختمة…")
            section("العبادة", moreWorship)
            section("الاتجاه والوقت", moreDirection)
            section("الخيرة والحساب", moreFiqh)
            section("المتابعة", moreTracking)
            section("المحفوظات والإعدادات", moreSaved)
            if !query.isEmpty && [moreWorship, moreDirection, moreFiqh, moreTracking, moreSaved].allSatisfy({ filtered($0).isEmpty }) {
                EmptyStateView(symbol: "magnifyingglass", title: "لا أداة باسم «\(query)»",
                               message: "للبحث في الأدعية والزيارات استخدم «الأدعية»، وللتسجيلات استخدم «استمع».")
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .toolbarBackground(Brand.canvas, for: .navigationBar)
    }

    @ViewBuilder private func section(_ title: String, _ all: [MoreTile]) -> some View {
        let tiles = filtered(all)
        if !tiles.isEmpty {
            SectionTitle(text: title)
            LazyVGrid(columns: columns, spacing: 10) {
                ForEach(tiles) { t in
                    Button { perform(t.action) } label: { MoreTileView(tile: t) }
                        .buttonStyle(.plain)
                }
            }
        }
    }

    private func perform(_ a: MoreAction) {
        Haptic.tick()
        switch a {
        case .tool(let t): nav.openTool(t)
        case .sheet(let s): nav.present(s)
        }
    }
}

/// Tool tile with a one-line explanation, so names like «رحلتي» say what they do.
private struct MoreTileView: View {
    let tile: MoreTile
    var body: some View {
        VStack(spacing: 6) {
            IconChip(symbol: tile.symbol, colors: Brand.categoryColors(tile.gradientId), size: 44)
            Text(tile.label).font(.ui(.footnote, .bold)).multilineTextAlignment(.center).lineLimit(1)
                .foregroundStyle(Brand.ink)
            Text(tile.sub).font(.ui(.caption2)).multilineTextAlignment(.center).lineLimit(2)
                .foregroundStyle(Brand.muted)
        }
        .frame(maxWidth: .infinity, minHeight: 124)
        .padding(.horizontal, 6)
        .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .accessibilityElement(children: .combine)
    }
}
