import SwiftUI

// MARK: - البرنامج الأسبوعي (ported from Android ui/WeeklyScreen.kt)
// Each day's dua (from Imam al-Sajjad) and ziyara, plus the well-known works of Thursday night and Friday.
// The user's current day is highlighted in gold.

private struct WeeklyExtra { let label: String; let catId: String; let itemId: String }
private struct WeeklyDay { let name: String; let duaId: String; let ziyaraId: String; let extras: [WeeklyExtra] }

private let weeklyDays: [WeeklyDay] = [
    WeeklyDay(name: "السبت", duaId: "d-sat", ziyaraId: "z-nabi", extras: []),
    WeeklyDay(name: "الأحد", duaId: "d-sun", ziyaraId: "z-amin", extras: []),
    WeeklyDay(name: "الإثنين", duaId: "d-mon", ziyaraId: "z-mutlaqa", extras: []),
    WeeklyDay(name: "الثلاثاء", duaId: "d-tue", ziyaraId: "z-baqi", extras: []),
    WeeklyDay(name: "الأربعاء", duaId: "d-wed", ziyaraId: "z-kadhim", extras: []),
    WeeklyDay(name: "الخميس", duaId: "d-thu", ziyaraId: "z-askari", extras: [
        WeeklyExtra(label: "ليلة الجمعة: دعاء كميل", catId: "mashhura", itemId: "m-kumayl")]),
    WeeklyDay(name: "الجمعة", duaId: "d-fri", ziyaraId: "z-yasin", extras: [
        WeeklyExtra(label: "صباح الجمعة: دعاء الندبة", catId: "mashhura", itemId: "m-nudba"),
        WeeklyExtra(label: "عصر الجمعة: دعاء السمات", catId: "jumaa", itemId: "j-samat")])
]

private func weeklyTitle(_ catId: String, _ itemId: String) -> String {
    Library.item(catId, itemId)?.title ?? itemId
}

struct WeeklyView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    /// Index starting at Saturday: Calendar weekday is Sunday = 1 ... Saturday = 7, so `% 7` gives Saturday = 0.
    private var todayIdx: Int { Calendar.current.component(.weekday, from: Date()) % 7 }

    var body: some View {
        List {
            Section {
                Text("دعاء كلّ يومٍ وزيارتُه، وأعمال ليلة الجمعة ويومها.")
                    .font(.ui(.subheadline)).foregroundStyle(.secondary)
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4))
            }
            ForEach(Array(weeklyDays.enumerated()), id: \.offset) { idx, day in
                daySection(day, isToday: idx == todayIdx)
            }
            Section {
                Text("دعاء كلّ يومٍ مرويٌّ عن الإمام زين العابدين (ع)، وزيارة كلّ يومٍ على ما ذكره العلماء من تخصيص أيّام الأسبوع بالمعصومين (ع).")
                    .font(.ui(.caption)).foregroundStyle(.secondary)
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4))
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Brand.canvas)
        .navigationTitle("البرنامج الأسبوعي")
        .navigationBarTitleDisplayMode(.inline)
    }

    @ViewBuilder private func daySection(_ day: WeeklyDay, isToday: Bool) -> some View {
        Section {
            WeeklyRow(label: "دعاء اليوم", title: weeklyTitle("osboo", day.duaId), gold: false) {
                nav.openReader("osboo", day.duaId)
            }
            WeeklyRow(label: "زيارة اليوم", title: weeklyTitle("ziyarat", day.ziyaraId), gold: false) {
                nav.openReader("ziyarat", day.ziyaraId)
            }
            ForEach(Array(day.extras.enumerated()), id: \.offset) { _, ex in
                WeeklyRow(label: ex.label, title: weeklyTitle(ex.catId, ex.itemId), gold: true) {
                    nav.openReader(ex.catId, ex.itemId)
                }
            }
        } header: {
            HStack {
                Text(day.name)
                    .font(.ui(.title3, .heavy))
                    .foregroundStyle(isToday ? Brand.gold : Color.primary)
                Spacer()
                if isToday { Tag(text: "اليوم", color: Brand.gold) }
            }
            .textCase(nil)
        }
        .listRowBackground(isToday ? Brand.gold.opacity(0.12) : Color(.secondarySystemGroupedBackground))
    }
}

private struct WeeklyRow: View {
    let label: String
    let title: String
    let gold: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: gold ? "sparkle" : "book.fill")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(gold ? Brand.gold : Brand.emerald)
                    .frame(width: 22)
                VStack(alignment: .leading, spacing: 2) {
                    Text(label).font(.ui(.caption, .bold)).foregroundStyle(gold ? Brand.gold : Color.secondary)
                    Text(title).font(.ui(.body, .semibold)).foregroundStyle(.primary).lineLimit(1)
                }
                Spacer(minLength: 4)
                Image(systemName: "chevron.forward").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}
