import SwiftUI

// MARK: - البرنامج الأسبوعي (ported from Android ui/WeeklyScreen.kt)
// Each day's dua (from Imam al-Sajjad) and ziyara, plus the well-known works of Thursday night and Friday.
// The user's current day is highlighted in gold.

private struct WeeklyExtra { let label: String; let catId: String; let itemId: String }
private struct WeeklyDay { let name: String; let duaId: String; let ziyaraId: String; let extras: [WeeklyExtra] }

private let weeklyDays: [WeeklyDay] = [
    WeeklyDay(name: "السبت", duaId: "d-sat", ziyaraId: "z-nabi", extras: []),
    WeeklyDay(name: "الأحد", duaId: "d-sun", ziyaraId: "z-amin", extras: []),
    WeeklyDay(name: "الإثنين", duaId: "d-mon", ziyaraId: "z-mutlaqa", extras: []),
    WeeklyDay(name: "الثلاثاء", duaId: "d-tue", ziyaraId: "z-baqi", extras: []),
    WeeklyDay(name: "الأربعاء", duaId: "d-wed", ziyaraId: "z-kadhim", extras: []),
    WeeklyDay(name: "الخميس", duaId: "d-thu", ziyaraId: "z-askari", extras: [
        WeeklyExtra(label: "ليلة الجمعة: دعاء كميل", catId: "mashhura", itemId: "m-kumayl")]),
    WeeklyDay(name: "الجمعة", duaId: "d-fri", ziyaraId: "z-yasin", extras: [
        WeeklyExtra(label: "صباح الجمعة: دعاء الندبة", catId: "mashhura", itemId: "m-nudba"),
        WeeklyExtra(label: "عصر الجمعة: دعاء السمات", catId: "jumaa", itemId: "j-samat")])
]

private func weeklyTitle(_ catId: String, _ itemId: String) -> String {
    Library.item(catId, itemId)?.title ?? itemId
}

struct WeeklyView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.dismiss) private var dismiss

    /// Index starting at Saturday: Calendar weekday is Sunday = 1 ... Saturday = 7, so `% 7` gives Saturday = 0.
    private var todayIdx: Int { Calendar.current.component(.weekday, from: Date()) % 7 }

    var body: some View {
        ScreenScroll(topPadding: 0) {
            ScreenHeader("البرنامج الأسبوعي", subtitle: "دعاء كلّ يومٍ وزيارتُه، وأعمال ليلة الجمعة ويومها") {
                RoundIconButton(symbol: "chevron.backward", label: "رجوع") { dismiss() }
            }
            // Today first, then the rest of the week in order.
            let order = (0..<weeklyDays.count).map { (todayIdx + $0) % weeklyDays.count }
            ForEach(order, id: \.self) { idx in
                dayCard(weeklyDays[idx], isToday: idx == todayIdx)
            }
            Text("دعاء كلّ يومٍ مرويٌّ عن الإمام زين العابدين (ع)، وزيارة كلّ يومٍ على ما ذكره العلماء من تخصيص أيّام الأسبوع بالمعصومين (ع).")
                .font(.ui(.caption)).foregroundStyle(Brand.muted).padding(.top, 4)
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    private func dayCard(_ day: WeeklyDay, isToday: Bool) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text(day.name).font(.display(20)).foregroundStyle(isToday ? Brand.goldDeep : Brand.ink)
                Spacer()
                if isToday { GoldTag(text: "اليوم").environment(\.colorScheme, .dark) }
            }
            .padding(.horizontal, 16).padding(.top, 14).padding(.bottom, 6)
            WeeklyRow(label: "دعاء اليوم", title: weeklyTitle("osboo", day.duaId), gold: false) { nav.openReader("osboo", day.duaId) }
            Divider().overlay(Brand.line).padding(.leading, 50)
            WeeklyRow(label: "زيارة اليوم", title: weeklyTitle("ziyarat", day.ziyaraId), gold: false) { nav.openReader("ziyarat", day.ziyaraId) }
            ForEach(Array(day.extras.enumerated()), id: \.offset) { _, ex in
                Divider().overlay(Brand.line).padding(.leading, 50)
                WeeklyRow(label: ex.label, title: weeklyTitle(ex.catId, ex.itemId), gold: true) { nav.openReader(ex.catId, ex.itemId) }
            }
        }
        .padding(.bottom, 6)
        .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(isToday ? Brand.gold : Color.clear, lineWidth: 1.5))
    }
}

private struct WeeklyRow: View {
    let label: String
    let title: String
    let gold: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: gold ? "sparkle" : "book")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(gold ? Brand.goldDeep : Brand.accent)
                    .frame(width: 22)
                VStack(alignment: .leading, spacing: 2) {
                    Text(label).font(.ui(.caption, .semibold)).foregroundStyle(gold ? Brand.goldDeep : Brand.muted)
                    Text(title).font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink).lineLimit(1)
                }
                Spacer(minLength: 4)
                Image(systemName: "chevron.backward").font(.caption.weight(.semibold)).foregroundStyle(Brand.muted)
            }
            .padding(.horizontal, 16).padding(.vertical, 10)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}
