import SwiftUI
import UIKit

// MARK: - خِيرة القرآن الكريم (ported from Android ui/KhiraScreen.kt)
// After the four adab, the Mushaf is opened on a right-hand (odd) page of the 604-page Madina Mushaf and the
// first verse of that page is read; its verdict and explanation are shown. Users of a paper Mushaf can enter
// the page number instead. The log of past khiras is kept on this device only.

// MARK: Quran verse index (same split as the Kotlin QuranIndex)

private struct KhiraVerse {
    let sura: Int
    let suraName: String
    let n: Int
    let text: String
}

private enum KhiraQuran {
    /// All 6236 verses, split from the app's Quran text at the verse numbers.
    static let verses: [KhiraVerse] = build()

    private static func build() -> [KhiraVerse] {
        guard let quran = Library.category("quran"),
              let rx = try? NSRegularExpression(pattern: "([^()]+?)\\s*\\(([0-9]+)\\)", options: [.dotMatchesLineSeparators])
        else { return [] }
        var out: [KhiraVerse] = []
        out.reserveCapacity(6236)
        for item in quran.items {
            let idPart = item.id.hasPrefix("q-") ? String(item.id.dropFirst(2)) : item.id
            let s = Int(idPart) ?? 0
            var name = item.title
            if name.hasPrefix("سورة ") { name = String(name.dropFirst(5)) }
            name = name.trimmingCharacters(in: .whitespacesAndNewlines)
            let ns = item.text as NSString
            let matches = rx.matches(in: item.text, options: [], range: NSRange(location: 0, length: ns.length))
            for m in matches {
                guard m.numberOfRanges >= 3 else { continue }
                let n = Int(ns.substring(with: m.range(at: 2))) ?? 0
                var seg = ns.substring(with: m.range(at: 1)).trimmingCharacters(in: .whitespacesAndNewlines)
                // The basmala is its own line before verse 1, except in al-Fatiha and al-Tawba.
                if s != 1 && s != 9 && n == 1, let r = seg.range(of: "\n", options: .backwards) {
                    seg = String(seg[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                }
                out.append(KhiraVerse(sura: s, suraName: name, n: n, text: seg))
            }
        }
        return out
    }
}

// MARK: Page data (Library.shared.khira)

private enum KhiraPage {
    static let count = 604
    private static let data = Library.shared.khira
    private static let verdicts: [Character] = Array(data.pageVerdict)
    private static let themeA: [Character] = Array(data.pageThemeA)
    private static let themeB: [Character] = Array(data.pageThemeB)

    /// 'g' good, 'm' middle, 'b' bad.
    static func verdict(_ page: Int) -> Character {
        let i = page - 1
        return verdicts.indices.contains(i) ? verdicts[i] : "m"
    }

    static func themes(_ page: Int) -> [String] {
        let i = page - 1
        let a: Character = themeA.indices.contains(i) ? themeA[i] : "-"
        let b: Character = themeB.indices.contains(i) ? themeB[i] : "-"
        var out: [String] = []
        for c in [a, b] where c != "-" {
            if let l = data.labels[String(c)], !out.contains(l) { out.append(l) }
        }
        return out
    }

    static func start(_ page: Int) -> Int {
        let i = page - 1
        return data.pageStart.indices.contains(i) ? data.pageStart[i] : 0
    }

    /// Verse indices of a page (1...604).
    static func verses(of page: Int, total: Int) -> ClosedRange<Int>? {
        guard total > 0 else { return nil }
        let p = max(1, min(count, page))
        let first = max(0, min(total - 1, start(p)))
        var last = p == count ? total - 1 : start(p + 1) - 1
        if p < count && !data.pageStart.indices.contains(p) { last = total - 1 }
        last = max(first, min(total - 1, last))
        return first...last
    }
}

private func khiraTitle(_ c: Character) -> String {
    switch c { case "g": return "خيرةٌ جيّدة"; case "b": return "خيرةٌ غير جيّدة"; default: return "خيرةٌ وسط" }
}
private func khiraShort(_ c: Character) -> String {
    switch c { case "g": return "جيّدة"; case "b": return "غير جيّدة"; default: return "وسط" }
}
private func khiraColor(_ c: Character) -> Color {
    switch c { case "g": return Brand.good; case "b": return Brand.bad; default: return Brand.mid }
}

/// Guidance for the common matters, derived from the verse's ruling (not a quoted text).
private func khiraDetails(_ c: Character) -> [(String, String)] {
    switch c {
    case "g":
        return [("عامّة", "خيرٌ ظاهر، فامضِ في أمرك متوكّلاً على الله."),
                ("الزواج", "فيه توفيقٌ وألفة إن شاء الله، فأقدِم بعد السؤال والتحقّق."),
                ("العمل والتجارة", "مظنّة ربحٍ وبركة، فأقدِم مع حسن التدبير."),
                ("السفر", "سفرٌ ميسَّر إن شاء الله، وتصدّق قبل خروجك.")]
    case "b":
        return [("عامّة", "الأولى ترك الأمر أو تأجيله، والتماس غيره ممّا فيه الخير."),
                ("الزواج", "الأولى عدم الإقدام الآن."),
                ("العمل والتجارة", "مظنّة تعبٍ أو خسارة، فالأولى تركه."),
                ("السفر", "الأولى تأجيله أو تركه.")]
    default:
        return [("عامّة", "لا يترجّح فيه فعلٌ ولا ترك، والأمر إلى اختيارك وتدبيرك."),
                ("الزواج", "لا بأس به، فقدّم المشورة والتحرّي ثم اختر."),
                ("العمل والتجارة", "متوسّط العاقبة، فادرسه واستشر أهل الخبرة."),
                ("السفر", "لا بأس به، مع حسن التدبير.")]
    }
}

private func khiraWhy(_ c: Character, _ themes: [String]) -> String {
    if c == "m" { return "الآية قصصٌ أو أحكامٌ أو أخبار، لا بشارة فيها ولا تحذير." }
    if !themes.isEmpty { return "في الآية وما يليها ذكرُ " + themes.joined(separator: " و") + "." }
    if c == "g" { return "في الآية بشارةٌ أو وعدٌ بالخير." }
    return "في الآية إنذارٌ أو نهيٌ أو ذمّ."
}

private func khiraParseDigits(_ s: String) -> Int? {
    let d = String(s.westernDigits.filter { $0.isASCII && $0.isNumber }.prefix(4))
    return Int(d)
}

// MARK: Log (on device only, last 100)

private struct KhiraEntry: Identifiable, Hashable {
    let at: Int64      // milliseconds since 1970, as Android
    let page: Int
    let intent: String
    var id: Int64 { at }
    var date: Date { Date(timeIntervalSince1970: Double(at) / 1000) }
}

private enum KhiraLog {
    static let key = "khira_log"

    static func load(_ store: Store) -> [KhiraEntry] {
        store.strings(key).compactMap { line in
            let p = line.components(separatedBy: "|")
            guard p.count >= 3, let at = Int64(p[0]), let page = Int(p[1]) else { return nil }
            return KhiraEntry(at: at, page: page, intent: p.dropFirst(2).joined(separator: " "))
        }
    }

    private static func save(_ store: Store, _ list: [KhiraEntry]) {
        store.put(key, list.prefix(100).map { "\($0.at)|\($0.page)|\($0.intent)" })
    }

    static func add(_ store: Store, _ e: KhiraEntry) {
        let clean = String(e.intent.replacingOccurrences(of: "|", with: " ")
            .replacingOccurrences(of: "\n", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines).prefix(140))
        save(store, [KhiraEntry(at: e.at, page: e.page, intent: clean)] + load(store))
    }

    static func remove(_ store: Store, _ at: Int64) { save(store, load(store).filter { $0.at != at }) }

    static func now() -> Int64 { Int64(Date().timeIntervalSince1970 * 1000) }

    static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ar")
        f.dateFormat = "d MMMM yyyy · h:mm a"
        return f
    }()
}

// MARK: - Screen

struct KhiraView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    @State private var tab = 0                 // 0 استخارة · 1 بمصحفك · 2 السجلّ
    @State private var result: KhiraEntry?
    @State private var intent = ""
    @State private var done: [Bool] = Array(repeating: false, count: Library.shared.khiraSteps.count)
    @State private var lookup = ""
    @State private var filter: Character = "a"

    private var log: [KhiraEntry] { KhiraLog.load(store) }

    var body: some View {
        ScreenScroll {
            if let r = result {
                KhiraResultSection(entry: r,
                                   onNew: { startNew() },
                                   onDelete: {
                                       KhiraLog.remove(store, r.at)
                                       withAnimation { result = nil; tab = 2 }
                                   })
                    .id(r.at)
            } else {
                tabPicker
                tabContent
            }
        }
        .navigationTitle("خِيرة القرآن الكريم")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(result != nil)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                if result != nil {
                    Button {
                        withAnimation { result = nil }
                    } label: {
                        Label("رجوع", systemImage: "chevron.backward")
                    }
                }
            }
        }
        .animation(.easeInOut(duration: 0.3), value: result)
    }

    private var tabPicker: some View {
        let n = log.count
        return Picker("", selection: $tab) {
            Text("استخارة").tag(0)
            Text("بمصحفك").tag(1)
            Text(n > 0 ? "السجلّ · \(n.ar)" : "السجلّ").tag(2)
        }
        .pickerStyle(.segmented)
        .labelsHidden()
    }

    @ViewBuilder private var tabContent: some View {
        switch tab {
        case 0:
            KhiraDrawSection(intent: $intent, done: $done) { page in
                record(page: page, intent: intent)
            }
        case 1:
            KhiraLookupSection(input: $lookup) { page in
                record(page: page, intent: "بالمصحف الورقي")
            }
        default:
            KhiraLogSection(log: log, filter: $filter) { e in
                withAnimation { result = e }
            }
        }
    }

    private func record(page: Int, intent: String) {
        let e = KhiraEntry(at: KhiraLog.now(), page: page, intent: intent)
        KhiraLog.add(store, e)
        // Read back the stored (sanitised) entry.
        let stored = KhiraLog.load(store).first(where: { $0.at == e.at }) ?? e
        withAnimation { result = stored }
    }

    private func startNew() {
        withAnimation {
            result = nil
            intent = ""
            tab = 0
            done = Array(repeating: false, count: Library.shared.khiraSteps.count)
        }
    }
}

// MARK: - Draw: intention, adab, seal

private struct KhiraDrawSection: View {
    @Binding var intent: String
    @Binding var done: [Bool]
    let onDrawn: (Int) -> Void

    private let steps: [KhiraStep] = Library.shared.khiraSteps
    private var doneCount: Int { done.filter { $0 }.count }
    private var allDone: Bool { !steps.isEmpty && done.count == steps.count && done.allSatisfy { $0 } }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            intentCard
            adabHeader
            ForEach(Array(steps.enumerated()), id: \.offset) { i, step in
                stepRow(i, step)
            }
            VStack(spacing: 8) {
                KhiraSeal(enabled: allDone) {
                    // A right-hand (odd) page of the 604 Madina Mushaf pages.
                    let page = Int.random(in: 0..<(KhiraPage.count / 2)) * 2 + 1
                    onDrawn(page)
                }
                Text("يُفتح المصحف على صفحةٍ يمنى، ويُقرأ أوّل سطرٍ منها.")
                    .font(.caption).foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(.top, 4)
        }
    }

    private var intentCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("في أيّ أمرٍ تستخير؟").font(.subheadline.weight(.bold))
            Text("اختياري، ويُحفظ في سجلّك على هذا الجهاز فقط.").font(.caption).foregroundStyle(.secondary)
            TextField("مثلاً: عرض عمل، سفر، خطبة…", text: $intent)
                .textFieldStyle(.plain)
                .padding(12)
                .background(Color(.tertiarySystemFill), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .padding(.top, 4)
                .onChange(of: intent) { _, v in
                    if v.count > 140 { intent = String(v.prefix(140)) }
                }
        }
        .card(20)
    }

    private var adabHeader: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("آداب الخيرة").font(.body.weight(.heavy))
                Spacer()
                Text("\(doneCount.ar) من \(steps.count.ar)")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(allDone ? Brand.emerald : Color.secondary)
            }
            ProgressView(value: Double(doneCount), total: Double(max(1, steps.count)))
                .tint(Brand.emerald)
        }
    }

    private func stepRow(_ i: Int, _ step: KhiraStep) -> some View {
        let isDone = done.indices.contains(i) ? done[i] : false
        return Button {
            if done.indices.contains(i) { done[i].toggle() }
            Haptic.tick()
        } label: {
            HStack(spacing: 12) {
                ZStack {
                    Circle().fill(isDone ? Brand.emerald : Color(.tertiarySystemFill))
                    if isDone {
                        Image(systemName: "checkmark").font(.footnote.weight(.bold)).foregroundStyle(.white)
                    } else {
                        Text((i + 1).ar).font(.footnote.weight(.bold)).foregroundStyle(.secondary)
                    }
                }
                .frame(width: 30, height: 30)
                VStack(alignment: .leading, spacing: 2) {
                    Text(step.title).font(.subheadline.weight(.bold)).foregroundStyle(.primary)
                    Text(step.desc).font(.caption).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .card(18, padding: 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(isDone ? .isSelected : [])
    }
}

/// Long-press seal: holding for 1.6 s fills the gold ring and opens the Mushaf.
private struct KhiraSeal: View {
    let enabled: Bool
    let onComplete: () -> Void
    @State private var progress: CGFloat = 0

    var body: some View {
        ZStack {
            Circle()
                .stroke(enabled ? Brand.gold.opacity(0.22) : Color(.systemFill), lineWidth: 12)
            Circle()
                .trim(from: 0, to: progress)
                .stroke(Brand.gold, style: StrokeStyle(lineWidth: 12, lineCap: .round))
                .rotationEffect(.degrees(-90))
            inner
                .frame(width: 156, height: 156)
                .glassCircle(tint: enabled ? Brand.emerald : nil, interactive: enabled)
        }
        .frame(width: 210, height: 210)
        .contentShape(Circle())
        .onLongPressGesture(minimumDuration: 1.6, maximumDistance: 60, perform: {
            guard enabled else { return }
            Haptic.confirm()
            onComplete()
        }, onPressingChanged: { pressing in
            guard enabled else { return }
            if pressing {
                Haptic.tick()
                withAnimation(.linear(duration: 1.6)) { progress = 1 }
            } else {
                withAnimation(.easeOut(duration: 0.2)) { progress = 0 }
            }
        })
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(enabled ? "اضغط مطوّلاً لفتح المصحف" : "أتمم الآداب أولاً")
        .accessibilityAddTraits(.isButton)
        .accessibilityAction {
            if enabled { onComplete() }
        }
    }

    private var inner: some View {
        VStack(spacing: 6) {
            Image(systemName: "book.fill")
                .font(.system(size: 30, weight: .semibold))
                .foregroundStyle(enabled ? Brand.emerald : Color.secondary)
            Text(enabled ? "اضغط مطوّلاً" : "أتمم الآداب أولاً")
                .font(.subheadline.weight(.bold))
                .foregroundStyle(enabled ? Brand.emerald : Color.secondary)
            if enabled {
                Text("لفتح المصحف").font(.caption).foregroundStyle(.secondary)
            }
        }
    }
}

// MARK: - Paper Mushaf lookup

private struct KhiraLookupSection: View {
    @Binding var input: String
    let onPage: (Int) -> Void

    private var page: Int? { khiraParseDigits(input) }
    private var valid: Bool { if let p = page { return p >= 1 && p <= KhiraPage.count } else { return false } }

    var body: some View {
        VStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 10) {
                Text("استخرتَ بمصحفك؟").font(.headline.weight(.heavy))
                Text("بعد الآداب الأربعة افتح المصحف، وانظر في الصفحة اليمنى، ثم أدخل رقمها ليُبيَّن لك حكم أوّل آيةٍ فيها.")
                    .font(.subheadline).foregroundStyle(.secondary)
                TextField("رقم الصفحة (١ إلى ٦٠٤)", text: $input)
                    .keyboardType(.numberPad)
                    .textFieldStyle(.plain)
                    .padding(12)
                    .background(Color(.tertiarySystemFill), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .onChange(of: input) { _, v in
                        if v.count > 4 { input = String(v.prefix(4)) }
                    }
                warnings
                Button {
                    if let p = page, valid { onPage(p) }
                } label: {
                    Text("اعرض الخيرة").font(.body.weight(.heavy)).frame(maxWidth: .infinity)
                }
                .glassButton(prominent: true)
                .controlSize(.large)
                .disabled(!valid)
                .padding(.top, 4)
            }
            .card(20, padding: 18)
            Text("الترقيم بحسب مصحف المدينة المنوّرة ذي الـ٦٠٤ صفحات، وهو الأشيع.")
                .font(.caption).foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
        }
    }

    @ViewBuilder private var warnings: some View {
        if let p = page, valid, p % 2 == 0 {
            Text("الصفحة اليمنى في مصحف المدينة فرديّة الرقم غالباً؛ تأكّد من الرقم.")
                .font(.caption).foregroundStyle(Brand.mid)
        }
        if page != nil && !valid {
            Text("عدد صفحات المصحف ٦٠٤.").font(.caption).foregroundStyle(Brand.bad)
        }
    }
}

// MARK: - Log

private struct KhiraLogSection: View {
    let log: [KhiraEntry]
    @Binding var filter: Character
    let onOpen: (KhiraEntry) -> Void

    private let filters: [(Character, String)] = [("a", "الكلّ"), ("g", "جيّدة"), ("m", "وسط"), ("b", "غير جيّدة")]

    private var shown: [KhiraEntry] {
        filter == "a" ? log : log.filter { KhiraPage.verdict($0.page) == filter }
    }

    var body: some View {
        if log.isEmpty {
            EmptyStateView(symbol: "book", title: "لا خِيَر محفوظة بعد", message: "تُحفظ كلّ خيرةٍ هنا مع نيّتها، لتعود إليها.")
                .card(20)
        } else {
            VStack(alignment: .leading, spacing: 10) {
                chips
                ForEach(shown) { e in
                    Button { onOpen(e) } label: { KhiraLogRow(entry: e) }
                        .buttonStyle(.plain)
                }
            }
        }
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(Array(filters.enumerated()), id: \.offset) { _, f in
                    let on = filter == f.0
                    let col: Color = f.0 == "a" ? Brand.emerald : khiraColor(f.0)
                    Button {
                        filter = f.0
                        Haptic.tick()
                    } label: {
                        Text(f.1)
                            .font(.caption.weight(.bold))
                            .foregroundStyle(on ? Color.white : Color.secondary)
                            .padding(.horizontal, 14).padding(.vertical, 7)
                            .background(on ? col : Color(.tertiarySystemFill), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

private struct KhiraLogRow: View {
    let entry: KhiraEntry

    var body: some View {
        let c = KhiraPage.verdict(entry.page)
        let col = khiraColor(c)
        let verses = KhiraQuran.verses
        let idx = KhiraPage.start(entry.page)
        let sura = verses.indices.contains(idx) ? "سورة \(verses[idx].suraName) · " : ""
        let meta = sura + "الصفحة \(entry.page.ar) · " + KhiraLog.dateFormatter.string(from: entry.date)
        return HStack(spacing: 12) {
            Circle().fill(col).frame(width: 10, height: 10)
            VStack(alignment: .leading, spacing: 2) {
                Text(entry.intent.trimmingCharacters(in: .whitespaces).isEmpty ? "خيرة" : entry.intent)
                    .font(.subheadline.weight(.bold)).foregroundStyle(.primary).lineLimit(1)
                Text(meta).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            Text(khiraShort(c))
                .font(.caption.weight(.heavy)).foregroundStyle(col)
                .padding(.horizontal, 10).padding(.vertical, 4)
                .background(col.opacity(0.12), in: Capsule())
        }
        .card(18, padding: 14)
        .contentShape(Rectangle())
    }
}

// MARK: - Result

private struct KhiraResultSection: View {
    let entry: KhiraEntry
    let onNew: () -> Void
    let onDelete: () -> Void

    @Environment(AppNav.self) private var nav
    @Environment(\.colorScheme) private var scheme
    @State private var fullPage = false
    @State private var copied = false

    private var verses: [KhiraVerse] { KhiraQuran.verses }
    private var verdict: Character { KhiraPage.verdict(entry.page) }
    private var color: Color { khiraColor(verdict) }

    var body: some View {
        if let range = KhiraPage.verses(of: entry.page, total: verses.count) {
            let v = verses[range.lowerBound]
            VStack(alignment: .leading, spacing: 14) {
                hero(v)
                pageCard(v, range)
                explanation
                actions(v)
                footer
            }
        } else {
            Text("تعذّر تحميل المصحف.").foregroundStyle(Brand.bad)
        }
    }

    // Verdict hero, coloured by verdict.
    private func hero(_ v: KhiraVerse) -> some View {
        VStack(spacing: 6) {
            if !entry.intent.trimmingCharacters(in: .whitespaces).isEmpty {
                Text(entry.intent)
                    .font(.footnote.weight(.medium)).foregroundStyle(.white.opacity(0.88))
                    .multilineTextAlignment(.center).lineLimit(2)
            }
            Text(khiraTitle(verdict)).font(.system(size: 26, weight: .heavy))
            Text("الصفحة \(entry.page.ar) · سورة \(v.suraName) · الآية \(v.n.ar)")
                .font(.caption.weight(.bold)).foregroundStyle(.white.opacity(0.9))
                .multilineTextAlignment(.center)
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity)
        .padding(22)
        .background(
            ZStack(alignment: .topLeading) {
                LinearGradient(colors: [color, color.opacity(0.78)], startPoint: .topLeading, endPoint: .bottomTrailing)
                StarPattern(cell: 64).foregroundStyle(.white.opacity(0.10))
            }
            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        )
        .shadow(color: color.opacity(0.3), radius: 10, y: 4)
    }

    // Mushaf page on paper with a gold double border.
    private func pageCard(_ v: KhiraVerse, _ range: ClosedRange<Int>) -> some View {
        let pageBg: Color = scheme == .dark ? Color(.secondarySystemGroupedBackground) : Brand.paper
        return VStack(spacing: 10) {
            HStack {
                Text("سورة \(v.suraName)")
                Spacer()
                Text("صفحة \(entry.page.ar)")
            }
            .font(.caption.weight(.bold)).foregroundStyle(Brand.goldDeep)
            Text("\(v.text) ﴿\(v.n.ar)﴾")
                .font(.scripture(24))
                .lineSpacing(10)
                .multilineTextAlignment(.center)
                .foregroundStyle(.primary)
                .frame(maxWidth: .infinity)
                .padding(12)
                .background(Brand.gold.opacity(0.13), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            Text("أوّل سطرٍ في الصفحة").font(.caption2).foregroundStyle(.secondary)
            if range.upperBound > range.lowerBound {
                if fullPage {
                    Text(restOfPage(range))
                        .font(.scripture(18))
                        .lineSpacing(8)
                        .multilineTextAlignment(.leading)
                        .foregroundStyle(Color.primary.opacity(0.78))
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                Button(fullPage ? "إخفاء بقية الصفحة" : "اقرأ الصفحة كاملة") {
                    withAnimation { fullPage.toggle() }
                }
                .font(.footnote.weight(.bold))
                .foregroundStyle(Brand.emerald)
                .buttonStyle(.borderless)
            }
        }
        .padding(16)
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Brand.gold.opacity(0.30), lineWidth: 1))
        .padding(5)
        .background(pageBg, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Brand.gold.opacity(0.55), lineWidth: 1))
    }

    private func restOfPage(_ range: ClosedRange<Int>) -> String {
        let lo = range.lowerBound + 1
        guard lo <= range.upperBound else { return "" }
        return (lo...range.upperBound)
            .compactMap { verses.indices.contains($0) ? verses[$0] : nil }
            .map { "\($0.text) ﴿\($0.n.ar)﴾" }
            .joined(separator: "  ")
    }

    private var explanation: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("بيان الخيرة").font(.body.weight(.heavy))
            Text(khiraWhy(verdict, KhiraPage.themes(entry.page)))
                .font(.subheadline).foregroundStyle(.secondary)
            ForEach(Array(khiraDetails(verdict).enumerated()), id: \.offset) { i, row in
                if i > 0 { Divider() }
                HStack(alignment: .top, spacing: 8) {
                    Text(row.0).font(.subheadline.weight(.heavy)).foregroundStyle(color)
                        .frame(width: 96, alignment: .leading)
                    Text(row.1).font(.subheadline)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .card(20, padding: 18)
    }

    private func shareText(_ v: KhiraVerse) -> String {
        let intent = entry.intent.trimmingCharacters(in: .whitespaces)
        let title = khiraTitle(verdict) + (intent.isEmpty ? "" : " · " + intent)
        return "\(title)\n\n\(v.text) ﴿\(v.n.ar)﴾\n\nسورة \(v.suraName) · الصفحة \(entry.page.ar)\n\n— تطبيق رفيق المؤمن"
    }

    private func copyText(_ v: KhiraVerse) -> String {
        khiraTitle(verdict) + "\n" + v.text + " ﴿" + v.n.ar + "﴾\nسورة " + v.suraName + " · الصفحة " + entry.page.ar
    }

    private func actions(_ v: KhiraVerse) -> some View {
        VStack(spacing: 12) {
            HStack(spacing: 10) {
                Button {
                    let intent = entry.intent.trimmingCharacters(in: .whitespaces)
                    ShareCard.present(title: khiraTitle(verdict) + (intent.isEmpty ? "" : " · " + intent),
                                      text: "\(v.text) ﴿\(v.n.ar)﴾",
                                      source: "سورة \(v.suraName) · الصفحة \(entry.page.ar)")
                } label: {
                    KhiraActionLabel(title: "مشاركة", symbol: "square.and.arrow.up")
                }
                .buttonStyle(.plain)
                Button {
                    nav.openReader("quran", "q-" + String(format: "%03d", v.sura))
                } label: {
                    KhiraActionLabel(title: "السورة", symbol: "book")
                }
                .buttonStyle(.plain)
                Button {
                    UIPasteboard.general.string = copyText(v)
                    Haptic.confirm()
                    copied = true
                } label: {
                    KhiraActionLabel(title: copied ? "نُسخت ✓" : "نسخ", symbol: copied ? "checkmark" : "doc.on.doc")
                }
                .buttonStyle(.plain)
            }
            Button(action: onNew) {
                Text("خيرة جديدة").font(.body.weight(.heavy)).frame(maxWidth: .infinity)
            }
            .glassButton(prominent: true)
            .controlSize(.large)
            Button(role: .destructive, action: onDelete) {
                Text("حذف من السجلّ").font(.footnote.weight(.bold)).frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderless)
            .tint(Brand.bad)
        }
    }

    private var footer: some View {
        Text("الخيرة إرشادٌ عند الحيرة بعد التدبّر والمشورة، والقرار بعدها لك متوكّلاً على الله.")
            .font(.caption).foregroundStyle(.secondary)
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
    }
}

private struct KhiraActionLabel: View {
    let title: String
    let symbol: String
    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: symbol).font(.system(size: 18, weight: .semibold)).foregroundStyle(Brand.emerald)
            Text(title).font(.caption.weight(.bold)).foregroundStyle(.primary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .contentShape(Rectangle())
    }
}
