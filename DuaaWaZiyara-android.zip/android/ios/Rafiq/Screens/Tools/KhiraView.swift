import SwiftUI
import UIKit

// MARK: - خِيرة القرآن الكريم (ported from Android ui/KhiraScreen.kt)
// After the four adab, the Mushaf is opened on a right-hand (odd) page of the 604-page Madina Mushaf and the
// first verse of that page is read; its verdict and explanation are shown. Users of a paper Mushaf can enter
// the page number instead. The log of past khiras is kept on this device only.

// MARK: Quran verse index (same split as the Kotlin QuranIndex)

private struct KhiraVerse {
    let sura: Int
    let suraName: String
    let n: Int
    let text: String
}

private enum KhiraQuran {
    /// All 6236 verses, split from the app's Quran text at the verse numbers.
    static let verses: [KhiraVerse] = build()

    private static func build() -> [KhiraVerse] {
        guard let quran = Library.category("quran"),
              let rx = try? NSRegularExpression(pattern: "([^()]+?)\\s*\\(([0-9]+)\\)", options: [.dotMatchesLineSeparators])
        else { return [] }
        var out: [KhiraVerse] = []
        out.reserveCapacity(6236)
        for item in quran.items {
            let idPart = item.id.hasPrefix("q-") ? String(item.id.dropFirst(2)) : item.id
            let s = Int(idPart) ?? 0
            var name = item.title
            if name.hasPrefix("سورة ") { name = String(name.dropFirst(5)) }
            name = name.trimmingCharacters(in: .whitespacesAndNewlines)
            let ns = item.text as NSString
            let matches = rx.matches(in: item.text, options: [], range: NSRange(location: 0, length: ns.length))
            for m in matches {
                guard m.numberOfRanges >= 3 else { continue }
                let n = Int(ns.substring(with: m.range(at: 2))) ?? 0
                var seg = ns.substring(with: m.range(at: 1)).trimmingCharacters(in: .whitespacesAndNewlines)
                // The basmala is its own line before verse 1, except in al-Fatiha and al-Tawba.
                if s != 1 && s != 9 && n == 1, let r = seg.range(of: "\n", options: .backwards) {
                    seg = String(seg[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                }
                out.append(KhiraVerse(sura: s, suraName: name, n: n, text: seg))
            }
        }
        return out
    }
}

// MARK: Page data (Library.shared.khira)

private enum KhiraPage {
    static let count = 604
    private static let data = Library.shared.khira
    private static let verdicts: [Character] = Array(data.pageVerdict)
    private static let themeA: [Character] = Array(data.pageThemeA)
    private static let themeB: [Character] = Array(data.pageThemeB)

    /// 'g' good, 'm' middle, 'b' bad.
    static func verdict(_ page: Int) -> Character {
        let i = page - 1
        return verdicts.indices.contains(i) ? verdicts[i] : "m"
    }

    static func themes(_ page: Int) -> [String] {
        let i = page - 1
        let a: Character = themeA.indices.contains(i) ? themeA[i] : "-"
        let b: Character = themeB.indices.contains(i) ? themeB[i] : "-"
        var out: [String] = []
        for c in [a, b] where c != "-" {
            if let l = data.labels[String(c)], !out.contains(l) { out.append(l) }
        }
        return out
    }

    static func start(_ page: Int) -> Int {
        let i = page - 1
        return data.pageStart.indices.contains(i) ? data.pageStart[i] : 0
    }

    /// Verse indices of a page (1...604).
    static func verses(of page: Int, total: Int) -> ClosedRange<Int>? {
        guard total > 0 else { return nil }
        let p = max(1, min(count, page))
        let first = max(0, min(total - 1, start(p)))
        var last = p == count ? total - 1 : start(p + 1) - 1
        if p < count && !data.pageStart.indices.contains(p) { last = total - 1 }
        last = max(first, min(total - 1, last))
        return first...last
    }
}

private func khiraTitle(_ c: Character) -> String {
    switch c { case "g": return "خيرةٌ جيّدة"; case "b": return "خيرةٌ غير جيّدة"; default: return "خيرةٌ وسط" }
}
private func khiraShort(_ c: Character) -> String {
    switch c { case "g": return "جيّدة"; case "b": return "غير جيّدة"; default: return "وسط" }
}
private func khiraColor(_ c: Character) -> Color {
    switch c { case "g": return Brand.good; case "b": return Brand.bad; default: return Brand.mid }
}

/// Guidance for the common matters, derived from the verse's ruling (not a quoted text).
private func khiraDetails(_ c: Character) -> [(String, String)] {
    switch c {
    case "g":
        return [("عامّة", "خيرٌ ظاهر، فامضِ في أمرك متوكّلاً على الله."),
                ("الزواج", "فيه توفيقٌ وألفة إن شاء الله، فأقدِم بعد السؤال والتحقّق."),
                ("العمل والتجارة", "مظنّة ربحٍ وبركة، فأقدِم مع حسن التدبير."),
                ("السفر", "سفرٌ ميسَّر إن شاء الله، وتصدّق قبل خروجك.")]
    case "b":
        return [("عامّة", "الأولى ترك الأمر أو تأجيله، والتماس غيره ممّا فيه الخير."),
                ("الزواج", "الأولى عدم الإقدام الآن."),
                ("العمل والتجارة", "مظنّة تعبٍ أو خسارة، فالأولى تركه."),
                ("السفر", "الأولى تأجيله أو تركه.")]
    default:
        return [("عامّة", "لا يترجّح فيه فعلٌ ولا ترك، والأمر إلى اختيارك وتدبيرك."),
                ("الزواج", "لا بأس به، فقدّم المشورة والتحرّي ثم اختر."),
                ("العمل والتجارة", "متوسّط العاقبة، فادرسه واستشر أهل الخبرة."),
                ("السفر", "لا بأس به، مع حسن التدبير.")]
    }
}

private func khiraWhy(_ c: Character, _ themes: [String]) -> String {
    if c == "m" { return "الآية قصصٌ أو أحكامٌ أو أخبار، لا بشارة فيها ولا تحذير." }
    if !themes.isEmpty { return "في الآية وما يليها ذكرُ " + themes.joined(separator: " و") + "." }
    if c == "g" { return "في الآية بشارةٌ أو وعدٌ بالخير." }
    return "في الآية إنذارٌ أو نهيٌ أو ذمّ."
}

private func khiraParseDigits(_ s: String) -> Int? {
    let d = String(s.westernDigits.filter { $0.isASCII && $0.isNumber }.prefix(4))
    return Int(d)
}

// MARK: Log (on device only, last 100)

private struct KhiraEntry: Identifiable, Hashable {
    let at: Int64      // milliseconds since 1970, as Android
    let page: Int
    let intent: String
    var id: Int64 { at }
    var date: Date { Date(timeIntervalSince1970: Double(at) / 1000) }
}

private enum KhiraLog {
    static let key = "khira_log"

    static func load(_ store: Store) -> [KhiraEntry] {
        store.strings(key).compactMap { line in
            let p = line.components(separatedBy: "|")
            guard p.count >= 3, let at = Int64(p[0]), let page = Int(p[1]) else { return nil }
            return KhiraEntry(at: at, page: page, intent: p.dropFirst(2).joined(separator: " "))
        }
    }

    private static func save(_ store: Store, _ list: [KhiraEntry]) {
        store.put(key, list.prefix(100).map { "\($0.at)|\($0.page)|\($0.intent)" })
    }

    static func add(_ store: Store, _ e: KhiraEntry) {
        let clean = String(e.intent.replacingOccurrences(of: "|", with: " ")
            .replacingOccurrences(of: "\n", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines).prefix(140))
        save(store, [KhiraEntry(at: e.at, page: e.page, intent: clean)] + load(store))
    }

    static func remove(_ store: Store, _ at: Int64) { save(store, load(store).filter { $0.at != at }) }

    static func now() -> Int64 { Int64(Date().timeIntervalSince1970 * 1000) }

    static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ar")
        f.dateFormat = "d MMMM yyyy · h:mm a"
        return f
    }()
}

// MARK: - Screen

struct KhiraView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    @State private var tab = 0                 // 0 استخارة · 1 بمصحفك · 2 السجلّ
    @State private var result: KhiraEntry?
    @State private var intent = ""
    @State private var done: [Bool] = Array(repeating: false, count: Library.shared.khiraSteps.count)
    @State private var lookup = ""
    @State private var filter: Character = "a"

    private var log: [KhiraEntry] { KhiraLog.load(store) }

    @Environment(\.dismiss) private var dismiss

    /// 0 purity & salawat · 1 intention & dua · 2 opening the mushaf · 3 result (the mockup's four steps).
    private var stage: Int {
        if result != nil { return 3 }
        let n = done.filter { $0 }.count
        if n >= done.count && !done.isEmpty { return 2 }
        if n >= 2 { return 1 }
        return 0
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if tab == 0 || result != nil { stepper }
                if let r = result {
                    KhiraResultSection(entry: r,
                                       onNew: { startNew() },
                                       onDelete: {
                                           KhiraLog.remove(store, r.at)
                                           withAnimation { result = nil; tab = 2 }
                                       },
                                       onLog: { withAnimation { result = nil; tab = 2 } },
                                       logCount: log.count,
                                       lastEntry: log.first(where: { $0.at != r.at }))
                        .id(r.at)
                } else {
                    tabContent
                }
            }
            .padding(.horizontal, 16).padding(.top, 6).padding(.bottom, 28)
            .readableWidth()
        }
        .scrollBounceBehavior(.basedOnSize)
        .background(
            ZStack { Color(hex: 0xF7F0E1); GirihPattern(cell: 64).foregroundStyle(Brand.gold.opacity(0.07)) }
                .ignoresSafeArea()
        )
        .safeAreaInset(edge: .top, spacing: 0) { topBar }
        .toolbar(.hidden, for: .navigationBar)
        .environment(\.colorScheme, .light)
        .animation(.easeInOut(duration: 0.3), value: result)
    }

    private var topBar: some View {
        HStack {
            RoundIconButton(symbol: "chevron.backward", label: "رجوع") {
                if result != nil { withAnimation { result = nil } } else if tab != 0 { withAnimation { tab = 0 } } else { dismiss() }
            }
            Spacer()
            Text(tab == 1 ? "الخيرة بمصحفك" : (tab == 3 ? "الخيرة بالسبحة" : (tab == 2 ? "سجل الخيرات" : "الخيرة بالمصحف")))
                .font(.display(22)).foregroundStyle(Brand.ink)
            Spacer()
            Menu {
                Button { withAnimation { result = nil; tab = 0 } } label: { Label("الخيرة بالمصحف", systemImage: "book") }
                Button { withAnimation { result = nil; tab = 1 } } label: { Label("بمصحفك الورقي", systemImage: "book.closed") }
                Button { withAnimation { result = nil; tab = 3 } } label: { Label("بالسبحة", systemImage: "circle.dotted") }
                Button { withAnimation { result = nil; tab = 2 } } label: { Label(log.isEmpty ? "السجلّ" : "السجلّ · \(log.count.ar)", systemImage: "list.bullet") }
            } label: {
                Image(systemName: "exclamationmark.circle")
                    .font(.system(size: 17, weight: .medium)).foregroundStyle(Brand.ink)
                    .frame(width: 42, height: 42).background(Color.white, in: Circle())
            }
            .accessibilityLabel("طرق الخيرة والسجلّ")
        }
        .padding(.horizontal, 16).padding(.vertical, 8)
    }

    private var stepper: some View {
        let titles = ["الطهارة والصلاة على محمد وآله", "النيّة والدعاء", "فتح المصحف", "النتيجة"]
        return HStack(alignment: .top, spacing: 4) {
            ForEach(0..<4, id: \.self) { k in
                VStack(spacing: 6) {
                    ZStack {
                        Circle().fill(k < stage ? Brand.emerald : (k == stage ? Brand.gold : Color(hex: 0xEAE4D6)))
                        if k < stage {
                            Image(systemName: "checkmark").font(.system(size: 12, weight: .bold)).foregroundStyle(.white)
                        } else {
                            Text((k + 1).ar).font(.ui(.caption, .bold)).foregroundStyle(k == stage ? .white : Brand.muted)
                        }
                    }
                    .frame(width: 30, height: 30)
                    Text(titles[k]).font(.ui(.caption2, .semibold)).foregroundStyle(k <= stage ? Brand.ink : Brand.muted)
                        .multilineTextAlignment(.center).lineLimit(2).fixedSize(horizontal: false, vertical: true)
                }
                .frame(maxWidth: .infinity)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("المرحلة \((stage + 1).ar) من ٤: \(titles[stage])")
    }

    @ViewBuilder private var tabContent: some View {
        switch tab {
        case 0:
            KhiraDrawSection(intent: $intent, done: $done) { page in
                record(page: page, intent: intent)
            }
        case 1:
            KhiraLookupSection(input: $lookup) { page in
                record(page: page, intent: "بالمصحف الورقي")
            }
        case 3:
            KhiraSabhaSection()
        default:
            KhiraLogSection(log: log, filter: $filter) { e in
                withAnimation { result = e }
            }
        }
    }

    private func record(page: Int, intent: String) {
        let e = KhiraEntry(at: KhiraLog.now(), page: page, intent: intent)
        KhiraLog.add(store, e)
        // Read back the stored (sanitised) entry.
        let stored = KhiraLog.load(store).first(where: { $0.at == e.at }) ?? e
        withAnimation { result = stored }
    }

    private func startNew() {
        withAnimation {
            result = nil
            intent = ""
            tab = 0
            done = Array(repeating: false, count: Library.shared.khiraSteps.count)
        }
    }
}

// MARK: - Draw: intention, adab, seal

private struct KhiraDrawSection: View {
    @Binding var intent: String
    @Binding var done: [Bool]
    let onDrawn: (Int) -> Void

    private let steps: [KhiraStep] = Library.shared.khiraSteps
    private var doneCount: Int { done.filter { $0 }.count }
    private var allDone: Bool { !steps.isEmpty && done.count == steps.count && done.allSatisfy { $0 } }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            intentCard
            adabHeader
            ForEach(Array(steps.enumerated()), id: \.offset) { i, step in
                stepRow(i, step)
            }
            VStack(spacing: 8) {
                KhiraSeal(enabled: allDone) {
                    // A right-hand (odd) page of the 604 Madina Mushaf pages.
                    let page = Int.random(in: 0..<(KhiraPage.count / 2)) * 2 + 1
                    onDrawn(page)
                }
                Text("يُفتح المصحف على صفحةٍ يمنى، ويُقرأ أوّل سطرٍ منها.")
                    .font(.ui(.caption)).foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(.top, 4)
        }
    }

    private var intentCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("في أيّ أمرٍ تستخير؟").font(.ui(.subheadline, .bold))
            Text("اختياري، ويُحفظ في سجلّك على هذا الجهاز فقط.").font(.ui(.caption)).foregroundStyle(.secondary)
            TextField("مثلاً: عرض عمل، سفر، خطبة…", text: $intent)
                .textFieldStyle(.plain)
                .padding(12)
                .background(Brand.soft, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .padding(.top, 4)
                .onChange(of: intent) { _, v in
                    if v.count > 140 { intent = String(v.prefix(140)) }
                }
        }
        .card(20)
    }

    private var adabHeader: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("آداب الخيرة").font(.display(18)).foregroundStyle(Brand.ink)
                Spacer()
                Text(verbatim: "\(doneCount.ar) من \(steps.count.ar)")
                    .font(.ui(.caption, .bold))
                    .foregroundStyle(allDone ? Brand.emerald : Color.secondary)
            }
            ProgressView(value: Double(doneCount), total: Double(max(1, steps.count)))
                .tint(Brand.emerald)
        }
    }

    private func stepRow(_ i: Int, _ step: KhiraStep) -> some View {
        let isDone = done.indices.contains(i) ? done[i] : false
        return Button {
            if done.indices.contains(i) { done[i].toggle() }
            Haptic.tick()
        } label: {
            HStack(spacing: 12) {
                ZStack {
                    Circle().fill(isDone ? Brand.emerald : Color(hex: 0xEAE4D6))
                    if isDone {
                        Image(systemName: "checkmark").font(.footnote.weight(.bold)).foregroundStyle(.white)
                    } else {
                        Text((i + 1).ar).font(.ui(.footnote, .bold)).foregroundStyle(.secondary)
                    }
                }
                .frame(width: 30, height: 30)
                VStack(alignment: .leading, spacing: 2) {
                    Text(step.title).font(.ui(.subheadline, .bold)).foregroundStyle(.primary)
                    Text(step.desc).font(.ui(.caption)).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .card(18, padding: 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(isDone ? .isSelected : [])
    }
}

/// Long-press seal: holding for 1.6 s fills the gold ring and opens the Mushaf.
private struct KhiraSeal: View {
    let enabled: Bool
    let onComplete: () -> Void
    @State private var progress: CGFloat = 0

    var body: some View {
        ZStack {
            Circle().fill(Color.white).shadow(color: Color(hex: 0x10322D).opacity(0.12), radius: 18, y: 8)
            Circle()
                .stroke(enabled ? Brand.gold.opacity(0.3) : Color(hex: 0xEAE4D6), lineWidth: 12)
            Circle()
                .trim(from: 0, to: progress)
                .stroke(Brand.gold, style: StrokeStyle(lineWidth: 12, lineCap: .round))
                .rotationEffect(.degrees(-90))
            inner
                .frame(width: 156, height: 156)
        }
        .frame(width: 210, height: 210)
        .contentShape(Circle())
        .onLongPressGesture(minimumDuration: 1.6, maximumDistance: 60, perform: {
            guard enabled else { return }
            Haptic.confirm()
            onComplete()
        }, onPressingChanged: { pressing in
            guard enabled else { return }
            if pressing {
                Haptic.tick()
                withAnimation(.linear(duration: 1.6)) { progress = 1 }
            } else {
                withAnimation(.easeOut(duration: 0.2)) { progress = 0 }
            }
        })
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(enabled ? "اضغط مطوّلاً لفتح المصحف" : "أتمم الآداب أولاً")
        .accessibilityAddTraits(.isButton)
        .accessibilityAction {
            if enabled { onComplete() }
        }
    }

    private var inner: some View {
        VStack(spacing: 6) {
            Image(systemName: "book.fill")
                .font(.system(size: 30, weight: .semibold))
                .foregroundStyle(enabled ? Brand.emerald : Color.secondary)
            Text(enabled ? "اضغط مطوّلاً" : "أتمم الآداب أولاً")
                .font(.ui(.subheadline, .bold))
                .foregroundStyle(enabled ? Brand.emerald : Color.secondary)
            if enabled {
                Text("لفتح المصحف").font(.ui(.caption)).foregroundStyle(.secondary)
            }
        }
    }
}

// MARK: - Paper Mushaf lookup

private struct KhiraLookupSection: View {
    @Binding var input: String
    let onPage: (Int) -> Void

    private var page: Int? { khiraParseDigits(input) }
    private var valid: Bool { if let p = page { return p >= 1 && p <= KhiraPage.count } else { return false } }

    var body: some View {
        VStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 10) {
                Text("استخرتَ بمصحفك؟").font(.ui(.headline, .heavy))
                Text("بعد الآداب الأربعة افتح المصحف، وانظر في الصفحة اليمنى، ثم أدخل رقمها ليُبيَّن لك حكم أوّل آيةٍ فيها.")
                    .font(.ui(.subheadline)).foregroundStyle(.secondary)
                TextField("رقم الصفحة (١ إلى ٦٠٤)", text: $input)
                    .keyboardType(.numberPad)
                    .textFieldStyle(.plain)
                    .padding(12)
                    .background(Brand.soft, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .onChange(of: input) { _, v in
                        if v.count > 4 { input = String(v.prefix(4)) }
                    }
                warnings
                Button {
                    if let p = page, valid { onPage(p) }
                } label: {
                    Text("اعرض الخيرة").font(.ui(.body, .heavy)).frame(maxWidth: .infinity)
                }
                .glassButton(prominent: true)
                .controlSize(.large)
                .disabled(!valid)
                .padding(.top, 4)
            }
            .card(20, padding: 18)
            Text("الترقيم بحسب مصحف المدينة المنوّرة ذي الـ٦٠٤ صفحات، وهو الأشيع.")
                .font(.ui(.caption)).foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
        }
    }

    @ViewBuilder private var warnings: some View {
        if let p = page, valid, p % 2 == 0 {
            Text("الصفحة اليمنى في مصحف المدينة فرديّة الرقم غالباً؛ تأكّد من الرقم.")
                .font(.ui(.caption)).foregroundStyle(Brand.mid)
        }
        if page != nil && !valid {
            Text("عدد صفحات المصحف ٦٠٤.").font(.ui(.caption)).foregroundStyle(Brand.bad)
        }
    }
}

// MARK: - Log

private struct KhiraLogSection: View {
    let log: [KhiraEntry]
    @Binding var filter: Character
    let onOpen: (KhiraEntry) -> Void

    private let filters: [(Character, String)] = [("a", "الكلّ"), ("g", "جيّدة"), ("m", "وسط"), ("b", "غير جيّدة")]

    private var shown: [KhiraEntry] {
        filter == "a" ? log : log.filter { KhiraPage.verdict($0.page) == filter }
    }

    var body: some View {
        if log.isEmpty {
            EmptyStateView(symbol: "book", title: "لا خِيَر محفوظة بعد", message: "تُحفظ كلّ خيرةٍ هنا مع نيّتها، لتعود إليها.")
                .card(20)
        } else {
            VStack(alignment: .leading, spacing: 10) {
                chips
                ForEach(shown) { e in
                    Button { onOpen(e) } label: { KhiraLogRow(entry: e) }
                        .buttonStyle(.plain)
                }
            }
        }
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(Array(filters.enumerated()), id: \.offset) { _, f in
                    let on = filter == f.0
                    let col: Color = f.0 == "a" ? Brand.emerald : khiraColor(f.0)
                    Button {
                        filter = f.0
                        Haptic.tick()
                    } label: {
                        Text(f.1)
                            .font(.ui(.caption, .bold))
                            .foregroundStyle(on ? Color.white : Color.secondary)
                            .padding(.horizontal, 14).padding(.vertical, 7)
                            .background(on ? col : Color(.tertiarySystemFill), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

private struct KhiraLogRow: View {
    let entry: KhiraEntry

    var body: some View {
        let c = KhiraPage.verdict(entry.page)
        let col = khiraColor(c)
        let verses = KhiraQuran.verses
        let idx = KhiraPage.start(entry.page)
        let sura = verses.indices.contains(idx) ? "سورة \(verses[idx].suraName) · " : ""
        let meta = sura + "الصفحة \(entry.page.ar) · " + KhiraLog.dateFormatter.string(from: entry.date)
        return HStack(spacing: 12) {
            Circle().fill(col).frame(width: 10, height: 10)
            VStack(alignment: .leading, spacing: 2) {
                Text(entry.intent.trimmingCharacters(in: .whitespaces).isEmpty ? "خيرة" : entry.intent)
                    .font(.ui(.subheadline, .bold)).foregroundStyle(.primary).lineLimit(1)
                Text(meta).font(.ui(.caption)).foregroundStyle(.secondary).lineLimit(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            Text(khiraShort(c))
                .font(.ui(.caption, .heavy)).foregroundStyle(col)
                .padding(.horizontal, 10).padding(.vertical, 4)
                .background(col.opacity(0.12), in: Capsule())
        }
        .card(18, padding: 14)
        .contentShape(Rectangle())
    }
}

// MARK: - Result

private struct KhiraResultSection: View {
    let entry: KhiraEntry
    let onNew: () -> Void
    let onDelete: () -> Void
    var onLog: () -> Void = {}
    var logCount: Int = 0
    var lastEntry: KhiraEntry? = nil

    @Environment(AppNav.self) private var nav
    @Environment(\.colorScheme) private var scheme
    @State private var fullPage = false
    @State private var copied = false

    private var verses: [KhiraVerse] { KhiraQuran.verses }
    private var verdict: Character { KhiraPage.verdict(entry.page) }
    private var color: Color { khiraColor(verdict) }

    var body: some View {
        if let range = KhiraPage.verses(of: entry.page, total: verses.count) {
            let v = verses[range.lowerBound]
            VStack(alignment: .leading, spacing: 14) {
                hero(v)
                pageCard(v, range)
                explanation
                logRow
                actions(v)
                footer
            }
        } else {
            Text("تعذّر تحميل المصحف.").foregroundStyle(Brand.bad)
        }
    }

    // v2: the verse on an ornamented paper card, then the verdict pill (as in the mockup).
    private func hero(_ v: KhiraVerse) -> some View {
        VStack(spacing: 6) {
            if !entry.intent.trimmingCharacters(in: .whitespaces).isEmpty {
                Text(entry.intent).font(.ui(.footnote)).foregroundStyle(Brand.muted).multilineTextAlignment(.center).lineLimit(2)
            }
        }
        .frame(maxWidth: .infinity)
    }

    private func pageCard(_ v: KhiraVerse, _ range: ClosedRange<Int>) -> some View {
        let pageBg: Color = scheme == .dark ? Brand.nightCard : Color(hex: 0xFBF7EC)
        return VStack(spacing: 12) {
            VStack(spacing: 14) {
                OrnamentDivider(color: Brand.gold)
                Text(verbatim: "سورة \(v.suraName) · الآية \(v.n.ar) · الصفحة \(entry.page.ar)")
                    .font(.ui(.caption)).foregroundStyle(Brand.muted)
                Text(LibraryText.quranAttributed("\(v.text) (\(v.n))", tint: Brand.goldDeep))
                    .font(.scripture(26))
                    .lineSpacing(12)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(Brand.ink)
                    .frame(maxWidth: .infinity)
                OrnamentDivider(color: Brand.gold)
            }
            .padding(.vertical, 18).padding(.horizontal, 16)
            .frame(maxWidth: .infinity)
            .background(pageBg, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(Brand.gold.opacity(0.6), lineWidth: 1.5))
            HStack(spacing: 8) {
                Image(systemName: verdict == "g" ? "checkmark.circle.fill" : (verdict == "b" ? "xmark.circle.fill" : "minus.circle.fill"))
                    .font(.system(size: 18, weight: .semibold))
                Text(khiraTitle(verdict)).font(.display(22))
            }
            .foregroundStyle(color)
            .padding(.horizontal, 22).padding(.vertical, 10)
            .background(color.opacity(0.12), in: Capsule())
            if range.upperBound > range.lowerBound {
                if fullPage {
                    Text(restOfPage(range))
                        .font(.scripture(18))
                        .lineSpacing(8)
                        .multilineTextAlignment(.leading)
                        .foregroundStyle(Brand.ink.opacity(0.8))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(14)
                        .background(pageBg, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
            }
        }
    }

    private func restOfPage(_ range: ClosedRange<Int>) -> String {
        let lo = range.lowerBound + 1
        guard lo <= range.upperBound else { return "" }
        return (lo...range.upperBound)
            .compactMap { verses.indices.contains($0) ? verses[$0] : nil }
            .map { "\($0.text) ﴿\($0.n.ar)﴾" }
            .joined(separator: "  ")
    }

    private var explanation: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(khiraWhy(verdict, KhiraPage.themes(entry.page)))
                .font(.ui(.subheadline)).foregroundStyle(Brand.ink).multilineTextAlignment(.center).frame(maxWidth: .infinity)
            Text("الحكم من دلالة الآية كما في كتب الخيرة المعتمدة · لا يُعاد فتح المصحف لنفس الأمر")
                .font(.ui(.caption2)).foregroundStyle(Brand.muted).multilineTextAlignment(.center).frame(maxWidth: .infinity)
            ForEach(Array(khiraDetails(verdict).enumerated()), id: \.offset) { i, row in
                if i > 0 { Divider() }
                HStack(alignment: .top, spacing: 8) {
                    Text(row.0).font(.ui(.subheadline, .heavy)).foregroundStyle(color)
                        .frame(width: 96, alignment: .leading)
                    Text(row.1).font(.ui(.subheadline))
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .padding(.horizontal, 8)
    }

    private var logRow: some View {
        Button(action: onLog) {
            HStack(spacing: 12) {
                Image(systemName: "calendar").font(.system(size: 17)).foregroundStyle(Brand.goldDeep)
                VStack(alignment: .leading, spacing: 2) {
                    Text("سجلّ الخيرات").font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink)
                    Text(lastEntry.map { e in "آخرها: " + (e.intent.isEmpty ? "خيرة" : "«\(e.intent)»") + " · " + khiraShort(KhiraPage.verdict(e.page)) } ?? "\(logCount.ar) خيرة محفوظة على جهازك")
                        .font(.ui(.caption)).foregroundStyle(Brand.muted).lineLimit(1)
                }
                Spacer()
                Image(systemName: "chevron.backward").font(.caption.weight(.bold)).foregroundStyle(Brand.muted)
            }
            .card(22, padding: 14)
        }
        .buttonStyle(.plain)
    }

    private func shareText(_ v: KhiraVerse) -> String {
        let intent = entry.intent.trimmingCharacters(in: .whitespaces)
        let title = khiraTitle(verdict) + (intent.isEmpty ? "" : " · " + intent)
        return "\(title)\n\n\(v.text) ﴿\(v.n.ar)﴾\n\nسورة \(v.suraName) · الصفحة \(entry.page.ar)\n\n\(AppLinks.signature)"
    }

    private func copyText(_ v: KhiraVerse) -> String {
        khiraTitle(verdict) + "\n" + v.text + " ﴿" + v.n.ar + "﴾\nسورة " + v.suraName + " · الصفحة " + entry.page.ar
    }

    private func actions(_ v: KhiraVerse) -> some View {
        VStack(spacing: 12) {
            HStack(spacing: 10) {
                Button {
                    let intent = entry.intent.trimmingCharacters(in: .whitespaces)
                    ShareCard.present(title: khiraTitle(verdict) + (intent.isEmpty ? "" : " · " + intent),
                                      text: "\(v.text) ﴿\(v.n.ar)﴾",
                                      source: "سورة \(v.suraName) · الصفحة \(entry.page.ar)")
                } label: { KhiraActionLabel(title: "مشاركة", symbol: "square.and.arrow.up") }
                .buttonStyle(.plain)
                Button {
                    UIPasteboard.general.string = copyText(v)
                    Haptic.confirm()
                    copied = true
                } label: { KhiraActionLabel(title: copied ? "نُسخت ✓" : "نسخ", symbol: copied ? "checkmark" : "doc.on.doc") }
                .buttonStyle(.plain)
                Button(role: .destructive, action: onDelete) { KhiraActionLabel(title: "حذف", symbol: "trash") }
                    .buttonStyle(.plain)
            }
            HStack(spacing: 10) {
                Button(action: onNew) {
                    Text("خيرة جديدة").font(.ui(.subheadline, .semibold)).foregroundStyle(Brand.ink)
                        .frame(maxWidth: .infinity).frame(height: 54)
                        .background(Brand.cardFill, in: Capsule())
                }
                .buttonStyle(.plain)
                Button {
                    nav.openReader("quran", "q-" + String(format: "%03d", v.sura))
                } label: {
                    Text("اقرأ السورة كاملة").font(.ui(.subheadline, .bold)).foregroundStyle(.white)
                        .frame(maxWidth: .infinity).frame(height: 54)
                        .background(Brand.deeper, in: Capsule())
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var footer: some View {
        Text("الخيرة إرشادٌ عند الحيرة بعد التدبّر والمشورة، والقرار بعدها لك متوكّلاً على الله.")
            .font(.ui(.caption)).foregroundStyle(.secondary)
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
    }
}

private struct KhiraActionLabel: View {
    let title: String
    let symbol: String
    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: symbol).font(.system(size: 18, weight: .semibold)).foregroundStyle(Brand.emerald)
            Text(title).font(.ui(.caption, .bold)).foregroundStyle(.primary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .contentShape(Rectangle())
    }
}


// MARK: - Khira by tasbih (sabha)

/// The well-known sabha method: take an uncounted handful and count it off in twos;
/// one left over means "do it", two left over means "leave it".
private struct KhiraSabhaSection: View {
    @State private var count = 0
    @State private var result: Int?
    @State private var manual = ""

    private let steps = [
        "صلِّ على محمدٍ وآل محمد، واطلب الخيرة من الله تعالى بقلبٍ حاضر.",
        "اقبض قبضةً من حبّات السبحة دون أن تعدّها.",
        "عُدّ الحبّات المقبوضة اثنتين اثنتين.",
        "إن بقيت حبّةٌ واحدة فالخيرة: افعل، وإن بقيت اثنتان فالخيرة: لا تفعل."
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 10) {
                Label("الطريقة المشهورة للخيرة بالسبحة", systemImage: "circle.dotted")
                    .font(.ui(.headline)).foregroundStyle(Brand.emerald)
                ForEach(Array(steps.enumerated()), id: \.offset) { i, t in
                    HStack(alignment: .top, spacing: 10) {
                        Text((i + 1).ar).font(.ui(.subheadline, .heavy)).foregroundStyle(Brand.gold).frame(width: 18)
                        Text(t).font(.ui(.subheadline))
                    }
                }
                Text("وفي كيفيّتها رواياتٌ وأقوال، والأحوط الرجوع إلى رسالة مرجعك.")
                    .font(.ui(.caption)).foregroundStyle(.secondary)
            }
            .card()

            VStack(alignment: .leading, spacing: 10) {
                Text("عددتَ بسبحتك؟ أدخل عدد الحبّات").font(.ui(.subheadline, .bold))
                HStack {
                    TextField("مثلاً ١٧", text: $manual)
                        .keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                    Button("النتيجة") {
                        if let n = Int(manual.westernDigits), n > 0 { reveal(n) }
                    }
                    .glassButton(prominent: true)
                }
            }
            .card()

            VStack(spacing: 12) {
                Text("أو قبضةٌ إلكترونية").font(.ui(.subheadline, .bold))
                Button {
                    reveal(Int.random(in: 5...33))
                } label: {
                    VStack(spacing: 6) {
                        Image(systemName: "hand.raised.fill").font(.system(size: 34))
                        Text("اقبض").font(.ui(.headline))
                    }
                    .frame(width: 120, height: 120)
                }
                .glassButton(prominent: true)
                .sensoryFeedback(.impact, trigger: count)
            }
            .frame(maxWidth: .infinity)
            .card()

            if let r = result { resultCard(r) }
        }
    }

    private func reveal(_ n: Int) {
        count += 1
        withAnimation(.spring(duration: 0.4)) { result = n }
    }

    private func resultCard(_ n: Int) -> some View {
        let good = n % 2 == 1
        return VStack(spacing: 8) {
            Text("عدد الحبّات: \(n.ar)").font(.ui(.subheadline)).foregroundStyle(.white.opacity(0.85))
            Text(good ? "افعل" : "لا تفعل")
                .font(.ui(size: 38, weight: .heavy))
                .foregroundStyle(good ? Brand.gold : .white)
            Text(good ? "بقيت حبّةٌ واحدة: الخيرة في الإقدام، فتوكّل على الله."
                      : "بقيت حبّتان: الخيرة في الترك، والخير فيما اختاره الله.")
                .font(.ui(.subheadline)).foregroundStyle(.white).multilineTextAlignment(.center)
        }
        .padding(20)
        .frame(maxWidth: .infinity)
        .hero()
        .id(n)
    }
}
