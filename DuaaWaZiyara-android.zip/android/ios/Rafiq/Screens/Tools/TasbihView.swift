import SwiftUI

// MARK: - التسبيح والذكر (ported from Android ui/Sheets.kt TasbihSheet)
// Presented bare as a sheet: full dark patterned surface, the dhikr in large scripture type, a huge gold counter,
// a big interactive glass tap target and a floating glass toolbar (close, reset, preset, goal).

private struct TasbihMode {
    let key: String
    let label: String
    let phrase: String
    let target: Int
    let stages: [(String, Int)]?
}

private let tasbihModes: [TasbihMode] = [
    TasbihMode(key: "zahra", label: "تسبيح الزهراء", phrase: "", target: 100,
               stages: [("اللّٰه أكبر", 34), ("الحمد لله", 33), ("سبحان الله", 33)]),
    TasbihMode(key: "istighfar", label: "الاستغفار", phrase: "أستَغفِرُ اللهَ وأتوبُ إلَيه", target: 100, stages: nil),
    TasbihMode(key: "salawat", label: "الصلوات", phrase: "اللّٰهُمَّ صَلِّ عَلى مُحَمَّدٍ وآلِ مُحَمَّد", target: 100, stages: nil),
    TasbihMode(key: "tahlil", label: "التهليل", phrase: "لا إلٰهَ إلّا الله", target: 100, stages: nil),
    TasbihMode(key: "hawqala", label: "الحوقلة", phrase: "لا حَولَ ولا قُوَّةَ إلّا بِالله", target: 100, stages: nil),
    TasbihMode(key: "free", label: "عدّاد حر", phrase: "", target: 33, stages: nil)
]

private let tasbihGoals = [33, 100, 313, 1000]

/// Keeps the count if the sheet is closed by mistake, for as long as the app stays alive (as Android TasbihSession).
enum TasbihSession {
    static var modeIdx = 0
    static var count = 0
    static var stage = 0
}

struct TasbihView: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss

    @State private var modeIdx = TasbihSession.modeIdx
    @State private var count = TasbihSession.count
    @State private var stage = TasbihSession.stage
    @State private var confirmReset = false
    @State private var resetToken = 0
    @State private var started = Date()

    // MARK: Derived state

    private var mode: TasbihMode { tasbihModes[max(0, min(tasbihModes.count - 1, modeIdx))] }
    private var stages: [(String, Int)] { mode.stages ?? [] }
    private var staged: Bool { mode.stages != nil }
    private var done: Bool { staged && stage >= stages.count }
    private var target: Int { (staged && !done) ? stages[stage].1 : mode.target }
    private var curLabel: String {
        if staged && done { return "تمّ تسبيح الزهراء (ع)" }
        if staged { return stages[stage].0 }
        return mode.phrase.isEmpty ? mode.label : mode.phrase
    }
    private var frac: Double { target > 0 ? min(1, Double(count) / Double(target)) : 0 }

    private var roundText: String {
        if staged {
            return done ? "تمّت المراحل" : "المرحلة \((stage + 1).ar) من \(stages.count.ar)"
        }
        let per = mode.key == "free" ? 33 : max(1, mode.target)
        return "الدورة \((count / per + 1).ar)"
    }

    // MARK: Body

    @State private var history: [Int] = []   // counts before each tap, for undo

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(hex: 0xF7F0E1), Color(hex: 0xF3E2BE)], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            GirihPattern(cell: 64).foregroundStyle(Brand.gold.opacity(0.07)).ignoresSafeArea()
            VStack(spacing: 0) {
                topBar
                stageChips.padding(.top, 14)
                Spacer(minLength: 10)
                beadRing
                    .contentShape(Rectangle())
                    .onTapGesture { tap() }
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("عُدّ تسبيحة")
                    .accessibilityValue("\(count.ar) من \(target.ar)")
                    .accessibilityAddTraits(.isButton)
                    .accessibilityAction { tap() }
                Text(done ? "تمّ التسبيح · تقبّل الله" : "اضغط في أيّ مكان · اهتزاز عند كلّ \(target.ar)")
                    .font(.footnote).foregroundStyle(Brand.muted)
                    .padding(.top, 14)
                if confirmReset {
                    Text("اضغط «من جديد» مرّةً أخرى للتصفير")
                        .font(.footnote.weight(.bold)).foregroundStyle(Brand.bad)
                        .padding(.top, 8)
                        .transition(.opacity)
                }
                Spacer(minLength: 10)
                todayCard
                bottomButtons.padding(.top, 14)
            }
            .padding(.horizontal, 16)
            .padding(.top, 14)
            .padding(.bottom, 16)
        }
        .foregroundStyle(Brand.ink)
        .environment(\.colorScheme, .light)
        .keepScreenAwake(true)
    }

    // MARK: Top bar: close, title with timer, dhikr menu

    private var topBar: some View {
        HStack {
            RoundIconButton(symbol: "chevron.backward", label: "إغلاق") { dismiss() }
            Spacer()
            VStack(spacing: 2) {
                Text(mode.label).font(.subheadline.weight(.bold)).foregroundStyle(Brand.ink)
                TimelineView(.periodic(from: started, by: 1)) { ctx in
                    Text(verbatim: "\(roundText) · \(tasbihElapsed(ctx.date.timeIntervalSince(started)))")
                        .font(.caption2).foregroundStyle(Brand.muted).monospacedDigit()
                }
            }
            Spacer()
            Menu {
                Picker("الذكر", selection: Binding(get: { modeIdx }, set: { select($0) })) {
                    ForEach(Array(tasbihModes.enumerated()), id: \.offset) { i, m in
                        Text(m.label).tag(i)
                    }
                }
            } label: {
                Image(systemName: "list.bullet")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(Brand.ink)
                    .frame(width: 42, height: 42)
                    .background(Color.white, in: Circle())
            }
            .accessibilityLabel("اختيار الذكر")
        }
    }

    // MARK: Stage chips

    @ViewBuilder private var stageChips: some View {
        if staged {
            HStack(spacing: 8) {
                ForEach(Array(stages.enumerated()), id: \.offset) { i, st in
                    let isDone = i < stage || done
                    let isCur = i == stage && !done
                    VStack(spacing: 2) {
                        Text(st.0).font(.caption.weight(.bold)).lineLimit(1).minimumScaleFactor(0.8)
                        Text(isDone ? "\(st.1.ar) ✓" : (isCur ? "\(count.ar) / \(st.1.ar)" : st.1.ar)).font(.caption2).monospacedDigit()
                    }
                    .foregroundStyle(isDone ? Color.white : (isCur ? Brand.goldDeep : Brand.muted))
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(isDone ? Brand.emerald : (isCur ? Color.white : Color.white.opacity(0.5)), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(isCur ? Brand.gold : Color.clear, lineWidth: 2))
                }
            }
        } else {
            HStack(spacing: 8) {
                VStack(spacing: 2) {
                    Text(curLabel).font(.scripture(16)).lineLimit(1).minimumScaleFactor(0.7)
                    Text(mode.key == "free" ? "عدّاد حرّ · دورة كلّ ٣٣" : "\(count.ar) / \(target.ar)").font(.caption2).foregroundStyle(Brand.muted).monospacedDigit()
                }
                .frame(maxWidth: .infinity)
                .frame(height: 52)
                .background(Color.white, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Brand.gold, lineWidth: 2))
            }
        }
    }

    // MARK: Bead ring with the counter

    private var beadRing: some View {
        let beads = max(1, min(99, target))
        let filled = done ? beads : min(beads, count)
        return ZStack {
            Canvas { ctx, size in
                let c = CGPoint(x: size.width / 2, y: size.height / 2)
                let r = min(size.width, size.height) / 2 - 10
                let bead = beads > 50 ? 5.5 : 7.5
                for i in 0..<beads {
                    let a = -Double.pi / 2 + Double(i) / Double(beads) * 2 * .pi
                    let p = CGPoint(x: c.x + r * CGFloat(cos(a)), y: c.y + r * CGFloat(sin(a)))
                    let on = i < filled
                    ctx.fill(Path(ellipseIn: CGRect(x: p.x - bead, y: p.y - bead, width: bead * 2, height: bead * 2)),
                             with: .color(on ? Brand.goldDeep : Color(hex: 0xD9C9A3)))
                }
            }
            .animation(.easeOut(duration: 0.15), value: filled)
            Circle().fill(Color.white).padding(34)
                .shadow(color: Brand.goldDeep.opacity(0.18), radius: 20, y: 8)
            VStack(spacing: 4) {
                Text(done ? "تقبّل الله" : curLabel)
                    .font(.scripture(26))
                    .foregroundStyle(Brand.deeper)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .minimumScaleFactor(0.5)
                    .padding(.horizontal, 52)
                Text(count.ar)
                    .font(.counter(64))
                    .foregroundStyle(Brand.ink)
                    .contentTransition(.numericText())
                    .animation(.snappy(duration: 0.18), value: count)
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)
                if !done && mode.key != "free" {
                    Text("من \(target.ar)").font(.footnote).foregroundStyle(Brand.muted)
                } else if mode.key == "free" {
                    Text("دورة \((count / 33 + 1).ar)").font(.footnote).foregroundStyle(Brand.muted)
                }
            }
        }
        .frame(width: 300, height: 300)
        .frame(maxWidth: .infinity)
    }

    // MARK: Today

    private var todayCard: some View {
        let today = store.dhikrToday
        let goal = store.dhikrGoal
        let rounds = today / 100
        let bars: [Int] = (0..<7).reversed().map { store.seriesValue("dhikrHist", offset: $0) }
        let top = max(1, bars.max() ?? 1)
        return HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 2) {
                Text("اليوم").font(.caption).foregroundStyle(Brand.muted)
                Text(rounds > 0 ? "\(rounds.ar) \(rounds == 1 ? "مرّة" : (rounds <= 10 ? "مرّات" : "مرّة")) · \(today.ar) تسبيحة" : "\(today.ar) تسبيحة")
                    .font(.subheadline.weight(.bold)).foregroundStyle(Brand.ink).lineLimit(1).minimumScaleFactor(0.8)
                Text(goal > 0 && today >= goal ? "بلغتَ هدفك اليوم — أحسنت 🌿" : "الهدف اليومي \(goal.ar)")
                    .font(.caption2).foregroundStyle(goal > 0 && today >= goal ? Brand.good : Brand.muted)
            }
            Spacer(minLength: 0)
            HStack(alignment: .bottom, spacing: 5) {
                ForEach(Array(bars.enumerated()), id: \.offset) { i, v in
                    RoundedRectangle(cornerRadius: 2)
                        .fill(i == bars.count - 1 ? Brand.goldDeep : Color(hex: 0xE4D3AC))
                        .frame(width: 9, height: max(6, 36 * CGFloat(v) / CGFloat(top)))
                }
            }
            .frame(height: 36)
            .accessibilityLabel("ذكر الأسبوع")
        }
        .padding(16)
        .background(Color.white, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    // MARK: Bottom buttons: undo, reset, goal

    private var bottomButtons: some View {
        HStack(spacing: 10) {
            pillButton("تراجع", enabled: !history.isEmpty) { undo() }
            pillButton("من جديد", enabled: count > 0 || stage > 0, tint: confirmReset ? Brand.bad : Brand.ink) { resetPressed() }
            Menu {
                Picker("هدف الذِّكر اليومي", selection: Binding(get: { store.dhikrGoal }, set: { store.dhikrGoal = $0 })) {
                    ForEach(tasbihGoals, id: \.self) { g in Text(g.ar).tag(g) }
                }
            } label: {
                Text("الهدف \(store.dhikrGoal.ar)")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(store.dhikrToday >= store.dhikrGoal ? Brand.goldDeep : Brand.ink)
                    .frame(maxWidth: .infinity)
                    .frame(height: 54)
                    .background(Color.white, in: Capsule())
            }
            .accessibilityLabel("هدف الذِّكر اليومي")
        }
    }

    private func pillButton(_ title: String, enabled: Bool, tint: Color = Brand.ink, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title).font(.subheadline.weight(.bold)).foregroundStyle(tint)
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .background(Color.white, in: Capsule())
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
        .opacity(enabled ? 1 : 0.5)
    }

    // MARK: Actions

    private func tap() {
        guard !done else { return }
        history.append(count | (stage << 16))
        if history.count > 50 { history.removeFirst() }
        count += 1
        store.addDhikr(1)
        confirmReset = false
        if staged, stage < stages.count, count >= stages[stage].1 {
            stage += 1
            count = 0
            Haptic.confirm()
        } else if !staged && mode.key != "free" && count == mode.target {
            Haptic.confirm()
        } else if mode.key == "free" && count % 33 == 0 {
            Haptic.confirm()
        } else {
            Haptic.tick()
        }
        saveSession()
    }

    /// Takes back the last tap (also steps back across a stage boundary).
    private func undo() {
        guard let last = history.popLast() else { return }
        count = last & 0xFFFF
        stage = last >> 16
        if store.dhikrToday > 0 { store.addDhikr(-1) }
        confirmReset = false
        Haptic.tick()
        saveSession()
    }

    private func select(_ idx: Int) {
        modeIdx = max(0, min(tasbihModes.count - 1, idx))
        count = 0
        stage = 0
        confirmReset = false
        started = Date()
        saveSession()
    }

    /// Two presses reset: the first warns, a second within three seconds clears (a stray touch never loses the count).
    private func resetPressed() {
        if count == 0 && stage == 0 {
            confirmReset = false
            return
        }
        if !confirmReset {
            withAnimation { confirmReset = true }
            Haptic.tick()
            resetToken += 1
            let token = resetToken
            Task {
                try? await Task.sleep(nanoseconds: 3_000_000_000)
                if token == resetToken { withAnimation { confirmReset = false } }
            }
        } else {
            count = 0
            stage = 0
            started = Date()
            withAnimation { confirmReset = false }
            Haptic.heavy()
            saveSession()
        }
    }

    private func saveSession() {
        TasbihSession.modeIdx = modeIdx
        TasbihSession.count = count
        TasbihSession.stage = stage
    }
}

/// mm:ss (or h:mm:ss) in Arabic digits.
private func tasbihElapsed(_ t: TimeInterval) -> String {
    let s = max(0, Int(t))
    let h = s / 3600, m = (s % 3600) / 60, sec = s % 60
    let core = h > 0 ? String(format: "%d:%02d:%02d", h, m, sec) : String(format: "%02d:%02d", m, sec)
    return core.arabicDigits
}
