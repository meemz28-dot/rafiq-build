import SwiftUI

// MARK: - التسبيح والذكر (ported from Android ui/Sheets.kt TasbihSheet)
// Presented bare as a sheet: full dark patterned surface, the dhikr in large scripture type, a huge gold counter,
// a big interactive glass tap target and a floating glass toolbar (close, reset, preset, goal).

private struct TasbihMode {
    let key: String
    let label: String
    let phrase: String
    let target: Int
    let stages: [(String, Int)]?
}

private let tasbihModes: [TasbihMode] = [
    TasbihMode(key: "zahra", label: "تسبيح الزهراء", phrase: "", target: 100,
               stages: [("اللّٰه أكبر", 34), ("الحمد لله", 33), ("سبحان الله", 33)]),
    TasbihMode(key: "istighfar", label: "الاستغفار", phrase: "أستَغفِرُ اللهَ وأتوبُ إلَيه", target: 100, stages: nil),
    TasbihMode(key: "salawat", label: "الصلوات", phrase: "اللّٰهُمَّ صَلِّ عَلى مُحَمَّدٍ وآلِ مُحَمَّد", target: 100, stages: nil),
    TasbihMode(key: "tahlil", label: "التهليل", phrase: "لا إلٰهَ إلّا الله", target: 100, stages: nil),
    TasbihMode(key: "hawqala", label: "الحوقلة", phrase: "لا حَولَ ولا قُوَّةَ إلّا بِالله", target: 100, stages: nil),
    TasbihMode(key: "free", label: "عدّاد حر", phrase: "", target: 33, stages: nil)
]

private let tasbihGoals = [33, 100, 313, 1000]

/// Keeps the count if the sheet is closed by mistake, for as long as the app stays alive (as Android TasbihSession).
private enum TasbihSession {
    static var modeIdx = 0
    static var count = 0
    static var stage = 0
}

struct TasbihView: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss

    @State private var modeIdx = TasbihSession.modeIdx
    @State private var count = TasbihSession.count
    @State private var stage = TasbihSession.stage
    @State private var confirmReset = false
    @State private var resetToken = 0
    @State private var started = Date()

    // MARK: Derived state

    private var mode: TasbihMode { tasbihModes[max(0, min(tasbihModes.count - 1, modeIdx))] }
    private var stages: [(String, Int)] { mode.stages ?? [] }
    private var staged: Bool { mode.stages != nil }
    private var done: Bool { staged && stage >= stages.count }
    private var target: Int { (staged && !done) ? stages[stage].1 : mode.target }
    private var curLabel: String {
        if staged && done { return "تمّ تسبيح الزهراء (ع)" }
        if staged { return stages[stage].0 }
        return mode.phrase.isEmpty ? mode.label : mode.phrase
    }
    private var frac: Double { target > 0 ? min(1, Double(count) / Double(target)) : 0 }

    private var roundText: String {
        if staged {
            return done ? "تمّت المراحل" : "المرحلة \((stage + 1).ar) من \(stages.count.ar)"
        }
        let per = mode.key == "free" ? 33 : max(1, mode.target)
        return "الدورة \((count / per + 1).ar)"
    }

    // MARK: Body

    var body: some View {
        ZStack {
            Brand.heroGradient.ignoresSafeArea()
            StarPattern().foregroundStyle(.white.opacity(0.06)).ignoresSafeArea()
            VStack(spacing: 0) {
                topPills
                Spacer(minLength: 12)
                dhikrBlock
                Spacer(minLength: 12)
                tapTarget
                Spacer(minLength: 16)
                if confirmReset {
                    Text("اضغط مرّةً أخرى للتصفير")
                        .font(.footnote.weight(.bold))
                        .padding(.horizontal, 16).padding(.vertical, 8)
                        .glassCapsule(tint: Brand.bad)
                        .padding(.bottom, 10)
                        .transition(.opacity)
                }
                bottomToolbar
            }
            .padding(.horizontal, 20)
            .padding(.top, 18)
            .padding(.bottom, 12)
        }
        .foregroundStyle(.white)
        .environment(\.colorScheme, .dark)
        .keepScreenAwake(true)
    }

    // MARK: Top: timer and set/round info

    private var topPills: some View {
        HStack(spacing: 10) {
            TimelineView(.periodic(from: started, by: 1)) { ctx in
                HStack(spacing: 6) {
                    Image(systemName: "timer")
                    Text(tasbihElapsed(ctx.date.timeIntervalSince(started)))
                        .monospacedDigit()
                }
                .font(.subheadline.weight(.bold))
                .padding(.horizontal, 14).padding(.vertical, 8)
                .glassCapsule()
            }
            Spacer()
            Text(roundText)
                .font(.subheadline.weight(.bold))
                .padding(.horizontal, 14).padding(.vertical, 8)
                .glassCapsule()
        }
    }

    // MARK: Dhikr text and counter

    private var dhikrBlock: some View {
        VStack(spacing: 10) {
            Text(mode.label)
                .font(.footnote.weight(.bold))
                .foregroundStyle(.white.opacity(0.7))
            Text(curLabel)
                .font(.scripture(36))
                .multilineTextAlignment(.center)
                .lineLimit(3)
                .minimumScaleFactor(0.6)
                .frame(maxWidth: .infinity)
            Text(count.ar)
                .font(.counter(96))
                .foregroundStyle(Brand.gold)
                .contentTransition(.numericText())
                .animation(.snappy(duration: 0.18), value: count)
                .lineLimit(1)
                .minimumScaleFactor(0.5)
            if !done && mode.key != "free" {
                Text("\(count.ar) / \(target.ar)")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.7))
                    .monospacedDigit()
            }
            goalLine
        }
    }

    @ViewBuilder private var goalLine: some View {
        let today = store.dhikrToday
        let goal = store.dhikrGoal
        if goal > 0 && today >= goal {
            Text("بلغتَ هدفك اليوم — أحسنت 🌿")
                .font(.caption.weight(.bold))
                .foregroundStyle(Brand.mint)
        } else {
            Text("ذِكر اليوم \(today.ar) / \(goal.ar)")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white.opacity(0.6))
        }
    }

    // MARK: Tap target

    private var tapTarget: some View {
        ZStack {
            Circle()
                .stroke(.white.opacity(0.14), lineWidth: 10)
            Circle()
                .trim(from: 0, to: frac)
                .stroke(Brand.gold, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .animation(.easeOut(duration: 0.2), value: frac)
            VStack(spacing: 6) {
                Image(systemName: done ? "checkmark" : "hand.tap.fill")
                    .font(.system(size: 34, weight: .semibold))
                Text("سبِّح").font(.title3.weight(.heavy))
            }
            .frame(width: 176, height: 176)
            .contentShape(Circle())
            .glassCircle(tint: Brand.gold, interactive: true)
            .onTapGesture { tap() }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("عُدّ تسبيحة")
            .accessibilityAddTraits(.isButton)
            .accessibilityAction { tap() }
        }
        .frame(width: 216, height: 216)
    }

    // MARK: Bottom glass toolbar

    private var bottomToolbar: some View {
        HStack(spacing: 6) {
            Button {
                dismiss()
            } label: {
                tasbihToolIcon("xmark")
            }
            .accessibilityLabel("إغلاق")

            Button {
                resetPressed()
            } label: {
                tasbihToolIcon("arrow.counterclockwise")
                    .foregroundStyle(confirmReset ? Brand.bad : Color.white)
            }
            .accessibilityLabel("تصفير")

            Menu {
                Picker("الذكر", selection: Binding(get: { modeIdx }, set: { select($0) })) {
                    ForEach(Array(tasbihModes.enumerated()), id: \.offset) { i, m in
                        Text(m.label).tag(i)
                    }
                }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "list.bullet")
                    Text(mode.label).lineLimit(1)
                }
                .font(.subheadline.weight(.bold))
                .foregroundStyle(Color.white)
                .padding(.horizontal, 10)
                .frame(height: 44)
            }

            Menu {
                Picker("هدف الذِّكر اليومي", selection: Binding(get: { store.dhikrGoal }, set: { store.dhikrGoal = $0 })) {
                    ForEach(tasbihGoals, id: \.self) { g in
                        Text(g.ar).tag(g)
                    }
                }
            } label: {
                HStack(spacing: 4) {
                    Image(systemName: "target")
                    Text(store.dhikrGoal.ar).monospacedDigit()
                }
                .font(.subheadline.weight(.bold))
                .foregroundStyle(store.dhikrToday >= store.dhikrGoal ? Brand.gold : Color.white)
                .padding(.horizontal, 10)
                .frame(height: 44)
            }
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 12).padding(.vertical, 6)
        .glassCapsule()
    }

    private func tasbihToolIcon(_ name: String) -> some View {
        Image(systemName: name)
            .font(.system(size: 18, weight: .bold))
            .frame(width: 44, height: 44)
            .contentShape(Rectangle())
    }

    // MARK: Actions

    private func tap() {
        guard !done else { return }
        count += 1
        store.addDhikr(1)
        confirmReset = false
        if staged, stage < stages.count, count >= stages[stage].1 {
            stage += 1
            count = 0
            Haptic.confirm()
        } else if !staged && mode.key != "free" && count == mode.target {
            Haptic.confirm()
        } else if mode.key == "free" && count % 33 == 0 {
            Haptic.confirm()
        } else {
            Haptic.tick()
        }
        saveSession()
    }

    private func select(_ idx: Int) {
        modeIdx = max(0, min(tasbihModes.count - 1, idx))
        count = 0
        stage = 0
        confirmReset = false
        started = Date()
        saveSession()
    }

    /// Two presses reset: the first warns, a second within three seconds clears (a stray touch never loses the count).
    private func resetPressed() {
        if count == 0 && stage == 0 {
            confirmReset = false
            return
        }
        if !confirmReset {
            withAnimation { confirmReset = true }
            Haptic.tick()
            resetToken += 1
            let token = resetToken
            Task {
                try? await Task.sleep(nanoseconds: 3_000_000_000)
                if token == resetToken { withAnimation { confirmReset = false } }
            }
        } else {
            count = 0
            stage = 0
            started = Date()
            withAnimation { confirmReset = false }
            Haptic.heavy()
            saveSession()
        }
    }

    private func saveSession() {
        TasbihSession.modeIdx = modeIdx
        TasbihSession.count = count
        TasbihSession.stage = stage
    }
}

/// mm:ss (or h:mm:ss) in Arabic digits.
private func tasbihElapsed(_ t: TimeInterval) -> String {
    let s = max(0, Int(t))
    let h = s / 3600, m = (s % 3600) / 60, sec = s % 60
    let core = h > 0 ? String(format: "%d:%02d:%02d", h, m, sec) : String(format: "%02d:%02d", m, sec)
    return core.arabicDigits
}
