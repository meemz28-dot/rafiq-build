import SwiftUI

// MARK: - أسماء الله الحسنى (ported from Android ui/AsmaScreen.kt)
// "Name of the day" hero, then the full gallery in a 3-column grid; tapping a name opens its contemplation card.

private struct AsmaPick: Identifiable { let id: Int }

/// Gem gradients cycling through the gallery (same category families as Android).
private let asmaGradientIds = ["ziyarat", "munajat", "ramadan", "jumaa", "tarbiya", "hawaij", "rajab", "sabah"]

struct AsmaView: View {
    @Environment(Store.self) private var store
    @State private var selected: AsmaPick?

    private let names: [AsmaName] = Library.shared.asma
    // 3 columns on iPhone, more on iPad
    private let columns: [GridItem] = [GridItem(.adaptive(minimum: 104, maximum: 180), spacing: 10)]

    private var todayIndex: Int? { names.isEmpty ? nil : store.dayIndex % names.count }

    var body: some View {
        ScreenScroll {
            if let ti = todayIndex { dailyHero(ti) }
            Text("الأسماءُ التسعةُ والتسعون")
                .font(.subheadline.weight(.bold)).foregroundStyle(.secondary)
                .padding(.top, 6)
            LazyVGrid(columns: columns, spacing: 10) {
                ForEach(Array(names.enumerated()), id: \.offset) { i, n in
                    Button {
                        Haptic.tick()
                        selected = AsmaPick(id: i)
                    } label: {
                        AsmaTile(number: i + 1, name: n.ar, colors: Brand.categoryColors(asmaGradientIds[i % asmaGradientIds.count]))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .navigationTitle("أسماء الله الحُسنى")
        .navigationBarTitleDisplayMode(.large)
        .sheet(item: $selected) { pick in
            AsmaDetailSheet(number: pick.id + 1, name: names.indices.contains(pick.id) ? names[pick.id] : nil)
                .environment(\.colorScheme, .dark)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
                .environment(\.layoutDirection, .rightToLeft)
        }
    }

    private func dailyHero(_ idx: Int) -> some View {
        Button {
            Haptic.tick()
            selected = AsmaPick(id: idx)
        } label: {
            VStack(spacing: 14) {
                Text("اسمُ اليوم").font(.footnote.weight(.bold)).foregroundStyle(.white.opacity(0.82))
                    .padding(.horizontal, 14).padding(.vertical, 6)
                    .glassCapsule()
                Text(names[idx].ar)
                    .font(.scripture(52)).fontWeight(.bold)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.6).lineLimit(1)
                Text(names[idx].sharh)
                    .font(.subheadline).foregroundStyle(.white.opacity(0.9))
                    .multilineTextAlignment(.center)
                Text("انقر للتأمّل ⟡").font(.caption2).foregroundStyle(.white.opacity(0.6))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 30).padding(.horizontal, 24)
            .hero()
        }
        .buttonStyle(.plain)
    }
}

private struct AsmaTile: View {
    let number: Int
    let name: String
    let colors: [Color]

    var body: some View {
        ZStack(alignment: .topLeading) {
            LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
            StarPattern(cell: 40).foregroundStyle(.white.opacity(0.06))
            Text("\(number)")
                .font(.caption2.weight(.bold)).foregroundStyle(.white.opacity(0.55))
                .padding(8)
            Text(name)
                .font(.scripture(22)).fontWeight(.bold)
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
                .minimumScaleFactor(0.6).lineLimit(2)
                .padding(.horizontal, 6)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(height: 104)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .contentShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .accessibilityElement(children: .combine)
    }
}

private struct AsmaDetailSheet: View {
    let number: Int
    let name: AsmaName?
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            Brand.heroGradient.ignoresSafeArea()
            StarPattern().foregroundStyle(.white.opacity(0.07)).ignoresSafeArea()
            VStack(spacing: 22) {
                Text("\(number)")
                    .font(.headline.weight(.heavy))
                    .frame(width: 44, height: 44)
                    .glassCircle()
                if let name {
                    Text(name.ar)
                        .font(.scripture(64)).fontWeight(.bold)
                        .multilineTextAlignment(.center)
                        .minimumScaleFactor(0.5).lineLimit(1)
                    Rectangle().fill(.white.opacity(0.25)).frame(width: 120, height: 1)
                    Text(name.sharh)
                        .font(.body).foregroundStyle(.white.opacity(0.92))
                        .multilineTextAlignment(.center)
                        .lineSpacing(6)
                }
                Button("إغلاق") { dismiss() }
                    .font(.subheadline.weight(.bold))
                    .glassButton()
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 28).padding(.vertical, 32)
        }
        .environment(\.colorScheme, .dark)
    }
}
