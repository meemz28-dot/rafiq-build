import SwiftUI

// MARK: - أسماء الله الحسنى (ported from Android ui/AsmaScreen.kt)
// "Name of the day" hero, then the full gallery in a 3-column grid; tapping a name opens its contemplation card.

private struct AsmaPick: Identifiable { let id: Int }

/// Gem gradients cycling through the gallery (same category families as Android).
private let asmaGradientIds = ["ziyarat", "munajat", "ramadan", "jumaa", "tarbiya", "hawaij", "rajab", "sabah"]

struct AsmaView: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var selected: AsmaPick?
    @State private var query = ""
    @State private var quiz = false
    @FocusState private var searching: Bool

    private let names: [AsmaName] = Library.shared.asma
    // 3 columns on iPhone, more on iPad
    private let columns: [GridItem] = [GridItem(.adaptive(minimum: 104, maximum: 180), spacing: 10)]

    private var todayIndex: Int? { names.isEmpty ? nil : store.dayIndex % names.count }
    private var memorised: Int { store.int("asmaMemorised", 0) }

    private var filtered: [(Int, AsmaName)] {
        let q = ArabicSearch.normalize(query.trimmingCharacters(in: .whitespaces))
        let all = Array(names.enumerated()).map { ($0.offset, $0.element) }
        if q.isEmpty { return all }
        return all.filter { ArabicSearch.normalize($0.1.ar + " " + $0.1.sharh).contains(q) }
    }

    var body: some View {
        ScreenScroll(topPadding: 0) {
            ScreenHeader("أسماء الله الحسنى") {
                RoundIconButton(symbol: "headphones", label: "استمع للأسماء") {
                    AppNav.shared.pendingListen = "أسماء الله الحسنى"
                    AppNav.shared.openTool(.listen)
                }
            }
            if let ti = todayIndex { dailyHero(ti) }
            LibrarySearchField(text: $query, focused: $searching, placeholder: "ابحث في الأسماء أو المعاني")
            LazyVGrid(columns: columns, spacing: 10) {
                ForEach(filtered, id: \.0) { i, n in
                    Button {
                        Haptic.tick()
                        selected = AsmaPick(id: i)
                    } label: {
                        AsmaTile(number: i + 1, name: n.ar, meaning: n.sharh)
                    }
                    .buttonStyle(.plain)
                }
            }
            quizRow
        }
        .toolbar(.hidden, for: .navigationBar)
        .sheet(item: $selected) { pick in
            AsmaDetailSheet(number: pick.id + 1, name: names.indices.contains(pick.id) ? names[pick.id] : nil)
                .environment(\.colorScheme, .dark)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
                .environment(\.layoutDirection, .rightToLeft)
        }
        .sheet(isPresented: $quiz) {
            AsmaQuizSheet(names: names).environment(store).environment(\.layoutDirection, .rightToLeft)
                .presentationDetents([.large])
        }
    }

    private func dailyHero(_ idx: Int) -> some View {
        Button {
            Haptic.tick()
            selected = AsmaPick(id: idx)
        } label: {
            ZStack(alignment: .topLeading) {
                Brand.heroGradient
                StarShape().stroke(Brand.goldSoft.opacity(0.35), lineWidth: 1.5).frame(width: 120, height: 120)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing).padding(14)
                StarShape().stroke(Brand.goldSoft.opacity(0.25), lineWidth: 1.5).frame(width: 60, height: 60)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading).padding(14)
                VStack(alignment: .leading, spacing: 6) {
                    Text(verbatim: "اسم اليوم · \((idx + 1).ar) من \(names.count.ar)").font(.ui(.caption, .semibold)).foregroundStyle(Brand.goldSoft)
                    Text(names[idx].ar)
                        .font(.scripture(46)).fontWeight(.bold).foregroundStyle(.white)
                        .minimumScaleFactor(0.6).lineLimit(1)
                        .frame(maxWidth: .infinity)
                    Text(names[idx].sharh)
                        .font(.ui(.footnote)).foregroundStyle(.white.opacity(0.9))
                        .multilineTextAlignment(.center).frame(maxWidth: .infinity)
                }
                .padding(20)
            }
            .frame(height: 180)
            .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private var quizRow: some View {
        HStack {
            Button { quiz = true } label: {
                Text("اختبر حفظك").font(.ui(.subheadline, .bold)).foregroundStyle(.white)
                    .padding(.horizontal, 20).frame(height: 46)
                    .background(Brand.deeper, in: Capsule())
            }
            .buttonStyle(.plain)
            Spacer()
            Text(verbatim: "\(memorised.ar) من \(names.count.ar) · حفظتَها").font(.ui(.caption)).foregroundStyle(Brand.muted)
        }
        .card(22, padding: 12)
    }
}

private struct AsmaTile: View {
    let number: Int
    let name: String
    let meaning: String

    var body: some View {
        VStack(spacing: 6) {
            Text(name)
                .font(.scripture(24)).fontWeight(.bold)
                .foregroundStyle(Brand.deeper)
                .multilineTextAlignment(.center)
                .minimumScaleFactor(0.6).lineLimit(1)
            Text(meaning)
                .font(.ui(.caption2)).foregroundStyle(Brand.muted)
                .multilineTextAlignment(.center)
                .lineLimit(2).minimumScaleFactor(0.8)
        }
        .padding(.horizontal, 8).padding(.vertical, 14)
        .frame(maxWidth: .infinity)
        .frame(height: 110)
        .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .contentShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(number.ar) \(name)")
    }
}

/// Memorisation quiz: the meaning is shown, pick the name (four choices).
private struct AsmaQuizSheet: View {
    let names: [AsmaName]
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var target = 0
    @State private var options: [Int] = []
    @State private var picked: Int?
    @State private var correct = 0
    @State private var asked = 0

    var body: some View {
        VStack(spacing: 18) {
            HStack {
                Text("اختبر حفظك").font(.display(22)).foregroundStyle(Brand.ink)
                Spacer()
                Button("إغلاق") { dismiss() }.font(.ui(.subheadline, .bold)).foregroundStyle(Brand.accent)
            }
            if names.indices.contains(target) {
                Text("ما الاسم الذي معناه:").font(.ui(.caption)).foregroundStyle(Brand.muted)
                Text(names[target].sharh).font(.ui(.title3, .bold)).foregroundStyle(Brand.ink).multilineTextAlignment(.center)
                    .padding(18).frame(maxWidth: .infinity).background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                ForEach(options, id: \.self) { o in
                    Button {
                        guard picked == nil else { return }
                        picked = o
                        asked += 1
                        if o == target { correct += 1; Haptic.confirm(); store.put("asmaMemorised", max(store.int("asmaMemorised", 0), correct)) } else { Haptic.tick() }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) { next() }
                    } label: {
                        Text(names[o].ar).font(.scripture(26)).fontWeight(.bold)
                            .foregroundStyle(picked == nil ? Brand.deeper : (o == target ? Color.white : (o == picked ? Color.white : Brand.deeper)))
                            .frame(maxWidth: .infinity).frame(height: 60)
                            .background(picked == nil ? Brand.cardFill : (o == target ? Brand.good : (o == picked ? Brand.bad : Brand.cardFill)), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
                Text(verbatim: "\(correct.ar) صحيحة من \(asked.ar)").font(.ui(.caption)).foregroundStyle(Brand.muted)
            }
            Spacer()
        }
        .padding(20)
        .background(Brand.canvas)
        .onAppear { next() }
    }

    private func next() {
        guard names.count >= 4 else { return }
        picked = nil
        target = Int.random(in: 0..<names.count)
        var set: Set<Int> = [target]
        while set.count < 4 { set.insert(Int.random(in: 0..<names.count)) }
        options = Array(set).shuffled()
    }
}

private struct AsmaDetailSheet: View {
    let number: Int
    let name: AsmaName?
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            Brand.heroGradient.ignoresSafeArea()
            StarPattern().foregroundStyle(.white.opacity(0.07)).ignoresSafeArea()
            VStack(spacing: 22) {
                Text(number.ar)
                    .font(.ui(.headline, .heavy))
                    .frame(width: 44, height: 44)
                    .glassCircle()
                if let name {
                    Text(name.ar)
                        .font(.scripture(64)).fontWeight(.bold)
                        .multilineTextAlignment(.center)
                        .minimumScaleFactor(0.5).lineLimit(1)
                    Rectangle().fill(.white.opacity(0.25)).frame(width: 120, height: 1)
                    Text(name.sharh)
                        .font(.ui(.body)).foregroundStyle(.white.opacity(0.92))
                        .multilineTextAlignment(.center)
                        .lineSpacing(6)
                }
                Button("إغلاق") { dismiss() }
                    .font(.ui(.subheadline, .bold))
                    .glassButton()
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 28).padding(.vertical, 32)
        }
        .environment(\.colorScheme, .dark)
    }
}
