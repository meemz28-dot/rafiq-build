import SwiftUI
import UserNotifications

// MARK: - حاسبة الخُمس (ported from Android ui/KhumsScreen.kt + notify/KhumsScheduler.kt)
// Native Form. Fields persist under the Android keys `khf_<id>`, marja `khMarja`, currency `khCur`,
// khums year `khDateSet` / `khHMonth` / `khHDay`.

private let khumsFieldIds = ["cash", "goods", "trade", "metals", "receivables", "other", "khumsed", "loans", "debts", "mixed"]

/// Arabic counted noun, as Android `arabicCount`.
private func khumsCount(_ n: Int, one: String, two: String, plural: String, many: String) -> String {
    if n == 1 { return one }
    if n == 2 { return two }
    if (3...10).contains(n % 100) { return "\(n) \(plural)" }
    return "\(n) \(many)"
}

/// Parses user input with Arabic or Western digits and thousands separators.
private func khumsParse(_ s: String) -> Double {
    let t = s.westernDigits
        .replacingOccurrences(of: "٫", with: ".")
        .replacingOccurrences(of: "٬", with: "")
        .replacingOccurrences(of: ",", with: "")
        .trimmingCharacters(in: .whitespacesAndNewlines)
    return Double(t) ?? 0
}

/// Yearly khums reminders: one week before and on the day, at 09:00 (ported from KhumsScheduler).
enum KhumsReminder {
    static let ids = ["khums-day", "khums-week"]

    static func at9(_ days: Int) -> Date {
        let cal = Calendar.current
        let base = cal.date(byAdding: .day, value: days, to: Date()) ?? Date()
        return cal.date(bySettingHour: 9, minute: 0, second: 0, of: base) ?? base
    }

    static func add(_ id: String, _ when: Date, _ title: String, _ body: String) {
        let c = UNMutableNotificationContent()
        c.title = title; c.body = body; c.sound = .default
        let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: when)
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: id, content: c,
                                                                     trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
    }

    static func reschedule(_ store: Store) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ids)
        guard store.bool("khDateSet", false) else { return }
        let adj = store.hijriAdj
        let m = store.int("khHMonth", 1), d = store.int("khHDay", 1)
        var days = Khums.daysUntilKhumsDay(m: m, d: d, adj: adj)
        if at9(days) <= Date() { days = Khums.daysUntilKhumsDay(m: m, d: d, adj: adj, from: 1) }
        add("khums-day", at9(days), "موعد سنتك الخمسية", "حان وقت حساب خمس أرباحك. افتح الحاسبة لتطمئنّ ذمّتك.")
        if days >= 7 {
            let w = at9(days - 7)
            if w > Date() {
                add("khums-week", w, "رأس سنتك الخمسية بعد أسبوع", "هيّئ حساباتك: النقد والبضائع وما فضل عن مؤونتك.")
            }
        }
    }
}

struct KhumsView: View {
    @Environment(Store.self) private var store
    @State private var mixedSeparate = true
    @State private var showRulings = false
    @State private var showDatePicker = false
    @FocusState private var focused: Bool

    private var cur: String { store.string("khCur", "د.إ") }
    private var marja: Khums.Marja { Khums.marja(store.string("khMarja", "shirazi")) }

    private func binding(_ id: String) -> Binding<String> {
        Binding(get: { store.string("khf_\(id)") }, set: { store.put("khf_\(id)", $0) })
    }
    private func value(_ id: String) -> Double { khumsParse(store.string("khf_\(id)")) }
    private func money(_ v: Double) -> String { "\(Khums.money(v)) \(cur)" }

    private var result: Khums.Result {
        var i = Khums.Inputs()
        i.cash = value("cash"); i.goods = value("goods"); i.trade = value("trade"); i.metals = value("metals")
        i.receivables = value("receivables"); i.other = value("other")
        i.khumsed = value("khumsed"); i.loans = value("loans"); i.debts = value("debts")
        i.mixed = value("mixed"); i.mixedSeparate = mixedSeparate
        return Khums.calc(i, marja)
    }

    var body: some View {
        Form {
            Section {
                Text("بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيمِ")
                    .font(.scripture(18)).foregroundStyle(Brand.emerald)
                    .frame(maxWidth: .infinity)
                    .listRowBackground(Color.clear)
                MarjaNote()
                    .listRowBackground(Color.clear)
            }
            Group {
                yearSection
                marjaSection
                currencySection
            }
            Group {
                assetsSection
                exemptSection
                mixedSection
            }
            resultSection
            actionsSection
            if showRulings { rulingsSection }
            Section {
                Text("حاسبة استرشادية مبنية على فتاوى \(marja.name). في موارد الشكّ والحالات الخاصّة والمصالحة يُرجع إلى المرجع أو وكيله المجاز.")
                    .font(.ui(.footnote)).foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity)
            }
        }
        .scrollDismissesKeyboard(.interactively)
        .onAppear {
            // Keeps the yearly reminders rolling (iOS has no boot receiver to re-arm them).
            if store.bool("khDateSet", false) { KhumsReminder.reschedule(store) }
        }
        .navigationTitle("حاسبة الخُمس")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("تم") { focused = false }
            }
        }
    }

    // MARK: Khums year

    private var yearSection: some View {
        Section {
            HStack(spacing: 12) {
                Image(systemName: "moon.fill")
                    .font(.system(size: 19, weight: .semibold)).foregroundStyle(Brand.gold)
                    .frame(width: 42, height: 42)
                    .background(Brand.gold.opacity(0.14), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text("سنتك الخمسية").font(.ui(.body, .heavy))
                    yearStatus
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                Button(store.bool("khDateSet", false) ? "تغيير" : "تحديد") {
                    withAnimation { showDatePicker.toggle() }
                }
                .font(.ui(.subheadline, .bold))
                .buttonStyle(.borderless)
            }
            if showDatePicker { monthPicker }
        }
    }

    @ViewBuilder private var yearStatus: some View {
        if store.bool("khDateSet", false) {
            let m = store.int("khHMonth", 1), d = store.int("khHDay", 1)
            let days = Khums.daysUntilKhumsDay(m: m, d: d, adj: store.hijriAdj)
            let monthName = Hijri.months.indices.contains(m - 1) ? Hijri.months[m - 1] : ""
            let text = days == 0
                ? "اليوم موعد خمسك — حاسب أموالك"
                : "بعد \(khumsCount(days, one: "يومٍ واحد", two: "يومين", plural: "أيّام", many: "يوماً")) (\(d) \(monthName))، ونذكّرك قبله بأسبوعٍ ويومَه"
            Text(text)
                .font(days <= 7 ? Font.ui(.caption, .bold) : Font.ui(.caption))
                .foregroundStyle(days <= 7 ? Brand.gold : Color.secondary)
        } else {
            Text("حدّد يوماً ثابتاً سنوياً لحساب خمس أرباحك").font(.ui(.caption)).foregroundStyle(.secondary)
        }
    }

    private var monthPicker: some View {
        let today = store.hijriToday()
        let setOn = store.bool("khDateSet", false)
        let selMonth = store.int("khHMonth", 1)
        return VStack(alignment: .leading, spacing: 8) {
            Text("اختر الشهر الهجريّ:").font(.ui(.caption, .bold)).foregroundStyle(.secondary)
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 6), count: 4), spacing: 6) {
                ForEach(Array(Hijri.months.enumerated()), id: \.offset) { i, name in
                    let on = setOn && selMonth == i + 1
                    Button {
                        saveDate(month: i + 1, day: min(29, max(1, today.d)))
                    } label: {
                        Text(name)
                            .font(.ui(.caption2, .bold)).lineLimit(1).minimumScaleFactor(0.7)
                            .foregroundStyle(on ? Color.white : Color.primary)
                            .frame(maxWidth: .infinity).padding(.vertical, 9)
                            .background(on ? Brand.emerald : Color(.tertiarySystemFill),
                                        in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                    .buttonStyle(.borderless)
                }
            }
            Text("يُضبط اليوم على \(today.d) تلقائياً (يمكنك تغيير الشهر). الخمس يجب على فاضل مؤونة السنة.")
                .font(.ui(.caption2)).foregroundStyle(.secondary)
            if setOn {
                Button("إلغاء التذكير", role: .destructive) {
                    store.put("khDateSet", false)
                    KhumsReminder.reschedule(store)
                    withAnimation { showDatePicker = false }
                }
                .font(.ui(.caption, .bold))
                .buttonStyle(.borderless)
            }
        }
        .padding(.vertical, 4)
    }

    private func saveDate(month: Int, day: Int) {
        Haptic.tick()
        store.put("khHMonth", month)
        store.put("khHDay", day)
        store.put("khDateSet", true)
        let s = store
        Task {
            _ = await Notifier.requestPermission()
            await MainActor.run { KhumsReminder.reschedule(s) }
        }
    }

    // MARK: Marja and currency

    private var marjaSection: some View {
        Section {
            Picker("مرجع التقليد", selection: Binding(get: { marja.key }, set: { store.put("khMarja", $0) })) {
                ForEach(Khums.maraji) { m in
                    Text(m.name).tag(m.key)
                }
            }
            .pickerStyle(.inline)
            .labelsHidden()
            Text(marja.note).font(.ui(.footnote)).foregroundStyle(.secondary)
                .listRowBackground(Brand.emerald.opacity(0.07))
        } header: {
            Text("مرجع التقليد")
        }
    }

    private var currencySection: some View {
        Section {
            Picker("العملة", selection: Binding(get: { cur }, set: { store.put("khCur", $0) })) {
                ForEach(Array(Khums.currencies.enumerated()), id: \.offset) { _, c in
                    Text(verbatim: "\(c.1) (\(c.0))").tag(c.0)
                }
            }
            .pickerStyle(.menu)
        }
    }

    // MARK: Fields

    private func field(_ id: String, _ label: String, _ hint: String) -> some View {
        KhumsFieldRow(label: label, hint: hint, text: binding(id), currency: cur, amount: value(id), focus: $focused)
    }

    private var assetsSection: some View {
        Section {
            field("cash", "النقد", "ما لديك من نقد في اليد وأرصدة الحسابات البنكية والمحافظ الإلكترونية.")
            field("goods", "المؤن والأغراض العينية غير المستعملة", "ما اشتُري من الأرباح ولم يُستهلك حتى رأس السنة، بقيمته الفعلية.")
            field("trade", "البضائع ورأس المال التجاري غير المخمّس", "بضاعة المتجر وأدوات الكسب ورأس المال بالقيمة الحالية، إن لم تُخمَّس.")
            field("metals", "الذهب والفضة والمجوهرات الزائدة عن المؤونة", "ما زاد عن حدّ الاستعمال المتعارف. وحُليّ المرأة المستعمَل اللائق بشأنها من المؤونة ولا خمس فيه.")
            if marja.receivablesCounted {
                field("receivables", "الديون المستحقّة لك", "ما لك في ذمم الآخرين من ديونٍ حالّة يمكن تحصيلها. (غير القابل للتحصيل يُخمَّس عند قبضه.)")
            } else {
                Text("الديون المستحقّة لك لا تُحتسب على رأي هذا المرجع، وتُخمَّس عند قبضها.")
                    .font(.ui(.footnote)).foregroundStyle(.secondary)
            }
            field("other", "أرباح وفوائد أخرى", "الهدايا والجوائز الفائضة عن المؤونة، أسهم واستثمارات غير مخمّسة بقيمتها الفعلية.")
        } header: {
            KhumsSectionHeader(title: "الموجودات عند رأس السنة الخمسية",
                               sub: "كلّ ما فضل عن مؤونة سنتك من الأرباح والفوائد، بقيمته الفعلية يوم حلول رأس السنة.")
        }
    }

    private var exemptSection: some View {
        Section {
            field("khumsed", "الأموال المخمّسة سابقاً", "المال المخمَّس لا يُخمَّس مرّة أخرى. أدخل ما بقي عندك ممّا سبق إخراج خمسه.")
            field("loans", "المال المقترَض الموجود بعينه", "القرض الذي لم تسدّده وعينُ ماله ما تزال ضمن موجوداتك، مقابَلٌ بالدين ولا خمس فيه عليك.")
            field("debts", "ديون المؤونة الحالّة", "الديون التي حلّ وقت سدادها وكانت لمؤونة هذه السنة. ديون السنوات السابقة أو غير الحالّة لا تُحسم، وفي موارد الشكّ يُرجع إلى وكيل المرجع.")
        } header: {
            KhumsSectionHeader(title: "المستثنيات (تُحسم من المجموع)", sub: "ما لا يتعلّق به الخمس فيُطرح قبل الحساب.")
        }
    }

    private var mixedSection: some View {
        Section {
            field("mixed", "مقدار المال المختلط", "يُخرَج خمسه لتطهيره. يُحسب مستقلّاً عند تفعيل الخيار أدناه.")
            Toggle("احسب خمس المال المختلط مستقلّاً (لتطهيره)", isOn: $mixedSeparate)
                .font(.ui(.subheadline))
                .tint(Brand.emerald)
        } header: {
            KhumsSectionHeader(title: "المال المختلط بالحرام",
                               sub: "إن كان فيك مالٌ اختلط حلاله بحرامه ولا تعرف مقداره ولا صاحبه، ففيه الخمس لتطهيره.")
        }
    }

    // MARK: Result

    private var resultSection: some View {
        let r = result
        return Section {
            KhumsResultCard(base: money(r.base), khums: money(r.khums), imam: money(r.imam), sada: money(r.sada), keep: money(r.keep))
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets())
        }
    }

    private var actionsSection: some View {
        Section {
            Button {
                withAnimation { showRulings.toggle() }
            } label: {
                Label(showRulings ? "إخفاء الأحكام والفتاوى" : "الأحكام والفتاوى", systemImage: "book.closed")
            }
            Button(role: .destructive) {
                Haptic.tick()
                for id in khumsFieldIds { store.put("khf_\(id)", nil) }
            } label: {
                Label("تصفير", systemImage: "arrow.counterclockwise")
            }
        }
    }

    private var rulingsSection: some View {
        Section {
            ForEach(Array(marja.rulings.enumerated()), id: \.offset) { _, r in
                VStack(alignment: .leading, spacing: 6) {
                    Text(r.first ?? "").font(.ui(.subheadline, .heavy)).foregroundStyle(Brand.emerald)
                    Text(r.count > 1 ? r[1] : "").font(.ui(.subheadline)).lineSpacing(4)
                }
                .padding(.vertical, 4)
            }
        } header: {
            Text("الأحكام والفتاوى")
        }
    }
}

private struct KhumsSectionHeader: View {
    let title: String
    let sub: String
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 8) {
                Capsule().fill(Brand.emerald).frame(width: 3, height: 16)
                Text(title).font(.ui(.subheadline, .heavy)).foregroundStyle(.primary)
            }
            Text(sub).font(.ui(.caption)).foregroundStyle(.secondary)
        }
        .textCase(nil)
        .padding(.bottom, 2)
    }
}

private struct KhumsFieldRow: View {
    let label: String
    let hint: String
    @Binding var text: String
    let currency: String
    let amount: Double
    var focus: FocusState<Bool>.Binding

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label).font(.ui(.subheadline, .bold))
            Text(hint).font(.ui(.caption2)).foregroundStyle(.secondary)
            HStack(spacing: 8) {
                TextField("٠", text: $text)
                    .keyboardType(.decimalPad)
                    .font(.ui(.title3, .bold))
                    .focused(focus)
                Text(currency).font(.ui(.caption, .bold)).foregroundStyle(.secondary)
            }
            .padding(.horizontal, 12).padding(.vertical, 8)
            .background(Color(.tertiarySystemFill), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            if amount > 0 {
                Text(verbatim: "\(Khums.money(amount)) \(currency)")
                    .font(.ui(.caption, .semibold)).foregroundStyle(Brand.emerald)
                    .monospacedDigit()
            }
        }
        .padding(.vertical, 4)
    }
}

private struct KhumsResultCard: View {
    let base: String
    let khums: String
    let imam: String
    let sada: String
    let keep: String

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text("الوعاء الخاضع للخمس").font(.ui(.caption, .bold)).foregroundStyle(.white.opacity(0.8))
                Text(base).font(.ui(.title3, .bold))
            }
            VStack(spacing: 4) {
                Text("مقدار الخمس الواجب").font(.ui(.footnote, .bold)).foregroundStyle(.white.opacity(0.9))
                Text(khums).font(.counter(30)).foregroundStyle(Brand.gold)
                    .minimumScaleFactor(0.5).lineLimit(1)
            }
            .frame(maxWidth: .infinity)
            .padding(16)
            .glass(18)
            HStack(spacing: 10) {
                mini("سهم الإمام (عج)", imam)
                mini("سهم السادة", sada)
            }
            Text("يبقى لك بعد الخمس: \(keep)").font(.ui(.caption)).foregroundStyle(.white.opacity(0.85))
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .hero(24)
        .environment(\.colorScheme, .dark)
    }

    private func mini(_ label: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(label).font(.ui(.caption2, .bold)).foregroundStyle(.white.opacity(0.8))
            Text(value).font(.ui(.subheadline, .heavy)).minimumScaleFactor(0.6).lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
