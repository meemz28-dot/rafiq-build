import SwiftUI

// MARK: - المعصومون الأربعة عشر (ported from Android ui/MasoomeenScreen.kt)
// A list of the Fourteen Infallibles; each opens a biography page with a link to his or her ziyara.

private let masoomGradientIds = ["ziyarat", "jumaa", "munajat", "rajab", "hawaij", "tarbiya", "ramadan", "sabah"]

/// Links each Masoom (same fixed order as the data) to a ziyara in the "ziyarat" category.
/// The four Imams of al-Baqi (al-Hasan, al-Sajjad, al-Baqir, al-Sadiq) share the Baqi ziyara.
private func masoomZiyara(_ index: Int) -> String {
    switch index {
    case 0: return "z-nabi"
    case 1: return "z-new4880"
    case 2: return "z-ali-najaf"
    case 3: return "z-baqi"
    case 4: return "z-warith"
    case 5: return "z-baqi"
    case 6: return "z-baqi"
    case 7: return "z-baqi"
    case 8: return "z-kadhim"
    case 9: return "z-redha"
    case 10: return "z-jawad"
    case 11: return "z-hadi"
    case 12: return "z-askari"
    case 13: return "z-yasin"
    default: return "z-jamia"
    }
}

struct MasoomeenView: View {
    @Environment(AppNav.self) private var nav
    @Environment(Store.self) private var store
    @State private var selected: Int?

    private let all: [Masoom] = Library.shared.masoomeen

    /// Today's or the next occasion in the Hijri calendar, with the Masoom it most likely belongs to.
    private var nextOccasion: (title: String, days: Int, masoom: Int?)? {
        guard let n = MoreView.nextOccasion(from: store.hijriToday(), adj: store.hijriAdj) else { return nil }
        let idx = all.firstIndex { m in
            let key = m.name.split(separator: " ").first.map(String.init) ?? ""
            return !key.isEmpty && n.title.contains(key)
        }
        return (n.title, n.days, idx)
    }

    var body: some View {
        ScreenScroll(topPadding: 0) {
            ScreenHeader("المعصومون الأربعة عشر (ع)")
            if let o = nextOccasion { occasionCard(o) }
            ForEach(Array(all.enumerated()), id: \.offset) { i, m in
                Button {
                    Haptic.tick()
                    nav.open(.masoom(i))
                } label: {
                    MasoomRow(number: i + 1, masoom: m, highlighted: nextOccasion?.masoom == i)
                }
                .buttonStyle(.plain)
            }
            Text(verbatim: "\(all.count.ar) معصوماً · لكلّ معصوم: السيرة، الزيارة، المناسبات")
                .font(.ui(.caption)).foregroundStyle(Brand.muted).frame(maxWidth: .infinity).padding(.top, 6)
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    private func occasionCard(_ o: (title: String, days: Int, masoom: Int?)) -> some View {
        Button { nav.openTool(.calendar) } label: {
            ZStack(alignment: .bottomTrailing) {
                Brand.purpleGradient
                MosqueSilhouette().fill(Color.white.opacity(0.08)).frame(width: 180, height: 90)
                VStack(alignment: .leading, spacing: 4) {
                    Text(verbatim: o.days == 0 ? "مناسبة اليوم" : "المناسبة القادمة · بعد \(o.days.ar) \(o.days == 1 ? "يوم" : (o.days <= 10 ? "أيام" : "يوماً"))")
                        .font(.ui(.caption, .semibold)).foregroundStyle(Brand.goldSoft)
                    Text(o.title).font(.display(22)).foregroundStyle(.white).lineLimit(2).minimumScaleFactor(0.7)
                    if let i = o.masoom, all.indices.contains(i) {
                        Text(all[i].shrine).font(.ui(.caption)).foregroundStyle(.white.opacity(0.8)).lineLimit(1)
                    }
                }
                .padding(18)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(height: 140)
            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}

private struct MasoomRow: View {
    let number: Int
    let masoom: Masoom
    let highlighted: Bool

    var body: some View {
        HStack(spacing: 14) {
            Text(number.ar)
                .font(.display(16)).foregroundStyle(highlighted ? Color.white : Brand.deeper)
                .frame(width: 44, height: 44)
                .background(highlighted ? Brand.gold : Brand.soft, in: Circle())
                .overlay(Circle().stroke(highlighted ? Brand.goldDeep : Brand.deeper.opacity(0.25), lineWidth: 1.5))
            VStack(alignment: .leading, spacing: 3) {
                Text(masoom.title).font(.ui(.subheadline, .bold)).foregroundStyle(Brand.ink).lineLimit(1).minimumScaleFactor(0.8)
                Text(verbatim: "\(masoom.birth) · \(masoom.passing) · \(masoom.shrine)").font(.ui(.caption2)).foregroundStyle(Brand.muted).lineLimit(1).minimumScaleFactor(0.8)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            Image(systemName: "chevron.backward").font(.caption.weight(.bold)).foregroundStyle(Brand.muted)
        }
        .padding(.horizontal, 14).padding(.vertical, 12)
        .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(highlighted ? Brand.gold : Color.clear, lineWidth: 1.5))
        .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .accessibilityElement(children: .combine)
    }
}

private struct MasoomDetailView: View {
    let number: Int
    let masoom: Masoom
    let ziyaraId: String
    @Environment(AppNav.self) private var nav
    @Environment(\.dismiss) private var dismiss

    /// The four Imams of al-Baqi (indices 3, 5, 6, 7) are visited together.
    private var isBaqi: Bool { [3, 5, 6, 7].contains(number - 1) }

    var body: some View {
        ScreenScroll {
            header
            facts
            ziyaraButton
            SectionTitle(text: "العصر والمعاصرون")
            Text(masoom.era).font(.ui(.body)).lineSpacing(6).card(18)
            SectionTitle(text: "من معالم سيرته")
            highlights
            note
            Button {
                dismiss()
            } label: {
                Text("العودة إلى القائمة").font(.ui(.body, .bold)).frame(maxWidth: .infinity)
            }
                .glassButton()
                .controlSize(.large)
                .padding(.top, 4)
        }
        .navigationTitle(masoom.title)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var header: some View {
        VStack(spacing: 12) {
            Text(number.ar)
                .font(.ui(.headline, .heavy))
                .frame(width: 46, height: 46)
                .glassCircle()
            Text(masoom.title)
                .font(.scripture(36)).fontWeight(.bold)
                .multilineTextAlignment(.center)
            Text(masoom.name).font(.ui(.subheadline, .medium)).foregroundStyle(.white.opacity(0.9))
                .multilineTextAlignment(.center)
            Text(masoom.rank).font(.ui(.caption)).foregroundStyle(.white.opacity(0.82))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 30).padding(.horizontal, 24)
        .hero()
    }

    private var facts: some View {
        VStack(alignment: .leading, spacing: 0) {
            MasoomFact(label: "الكنية", value: masoom.kunya)
            Divider()
            MasoomFact(label: "المولد", value: masoom.birth)
            Divider()
            MasoomFact(label: "الشهادة / الوفاة", value: masoom.passing)
            Divider()
            MasoomFact(label: "المرقد الشريف", value: masoom.shrine)
        }
        .card(20, padding: 18)
    }

    private var ziyaraButton: some View {
        Button {
            nav.openReader("ziyarat", ziyaraId)
        } label: {
            HStack(spacing: 14) {
                Image(systemName: "book.fill")
                    .font(.system(size: 18, weight: .semibold))
                    .frame(width: 40, height: 40)
                    .background(.white.opacity(0.18), in: Circle())
                VStack(alignment: .leading, spacing: 2) {
                    Text(isBaqi ? "اقرأ زيارة أئمّة البقيع" : "اقرأ زيارته الشريفة").font(.ui(.body, .bold))
                    Text(isBaqi ? "يُزارون جماعةً في البقيع" : "تفتحُ في قسم الزيارات")
                        .font(.ui(.caption2)).foregroundStyle(.white.opacity(0.8))
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                Image(systemName: "chevron.forward").foregroundStyle(.white.opacity(0.7))
            }
            .foregroundStyle(.white)
            .padding(.vertical, 16).padding(.horizontal, 18)
            .background(
                LinearGradient(colors: Brand.categoryColors("ziyarat"), startPoint: .topLeading, endPoint: .bottomTrailing),
                in: RoundedRectangle(cornerRadius: 18, style: .continuous)
            )
        }
        .buttonStyle(.plain)
    }

    private var highlights: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(masoom.highlights.enumerated()), id: \.offset) { i, h in
                HStack(alignment: .top, spacing: 12) {
                    Circle().fill(Brand.gold).frame(width: 7, height: 7).padding(.top, 8)
                    Text(h).font(.ui(.body)).lineSpacing(5).frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.vertical, 10)
                if i < masoom.highlights.count - 1 { Divider() }
            }
        }
        .card(18, padding: 16)
    }

    private var note: some View {
        HStack(alignment: .top, spacing: 14) {
            Capsule().fill(Brand.emerald).frame(width: 3, height: 40)
            Text(masoom.note).font(.ui(.body, .medium)).lineSpacing(5)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(18)
        .background(Brand.emerald.opacity(0.1), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

private struct MasoomFact: View {
    let label: String
    let value: String
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(label).font(.ui(.caption2, .bold)).foregroundStyle(.secondary)
            Text(value).font(.ui(.subheadline, .medium))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 8)
    }
}

/// Routed detail page (pushed on the tab's path so opening the ziyara keeps the stack intact).
struct MasoomeenDetailScreen: View {
    let index: Int
    var body: some View {
        let all = Library.shared.masoomeen
        if all.indices.contains(index) {
            MasoomDetailView(number: index + 1, masoom: all[index], ziyaraId: masoomZiyara(index))
        } else {
            EmptyStateView(symbol: "questionmark", title: "غير متوفّر", message: "")
        }
    }
}
