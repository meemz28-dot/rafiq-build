import SwiftUI

// MARK: - المعصومون الأربعة عشر (ported from Android ui/MasoomeenScreen.kt)
// A list of the Fourteen Infallibles; each opens a biography page with a link to his or her ziyara.

private let masoomGradientIds = ["ziyarat", "jumaa", "munajat", "rajab", "hawaij", "tarbiya", "ramadan", "sabah"]

/// Links each Masoom (same fixed order as the data) to a ziyara in the "ziyarat" category.
/// The four Imams of al-Baqi (al-Hasan, al-Sajjad, al-Baqir, al-Sadiq) share the Baqi ziyara.
private func masoomZiyara(_ index: Int) -> String {
    switch index {
    case 0: return "z-nabi"
    case 1: return "z-new4880"
    case 2: return "z-ali-najaf"
    case 3: return "z-baqi"
    case 4: return "z-warith"
    case 5: return "z-baqi"
    case 6: return "z-baqi"
    case 7: return "z-baqi"
    case 8: return "z-kadhim"
    case 9: return "z-redha"
    case 10: return "z-jawad"
    case 11: return "z-hadi"
    case 12: return "z-askari"
    case 13: return "z-yasin"
    default: return "z-jamia"
    }
}

struct MasoomeenView: View {
    @Environment(AppNav.self) private var nav
    @State private var selected: Int?

    private let all: [Masoom] = Library.shared.masoomeen

    var body: some View {
        ScreenScroll {
            salawatHero
            Text("أهلُ الكساء وأئمّةُ الهدى")
                .font(.subheadline.weight(.bold)).foregroundStyle(.secondary)
                .padding(.top, 8)
            ForEach(Array(all.enumerated()), id: \.offset) { i, m in
                Button {
                    Haptic.tick()
                    nav.open(.masoom(i))
                } label: {
                    MasoomCard(number: i + 1, masoom: m, colors: Brand.categoryColors(masoomGradientIds[i % masoomGradientIds.count]))
                }
                .buttonStyle(.plain)
            }
        }
        .navigationTitle("المعصومون الأربعة عشر")
        .navigationBarTitleDisplayMode(.large)
    }

    private var salawatHero: some View {
        VStack(spacing: 14) {
            Text("أهل بيت النبوّة ومعدن الرسالة")
                .font(.footnote.weight(.bold)).foregroundStyle(.white.opacity(0.82))
            Text("اللّٰهُمَّ صَلِّ عَلىٰ مُحَمَّدٍ وَآلِ مُحَمَّد")
                .font(.scripture(26)).fontWeight(.bold)
                .multilineTextAlignment(.center)
                .lineSpacing(8)
            Text("الذين أذهب الله عنهم الرجس وطهّرهم تطهيراً")
                .font(.footnote).foregroundStyle(.white.opacity(0.85))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 30).padding(.horizontal, 24)
        .hero()
    }
}

private struct MasoomCard: View {
    let number: Int
    let masoom: Masoom
    let colors: [Color]

    var body: some View {
        HStack(spacing: 16) {
            Text(verbatim: "\(number)")
                .font(.subheadline.weight(.heavy))
                .frame(width: 40, height: 40)
                .background(.white.opacity(0.18), in: Circle())
            VStack(alignment: .leading, spacing: 3) {
                Text(masoom.title).font(.scripture(22)).fontWeight(.bold)
                Text(masoom.name).font(.caption.weight(.medium)).foregroundStyle(.white.opacity(0.85))
                Text(masoom.shrine).font(.caption2).foregroundStyle(.white.opacity(0.7))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            Image(systemName: "chevron.forward").font(.footnote.weight(.semibold)).foregroundStyle(.white.opacity(0.6))
        }
        .foregroundStyle(.white)
        .padding(18)
        .background(
            ZStack {
                LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
                StarPattern(cell: 44).foregroundStyle(.white.opacity(0.06))
            }
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        )
        .contentShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

private struct MasoomDetailView: View {
    let number: Int
    let masoom: Masoom
    let ziyaraId: String
    @Environment(AppNav.self) private var nav
    @Environment(\.dismiss) private var dismiss

    /// The four Imams of al-Baqi (indices 3, 5, 6, 7) are visited together.
    private var isBaqi: Bool { [3, 5, 6, 7].contains(number - 1) }

    var body: some View {
        ScreenScroll {
            header
            facts
            ziyaraButton
            SectionTitle(text: "العصر والمعاصرون")
            Text(masoom.era).font(.body).lineSpacing(6).card(18)
            SectionTitle(text: "من معالم سيرته")
            highlights
            note
            Button {
                dismiss()
            } label: {
                Text("العودة إلى القائمة").font(.body.weight(.bold)).frame(maxWidth: .infinity)
            }
                .glassButton()
                .controlSize(.large)
                .padding(.top, 4)
        }
        .navigationTitle(masoom.title)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var header: some View {
        VStack(spacing: 12) {
            Text(verbatim: "\(number)")
                .font(.headline.weight(.heavy))
                .frame(width: 46, height: 46)
                .glassCircle()
            Text(masoom.title)
                .font(.scripture(36)).fontWeight(.bold)
                .multilineTextAlignment(.center)
            Text(masoom.name).font(.subheadline.weight(.medium)).foregroundStyle(.white.opacity(0.9))
                .multilineTextAlignment(.center)
            Text(masoom.rank).font(.caption).foregroundStyle(.white.opacity(0.82))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 30).padding(.horizontal, 24)
        .hero()
    }

    private var facts: some View {
        VStack(alignment: .leading, spacing: 0) {
            MasoomFact(label: "الكنية", value: masoom.kunya)
            Divider()
            MasoomFact(label: "المولد", value: masoom.birth)
            Divider()
            MasoomFact(label: "الشهادة / الوفاة", value: masoom.passing)
            Divider()
            MasoomFact(label: "المرقد الشريف", value: masoom.shrine)
        }
        .card(20, padding: 18)
    }

    private var ziyaraButton: some View {
        Button {
            nav.openReader("ziyarat", ziyaraId)
        } label: {
            HStack(spacing: 14) {
                Image(systemName: "book.fill")
                    .font(.system(size: 18, weight: .semibold))
                    .frame(width: 40, height: 40)
                    .background(.white.opacity(0.18), in: Circle())
                VStack(alignment: .leading, spacing: 2) {
                    Text(isBaqi ? "اقرأ زيارة أئمّة البقيع" : "اقرأ زيارته الشريفة").font(.body.weight(.bold))
                    Text(isBaqi ? "يُزارون جماعةً في البقيع" : "تفتحُ في قسم الزيارات")
                        .font(.caption2).foregroundStyle(.white.opacity(0.8))
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                Image(systemName: "chevron.forward").foregroundStyle(.white.opacity(0.7))
            }
            .foregroundStyle(.white)
            .padding(.vertical, 16).padding(.horizontal, 18)
            .background(
                LinearGradient(colors: Brand.categoryColors("ziyarat"), startPoint: .topLeading, endPoint: .bottomTrailing),
                in: RoundedRectangle(cornerRadius: 18, style: .continuous)
            )
        }
        .buttonStyle(.plain)
    }

    private var highlights: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(masoom.highlights.enumerated()), id: \.offset) { i, h in
                HStack(alignment: .top, spacing: 12) {
                    Circle().fill(Brand.gold).frame(width: 7, height: 7).padding(.top, 8)
                    Text(h).font(.body).lineSpacing(5).frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.vertical, 10)
                if i < masoom.highlights.count - 1 { Divider() }
            }
        }
        .card(18, padding: 16)
    }

    private var note: some View {
        HStack(alignment: .top, spacing: 14) {
            Capsule().fill(Brand.emerald).frame(width: 3, height: 40)
            Text(masoom.note).font(.body.weight(.medium)).lineSpacing(5)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(18)
        .background(Brand.emerald.opacity(0.1), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

private struct MasoomFact: View {
    let label: String
    let value: String
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(label).font(.caption2.weight(.bold)).foregroundStyle(.secondary)
            Text(value).font(.subheadline.weight(.medium))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 8)
    }
}

/// Routed detail page (pushed on the tab's path so opening the ziyara keeps the stack intact).
struct MasoomeenDetailScreen: View {
    let index: Int
    var body: some View {
        let all = Library.shared.masoomeen
        if all.indices.contains(index) {
            MasoomDetailView(number: index + 1, masoom: all[index], ziyaraId: masoomZiyara(index))
        } else {
            EmptyStateView(symbol: "questionmark", title: "غير متوفّر", message: "")
        }
    }
}
