import SwiftUI
import StoreKit

// MARK: - Home (port of Android HomeScreen in ui/Screens.kt)

struct HomeView: View {
    @Environment(Store.self) private var store

    var body: some View {
        // Live clock: refreshes every 30 s so the countdown, prayer times and Hijri date stay correct after midnight.
        TimelineView(.periodic(from: .now, by: 30)) { ctx in
            HomeContent(snap: HomeSnapshot(store: store, now: ctx.date))
        }
        .background(Brand.canvas)
        .toolbar(.hidden, for: .navigationBar)
        .onAppear { store.touchStreak() }
    }
}

// MARK: - Snapshot of the time dependent values

struct HomeSnapshot {
    let now: Date
    let hijri: Hijri.HDate
    let city: City
    let times: PrayerTimes.Times
    let nextKey: String
    let prevKey: String
    let nextDate: Date
    /// Share of the span between the previous and the next prayer that has passed (0…1).
    let elapsedFraction: Double
    let totalMin: Int
    let weekday: Int     // 0 = Sunday … 6 = Saturday
    let hour: Int
    let nowH: Double

    init(store: Store, now: Date) {
        self.now = now
        hijri = store.hijriToday()
        city = store.location()
        let t = store.times(for: now)
        times = t
        let comps = Calendar.current.dateComponents([.hour, .minute, .second, .weekday], from: now)
        let h = comps.hour ?? 0
        let mi = comps.minute ?? 0
        let nh = Double(h) + Double(mi) / 60.0 + Double(comps.second ?? 0) / 3600.0
        hour = h
        nowH = nh
        weekday = max(0, min(6, (comps.weekday ?? 1) - 1))
        let nx = PrayerTimes.next(t, nowHours: nh)
        nextKey = nx.key
        nextDate = now.addingTimeInterval(nx.hours * 3600)
        let keys = PrayerTimes.prayerKeys
        let ni = keys.firstIndex(of: nx.key) ?? 0
        let pk = keys[(ni + keys.count - 1) % keys.count]
        prevKey = pk
        var sincePrev = nh - PrayerTimes.norm(PrayerTimes.value(t, pk))
        if sincePrev < 0 { sincePrev += 24 }
        let span = sincePrev + nx.hours
        elapsedFraction = span > 0 ? max(0, min(1, sincePrev / span)) : 0
        // Whole minutes rounded up: never shows "60 min" or "0 min".
        totalMin = max(0, Int(ceil(nx.hours * 60)))
    }

    var countdown: String {
        let hh = totalMin / 60, mm = totalMin % 60
        if hh > 0 { return "\(hh.ar)س \(mm.ar)د" }
        if mm > 0 { return "\(mm.ar)د" }
        return "الآن"
    }

    var monthName: String { homeMonthName(hijri.m) }
}

fileprivate func homeMonthName(_ m: Int) -> String { Hijri.months[max(0, min(11, m - 1))] }

fileprivate func homeHex(_ v: UInt32) -> Color {
    Color(red: Double((v >> 16) & 0xFF) / 255, green: Double((v >> 8) & 0xFF) / 255, blue: Double(v & 0xFF) / 255)
}

private let homeWeekdayDua = ["d-sun", "d-mon", "d-tue", "d-wed", "d-thu", "d-fri", "d-sat"]

// MARK: - Content

private struct HomeContent: View {
    let snap: HomeSnapshot
    @Environment(Store.self) private var store
    @Environment(\.requestReview) private var requestReview

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                // First screen (v2): sky + prayer arc, the tonight card, your day, quick row.
                HomeSkyHeader(snap: snap)
                VStack(alignment: .leading, spacing: 14) {
                    HomeTonightCard(snap: snap)
                        .padding(.top, -68)
                    PersonalOccasionsHomeBanner()
                    HomeOccasions(snap: snap)
                    HomeDayRings(snap: snap)
                    HomeQuickRow()
                    HomeAdhanOffer()
                    // Everything below is the full home: continue reading, listening, progress, wird, day cards, tools.
                    HomeReadingCards(snap: snap)
                    if snap.hijri.m == 9 { HomeRamadanCard(snap: snap) }
                    HomeRecentStrip()
                    HomeQuranListenCard()
                    // Progress lives in Journey; Home keeps one compact line once there is progress.
                    if HomeProgress.activeDays(store) >= 3 {
                        HomeStreakStrip()
                        HomeJourneyCard()
                    }
                    HomeLibraryShortcuts()
                    HomeWirdSection(snap: snap)
                    HomeWorksCard(snap: snap)
                    HomeDayCards(snap: snap)
                    SectionTitle(text: "أعمال وأدوات")
                    HomeQuickGrid()
                    HomeShareAppCard()
                }
                .padding(.horizontal, 16)
                .readableWidth(900)
                .padding(.bottom, 28)
            }
        }
        .ignoresSafeArea(edges: .top)
        .onAppear {
            // Ask for a rating only after real use (a week-long streak or 10 active days), at most every 4 months.
            let last = store.int("reviewAskedDay", -1000)
            if (store.streak >= 7 || HomeProgress.activeDays(store) >= 10) && store.today - last > 120 {
                store.put("reviewAskedDay", store.today)
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) { requestReview() }
            }
        }
        .background(Brand.canvas)
    }
}

// MARK: - Today's occasions

private struct HomeOccasions: View {
    let snap: HomeSnapshot

    var body: some View {
        let occ = Library.occasions(m: snap.hijri.m, d: snap.hijri.d)
        if !occ.isEmpty {
            VStack(spacing: 6) {
                ForEach(Array(occ.enumerated()), id: \.offset) { _, o in
                    HomeOccasionBanner(o: o)
                }
            }
        }
    }
}

private struct HomeOccasionBanner: View {
    let o: Occasion

    private var mourning: Bool { o.k == "death" }

    private var colors: [Color] {
        switch o.k {
        case "death": return [homeHex(0x2B2F35), homeHex(0x15171B)]
        case "birth", "eid": return [homeHex(0xC9A86A), homeHex(0xA9834A)]
        default: return [Brand.emerald, Brand.emerald.opacity(0.82)]
        }
    }

    private var label: String {
        switch o.k {
        case "death": return "ذكرى حزن"
        case "birth": return "ذكرى ولادة"
        case "eid": return "عيد ومناسبة"
        default: return "مناسبة اليوم"
        }
    }

    var body: some View {
        HStack(spacing: 11) {
            Image(systemName: mourning ? "moon.fill" : "sparkles")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(mourning ? Brand.gold : Color.white)
                .frame(width: 34, height: 34)
                .background(Color.white.opacity(0.14), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(label)
                    .font(.ui(.caption2, .heavy))
                    .foregroundStyle(mourning ? Brand.gold : Color.white.opacity(0.9))
                Text(o.t)
                    .font(.ui(.subheadline, .bold))
                    .foregroundStyle(Color.white)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing),
                    in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

// MARK: - Weekly activity (reads + dhikr, last seven days)

private struct HomeActivityDay {
    let initial: String
    let reads: Int
    let dhikr: Int
    let isToday: Bool
    /// One unit per read text, plus one unit per 33 dhikr.
    var score: Double { Double(reads) + Double(dhikr) / 33.0 }
}

private let homeWeekdayInitials = ["ح", "ن", "ث", "ر", "خ", "ج", "س"]

private struct HomeActivityCard: View {
    let snap: HomeSnapshot
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private var days: [HomeActivityDay] {
        var out: [HomeActivityDay] = []
        for offset in stride(from: 6, through: 0, by: -1) {
            let date = Calendar.current.date(byAdding: .day, value: -offset, to: snap.now) ?? snap.now
            let wd = max(0, min(6, Calendar.current.component(.weekday, from: date) - 1))
            out.append(HomeActivityDay(initial: homeWeekdayInitials[wd],
                                       reads: store.seriesValue("readHist", offset: offset),
                                       dhikr: store.seriesValue("dhikrHist", offset: offset),
                                       isToday: offset == 0))
        }
        return out
    }

    var body: some View {
        let ds = days
        let totalReads = ds.reduce(0) { $0 + $1.reads }
        let totalDhikr = ds.reduce(0) { $0 + $1.dhikr }
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .center, spacing: 10) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("نشاط الأسبوع").font(.ui(.headline, .heavy))
                    Text(verbatim: "\(totalReads.ar) قراءة · \(totalDhikr.ar) ذكر")
                        .font(.ui(.caption, .semibold))
                        .foregroundStyle(Color.white.opacity(0.75))
                }
                Spacer(minLength: 8)
                tasbihButton
            }
            HomeActivityBars(days: ds)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .hero(24)
    }

    private var tasbihButton: some View {
        Button { nav.present(.tasbih) } label: {
            HStack(spacing: 6) {
                Image(systemName: "circle.hexagongrid.fill")
                Text("السبحة")
            }
            .font(.ui(.subheadline, .bold))
            .foregroundStyle(Color.white)
            .padding(.horizontal, 14)
            .padding(.vertical, 9)
            .glassCapsule(interactive: true)
        }
        .buttonStyle(.plain)
    }
}

private struct HomeActivityBars: View {
    let days: [HomeActivityDay]
    private let barMax: CGFloat = 84

    var body: some View {
        let top = days.map { $0.score }.max() ?? 0
        HStack(alignment: .bottom, spacing: 10) {
            ForEach(Array(days.enumerated()), id: \.offset) { _, d in
                VStack(spacing: 6) {
                    VStack(spacing: 0) {
                        Spacer(minLength: 0)
                        Capsule()
                            .fill(d.isToday ? Brand.gold : Color.white.opacity(0.6))
                            .frame(height: barHeight(d.score, top: top))
                    }
                    .frame(height: barMax)
                    Text(d.initial)
                        .font(.ui(.caption2, .bold))
                        .foregroundStyle(d.isToday ? Brand.gold : Color.white.opacity(0.7))
                }
                .frame(maxWidth: .infinity)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("نشاط الأسبوع")
    }

    private func barHeight(_ v: Double, top: Double) -> CGFloat {
        guard top > 0 else { return 6 }
        return max(6, CGFloat(v / top) * barMax)
    }
}

// MARK: - Ramadan mode (shown automatically in the holy month)

private struct HomeRamadanCard: View {
    let snap: HomeSnapshot
    @Environment(AppNav.self) private var nav

    private var qadrNight: Bool { [19, 21, 23].contains(snap.hijri.d) }
    private var maghribH: Double { PrayerTimes.value(snap.times, "maghrib") }
    private var fajrH: Double { PrayerTimes.value(snap.times, "fajr") }
    private var beforeIftar: Bool { snap.nowH < maghribH }

    private var remainText: String {
        let target = beforeIftar ? maghribH : fajrH + 24.0
        let remH = ((target - snap.nowH).truncatingRemainder(dividingBy: 24.0) + 24.0).truncatingRemainder(dividingBy: 24.0)
        let rh = Int(remH)
        let rm = Int((remH - Double(rh)) * 60)
        if beforeIftar { return "الإفطار بعد \(rh.ar)س \(rm.ar)د — \(PrayerTimes.fmt(maghribH))" }
        return "الإمساك بعد \(rh.ar)س \(rm.ar)د — \(PrayerTimes.fmt(fajrH))"
    }

    private var colors: [Color] {
        qadrNight ? [homeHex(0x6D5518), homeHex(0x3E3110)] : [homeHex(0x1F5A4E), homeHex(0x123C34)]
    }

    var body: some View {
        Button { nav.openReader("ramadan", qadrNight ? "r-new5092" : "r-abuhamza") } label: {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 9) {
                    Image(systemName: "moon.stars.fill").foregroundStyle(Brand.gold)
                    Text(qadrNight ? "ليلة القدر — أحيِها" : "رمضان المبارك")
                        .font(.ui(.headline, .heavy))
                    Spacer(minLength: 0)
                    Text("اليوم \(snap.hijri.d.ar)")
                        .font(.ui(.caption, .bold))
                        .foregroundStyle(Color.white.opacity(0.85))
                }
                Text(remainText)
                    .font(.ui(.footnote, .bold))
                    .foregroundStyle(Color.white.opacity(0.92))
                Text(qadrNight ? "أعمال الليلة المباركة — انقر للبدء" : "دعاء أبي حمزة الثمالي — انقر للقراءة")
                    .font(.ui(.caption2, .bold))
                    .foregroundStyle(Brand.gold.opacity(0.95))
            }
            .foregroundStyle(Color.white)
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(HomePatternFill(colors: colors, radius: 22))
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Streak strip and Quran points badge

private struct HomeStreakStrip: View {
    @Environment(Store.self) private var store

    var body: some View {
        let s = store.streak
        let best = store.int("bestStreak", 0)
        HStack(spacing: 10) {
            Image(systemName: "flame.fill")
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(Brand.gold)
            Text("مواظبة \(s.ar) \(s == 1 ? "يوم" : "أيام")")
                .font(.ui(.subheadline, .heavy))
            Spacer(minLength: 0)
            if best > 0 {
                Text("الأفضل \(best.ar)")
                    .font(.ui(.caption, .bold))
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Brand.gold.opacity(0.14), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

private struct HomeQuranPointsBadge: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    var body: some View {
        let points = QuranProgress.lifetime(store)
        let done = QuranPointsLevel.doneSet(store).count
        if points > 0 {
            Button { nav.openTool(.qpoints) } label: {
                HStack(spacing: 10) {
                    Image(systemName: "rosette")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(Brand.gold)
                    Text("نقاط القرآن \(points.ar)")
                        .font(.ui(.subheadline, .heavy))
                        .foregroundStyle(.primary)
                    Spacer(minLength: 0)
                    Text(verbatim: "\(done.ar)/\(114.ar) سورة")
                        .font(.ui(.caption, .bold))
                        .foregroundStyle(.secondary)
                    Image(systemName: "chevron.forward")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Brand.emerald.opacity(0.12), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .buttonStyle(.plain)
        }
    }
}

// MARK: - Shared gradient surfaces

private struct HomePatternFill: View {
    let colors: [Color]
    var radius: CGFloat = 18
    var cell: CGFloat = 60

    var body: some View {
        ZStack {
            LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
            StarPattern(cell: cell).foregroundStyle(Color.white.opacity(0.07))
        }
        .clipShape(RoundedRectangle(cornerRadius: radius, style: .continuous))
    }
}

private struct HomeGradientRow: View {
    let colors: [Color]
    let symbol: String
    let overline: String
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: symbol)
                .font(.system(size: 22, weight: .semibold))
                .frame(width: 50, height: 50)
                .glass(16)
            VStack(alignment: .leading, spacing: 3) {
                Text(overline)
                    .font(.ui(.caption, .heavy))
                    .foregroundStyle(Color.white.opacity(0.82))
                Text(title)
                    .font(.ui(.headline, .heavy))
                    .lineLimit(1)
                Text(subtitle)
                    .font(.ui(.caption))
                    .foregroundStyle(Color.white.opacity(0.7))
                    .lineLimit(1)
            }
            Spacer(minLength: 8)
            Image(systemName: "chevron.forward").font(.footnote.weight(.bold))
        }
        .foregroundStyle(Color.white)
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(HomePatternFill(colors: colors, radius: 20))
    }
}

// MARK: - "What to read now" and continue reading

private struct HomeReadingCards: View {
    let snap: HomeSnapshot
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private var resume: (DuaaCategory, DuaaItem)? {
        guard let first = store.recentReads.first,
              let c = Library.category(first.0),
              let i = c.items.first(where: { $0.id == first.1 }) else { return nil }
        return (c, i)
    }

    var body: some View {
        // The recommendation lives in the tonight card above; this row only continues an unfinished read.
        if let r = resume {
            Button { nav.openReader(r.0.id, r.1.id) } label: {
                HomeGradientRow(colors: Brand.purpleColors, symbol: "book.fill",
                                overline: "تابع من حيث توقّفت", title: r.1.title, subtitle: r.0.name)
            }
            .buttonStyle(.plain)
        }
    }
}

// MARK: - Recently read strip

private struct HomeRecentEntry: Hashable {
    let catId: String
    let itemId: String
    let title: String
}

private struct HomeRecentStrip: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private var entries: [HomeRecentEntry] {
        let all: [HomeRecentEntry] = store.recentReads.compactMap { pair in
            guard let it = Library.item(pair.0, pair.1) else { return nil }
            return HomeRecentEntry(catId: pair.0, itemId: pair.1, title: it.title)
        }
        // The first entry is the "continue reading" card itself.
        return Array(all.dropFirst().prefix(8))
    }

    var body: some View {
        let list = entries
        if !list.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                SectionTitle(text: "المقروء حديثاً")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(list, id: \.self) { e in
                            Button { nav.openReader(e.catId, e.itemId) } label: { tile(e) }
                                .buttonStyle(.plain)
                        }
                    }
                }
            }
        }
    }

    private func tile(_ e: HomeRecentEntry) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Image(systemName: Brand.categorySymbol(e.catId))
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(Color.white.opacity(0.9))
            Spacer(minLength: 4)
            Text(e.title)
                .font(.ui(.footnote, .bold))
                .foregroundStyle(Color.white)
                .lineLimit(2)
                .multilineTextAlignment(.leading)
        }
        .padding(12)
        .frame(width: 150, height: 74, alignment: .topLeading)
        .background(HomePatternFill(colors: Brand.categoryColors(e.catId), radius: 16, cell: 44))
    }
}

// MARK: - My library: favourites and bookmarks

private struct HomeLibraryShortcuts: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    var body: some View {
        let favCount = store.favorites.count
        let bmCount = store.bookmarks.count
        if favCount > 0 || bmCount > 0 {
            HStack(spacing: 12) {
                Button { nav.present(.favorites) } label: {
                    tile(symbol: "star.fill", color: Brand.gold, title: "المفضّلة",
                         sub: favCount > 0 ? "\(favCount.ar) محفوظ" : "لا شيء بعد")
                }
                .buttonStyle(.plain)
                Button { nav.present(.bookmarks) } label: {
                    tile(symbol: "bookmark.fill", color: Brand.emerald, title: "العلامات",
                         sub: bmCount > 0 ? "\(bmCount.ar) علامة" : "لا شيء بعد")
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func tile(symbol: String, color: Color, title: String, sub: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Image(systemName: symbol)
                .font(.system(size: 22, weight: .semibold))
                .foregroundStyle(color)
            Text(title)
                .font(.ui(.subheadline, .heavy))
                .foregroundStyle(.primary)
            Text(sub)
                .font(.ui(.caption, .medium))
                .foregroundStyle(.secondary)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(color.opacity(0.12), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(color.opacity(0.22), lineWidth: 1))
    }
}

// MARK: - My journey entry

private struct HomeJourneyCard: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    var body: some View {
        let s = store.streak
        Button { nav.openTool(.journey) } label: {
            HStack(spacing: 14) {
                Image(systemName: "star.fill")
                    .font(.system(size: 22, weight: .semibold))
                    .frame(width: 52, height: 52)
                    .glass(16)
                VStack(alignment: .leading, spacing: 3) {
                    Text("رحلتي").font(.ui(.title3, .heavy))
                    Text(s > 0 ? "سلسلة مواظبتك: \(s.ar) \(s == 1 ? "يوم" : "يوماً") — تابِع تقدّمك" : "ابدأ رحلتك الروحيّة وتابِع تقدّمك")
                        .font(.ui(.caption))
                        .foregroundStyle(Color.white.opacity(0.85))
                        .multilineTextAlignment(.leading)
                }
                Spacer(minLength: 8)
                Image(systemName: "chevron.forward")
                    .font(.footnote.weight(.bold))
                    .foregroundStyle(Color.white.opacity(0.8))
            }
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .hero(22)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Daily wird checklist + dhikr of the day + daily dhikr counter

private struct HomeWirdSection: View {
    let snap: HomeSnapshot
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private var duaId: String { homeWeekdayDua[snap.weekday] }
    private var dua: DuaaItem? { Library.item("osboo", duaId) }

    private func isOn(_ bit: Int) -> Bool { store.wirdMask & (1 << bit) != 0 }
    private func markWird(_ bit: Int) { if !isOn(bit) { store.toggleWird(bit) } }

    var body: some View {
        let done = store.wirdMask & 0b1111 == 0b1111
        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(text: done ? "وِرد اليوم — اكتمل، تقبّل الله ✓" : "وِرد اليوم")
            VStack(spacing: 8) {
                rows
                HomeDhikrOfDay(dayIndex: store.dayIndex)
                dhikrProgress
            }
            .card()
        }
    }

    @ViewBuilder private var rows: some View {
        HomeWirdRow(symbol: "book.fill", label: dua.map { "دعاء اليوم: \($0.title)" } ?? "دعاء اليوم", done: isOn(0)) {
            markWird(0)
            nav.openReader("osboo", duaId)
        }
        HomeWirdRow(symbol: "circle.hexagongrid.fill", label: "تسبيح الزهراء (ع)", done: isOn(1)) {
            markWird(1)
            nav.present(.tasbih)
        }
        HomeWirdRow(symbol: "sparkles", label: "ذكر اليوم", done: isOn(2)) {
            if !isOn(2) { Haptic.confirm() }
            store.toggleWird(2)
        }
        HomeWirdRow(symbol: "hands.sparkles.fill", label: "صدقة اليوم — ولو يسيرة", done: isOn(3)) {
            if !isOn(3) { Haptic.confirm() }
            store.toggleWird(3)
        }
    }

    private var dhikrProgress: some View {
        let count = store.dhikrToday
        let goal = store.dhikrGoal
        let frac = goal > 0 ? min(1.0, max(0.0, Double(count) / Double(goal))) : 0.0
        return Button { nav.present(.tasbih) } label: {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 8) {
                    Image(systemName: "circle.hexagongrid.fill").foregroundStyle(Brand.emerald)
                    Text(count >= goal && goal > 0 ? "وِرد الذِّكر اليومي — اكتمل ✓" : "وِرد الذِّكر اليومي")
                        .font(.ui(.footnote, .bold))
                        .foregroundStyle(.primary)
                    Spacer(minLength: 0)
                    Text(verbatim: "\(count.ar) / \(goal.ar)")
                        .font(.ui(.subheadline, .heavy))
                        .foregroundStyle(Brand.emerald)
                }
                ProgressView(value: frac)
                    .tint(Brand.emerald)
            }
            .padding(14)
            .background(Brand.emerald.opacity(0.08), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}

private struct HomeWirdRow: View {
    let symbol: String
    let label: String
    let done: Bool
    let action: () -> Void

    var body: some View {
        Button(action: { Haptic.tick(); action() }) {
            HStack(spacing: 10) {
                ZStack {
                    Circle()
                        .fill(done ? Brand.good : Color.clear)
                    Circle()
                        .strokeBorder(done ? Brand.good : Color(.separator), lineWidth: 1.5)
                    if done {
                        Image(systemName: "checkmark")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(Color.white)
                    }
                }
                .frame(width: 24, height: 24)
                Image(systemName: symbol)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Brand.emerald)
                Text(label)
                    .font(.ui(.footnote, .bold))
                    .foregroundStyle(.primary)
                    .multilineTextAlignment(.leading)
                Spacer(minLength: 4)
                Image(systemName: "chevron.forward")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 11)
            .background(done ? Brand.good.opacity(0.10) : Color(.tertiarySystemFill),
                        in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(done ? .isSelected : [])
    }
}

private struct HomeDhikrOfDay: View {
    let dayIndex: Int

    var body: some View {
        let list = Library.shared.adhkar
        if !list.isEmpty {
            let d = list[((dayIndex % list.count) + list.count) % list.count]
            VStack(spacing: 4) {
                Text(d.text)
                    .font(.scripture(20))
                    .multilineTextAlignment(.center)
                    .lineSpacing(6)
                    .foregroundStyle(.primary)
                    .frame(maxWidth: .infinity)
                    .textSelection(.enabled)
                Text(d.src)
                    .font(.ui(.caption2, .bold))
                    .foregroundStyle(Brand.gold)
            }
            .padding(14)
            .frame(maxWidth: .infinity)
            .background(Brand.gold.opacity(0.12), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
    }
}

// MARK: - Works of today (and of tonight after 17:00) from the calendar

private struct HomeWorksCard: View {
    let snap: HomeSnapshot
    @Environment(AppNav.self) private var nav

    private static func core(_ title: String) -> String {
        title.components(separatedBy: " · ").first ?? title
    }

    private static func nights(_ m: Int, _ d: Int) -> [Work] {
        Library.works(m: m, d: d).filter { $0.d == d && $0.title.hasPrefix("الليلة") }
    }

    private var tonight: [Work] {
        guard snap.hour >= 17 else { return [] }
        let h = snap.hijri
        var out = HomeWorksCard.nights(h.m, h.d + 1)
        // End of month: the night of the first of next month (such as the first night of Ramadan) is shown too.
        if h.d >= 29 { out += HomeWorksCard.nights(h.m % 12 + 1, 1) }
        return out
    }

    private var featured: [Work] {
        let h = snap.hijri
        // The night of today has passed (it is shown on the previous evening), so it is excluded from the day works.
        let today = Library.works(m: h.m, d: h.d).filter { $0.d != 0 && !$0.title.hasPrefix("الليلة") }
        var seen = Set<String>()
        var out: [Work] = []
        for w in tonight + today {
            let k = HomeWorksCard.core(w.title)
            if !seen.contains(k) { seen.insert(k); out.append(w) }
        }
        return out
    }

    var body: some View {
        let list = featured
        let hasTonight = !tonight.isEmpty
        if !list.isEmpty {
            Button { nav.openTool(.calendar) } label: {
                VStack(alignment: .leading, spacing: 10) {
                    header(count: list.count, hasTonight: hasTonight)
                    ForEach(Array(list.prefix(3).enumerated()), id: \.offset) { _, w in
                        HStack(spacing: 8) {
                            Circle().fill(Color.white.opacity(0.85)).frame(width: 6, height: 6)
                            Text(HomeWorksCard.core(w.title) + (w.m != snap.hijri.m ? " من \(homeMonthName(w.m))" : ""))
                                .font(.ui(.footnote, .bold))
                                .lineLimit(1)
                        }
                    }
                    if list.count > 3 {
                        Text("و\((list.count - 3).ar) غيرها في التقويم")
                            .font(.ui(.caption2))
                            .foregroundStyle(Color.white.opacity(0.75))
                    }
                }
                .foregroundStyle(Color.white)
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(HomePatternFill(colors: Brand.categoryColors("hajj"), radius: 20))
            }
            .buttonStyle(.plain)
        }
    }

    private func header(count: Int, hasTonight: Bool) -> some View {
        HStack(spacing: 12) {
            Image(systemName: "moon.fill")
                .font(.system(size: 18, weight: .semibold))
                .frame(width: 40, height: 40)
                .glass(12)
            VStack(alignment: .leading, spacing: 2) {
                Text(hasTonight ? "عمل الليلة واليوم" : "عمل اليوم")
                    .font(.ui(.headline, .heavy))
                Text(verbatim: "\(snap.hijri.d.ar) \(snap.monthName) · \(count.ar) \(count == 1 ? "عمل" : "أعمال")")
                    .font(.ui(.caption, .medium))
                    .foregroundStyle(Color.white.opacity(0.85))
            }
            Spacer(minLength: 0)
            Image(systemName: "chevron.forward")
                .font(.caption.weight(.bold))
                .foregroundStyle(Color.white.opacity(0.85))
        }
    }
}

// MARK: - Day cards: hikma, ziyara of the day, right of the day, dua of this hour

private struct HomeDayCards: View {
    let snap: HomeSnapshot
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private static let ziyaraOfDay: [(String, String, String)] = [
        ("أمير المؤمنين (ع)", "ziyarat", "z-amin"),
        ("الحسنان (ع)", "ziyarat", "z-mutlaqa"),
        ("السجاد والباقر والصادق (ع)", "ziyarat", "z-baqi"),
        ("الكاظم والرضا والجواد والهادي (ع)", "ziyarat", "z-kadhim"),
        ("العسكري (ع)", "ziyarat", "z-askari"),
        ("صاحب الزمان (عج)", "ziyarat", "z-yasin"),
        ("النبي الأعظم (ص)", "ziyarat", "z-nabi")
    ]

    private var right: DuaaItem? {
        guard let c = Library.category("huquq"), c.items.count > 2 else { return nil }
        let rights = Array(c.items[1..<(c.items.count - 1)])
        return rights[store.dayIndex % rights.count]
    }

    private var hourPick: DuaaItem? {
        guard let c = Library.category("yawm"), !c.items.isEmpty else { return nil }
        let h = snap.hour
        let bucket: [String]
        if h < 4 { bucket = ["hj-nawm-adab"] }
        else if h < 10 { bucket = ["hj-intibah", "hj-wudu", "hj-libs-hamd", "hj-libs-yumn"] }
        else if h < 15 { bucket = ["hj-taam", "hj-ghasl-taam", "hj-adha-taam", "hj-thawb-jadid"] }
        else if h < 21 { bucket = ["hj-masjid-going", "hj-masjid-enter", "hj-tawajjuh", "hj-adhan-iqama"] }
        else { bucket = ["hj-nawm-adab", "hj-atas"] }
        let ids = bucket.filter { b in c.items.contains { $0.id == b } }
        guard !ids.isEmpty else { return nil }
        let pick = ids[store.dayIndex % ids.count]
        return c.items.first { $0.id == pick }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(text: "بطاقات اليوم")
            HomeHikmaCard(dayIndex: store.dayIndex)
            ziyaraRow
            specialRow
        }
    }

    private var ziyaraRow: some View {
        let z = HomeDayCards.ziyaraOfDay[snap.weekday]
        return Button { nav.openReader(z.1, z.2) } label: {
            HomeGradientRow(colors: Brand.categoryColors("ziyarat"), symbol: "flag.fill",
                            overline: "زيارة اليوم", title: z.0, subtitle: "بحسب المأثور")
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder private var specialRow: some View {
        let r = right
        let p = hourPick
        if r != nil || p != nil {
            HStack(spacing: 10) {
                if let r {
                    Button { nav.openReader("huquq", r.id) } label: {
                        HomeSmallTile(colors: Brand.categoryColors("huquq"), overline: "حقّ اليوم", title: r.title, footer: "رسالة الحقوق")
                    }
                    .buttonStyle(.plain)
                }
                if let p {
                    Button { nav.openReader("yawm", p.id) } label: {
                        HomeSmallTile(colors: Brand.categoryColors("yawm"), overline: "دعاء هذه الساعة", title: p.title, footer: "اليوم والليلة")
                    }
                    .buttonStyle(.plain)
                }
            }
            .fixedSize(horizontal: false, vertical: true)
        }
    }
}

private struct HomeSmallTile: View {
    let colors: [Color]
    let overline: String
    let title: String
    let footer: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(overline)
                .font(.ui(.caption2, .heavy))
                .foregroundStyle(Color.white.opacity(0.82))
            Text(title)
                .font(.ui(.subheadline, .heavy))
                .lineLimit(2)
                .multilineTextAlignment(.leading)
            Spacer(minLength: 4)
            Text(footer)
                .font(.ui(.caption2, .bold))
                .foregroundStyle(Color.white.opacity(0.8))
        }
        .foregroundStyle(Color.white)
        .padding(14)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(HomePatternFill(colors: colors, radius: 20, cell: 54))
    }
}

private struct HomeHikmaCard: View {
    let dayIndex: Int
    @Environment(AppNav.self) private var nav

    var body: some View {
        let list = Library.shared.hikam
        if !list.isEmpty {
            // Same rotation as Android DailyContent.hikmaOfDay: (dayIndex + 3) % count.
            let h = list[((dayIndex + 3) % list.count + list.count) % list.count]
            Button { nav.openReader("hikam", "hk-ali-1") } label: {
                VStack(alignment: .leading, spacing: 8) {
                    HStack(spacing: 8) {
                        IconChip(symbol: "scroll.fill", colors: Brand.categoryColors("hikam"), size: 32)
                        Text("حكمة اليوم")
                            .font(.ui(.caption, .heavy))
                            .foregroundStyle(.secondary)
                        Spacer(minLength: 0)
                    }
                    Text("«\(h.text)»")
                        .font(.scripture(19))
                        .lineSpacing(5)
                        .foregroundStyle(.primary)
                        .multilineTextAlignment(.leading)
                        .fixedSize(horizontal: false, vertical: true)
                    Text(verbatim: "— \(h.who)")
                        .font(.ui(.caption, .bold))
                        .foregroundStyle(Brand.gold)
                }
                .card()
            }
            .buttonStyle(.plain)
        }
    }
}

// MARK: - Quick tools grid

private struct HomeQuickItem {
    let symbol: String
    let title: String
    let catColor: String
    let tool: Tool?          // nil => tasbih sheet
}

private struct HomeQuickGrid: View {
    @Environment(AppNav.self) private var nav

    private static let items: [HomeQuickItem] = [
        HomeQuickItem(symbol: Tool.hajj.symbol, title: "الحجّ والعمرة", catColor: "ziyarat", tool: .hajj),
        HomeQuickItem(symbol: Tool.khira.symbol, title: "خيرة القرآن", catColor: "hikam", tool: .khira),
        HomeQuickItem(symbol: Tool.khatma.symbol, title: "الختمة", catColor: "quran", tool: .khatma),
        HomeQuickItem(symbol: Tool.khums.symbol, title: "حاسبة الخمس", catColor: "hajat", tool: .khums),
        HomeQuickItem(symbol: Tool.masoom.symbol, title: "المعصومون", catColor: "rajab", tool: .masoom),
        HomeQuickItem(symbol: Tool.muhasaba.symbol, title: "محاسبة النفس", catColor: "tarbiya", tool: .muhasaba),
        HomeQuickItem(symbol: Tool.qada.symbol, title: "قضاء الفوائت", catColor: "osboo", tool: .qada),
        HomeQuickItem(symbol: Tool.qibla.symbol, title: "اتجاه القبلة", catColor: "salawat", tool: .qibla),
        HomeQuickItem(symbol: Tool.asma.symbol, title: "أسماء الله", catColor: "nawafil", tool: .asma),
        HomeQuickItem(symbol: "book.closed.fill", title: "ختمتي", catColor: "quran", tool: .khatma),
        HomeQuickItem(symbol: Tool.layl.symbol, title: "صلاة الليل", catColor: "ramadan", tool: .layl),
        HomeQuickItem(symbol: Tool.amaal.symbol, title: "أعمال اليوم", catColor: "jumaa", tool: .amaal),
        HomeQuickItem(symbol: Tool.weekly.symbol, title: Tool.weekly.title, catColor: "osboo", tool: .weekly),
        HomeQuickItem(symbol: "circle.hexagongrid.fill", title: "السبحة", catColor: "munajat", tool: nil)
    ]

    // 3 columns on iPhone, more on iPad
    private let columns: [GridItem] = [GridItem(.adaptive(minimum: 104, maximum: 180), spacing: 10)]

    var body: some View {
        LazyVGrid(columns: columns, spacing: 10) {
            ForEach(Array(HomeQuickGrid.items.enumerated()), id: \.offset) { _, q in
                Button { open(q) } label: {
                    ToolTile(symbol: q.symbol, title: q.title, colors: Brand.categoryColors(q.catColor))
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func open(_ q: HomeQuickItem) {
        Haptic.tick()
        if let t = q.tool { nav.openTool(t) } else { nav.present(.tasbih) }
    }
}


// MARK: - First-week helpers

enum HomeProgress {
    /// Distinct days with any reading, wird or dhikr in the last 90 days.
    static func activeDays(_ store: Store) -> Int {
        var days = Set<Int>()
        for k in ["readHist", "wird", "dhikrHist"] {
            for (d, v) in store.series(k) where v > 0 { days.insert(d) }
        }
        return days.count
    }
}

/// Offers the adhan right where people look at prayer times (alerts are off until asked).
private struct HomeAdhanOffer: View {
    @Environment(Store.self) private var store

    var body: some View {
        if !store.bool("notify", false) && store.int("adhanOfferHidden", -1) < store.today - 14 {
            HStack(spacing: 12) {
                Image(systemName: "bell.badge.fill").font(.title3).foregroundStyle(Brand.gold)
                VStack(alignment: .leading, spacing: 2) {
                    Text("فعّل تنبيه الأذان").font(.ui(.subheadline, .heavy))
                    Text("يصلك الأذان في وقته في \(store.location().n)").font(.ui(.caption)).foregroundStyle(.secondary)
                }
                Spacer(minLength: 4)
                Button("تفعيل") {
                    Task {
                        let ok = await Notifier.requestPermission()
                        if ok {
                            store.put("notify", true)
                            Notifier.schedulePrayers(store: store)
                            Haptic.confirm()
                        }
                    }
                }
                .buttonStyle(.borderedProminent).tint(Brand.emerald)
                Button {
                    store.put("adhanOfferHidden", store.today)
                } label: {
                    Image(systemName: "xmark").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("لاحقاً")
            }
            .card()
        }
    }
}

/// Word of mouth: the app spreads through family WhatsApp groups.
private struct HomeShareAppCard: View {
    var body: some View {
        ShareLink(item: AppLinks.shareText) {
            HStack(spacing: 12) {
                Image(systemName: "square.and.arrow.up.fill").font(.title3).foregroundStyle(Brand.emerald)
                VStack(alignment: .leading, spacing: 2) {
                    Text("شارك التطبيق مع أهلك").font(.ui(.subheadline, .heavy)).foregroundStyle(.primary)
                    Text("الدالّ على الخير كفاعله").font(.ui(.caption)).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.left").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
            }
            .card()
        }
        .buttonStyle(.plain)
    }
}


/// One tap to the whole Quran (auto-advancing), and the way into Listen.
private struct HomeQuranListenCard: View {
    @Environment(AppNav.self) private var nav
    var body: some View {
        VStack(spacing: 10) {
            QuranPlaylistCard { nav.tab = .listen }
            HomeListenNow()
        }
    }
}

/// One tap from Home: continue the recording left part-way, or play what fits now
/// (Kumail on Thursday evening, Nudba on Friday…).
private struct HomeListenNow: View {
    @Environment(AppNav.self) private var nav
    @Environment(Store.self) private var store
    @State private var player = AudioPlayer.shared
    @State private var library = AudioLibrary.shared

    private var resumeItem: AudioItem? {
        player.recent.first { $0.id != player.current?.id && (player.resumeFraction($0) ?? 0) > 0.02 }
    }

    var body: some View {
        if let r = resumeItem {
            row(symbol: "play.fill", title: "أكمل: \(r.title)",
                detail: "من \(AudioFormat.time(player.resume[r.id]))", progress: player.resumeFraction(r)) {
                player.play(r)
            }
        } else if let s = ListenDiscover.today(store.hijriToday()).first {
            let linked = library.linked(catId: s.item.catId, itemId: s.item.itemId)
            row(symbol: linked == nil ? "magnifyingglass" : "play.fill", title: s.item.title,
                detail: s.why + (linked == nil ? " · اختر تسجيلاً" : ""), progress: nil) {
                if let a = linked {
                    player.play(a)
                } else {
                    nav.pendingListen = ListenDiscover.query(s.item, reciter: UserDefaults.standard.string(forKey: ListenDiscover.favReciterKey) ?? "")
                    nav.pendingLinkTarget = s.item.id
                    nav.tab = .listen
                }
            }
        }
    }

    private func row(symbol: String, title: String, detail: String, progress: Double?, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: symbol)
                    .font(.system(size: 16, weight: .bold)).foregroundStyle(.white)
                    .frame(width: 44, height: 44)
                    .background(Circle().fill(Brand.gold))
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.ui(.subheadline, .bold)).foregroundStyle(.primary).lineLimit(1)
                    Text(detail).font(.ui(.caption)).foregroundStyle(.secondary).lineLimit(1)
                    if let progress { ProgressView(value: progress).tint(Brand.gold) }
                }
                Spacer(minLength: 0)
                Image(systemName: "headphones").foregroundStyle(Brand.emerald)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .card(18, padding: 14)
    }
}
