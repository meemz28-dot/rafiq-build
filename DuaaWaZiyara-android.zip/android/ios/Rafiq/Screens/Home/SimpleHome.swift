import SwiftUI

// MARK: - الوضع المبسّط: a calm home for older users.
// One large "next prayer" card, today's dua, and eight big tiles. Nothing else.

extension Store {
    var simpleMode: Bool {
        get { bool("simpleMode", false) }
        set { put("simpleMode", newValue) }
    }
}

struct SimpleHomeContent: View {
    let snap: HomeSnapshot
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private struct Tile: Identifiable {
        let id: String
        let title: String
        let symbol: String
        let color: Color
        let action: () -> Void
    }

    private var tiles: [Tile] {
        [
            Tile(id: "prayer", title: "مواقيت الصلاة", symbol: "clock.fill", color: Brand.deeper) { nav.openTool(.prayer) },
            Tile(id: "quran", title: "القرآن الكريم", symbol: "book.closed.fill", color: Color(hex: 0x3D5F8C)) { nav.open(.category("quran")) },
            Tile(id: "duas", title: "الأدعية والزيارات", symbol: "book.fill", color: Brand.emerald) { nav.tab = .library },
            Tile(id: "listen", title: "استمع", symbol: "headphones", color: Color(hex: 0x7A4E9C)) { nav.tab = .listen },
            Tile(id: "qibla", title: "القبلة", symbol: "location.north.line.fill", color: Brand.goldDeep) { nav.openTool(.qibla) },
            Tile(id: "tasbih", title: "السبحة", symbol: "circle.hexagongrid.fill", color: Brand.gold) { nav.present(.tasbih) },
            Tile(id: "calendar", title: "التقويم", symbol: "moon.fill", color: Brand.deep) { nav.openTool(.calendar) },
            Tile(id: "settings", title: "الإعدادات", symbol: "gearshape.fill", color: Color(hex: 0x5B6670)) { nav.present(.settings) },
        ]
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                header
                prayerCard
                todayDua
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)], spacing: 14) {
                    ForEach(tiles) { t in tileView(t) }
                }
                Button {
                    store.simpleMode = false
                    Haptic.tick()
                } label: {
                    Text("العودة إلى العرض العادي")
                        .font(.ui(size: 17, weight: .semibold))
                        .foregroundStyle(Brand.deeper)
                        .frame(maxWidth: .infinity)
                        .frame(minHeight: 54)
                }
                .buttonStyle(.plain)
                .padding(.top, 4)
            }
            .padding(.horizontal, 18)
            .padding(.top, 12)
            .padding(.bottom, 140)
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("السلام عليكم").font(.display(30)).foregroundStyle(Brand.ink)
            Text(verbatim: "\(Hijri.weekDays[snap.weekday]) · \(Hijri.format(snap.hijri))")
                .font(.ui(size: 19, weight: .medium)).foregroundStyle(Brand.muted)
        }
        .padding(.top, 8)
        .accessibilityElement(children: .combine)
    }

    private var prayerCard: some View {
        Button { nav.openTool(.prayer) } label: {
            VStack(alignment: .leading, spacing: 6) {
                Text(verbatim: "الصلاة القادمة · \(snap.city.n)")
                    .font(.ui(size: 18, weight: .medium)).foregroundStyle(.white.opacity(0.85))
                HStack(alignment: .firstTextBaseline) {
                    Text(PrayerTimes.name(snap.nextKey)).font(.display(42)).foregroundStyle(.white)
                    Spacer()
                    Text(PrayerTimes.fmt(PrayerTimes.value(snap.times, snap.nextKey)))
                        .font(.ui(size: 34, weight: .bold)).foregroundStyle(Brand.gold)
                }
                TimelineView(.periodic(from: .now, by: 1)) { ctx in
                    let left = max(0, Int(snap.nextDate.timeIntervalSince(ctx.date)))
                    Text(verbatim: "بعد \(simpleLeft(left))")
                        .font(.ui(size: 22, weight: .semibold)).foregroundStyle(.white)
                }
            }
            .padding(22)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Brand.heroGradient, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("الصلاة القادمة \(PrayerTimes.name(snap.nextKey))")
    }

    /// Spoken-style countdown: "ساعتان و١٠ دقائق" reads easier than a clock.
    private func simpleLeft(_ s: Int) -> String {
        let h = s / 3600, m = (s % 3600) / 60
        if h == 0 { return m <= 1 ? "دقيقة" : "\(m.ar) \(m <= 10 ? "دقائق" : "دقيقة")" }
        let hs = h == 1 ? "ساعة" : (h == 2 ? "ساعتين" : "\(h.ar) ساعات")
        return m == 0 ? hs : "\(hs) و\(m.ar) \(m <= 10 ? "دقائق" : "دقيقة")"
    }

    @ViewBuilder private var todayDua: some View {
        let sg = Recommend.now(hMonth: snap.hijri.m, hDay: snap.hijri.d, weekday: snap.weekday, hour: snap.hour)
        if let item = Library.item(sg.catId, sg.itemId) {
            Button {
                if let a = AudioLibrary.shared.linked(catId: sg.catId, itemId: sg.itemId) { AudioPlayer.shared.play(a) }
                nav.openReader(sg.catId, sg.itemId)
            } label: {
                HStack(spacing: 16) {
                    Image(systemName: "play.fill")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundStyle(Brand.ink)
                        .frame(width: 64, height: 64)
                        .background(Brand.gold, in: Circle())
                    VStack(alignment: .leading, spacing: 3) {
                        Text("دعاء اليوم").font(.ui(size: 16, weight: .medium)).foregroundStyle(Brand.muted)
                        Text(item.title).font(.ui(size: 24, weight: .bold)).foregroundStyle(Brand.ink)
                            .lineLimit(2).minimumScaleFactor(0.8)
                    }
                    Spacer(minLength: 0)
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Brand.line, lineWidth: 1))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("دعاء اليوم: \(item.title)")
        }
    }

    private func tileView(_ t: Tile) -> some View {
        Button {
            Haptic.tick()
            t.action()
        } label: {
            VStack(spacing: 12) {
                Image(systemName: t.symbol)
                    .font(.system(size: 34, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 70, height: 70)
                    .background(t.color, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                Text(t.title)
                    .font(.ui(size: 19, weight: .bold))
                    .foregroundStyle(Brand.ink)
                    .multilineTextAlignment(.center)
                    .lineLimit(2).minimumScaleFactor(0.85)
            }
            .frame(maxWidth: .infinity)
            .frame(minHeight: 158)
            .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Brand.line, lineWidth: 1))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(t.title)
    }
}

/// Settings row: «طريقة العرض» عادي / مبسّط.
struct SimpleModeSection: View {
    @Environment(Store.self) private var store

    var body: some View {
        Section {
            Picker("طريقة العرض", selection: Binding(get: { store.simpleMode }, set: { on in
                store.simpleMode = on
                if on && store.fontSize < 28 { store.fontSize = 28 }
                if on && AppNav.shared.tab == .more { AppNav.shared.tab = .home }
            })) {
                Text("عادي").tag(false)
                Text("مبسّط").tag(true)
            }
            .pickerStyle(.segmented)
            .listRowBackground(Color.clear)
        } header: {
            Text("طريقة العرض")
        } footer: {
            Text("العرض المبسّط: خطٌّ أكبر وأزرار كبيرة، وصفحة رئيسية تعرض الأهمّ فقط: الصلاة القادمة ودعاء اليوم وثمانية أزرار. مناسب لكبار السن.")
        }
    }
}
