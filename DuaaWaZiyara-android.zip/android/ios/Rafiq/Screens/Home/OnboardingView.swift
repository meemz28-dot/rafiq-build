import SwiftUI
import CoreLocation

// MARK: - First-run flow (port of Android ui/OnboardingScreen.kt)
// Sets the user up in seconds (location, calculation method, reminders), writing straight to the real settings,
// then raises the completion flag (store.onboardingDone).

struct OnboardingView: View {
    @Environment(Store.self) private var store
    @State private var step = 0
    @State private var forward = true
    @State private var locator = LocationService()
    @State private var locating = false
    private let total = 4
    /// Set by "skip": only the location step remains (prayer times must be right for the user's city).
    @State private var skipRest = false
    private var needsLocation: Bool { step == 1 && !store.bool("locationChosen") }

    var body: some View {
        ZStack {
            OnboardingBackground()
                .ignoresSafeArea()
            VStack(spacing: 0) {
                progress
                stepContent
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                buttons
                if step == 0 { skipButton }
            }
        }
        .foregroundStyle(Color.white)
        .onChange(of: locator.location) { _, loc in useLocation(loc) }
        .onChange(of: locator.errorText) { _, err in if err != nil { locating = false } }
    }

    // MARK: Progress indicator

    private var progress: some View {
        HStack(spacing: 6) {
            ForEach(0..<total, id: \.self) { i in
                Capsule()
                    .fill(i <= step ? Brand.gold : Color.white.opacity(0.22))
                    .frame(height: 5)
            }
        }
        .padding(20)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\((step + 1).ar) / \(total.ar)")
    }

    // MARK: Steps

    private var stepContent: some View {
        Group {
            switch step {
            case 0: OnboardingWelcomeStep()
            case 1: OnboardingLocationStep(locator: locator, locating: $locating)
            case 2: OnboardingMethodStep()
            default: OnboardingRemindersStep()
            }
        }
        .id(step)
        .transition(.asymmetric(
            insertion: .move(edge: forward ? .trailing : .leading).combined(with: .opacity),
            removal: .move(edge: forward ? .leading : .trailing).combined(with: .opacity)))
    }

    // MARK: Navigation buttons

    private var buttons: some View {
        HStack(spacing: 12) {
            if step > 0 {
                Button { go(step - 1) } label: {
                    Text("السابق")
                        .font(.body.weight(.bold))
                        .foregroundStyle(Color.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 6)
                }
                .glassButton()
                .controlSize(.large)
            }
            Button { next() } label: {
                Text(needsLocation ? "اختر مدينتك أولاً" : (step < total - 1 && !(skipRest && step == 1) ? "التالي" : "ابدأ الآن"))
                    .font(.body.weight(.heavy))
                    .foregroundStyle(Color.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
            }
            .glassButton(prominent: true)
            .controlSize(.large)
            .disabled(needsLocation)
            .opacity(needsLocation ? 0.6 : 1)
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
        .padding(.bottom, step == 0 ? 6 : 20)
    }

    private var skipButton: some View {
        Button {
            // Skipping keeps one step: the city, so prayer times are never silently wrong.
            if store.bool("locationChosen") { finish() } else { skipRest = true; go(1) }
        } label: {
            Text("تخطّي")
                .font(.footnote)
                .foregroundStyle(Color.white.opacity(0.7))
                .padding(.vertical, 8)
                .padding(.horizontal, 24)
        }
        .buttonStyle(.plain)
        .padding(.bottom, 8)
    }

    // MARK: Actions

    private func go(_ s: Int) {
        Haptic.tick()
        forward = s > step
        withAnimation(.easeInOut(duration: 0.3)) { step = max(0, min(total - 1, s)) }
    }

    private func next() {
        if needsLocation { return }
        if skipRest && step == 1 { Haptic.confirm(); finish(); return }
        if step < total - 1 { go(step + 1) } else { Haptic.confirm(); finish() }
    }

    private func finish() {
        if store.bool("notify", false) { Notifier.schedulePrayers(store: store) }
        store.onboardingDone = true
    }

    private func useLocation(_ loc: CLLocation?) {
        guard let loc else { return }
        let tz = Double(TimeZone.current.secondsFromGMT()) / 3600.0
        Task {
            let name = await locator.cityName(for: loc)
            store.setCustomLocation(name: name, lat: loc.coordinate.latitude, lng: loc.coordinate.longitude, tz: tz)
            locating = false
            Haptic.confirm()
        }
    }
}

// MARK: - Background: dark patterned hero surface, full screen

private struct OnboardingBackground: View {
    var body: some View {
        ZStack {
            Brand.heroGradient
            StarPattern().foregroundStyle(Color.white.opacity(0.06))
        }
    }
}

// MARK: - Step shell (icon, title, subtitle, content)

private struct OnboardingStepShell<Content: View>: View {
    let symbol: String
    let title: String
    let subtitle: String
    @ViewBuilder var content: () -> Content

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                Image(systemName: symbol)
                    .font(.system(size: 38, weight: .semibold))
                    .foregroundStyle(Brand.gold)
                    .frame(width: 88, height: 88)
                    .glassCircle()
                    .padding(.top, 12)
                Text(title)
                    .font(.title2.weight(.heavy))
                    .multilineTextAlignment(.center)
                    .padding(.top, 20)
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundStyle(Color.white.opacity(0.8))
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
                    .padding(.top, 8)
                VStack(spacing: 8) { content() }
                    .padding(.top, 24)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 20)
        }
        .scrollIndicators(.hidden)
    }
}

// MARK: - Step 0: welcome

private struct OnboardingWelcomeStep: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                heroCard
                VStack(spacing: 12) {
                    OnboardingQuickValue(symbol: "clock.fill", title: "مواقيت الصلاة", sub: "محسوبة فلكياً لموقعك بدقّة")
                    OnboardingQuickValue(symbol: "book.fill", title: "القرآن والأدعية", sub: "المصحف كاملاً والأدعية والزيارات")
                    OnboardingQuickValue(symbol: "headphones", title: "استمع ونزّل", sub: "القرآن كاملاً والأدعية للاستماع دون إنترنت")
                }
                .padding(.top, 28)
                Label("من مفاتيح الجنان والصحيفة السجّادية والكافي · مجاني بلا إعلانات · لا يغادر شيءٌ جهازك",
                      systemImage: "checkmark.seal.fill")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(Color.white.opacity(0.85))
                    .multilineTextAlignment(.center)
                    .padding(.top, 14)
                Text("لنهيّئ التطبيق لك في أقلّ من دقيقة")
                    .font(.footnote.weight(.bold))
                    .foregroundStyle(Brand.gold)
                    .multilineTextAlignment(.center)
                    .padding(.top, 20)
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 16)
        }
        .scrollIndicators(.hidden)
    }

    private var heroCard: some View {
        VStack(spacing: 6) {
            Spacer(minLength: 0)
            StarShape()
                .stroke(Brand.gold, lineWidth: 2)
                .frame(width: 84, height: 84)
                .overlay(
                    Image(systemName: "moon.stars.fill")
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundStyle(Brand.gold)
                )
                .padding(.bottom, 18)
            Text("رفيق المؤمن")
                .font(.system(size: 30, weight: .heavy))
            Text("رفيقك إلى ربّك كل يوم")
                .font(.body.weight(.medium))
                .foregroundStyle(Color.white.opacity(0.9))
            Spacer(minLength: 0)
        }
        .padding(28)
        .frame(maxWidth: .infinity)
        .frame(height: 260)
        .glass(28)
    }
}

private struct OnboardingQuickValue: View {
    let symbol: String
    let title: String
    let sub: String

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: symbol)
                .font(.system(size: 20, weight: .semibold))
                .foregroundStyle(Brand.gold)
                .frame(width: 46, height: 46)
                .glass(14)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.body.weight(.bold))
                Text(sub)
                    .font(.caption)
                    .foregroundStyle(Color.white.opacity(0.75))
            }
            Spacer(minLength: 0)
        }
    }
}

// MARK: - Shared selectable row on the hero background

private struct OnboardingChoiceRow: View {
    let title: String
    var subtitle: String? = nil
    let on: Bool
    let action: () -> Void

    var body: some View {
        Button(action: { Haptic.tick(); action() }) {
            HStack(spacing: 12) {
                Circle()
                    .fill(on ? Brand.gold : Color.white.opacity(0.3))
                    .frame(width: 10, height: 10)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.body.weight(on ? .heavy : .medium))
                        .foregroundStyle(on ? Brand.gold : Color.white)
                        .multilineTextAlignment(.leading)
                    if let subtitle {
                        Text(subtitle)
                            .font(.caption)
                            .foregroundStyle(Color.white.opacity(0.7))
                    }
                }
                Spacer(minLength: 0)
                if on {
                    Image(systemName: "checkmark")
                        .font(.footnote.weight(.bold))
                        .foregroundStyle(Brand.gold)
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .glass(14, interactive: true)
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .strokeBorder(on ? Brand.gold : Color.clear, lineWidth: 1.5)
            )
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

// MARK: - Step 1: location (city list or current location)

private struct OnboardingLocationStep: View {
    let locator: LocationService
    @Binding var locating: Bool
    @Environment(Store.self) private var store

    private var custom: Bool { store.has("lat") && store.has("lng") }

    var body: some View {
        OnboardingStepShell(symbol: "mappin.and.ellipse", title: "أين أنت؟",
                            subtitle: "نحتاج مدينتك لحساب مواقيت الصلاة بدقّة. اختر أقرب مدينة إليك.") {
            locationButton
            if custom {
                OnboardingChoiceRow(title: store.location().n, subtitle: "موقعي", on: true) { }
            }
            ForEach(Array(Library.shared.cities.enumerated()), id: \.offset) { i, c in
                OnboardingChoiceRow(title: c.n, on: !custom && store.cityIdx == i) {
                    store.selectCity(i)
                }
            }
        }
    }

    private var locationButton: some View {
        VStack(spacing: 6) {
            Button {
                locating = true
                locator.requestLocation()
            } label: {
                HStack(spacing: 8) {
                    if locating {
                        ProgressView().tint(Color.white)
                    } else {
                        Image(systemName: "location.fill")
                    }
                    Text("استخدام موقعي الحالي")
                        .font(.body.weight(.bold))
                }
                .foregroundStyle(Color.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 6)
            }
            .glassButton(prominent: true)
            .controlSize(.large)
            .disabled(locating)
            if let err = locator.errorText {
                Text(err)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(Brand.gold)
            }
        }
        .padding(.bottom, 8)
    }
}

// MARK: - Step 2: calculation method

private struct OnboardingMethodStep: View {
    @Environment(Store.self) private var store

    private var preview: String {
        let t = store.times()
        return "\(PrayerTimes.name("fajr")) \(PrayerTimes.fmt(t.fajr)) · \(PrayerTimes.name("maghrib")) \(PrayerTimes.fmt(t.maghrib))"
    }

    var body: some View {
        OnboardingStepShell(symbol: "clock.fill", title: "طريقة حساب المواقيت",
                            subtitle: "اختر طريقة الحساب التي تعتمدها. يمكنك تغييرها لاحقاً من الإعدادات.") {
            ForEach(PrayerTimes.methods, id: \.key) { m in
                OnboardingChoiceRow(title: m.name, on: store.method == m.key) {
                    store.method = m.key
                }
            }
            Text("\(store.location().n) · \(preview)")
                .font(.footnote.weight(.semibold))
                .foregroundStyle(Color.white.opacity(0.85))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .glassCapsule()
                .padding(.top, 10)
        }
    }
}

// MARK: - Step 3: reminders

private struct OnboardingRemindersStep: View {
    @Environment(Store.self) private var store

    private var on: Bool { store.bool("notify", false) }

    var body: some View {
        OnboardingStepShell(symbol: "sparkles", title: "تذكيرات تعينك",
                            subtitle: "نُنبّهك بأوقات الصلاة وما يعينك على المداومة. يمكنك ضبط التفاصيل لاحقاً من الإعدادات.") {
            mainCard
            OnboardingReminderToggle(label: "تذكير صلاة الليل قبل الفجر", key: "laylOn")
                .padding(.top, 6)
            OnboardingReminderToggle(label: "تذكير لطيف بالأذكار خلال اليوم", key: "dhikrOn")
            Text("تقبّل الله طاعاتك 🌙")
                .font(.subheadline.weight(.bold))
                .foregroundStyle(Brand.gold)
                .multilineTextAlignment(.center)
                .padding(.top, 14)
        }
    }

    private var mainCard: some View {
        Button { toggleMain() } label: {
            VStack(spacing: 0) {
                Image(systemName: on ? "star.fill" : "clock")
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundStyle(on ? Brand.deeper : Color.white.opacity(0.85))
                    .frame(width: 64, height: 64)
                    .background(Circle().fill(on ? Brand.gold : Color.white.opacity(0.12)))
                Text(on ? "التذكيرات مفعّلة ✓" : "تفعيل التذكيرات")
                    .font(.headline.weight(.heavy))
                    .foregroundStyle(on ? Brand.gold : Color.white)
                    .padding(.top, 14)
                Text("تنبيهات أوقات الصلاة والتعقيبات بعد كلّ صلاة")
                    .font(.caption)
                    .foregroundStyle(Color.white.opacity(0.75))
                    .multilineTextAlignment(.center)
                    .padding(.top, 6)
            }
            .padding(20)
            .frame(maxWidth: .infinity)
            .glass(20, interactive: true)
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .strokeBorder(on ? Brand.gold : Color.white.opacity(0.2), lineWidth: 1.5)
            )
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(on ? .isSelected : [])
    }

    private func toggleMain() {
        Haptic.tick()
        let nv = !on
        store.put("notify", nv)
        // Turns on the useful bundle by default (prayer alerts + taqibat), as on Android.
        store.put("taqibOn", nv)
        if nv {
            Task {
                let granted = await Notifier.requestPermission()
                if granted { Notifier.schedulePrayers(store: store) }
            }
        } else {
            // Removes the pending prayer alerts (schedulePrayers clears them when notify is off).
            Notifier.schedulePrayers(store: store)
        }
    }
}

private struct OnboardingReminderToggle: View {
    let label: String
    let key: String
    @Environment(Store.self) private var store

    var body: some View {
        Toggle(isOn: Binding(
            get: { store.bool(key, false) },
            set: { v in
                store.put(key, v)
                if v { Task { _ = await Notifier.requestPermission() } }
            })) {
            Text(label)
                .font(.footnote.weight(.medium))
                .foregroundStyle(Color.white)
        }
        .tint(Brand.gold)
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
        .glass(14)
    }
}
