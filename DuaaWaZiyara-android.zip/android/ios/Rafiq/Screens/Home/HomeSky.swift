import SwiftUI

// MARK: - Home v2 first screen: sky header with the prayer arc, the tonight card, day rings and the quick row.

/// Sky header: time-of-day gradient, girih pattern, greeting + Hijri date, city pill, prayer arc, live countdown
/// and the mosque skyline at the bottom. Tapping the arc opens the full prayer-times screen.
struct HomeSkyHeader: View {
    let snap: HomeSnapshot
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.colorScheme) private var scheme

    private var night: Bool { scheme == .dark || snap.nowH < 5 || snap.nowH >= 19 }
    private var inkColor: Color { night ? Color.white : Color(hex: 0x0F3B35) }
    private var subColor: Color { night ? Color.white.opacity(0.8) : Color(hex: 0x24524B) }

    var body: some View {
        ZStack(alignment: .top) {
            Brand.skyGradient(hour: snap.nowH, dark: scheme == .dark)
            GirihPattern().foregroundStyle(.white.opacity(night ? 0.06 : 0.2))
            if night { StarField(count: 22) }
            VStack(spacing: 0) {
                Spacer(minLength: 0)
                MosqueSilhouette()
                    .fill(night ? Color.black.opacity(0.35) : Color.white.opacity(0.35))
                    .frame(height: 150)
            }
            VStack(spacing: 0) {
                topRow
                    .padding(.horizontal, 20)
                    .padding(.top, 54)
                Button { nav.openTool(.prayer) } label: { arc }
                    .buttonStyle(.plain)
                    .padding(.top, 8)
                    .accessibilityLabel("مواقيت الصلاة")
            }
        }
        .frame(height: 396)
        .clipped()
        .ignoresSafeArea(edges: .top)
    }

    private var topRow: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 2) {
                Text("السلام عليكم").font(.display(22)).foregroundStyle(inkColor)
                Button { nav.openTool(.calendar) } label: {
                    Text(verbatim: "\(Hijri.weekDays[snap.weekday]) · \(Hijri.format(snap.hijri))")
                        .font(.ui(.footnote)).foregroundStyle(subColor)
                }
                .buttonStyle(.plain)
            }
            Spacer()
            Button { nav.present(.location) } label: {
                HStack(spacing: 6) {
                    Image(systemName: "location.fill").font(.system(size: 12, weight: .bold))
                    Text(snap.city.n).font(.ui(.footnote, .semibold)).lineLimit(1)
                }
                .foregroundStyle(inkColor)
                .padding(.horizontal, 14)
                .frame(height: 40)
                .background(Color.white.opacity(night ? 0.14 : 0.35), in: Capsule())
                .overlay(Capsule().stroke(Color.white.opacity(0.6), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("المدينة")
        }
    }

    private var arc: some View {
        VStack(spacing: 0) {
            PrayerArc(snap: snap, ink: inkColor, night: night)
                .frame(height: 182)
                .padding(.horizontal, 14)
            countdown
                .padding(.top, -74)
        }
    }

    private var countdown: some View {
        VStack(spacing: 0) {
            Text(verbatim: "\(PrayerTimes.name(snap.nextKey)) بعد").font(.ui(.footnote)).foregroundStyle(subColor)
            // Live h:mm:ss in Arabic-Indic digits (Text(timerInterval:) ignores the Arabic numbering system).
            TimelineView(.periodic(from: .now, by: 1)) { ctx in
                let left = max(0, Int(snap.nextDate.timeIntervalSince(ctx.date).rounded(.down)))
                Text(verbatim: homeClock(left))
                    .font(.display(44))
                    .foregroundStyle(inkColor)
                    .monospacedDigit()
                    .lineLimit(1)
                    .minimumScaleFactor(0.6)
                    .contentTransition(.numericText(countsDown: true))
            }
            Text(verbatim: "\(PrayerTimes.fmt(PrayerTimes.value(snap.times, snap.nextKey))) · \(store.bool("notify", false) ? "الأذان مفعّل" : "الأذان غير مفعّل")")
                .font(.ui(.footnote)).foregroundStyle(subColor)
        }
        .accessibilityElement(children: .combine)
    }
}

/// The prayer arc: five nodes on a dashed path, the elapsed part since the previous prayer in gold, and the sun
/// (or moon at night) where the day stands now. Drawn in a 350×170 design box and scaled to its width.
struct PrayerArc: View {
    let snap: HomeSnapshot
    var ink: Color
    var night: Bool

    private static let angles: [String: Double] = ["fajr": 12, "dhuhr": 90, "asr": 130, "maghrib": 168, "isha": 192]
    private static let labelAt: [String: CGPoint] = [
        "fajr": CGPoint(x: 302, y: 146), "dhuhr": CGPoint(x: 175, y: 48), "asr": CGPoint(x: 91, y: 74),
        "maghrib": CGPoint(x: 48, y: 146), "isha": CGPoint(x: 28, y: 164)
    ]

    var body: some View {
        Canvas { ctx, size in
            let s = size.width / 350
            let c = CGPoint(x: 175 * s, y: 150 * s), r = 130 * s
            func pt(_ deg: Double) -> CGPoint {
                let a = deg * .pi / 180
                return CGPoint(x: c.x + r * CGFloat(cos(a)), y: c.y - r * CGFloat(sin(a)))
            }
            func arcPath(from a: Double, to b: Double) -> Path {
                var p = Path()
                let steps = max(2, Int(abs(b - a) / 2))
                for i in 0...steps {
                    let d = a + (b - a) * Double(i) / Double(steps)
                    if i == 0 { p.move(to: pt(d)) } else { p.addLine(to: pt(d)) }
                }
                return p
            }
            // Dashed day path from the right horizon over the top to the left horizon.
            ctx.stroke(arcPath(from: 0, to: 180), with: .color(.white.opacity(0.7)),
                       style: StrokeStyle(lineWidth: 3 * s, lineCap: .round, dash: [2 * s, 7 * s]))
            // Elapsed part since the previous prayer (day only).
            let prevA = PrayerArc.angles[snap.prevKey] ?? 0, nextA = PrayerArc.angles[snap.nextKey] ?? 90
            let isNight = snap.prevKey == "isha"
            var nowA = prevA
            if !isNight && nextA > prevA {
                nowA = prevA + (nextA - prevA) * snap.elapsedFraction
                ctx.stroke(arcPath(from: prevA, to: nowA), with: .color(Brand.gold),
                           style: StrokeStyle(lineWidth: 4 * s, lineCap: .round))
            }
            // Nodes.
            for key in PrayerTimes.prayerKeys {
                guard let a = PrayerArc.angles[key] else { continue }
                let p = pt(a)
                let isNext = key == snap.nextKey
                let rad = (isNext ? 7 : 5) * s
                ctx.fill(Path(ellipseIn: CGRect(x: p.x - rad, y: p.y - rad, width: rad * 2, height: rad * 2)), with: .color(.white))
                if isNext {
                    ctx.stroke(Path(ellipseIn: CGRect(x: p.x - rad, y: p.y - rad, width: rad * 2, height: rad * 2)),
                               with: .color(Brand.gold), lineWidth: 3 * s)
                }
                if let l = PrayerArc.labelAt[key] {
                    let t = Text(PrayerTimes.name(key))
                        .font(isNext ? .ui(size: 12 * s, weight: .bold) : .ui(size: 11 * s))
                        .foregroundColor(ink)
                    ctx.draw(t, at: CGPoint(x: l.x * s, y: l.y * s), anchor: .center)
                }
            }
            // Sun / moon marker.
            let m = isNight ? pt(snap.nowH >= 12 ? 192 : 12) : pt(nowA)
            if isNight {
                ctx.fill(Path(ellipseIn: CGRect(x: m.x - 9 * s, y: m.y - 9 * s, width: 18 * s, height: 18 * s)), with: .color(Brand.goldPale))
                ctx.fill(Path(ellipseIn: CGRect(x: m.x - 3 * s, y: m.y - 11 * s, width: 16 * s, height: 16 * s)), with: .color(Color(hex: 0x123F3A)))
            } else {
                ctx.fill(Path(ellipseIn: CGRect(x: m.x - 13 * s, y: m.y - 13 * s, width: 26 * s, height: 26 * s)), with: .color(Color(hex: 0xFFE7A8).opacity(0.55)))
                ctx.fill(Path(ellipseIn: CGRect(x: m.x - 8 * s, y: m.y - 8 * s, width: 16 * s, height: 16 * s)), with: .color(Color(hex: 0xF6C453)))
            }
        }
        .accessibilityHidden(true)
    }
}

/// "The night / now" card: what to read now (occasion-ranked), with listen-and-read and text-only actions.
struct HomeTonightCard: View {
    let snap: HomeSnapshot
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @State private var library = AudioLibrary.shared

    private var pick: (sg: Recommend.Suggestion, item: DuaaItem)? {
        let sg = Recommend.now(hMonth: snap.hijri.m, hDay: snap.hijri.d, weekday: snap.weekday, hour: snap.hour)
        guard let item = Library.item(sg.catId, sg.itemId) else { return nil }
        return (sg, item)
    }

    private func excerpt(_ item: DuaaItem) -> String {
        let first = item.text.split(whereSeparator: { $0.isNewline }).map(String.init).first { !$0.trimmingCharacters(in: .whitespaces).isEmpty } ?? ""
        return first.trimmingCharacters(in: .whitespaces)
    }

    var body: some View {
        if let p = pick {
            let linked = library.linked(catId: p.sg.catId, itemId: p.sg.itemId)
            ZStack(alignment: .bottomLeading) {
                Brand.heroGradient
                StarField(count: 8)
                CrescentMoon(size: 44)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                    .padding(.top, 22).padding(.trailing, 48)
                CardSkyline().fill(Color(hex: 0x0B2E2A).opacity(0.7)).frame(height: 70)
                VStack(alignment: .leading, spacing: 4) {
                    GoldTag(text: "\(snap.hour >= 17 || snap.hour < 4 ? "الليلة" : "الآن") · \(p.sg.reason)")
                    Text(p.item.title).font(.display(30)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.7).padding(.top, 4)
                    Text(excerpt(p.item)).font(.scripture(16)).foregroundStyle(.white.opacity(0.85)).lineLimit(1)
                    Spacer(minLength: 10)
                    HStack(spacing: 10) {
                        GoldButton(title: "استمع واقرأ", symbol: "play.fill") {
                            if let a = linked { AudioPlayer.shared.play(a) }
                            nav.openReader(p.sg.catId, p.sg.itemId)
                        }
                        GhostButton(title: "النصّ فقط") { nav.openReader(p.sg.catId, p.sg.itemId) }
                    }
                }
                .padding(.horizontal, 20).padding(.top, 18).padding(.bottom, 16)
            }
            .frame(height: 190)
            .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            .shadow(color: Color(hex: 0x10322D).opacity(0.28), radius: 17, y: 14)
            .environment(\.colorScheme, .dark)
        }
    }
}

/// "يومك": four rings — dua of the day, khatma verses today, Fatima's tasbih and the ziyara of the day.
struct HomeDayRings: View {
    let snap: HomeSnapshot
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav

    private static let ziyaraOfDay: [(String, String)] = [
        ("ziyarat", "z-amin"), ("ziyarat", "z-mutlaqa"), ("ziyarat", "z-baqi"), ("ziyarat", "z-kadhim"),
        ("ziyarat", "z-askari"), ("ziyarat", "z-yasin"), ("ziyarat", "z-nabi")
    ]
    private static let weekdayDua = ["d-sun", "d-mon", "d-tue", "d-wed", "d-thu", "d-fri", "d-sat"]

    private func isOn(_ bit: Int) -> Bool { store.wirdMask & (1 << bit) != 0 }

    var body: some View {
        let duaId = HomeDayRings.weekdayDua[snap.weekday]
        let z = HomeDayRings.ziyaraOfDay[snap.weekday]
        let verses = QuranProgress.today(store), goal = max(1, QuranProgress.goal(store))
        let khatmaFrac = min(1, Double(verses) / Double(goal))
        let zRead = store.recentReads.first.map { $0.0 == z.0 && $0.1 == z.1 } ?? false
        let done = [isOn(0), khatmaFrac >= 1, isOn(1), zRead].filter { $0 }.count
        VStack(alignment: .leading, spacing: 10) {
            SectionHeading("يومك") { Text(verbatim: "\(done.ar) من ٤ مكتملة").foregroundStyle(Brand.muted) }
            HStack(spacing: 8) {
                ring(title: "دعاء اليوم", fraction: isOn(0) ? 1 : 0, check: isOn(0)) {
                    if !isOn(0) { store.toggleWird(0) }
                    nav.openReader("osboo", duaId)
                }
                ring(title: "ختمتي \(verses.ar)/\(goal.ar)", fraction: khatmaFrac, check: khatmaFrac >= 1, color: Brand.gold, label: verses.ar) {
                    nav.openTool(.khatma)
                }
                ring(title: "تسبيح الزهراء", fraction: isOn(1) ? 1 : 0, check: isOn(1)) {
                    if !isOn(1) { store.toggleWird(1) }
                    nav.present(.tasbih)
                }
                ring(title: "زيارة اليوم", fraction: zRead ? 1 : 0, check: zRead, pending: !zRead) {
                    nav.openReader(z.0, z.1)
                }
            }
        }
    }

    private func ring(title: String, fraction: Double, check: Bool, color: Color = Brand.emerald, label: String? = nil,
                      pending: Bool = false, action: @escaping () -> Void) -> some View {
        Button { Haptic.tick(); action() } label: {
            VStack(spacing: 6) {
                RingProgress(fraction: fraction, size: 46, lineWidth: 5, color: color) {
                    if check {
                        Image(systemName: "checkmark").font(.system(size: 15, weight: .bold)).foregroundStyle(color)
                    } else if let label {
                        Text(label).font(.ui(size: 11, weight: .bold)).foregroundStyle(Brand.ink)
                    } else if pending {
                        Image(systemName: "clock").font(.system(size: 15, weight: .semibold)).foregroundStyle(Brand.emerald)
                    }
                }
                Text(title).font(.ui(.caption, .semibold)).foregroundStyle(Brand.ink).lineLimit(1).minimumScaleFactor(0.8)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12).padding(.horizontal, 4)
            .background(Brand.cardFill, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(title)
        .accessibilityValue(check ? "مكتمل" : "لم يكتمل")
    }
}

/// Quick row: qibla, tasbih, calendar.
struct HomeQuickRow: View {
    @Environment(AppNav.self) private var nav
    var body: some View {
        HStack(spacing: 8) {
            SoftPill(symbol: "safari", title: "القبلة") { nav.openTool(.qibla) }
            SoftPill(symbol: "circle.hexagongrid", title: "السبحة") { nav.present(.tasbih) }
            SoftPill(symbol: "calendar", title: "التقويم") { nav.openTool(.calendar) }
        }
    }
}

/// h:mm:ss (or m:ss under an hour) in Arabic-Indic digits.
func homeClock(_ seconds: Int) -> String {
    let h = seconds / 3600, m = (seconds % 3600) / 60, sec = seconds % 60
    let core = h > 0 ? String(format: "%d:%02d:%02d", h, m, sec) : String(format: "%d:%02d", m, sec)
    return core.arabicDigits
}
