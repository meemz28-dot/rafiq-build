import SwiftUI

// MARK: - ما الجديد: shown once after each update (an actively maintained app, visibly)

enum WhatsNew {
    static let seenKey = "whatsNewSeen"
    static var version: String { Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "" }

    struct Item: Identifiable { let id = UUID(); let symbol: String; let title: String; let detail: String }

    /// Highlights of this version (update with every release).
    static let items: [Item] = [
        Item(symbol: "sparkles", title: "تصميمٌ جديد أبسط",
             detail: "أربعة أقسام: الرئيسية والأدعية واستمع والأدوات. قوس الصلاة والعدّ الحيّ في الصفحة الأولى، وبطاقة «الليلة» بما يُقرأ الآن، وكلّ الميزات في مكانها."),
        Item(symbol: "text.book.closed.fill", title: "قارئٌ غامر",
             detail: "النصّ على ورق هادئ بخطّ أميري، خيط تقدّم ذهبي، لوحة Aa للخطّ والوضع، والسطر الحالي يُضاء مع الصوت أو التمرير التلقائي."),
        Item(symbol: "book.closed.fill", title: "ختمتي",
             detail: "تقدّمك في القرآن آيةً آية بحسب قراءتك الفعلية وبسرعتك، مع وِردٍ يوميّ وخطّة ختمة."),
        Item(symbol: "headphones", title: "استمع ونزّل",
             detail: "القرآن كاملاً بقارئك المفضّل، وأشهر الأدعية بضغطة، ومقترح لكلّ وقت. يكمل التسجيل الطويل من حيث توقفت، وينزّل عبر Wi‑Fi إن شئت."),
        Item(symbol: "square.grid.2x2.fill", title: "ويدجت جديدة",
             detail: "عدّ تنازلي حيّ للصلاة مع شريط تقدّم، وويدجت «اليوم» بالمناسبة القادمة وحكمة اليوم، وسبحة تسبّح بها من الشاشة الرئيسية مباشرة."),
        Item(symbol: "bell.badge.fill", title: "أذانٌ لا يفوتك",
             detail: "يُعاد ضبط التنبيهات تلقائياً في الخلفية، مع تذكيرٍ اختياريّ قبل الأذان."),
        Item(symbol: "person.2.fill", title: "مناسباتي",
             detail: "ذكرى وفاة عزيز أو مولدٌ أو نذر، تتكرّر كلّ عامٍ بالتاريخ الهجري ويذكّرك بها التطبيق."),
        Item(symbol: "location.north.line.fill", title: "قبلةٌ أدقّ وبوصلة الزيارة",
             detail: "من موقعك الحالي، مع التحقّق بالشمس دون بوصلة، والتوجّه إلى كربلاء والنجف ومشهد."),
        Item(symbol: "checkmark.seal.fill", title: "المصادر والمرجع",
             detail: "صفحةٌ توضّح مصدر كلّ نصّ، واختيار مرجع التقليد في أدوات الخمس والقضاء.")
    ]

    /// True once per version, never on a fresh install (onboarding covers that).
    static func shouldShow(_ store: Store) -> Bool {
        guard store.onboardingDone else { return false }
        let seen = store.string(seenKey)
        if seen.isEmpty { store.put(seenKey, version); return false }   // first launch after install
        return seen != version
    }
}

struct WhatsNewView: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(spacing: 8) {
                    Image(systemName: "sparkles").font(.system(size: 40)).foregroundStyle(Brand.gold)
                    Text("ما الجديد").font(.largeTitle.weight(.heavy))
                    Text("الإصدار \(WhatsNew.version.arabicDigits)").font(.subheadline).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.top, 24)
                ForEach(WhatsNew.items) { it in
                    HStack(alignment: .top, spacing: 14) {
                        Image(systemName: it.symbol)
                            .font(.title2)
                            .foregroundStyle(Brand.emerald)
                            .frame(width: 36)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(it.title).font(.headline)
                            Text(it.detail).font(.subheadline).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .padding(24)
        }
        .safeAreaInset(edge: .bottom) {
            Button {
                store.put(WhatsNew.seenKey, WhatsNew.version)
                dismiss()
            } label: {
                Text("متابعة").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 6)
            }
            .buttonStyle(.borderedProminent)
            .tint(Brand.emerald)
            .controlSize(.large)
            .padding(.horizontal, 24)
            .padding(.bottom, 12)
        }
        .onDisappear { store.put(WhatsNew.seenKey, WhatsNew.version) }
    }
}
