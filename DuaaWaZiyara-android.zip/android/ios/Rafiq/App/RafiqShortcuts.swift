import Foundation
import AppIntents

/// "ما الصلاة القادمة؟" answered by Siri without opening the app.
struct NextPrayerIntent: AppIntent {
    static var title: LocalizedStringResource = "الصلاة القادمة"
    static var description = IntentDescription("يخبرك بالصلاة القادمة ووقتها والمدّة المتبقية")

    @MainActor func perform() async throws -> some IntentResult & ProvidesDialog {
        let store = Store()
        let t = store.times()
        let nx = PrayerTimes.next(t, nowHours: PrayerTimes.nowHours())
        let text = "صلاة \(PrayerTimes.name(nx.key)) الساعة \(PrayerTimes.fmt(PrayerTimes.value(t, nx.key))) في \(store.location().n)، بعد \(PrayerTimes.countdown(nx.hours))."
        return .result(dialog: IntentDialog(stringLiteral: text))
    }
}

struct RafiqShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: NextPrayerIntent(),
                    phrases: ["الصلاة القادمة في \(.applicationName)", "متى الصلاة في \(.applicationName)"],
                    shortTitle: "الصلاة القادمة", systemImageName: "clock.fill")
        AppShortcut(intent: OpenRafiqIntent(destination: .tasbih),
                    phrases: ["ابدأ التسبيح في \(.applicationName)", "افتح السبحة في \(.applicationName)"],
                    shortTitle: "التسبيح", systemImageName: "circle.dotted")
        AppShortcut(intent: OpenRafiqIntent(destination: .qibla),
                    phrases: ["اتجاه القبلة في \(.applicationName)"],
                    shortTitle: "القبلة", systemImageName: "location.north.line")
        AppShortcut(intent: OpenRafiqIntent(destination: .kumayl),
                    phrases: ["افتح دعاء كميل في \(.applicationName)"],
                    shortTitle: "دعاء كميل", systemImageName: "book.fill")
        AppShortcut(intent: OpenRafiqIntent(),
                    phrases: ["افتح \(\.$destination) في \(.applicationName)"],
                    shortTitle: "فتح", systemImageName: "sparkles")
    }
}
