import Foundation
import AppIntents

/// "ما الصلاة القادمة؟" answered by Siri without opening the app.
struct NextPrayerIntent: AppIntent {
    static var title: LocalizedStringResource = "الصلاة القادمة"
    static var description = IntentDescription("يخبرك بالصلاة القادمة ووقتها والمدّة المتبقية")

    @MainActor func perform() async throws -> some IntentResult & ProvidesDialog {
        let store = Store()
        let t = store.times()
        let nx = PrayerTimes.next(t, nowHours: PrayerTimes.nowHours())
        let text = "صلاة \(PrayerTimes.name(nx.key)) الساعة \(PrayerTimes.fmt(PrayerTimes.value(t, nx.key))) في \(store.location().n)، بعد \(PrayerTimes.countdown(nx.hours))."
        return .result(dialog: IntentDialog(stringLiteral: text))
    }
}

/// Famous duas Siri can play: "شغّل دعاء كميل في رفيق المؤمن".
enum AudioDua: String, AppEnum {
    case kumayl, tawassul, ahd, nudba, ashura, warith, samat, sabah, iftitah, jamia

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "دعاء"
    static var caseDisplayRepresentations: [AudioDua: DisplayRepresentation] = [
        .kumayl: "دعاء كميل", .tawassul: "دعاء التوسل", .ahd: "دعاء العهد", .nudba: "دعاء الندبة",
        .ashura: "زيارة عاشوراء", .warith: "زيارة وارث", .samat: "دعاء السمات", .sabah: "دعاء الصباح",
        .iftitah: "دعاء الافتتاح", .jamia: "الزيارة الجامعة"
    ]

    var itemId: String {
        switch self {
        case .kumayl: return "m-kumayl"
        case .tawassul: return "m-tawassul"
        case .ahd: return "m-ahd"
        case .nudba: return "m-nudba"
        case .ashura: return "z-ashura"
        case .warith: return "z-warith"
        case .samat: return "j-samat"
        case .sabah: return "sb-sabah-ali"
        case .iftitah: return "m-iftitah"
        case .jamia: return "z-jamia"
        }
    }
}

/// Plays the recording linked to a dua, in the background (lock screen, CarPlay audio, AirPods).
struct PlayDuaIntent: AudioPlaybackIntent {
    static var title: LocalizedStringResource = "تشغيل دعاء"
    static var description = IntentDescription("يشغّل التسجيل المربوط بالدعاء من مكتبتك")

    @Parameter(title: "الدعاء", default: .kumayl) var dua: AudioDua

    init() {}
    init(dua: AudioDua) { self.dua = dua }

    @MainActor func perform() async throws -> some IntentResult & ProvidesDialog {
        guard let c = ListenDiscover.find(dua.itemId),
              let a = AudioLibrary.shared.linked(catId: c.catId, itemId: c.itemId) else {
            return .result(dialog: "لم تربط تسجيلاً بهذا الدعاء بعد. افتح «استمع» واضغط على الدعاء لاختيار تسجيل.")
        }
        AudioPlayer.shared.play(a)
        return .result(dialog: IntentDialog(stringLiteral: "تشغيل \(c.title)"))
    }
}

struct RafiqShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: NextPrayerIntent(),
                    phrases: ["الصلاة القادمة في \(.applicationName)", "متى الصلاة في \(.applicationName)"],
                    shortTitle: "الصلاة القادمة", systemImageName: "clock.fill")
        AppShortcut(intent: OpenRafiqIntent(destination: .tasbih),
                    phrases: ["ابدأ التسبيح في \(.applicationName)", "افتح السبحة في \(.applicationName)"],
                    shortTitle: "التسبيح", systemImageName: "circle.dotted")
        AppShortcut(intent: OpenRafiqIntent(destination: .qibla),
                    phrases: ["اتجاه القبلة في \(.applicationName)"],
                    shortTitle: "القبلة", systemImageName: "location.north.line")
        AppShortcut(intent: OpenRafiqIntent(destination: .kumayl),
                    phrases: ["افتح دعاء كميل في \(.applicationName)"],
                    shortTitle: "دعاء كميل", systemImageName: "book.fill")
        AppShortcut(intent: PlayDuaIntent(),
                    phrases: ["شغّل \(\.$dua) في \(.applicationName)", "استمع إلى \(\.$dua) في \(.applicationName)"],
                    shortTitle: "تشغيل دعاء", systemImageName: "play.circle.fill")
        AppShortcut(intent: OpenRafiqIntent(),
                    phrases: ["افتح \(\.$destination) في \(.applicationName)"],
                    shortTitle: "فتح", systemImageName: "sparkles")
    }
}
