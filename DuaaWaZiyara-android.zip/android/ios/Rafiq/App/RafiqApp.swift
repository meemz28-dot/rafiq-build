import SwiftUI
import UIKit
import Observation

/// Lets iOS hand background download events back to the audio library.
final class RafiqAppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        // v2 type: navigation titles in the display face (Reem Kufi) on every pushed screen.
        let nav = UINavigationBar.appearance()
        if let large = UIFont(name: "ReemKufi-Bold", size: 30), let small = UIFont(name: "ReemKufi-SemiBold", size: 17) {
            nav.largeTitleTextAttributes = [.font: large]
            nav.titleTextAttributes = [.font: small]
        }
        return true
    }

    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        AudioLibrary.shared.backgroundCompletion = completionHandler
    }
}

@main
struct RafiqApp: App {
    @UIApplicationDelegateAdaptor(RafiqAppDelegate.self) private var appDelegate
    @State private var store = Store()
    @State private var nav = AppNav.shared

    var body: some Scene {
        WindowGroup {
            RootView()
                .onAppear { Store.main = store }
                .environment(store)
                .environment(nav)
                // App-wide native scrolling: bounce only when content is taller than the screen.
                .scrollBounceBehavior(.basedOnSize)
                .scrollDismissesKeyboard(.interactively)
                .environment(\.layoutDirection, .rightToLeft)
                .environment(\.locale, Locale(identifier: "ar"))
                .environment(\.font, .ui(.body))
                .tint(Brand.emerald)
                .preferredColorScheme(store.theme == "dark" ? .dark : store.theme == "light" ? .light : nil)
        }
        // Woken by iOS every few hours: re-arm the adhan and all reminders, then ask to be woken again.
        .backgroundTask(.appRefresh(BackgroundRefresh.identifier)) {
            await BackgroundRefresh.rearmAll()
            BackgroundRefresh.submit()
        }
    }
}

// MARK: - Navigation model

/// Four tabs (v2): الرئيسية، الأدعية، استمع، الأدوات. Prayer times are a pushed screen (`Tool.prayer`).
enum AppTab: String, Hashable, CaseIterable { case home, library, listen, more }

/// Every full screen reachable in the app (same keys as the Android routes).
enum Tool: String, Hashable, CaseIterable, Identifiable {
    case khira, weekly, asma, masoom, khums, tracker, layl, hajj, ashura, qibla, muhasaba
    case journey, trait, amaal, qada, khatma, converter, ptable, qpoints, shrine, listen, calendar
    case prayer, allTools
    var id: String { rawValue }

    var title: String {
        switch self {
        case .prayer: return "مواقيت الصلاة"
        case .allTools: return "كلّ الأدوات"
        case .khira: return "خِيرة القرآن"
        case .weekly: return "البرنامج الأسبوعي"
        case .asma: return "أسماء الله الحسنى"
        case .masoom: return "المعصومون (ع)"
        case .khums: return "حاسبة الخُمس"
        case .tracker: return "عدّاد الركعات"
        case .layl: return "دليل صلاة الليل"
        case .hajj: return "الحجّ والعمرة"
        case .ashura: return "زيارة عاشوراء"
        case .qibla: return "اتجاه القبلة"
        case .muhasaba: return "محاسبة النفس"
        case .journey: return "رحلتي"
        case .trait: return "صفة الشهر"
        case .amaal: return "المستحبّات"
        case .qada: return "قضاء الصلوات"
        case .khatma: return "ختمتي"
        case .converter: return "محوّل التاريخ"
        case .ptable: return "مواقيت الأسبوع"
        case .qpoints: return "نقاط القرآن والختمة"
        case .shrine: return "بوصلة الزيارة"
        case .listen: return "استمع"
        case .calendar: return "التقويم"
        }
    }

    var symbol: String {
        switch self {
        case .prayer: return "clock.fill"
        case .allTools: return "square.grid.2x2"
        case .khira: return "sparkle"
        case .weekly: return "calendar.day.timeline.right"
        case .asma: return "sparkles"
        case .masoom: return "building.columns"
        case .khums: return "percent"
        case .tracker: return "figure.mind.and.body"
        case .layl: return "moon.stars"
        case .hajj: return "location.north.circle"
        case .ashura: return "flag"
        case .qibla: return "location.north.line"
        case .muhasaba: return "checklist"
        case .journey: return "star"
        case .trait: return "leaf"
        case .amaal: return "calendar.badge.clock"
        case .qada: return "arrow.counterclockwise.circle"
        case .khatma: return "book.closed"
        case .converter: return "arrow.left.arrow.right"
        case .ptable: return "tablecells"
        case .qpoints: return "rosette"
        case .shrine: return "building.columns.circle"
        case .listen: return "headphones"
        case .calendar: return "moon.fill"
        }
    }
}

enum Route: Hashable {
    case category(String)
    case reader(String, String)        // category id, item id
    case tool(Tool)
    case masoom(Int)                  // index into Library.shared.masoomeen
    case hajjGuide(String)            // "umrah" or "hajj"
}

enum SheetKind: String, Identifiable {
    case tasbih, favorites, bookmarks, settings, about, location, method, whatsNew
    var id: String { rawValue }
}

@Observable
final class AppNav {
    static let shared = AppNav()
    var tab: AppTab = .home
    var paths: [AppTab: [Route]] = [:]
    var sheet: SheetKind?
    /// Search text the next opened reader should jump to (set by a search result tap).
    var pendingFind: String?
    /// Search text and dua link target for the Listen screen (set from the reader).
    var pendingListen: String?
    var pendingLinkTarget: String?

    func path(_ t: AppTab) -> [Route] { paths[t] ?? [] }
    /// Pushes a route on the current tab.
    func open(_ r: Route) { paths[tab, default: []].append(r) }
    func openReader(_ c: String, _ i: String) { open(.reader(c, i)) }
    func openTool(_ t: Tool) { open(.tool(t)) }
    func present(_ s: SheetKind) { sheet = s }
    func popToRoot() { paths[tab] = [] }
}

// MARK: - Root

struct RootView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        @Bindable var nav = nav
        Group {
            if !store.onboardingDone {
                OnboardingView().environment(\.colorScheme, .dark)
            } else {
                TabView(selection: $nav.tab) {
                    Tab("الرئيسية", systemImage: "house.fill", value: AppTab.home) { stack(.home) { HomeView() } }
                    Tab("الأدعية", systemImage: "book.fill", value: AppTab.library) { stack(.library) { LibraryView() } }
                    Tab("استمع", systemImage: "headphones", value: AppTab.listen) { stack(.listen) { ListenView() } }
                    Tab("الأدوات", systemImage: "square.grid.2x2.fill", value: AppTab.more) { stack(.more) { MoreView() } }
                }
                .tint(Brand.accent)
                // The v2 floating tab bar (the system bar is hidden on every tab root); it steps aside on pushed screens.
                .overlay(alignment: .bottom) {
                    VStack(spacing: 10) {
                        MiniPlayerBar()
                        if nav.path(nav.tab).isEmpty {
                            RafiqTabBar(selection: $nav.tab)
                                .transition(.move(edge: .bottom).combined(with: .opacity))
                        }
                    }
                    .padding(.bottom, nav.path(nav.tab).isEmpty ? 22 : 10)
                    .ignoresSafeArea(.container, edges: .bottom)
                    .animation(.easeInOut(duration: 0.2), value: nav.path(nav.tab).isEmpty)
                }
                .onAppear {
                    applyDebugLaunch()
                    if nav.sheet == nil && WhatsNew.shouldShow(store) { nav.sheet = .whatsNew }
                    RafiqIntentBridge.handler = { route($0) }
                    if let p = UserDefaults.standard.string(forKey: RafiqIntentBridge.pendingKey) {
                        UserDefaults.standard.removeObject(forKey: RafiqIntentBridge.pendingKey)
                        route(p)
                    }
                }
                // Widget taps open rafiq://prayer
                .onOpenURL { url in
                    // Audio shared from WhatsApp, Telegram, Files… ("Open in رفيق المؤمن")
                    if url.isFileURL {
                        if AudioLibrary.shared.importFile(url) != nil { nav.openTool(.listen) }
                        return
                    }
                    guard url.scheme == "rafiq" else { return }
                    let host = url.host ?? ""
                    if let t = AppTab(rawValue: host) { nav.tab = t }
                    else if host == "prayer" { nav.tab = .home; nav.openTool(.prayer) }
                    else if let tool = Tool(rawValue: host) { nav.openTool(tool) }
                }
                // iOS has no boot receiver: re-arm every reminder whenever the app becomes active
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active {
                        PrayerRoutines.refreshAll(store: store)
                        KhumsReminder.reschedule(store)
                        PrayerLive.refresh(store: store)
                        PersonalOccasions.reschedule(store)
                        BackgroundRefresh.submit()
                    }
                }
                .sheet(item: $nav.sheet) { kind in
                    sheetView(kind)
                        .environment(store).environment(nav)
                        .environment(\.layoutDirection, .rightToLeft)
                }
            }
        }
    }

    /// Opens a destination requested by Siri, Shortcuts, a control or a widget.
    private func route(_ raw: String) {
        guard let d = RafiqDestination(rawValue: raw) else { return }
        let nav = AppNav.shared
        nav.sheet = nil
        switch d {
        case .prayer: nav.openTool(.prayer)
        case .tasbih: nav.sheet = .tasbih
        case .qibla: nav.openTool(.qibla)
        case .shrine: nav.openTool(.shrine)
        case .khira: nav.openTool(.khira)
        case .ashura: nav.openTool(.ashura)
        case .kumayl: nav.openReader("mashhura", "m-kumayl")
        case .tawassul: nav.openReader("mashhura", "m-tawassul")
        case .sabah: nav.openReader("sabah", "sb-sabah-ali")
        }
    }

    /// Simulator screenshots only: launch arguments like `-debugTab prayer -debugTool khira -debugSheet tasbih`
    /// arrive in UserDefaults' argument domain (never persisted), so release use is unaffected.
    private func applyDebugLaunch() {
        let d = UserDefaults.standard
        if let t = d.string(forKey: "debugTab") {
            if let tab = AppTab(rawValue: t) { nav.tab = tab } else if t == "prayer" { nav.openTool(.prayer) }
        }
        if let t = d.string(forKey: "debugTool"), let tool = Tool(rawValue: t) { nav.openTool(tool) }
        if let r = d.string(forKey: "debugReader") {
            let p = r.split(separator: "/").map(String.init)
            if p.count == 2 { nav.openReader(p[0], p[1]) }
        }
        if let c = d.string(forKey: "debugCategory") { nav.open(.category(c)) }
        if let g = d.string(forKey: "debugHajjGuide") { nav.openTool(.hajj); nav.open(.hajjGuide(g)) }
        if let q = d.string(forKey: "debugListen") { nav.pendingListen = q; nav.openTool(.listen) }
        if d.bool(forKey: "debugSeedPersonal") {
            // Screenshots only: one anniversary tomorrow, one birth and one vow later in the year.
            let h = store.hijriToday()
            let tomorrowDay = h.d < 29 ? h.d + 1 : 1
            let tomorrowMonth = h.d < 29 ? h.m : (h.m % 12) + 1
            PersonalOccasions.save(store, [
                PersonalOccasion(name: "الوالد رحمه الله", kind: .death, month: tomorrowMonth, day: tomorrowDay, year: h.y - 8),
                PersonalOccasion(name: "ميلاد علي", kind: .birth, month: 7, day: 13),
                PersonalOccasion(name: "نذر زيارة", kind: .vow, month: 9, day: 1, daysBefore: 3)
            ])
        }
        if let s = d.string(forKey: "debugSheet"), let k = SheetKind(rawValue: s) { nav.sheet = k }
    }

    private func stack<V: View>(_ t: AppTab, @ViewBuilder _ root: () -> V) -> some View {
        NavigationStack(path: Binding(get: { nav.path(t) }, set: { nav.paths[t] = $0 })) {
            root()
                .navigationDestination(for: Route.self) { destination($0) }
                .toolbar(.hidden, for: .tabBar)
                // Room for the floating bar (and the mini player) above the home indicator.
                .safeAreaInset(edge: .bottom, spacing: 0) { Color.clear.frame(height: 78) }
        }
        .toolbar(.hidden, for: .tabBar)
    }

    @ViewBuilder private func destination(_ r: Route) -> some View {
        switch r {
        case .category(let c): CategoryView(catId: c)
        case .reader(let c, let i): ReaderView(catId: c, itemId: i)
        case .tool(let t): toolView(t)
        case .masoom(let i): MasoomeenDetailScreen(index: i)
        case .hajjGuide(let r): HajjGuideScreen(ritual: r)
        }
    }

    @ViewBuilder private func toolView(_ t: Tool) -> some View {
        switch t {
        case .khira: KhiraView()
        case .weekly: WeeklyView()
        case .asma: AsmaView()
        case .masoom: MasoomeenView()
        case .khums: KhumsView()
        case .tracker: TrackerView()
        case .layl: LaylView()
        case .hajj: HajjView()
        case .ashura: AshuraView()
        case .qibla: QiblaView()
        case .muhasaba: MuhasabaView()
        case .journey: JourneyView()
        case .trait: TraitView()
        case .amaal: AmaalView()
        case .qada: QadaView()
        case .khatma: QuranPointsView()
        case .converter: ConverterView()
        case .ptable: PrayerTableView()
        case .qpoints: QuranPointsView()
        case .shrine: QiblaView(shrineMode: true)
        case .listen: ListenView()
        case .calendar: CalendarView()
        case .prayer: PrayerView()
        case .allTools: AllToolsView()
        }
    }

    @ViewBuilder private func sheetView(_ k: SheetKind) -> some View {
        switch k {
        case .tasbih: TasbihView()
        case .favorites: NavigationStack { FavoritesView() }
        case .bookmarks: NavigationStack { BookmarksView() }
        case .settings: NavigationStack { SettingsView() }
        case .about: NavigationStack { AboutView() }
        case .location: NavigationStack { LocationView() }
        case .method: NavigationStack { MethodView() }
        case .whatsNew: WhatsNewView()
        }
    }
}


// MARK: - Floating tab bar (v2)

struct RafiqTabBar: View {
    @Binding var selection: AppTab
    @Environment(\.colorScheme) private var scheme

    private let items: [(AppTab, String, String, String)] = [
        (.home, "الرئيسية", "house", "house.fill"),
        (.library, "الأدعية", "book", "book.fill"),
        (.listen, "استمع", "headphones", "headphones"),
        (.more, "الأدوات", "square.grid.2x2", "square.grid.2x2.fill")
    ]

    var body: some View {
        HStack(spacing: 0) {
            ForEach(items, id: \.0) { it in
                let on = selection == it.0
                Button {
                    if on { AppNav.shared.popToRoot() } else { selection = it.0 }
                    Haptic.tick()
                } label: {
                    VStack(spacing: 3) {
                        Image(systemName: on ? it.3 : it.2)
                            .font(.system(size: 22, weight: on ? .semibold : .regular))
                            .frame(height: 24)
                        Text(it.1).font(.ui(.caption2, .semibold))
                    }
                    .foregroundStyle(on ? Brand.accent : Brand.muted)
                    .frame(maxWidth: .infinity)
                    .frame(height: 64)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(it.1)
                .accessibilityAddTraits(on ? AccessibilityTraits([.isSelected, .isButton]) : AccessibilityTraits.isButton)
            }
        }
        .background((scheme == .dark ? Color(hex: 0x182B29).opacity(0.85) : Color.white.opacity(0.78)), in: RoundedRectangle(cornerRadius: 32, style: .continuous))
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 32, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 32, style: .continuous).stroke(scheme == .dark ? Color.white.opacity(0.1) : Color.white.opacity(0.9), lineWidth: 1))
        .shadow(color: Color(hex: 0x10322D).opacity(scheme == .dark ? 0.4 : 0.16), radius: 15, y: 10)
        .padding(.horizontal, 16)
    }
}
