import SwiftUI
import Observation

@main
struct RafiqApp: App {
    @State private var store = Store()
    @State private var nav = AppNav()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(store)
                .environment(nav)
                .environment(\.layoutDirection, .rightToLeft)
                .environment(\.locale, Locale(identifier: "ar"))
                .tint(Brand.emerald)
                .preferredColorScheme(store.theme == "dark" ? .dark : store.theme == "light" ? .light : nil)
        }
    }
}

// MARK: - Navigation model

enum AppTab: String, Hashable, CaseIterable { case home, library, prayer, calendar, more }

/// Every full screen reachable in the app (same keys as the Android routes).
enum Tool: String, Hashable, CaseIterable, Identifiable {
    case khira, weekly, asma, masoom, khums, tracker, layl, hajj, ashura, qibla, muhasaba
    case journey, trait, amaal, qada, khatma, converter, ptable, qpoints
    var id: String { rawValue }

    var title: String {
        switch self {
        case .khira: return "خِيرة القرآن"
        case .weekly: return "البرنامج الأسبوعي"
        case .asma: return "أسماء الله الحسنى"
        case .masoom: return "المعصومون (ع)"
        case .khums: return "حاسبة الخُمس"
        case .tracker: return "عدّاد الركعات"
        case .layl: return "دليل صلاة الليل"
        case .hajj: return "الحجّ والعمرة"
        case .ashura: return "زيارة عاشوراء"
        case .qibla: return "اتجاه القبلة"
        case .muhasaba: return "محاسبة النفس"
        case .journey: return "رحلتي"
        case .trait: return "صفة الشهر"
        case .amaal: return "المستحبّات"
        case .qada: return "قضاء الصلوات"
        case .khatma: return "الختمة"
        case .converter: return "محوّل التاريخ"
        case .ptable: return "مواقيت الأسبوع"
        case .qpoints: return "نقاط القرآن"
        }
    }

    var symbol: String {
        switch self {
        case .khira: return "sparkle"
        case .weekly: return "calendar.day.timeline.right"
        case .asma: return "sparkles"
        case .masoom: return "building.columns"
        case .khums: return "percent"
        case .tracker: return "figure.mind.and.body"
        case .layl: return "moon.stars"
        case .hajj: return "location.north.circle"
        case .ashura: return "flag"
        case .qibla: return "location.north.line"
        case .muhasaba: return "checklist"
        case .journey: return "star"
        case .trait: return "leaf"
        case .amaal: return "calendar.badge.clock"
        case .qada: return "arrow.counterclockwise.circle"
        case .khatma: return "book.closed"
        case .converter: return "arrow.left.arrow.right"
        case .ptable: return "tablecells"
        case .qpoints: return "rosette"
        }
    }
}

enum Route: Hashable {
    case category(String)
    case reader(String, String)        // category id, item id
    case tool(Tool)
    case masoom(Int)                  // index into Library.shared.masoomeen
    case hajjGuide(String)            // "umrah" or "hajj"
}

enum SheetKind: String, Identifiable {
    case tasbih, favorites, bookmarks, settings, about, location, method
    var id: String { rawValue }
}

@Observable
final class AppNav {
    var tab: AppTab = .home
    var paths: [AppTab: [Route]] = [:]
    var sheet: SheetKind?

    func path(_ t: AppTab) -> [Route] { paths[t] ?? [] }
    /// Pushes a route on the current tab.
    func open(_ r: Route) { paths[tab, default: []].append(r) }
    func openReader(_ c: String, _ i: String) { open(.reader(c, i)) }
    func openTool(_ t: Tool) { open(.tool(t)) }
    func present(_ s: SheetKind) { sheet = s }
    func popToRoot() { paths[tab] = [] }
}

// MARK: - Root

struct RootView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        @Bindable var nav = nav
        Group {
            if !store.onboardingDone {
                OnboardingView()
            } else {
                TabView(selection: $nav.tab) {
                    Tab("الرئيسية", systemImage: "house.fill", value: AppTab.home) { stack(.home) { HomeView() } }
                    Tab("الفهرس", systemImage: "books.vertical.fill", value: AppTab.library) { stack(.library) { LibraryView() } }
                    Tab("الأوقات", systemImage: "clock.fill", value: AppTab.prayer) { stack(.prayer) { PrayerView() } }
                    Tab("التقويم", systemImage: "moon.fill", value: AppTab.calendar) { stack(.calendar) { CalendarView() } }
                    Tab("المزيد", systemImage: "square.grid.2x2.fill", value: AppTab.more) { stack(.more) { MoreView() } }
                }
                .minimizeTabBarOnScroll()
                .onAppear { applyDebugLaunch() }
                // Widget taps open rafiq://prayer
                .onOpenURL { url in
                    if url.scheme == "rafiq", let t = AppTab(rawValue: url.host ?? "") { nav.tab = t }
                }
                // iOS has no boot receiver: re-arm every reminder whenever the app becomes active
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active {
                        PrayerRoutines.refreshAll(store: store)
                        KhumsReminder.reschedule(store)
                    }
                }
                .sheet(item: $nav.sheet) { kind in
                    sheetView(kind)
                        .environment(store).environment(nav)
                        .environment(\.layoutDirection, .rightToLeft)
                }
            }
        }
    }

    /// Simulator screenshots only: launch arguments like `-debugTab prayer -debugTool khira -debugSheet tasbih`
    /// arrive in UserDefaults' argument domain (never persisted), so release use is unaffected.
    private func applyDebugLaunch() {
        let d = UserDefaults.standard
        if let t = d.string(forKey: "debugTab"), let tab = AppTab(rawValue: t) { nav.tab = tab }
        if let t = d.string(forKey: "debugTool"), let tool = Tool(rawValue: t) { nav.openTool(tool) }
        if let r = d.string(forKey: "debugReader") {
            let p = r.split(separator: "/").map(String.init)
            if p.count == 2 { nav.openReader(p[0], p[1]) }
        }
        if let c = d.string(forKey: "debugCategory") { nav.open(.category(c)) }
        if let s = d.string(forKey: "debugSheet"), let k = SheetKind(rawValue: s) { nav.sheet = k }
    }

    private func stack<V: View>(_ t: AppTab, @ViewBuilder _ root: () -> V) -> some View {
        NavigationStack(path: Binding(get: { nav.path(t) }, set: { nav.paths[t] = $0 })) {
            root().navigationDestination(for: Route.self) { destination($0) }
        }
    }

    @ViewBuilder private func destination(_ r: Route) -> some View {
        switch r {
        case .category(let c): CategoryView(catId: c)
        case .reader(let c, let i): ReaderView(catId: c, itemId: i)
        case .tool(let t): toolView(t)
        case .masoom(let i): MasoomeenDetailScreen(index: i)
        case .hajjGuide(let r): HajjGuideScreen(ritual: r)
        }
    }

    @ViewBuilder private func toolView(_ t: Tool) -> some View {
        switch t {
        case .khira: KhiraView()
        case .weekly: WeeklyView()
        case .asma: AsmaView()
        case .masoom: MasoomeenView()
        case .khums: KhumsView()
        case .tracker: TrackerView()
        case .layl: LaylView()
        case .hajj: HajjView()
        case .ashura: AshuraView()
        case .qibla: QiblaView()
        case .muhasaba: MuhasabaView()
        case .journey: JourneyView()
        case .trait: TraitView()
        case .amaal: AmaalView()
        case .qada: QadaView()
        case .khatma: KhatmaView()
        case .converter: ConverterView()
        case .ptable: PrayerTableView()
        case .qpoints: QuranPointsView()
        }
    }

    @ViewBuilder private func sheetView(_ k: SheetKind) -> some View {
        switch k {
        case .tasbih: TasbihView()
        case .favorites: NavigationStack { FavoritesView() }
        case .bookmarks: NavigationStack { BookmarksView() }
        case .settings: NavigationStack { SettingsView() }
        case .about: NavigationStack { AboutView() }
        case .location: NavigationStack { LocationView() }
        case .method: NavigationStack { MethodView() }
        }
    }
}
