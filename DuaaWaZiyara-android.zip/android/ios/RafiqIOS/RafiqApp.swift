import SwiftUI

@main
struct RafiqApp: App {
    var body: some Scene {
        WindowGroup {
            WebContainer()
                .ignoresSafeArea()
                .background(Color(red: 0.93, green: 0.96, blue: 0.965))
        }
    }
}
