import SwiftUI
import WebKit
import CoreLocation
import UserNotifications
import UIKit

/// يعرض نواة الويب المضمَّنة، ويوفّر لها جسراً إلى إمكانات الآيفون الأصلية.
struct WebContainer: UIViewRepresentable {
    func makeCoordinator() -> Bridge { Bridge() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.setURLSchemeHandler(context.coordinator, forURLScheme: "app")     // أصلٌ ثابت يحفظ الإعدادات بين التشغيلات
        config.userContentController.add(context.coordinator, name: "native")
        config.allowsInlineMediaPlayback = true
        let web = WKWebView(frame: .zero, configuration: config)
        web.isOpaque = false
        web.backgroundColor = .clear
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.scrollView.bounces = false
        context.coordinator.web = web
        web.load(URLRequest(url: URL(string: "app://local/index.html")!))
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

final class Bridge: NSObject, WKScriptMessageHandler, WKURLSchemeHandler, CLLocationManagerDelegate {
    weak var web: WKWebView?
    private let location = CLLocationManager()
    private var wantsLocation = false

    override init() {
        super.init()
        location.delegate = self
        location.desiredAccuracy = kCLLocationAccuracyKilometer
        location.headingFilter = 1
    }

    // MARK: - ملفات الويب من داخل الحزمة عبر app://local/...
    func webView(_ webView: WKWebView, start task: WKURLSchemeTask) {
        guard let url = task.request.url else { return }
        var path = url.path
        if path.isEmpty || path == "/" { path = "/index.html" }
        let base = Bundle.main.resourceURL!.appendingPathComponent("web")
        let file = base.appendingPathComponent(String(path.dropFirst()))
        guard let data = try? Data(contentsOf: file) else {
            task.didFailWithError(NSError(domain: "app", code: 404)); return
        }
        let mime: String
        switch file.pathExtension.lowercased() {
        case "html": mime = "text/html"
        case "js": mime = "application/javascript"
        case "css": mime = "text/css"
        case "ttf": mime = "font/ttf"
        case "png": mime = "image/png"
        default: mime = "application/octet-stream"
        }
        let resp = HTTPURLResponse(url: url, statusCode: 200, httpVersion: "HTTP/1.1",
                                   headerFields: ["Content-Type": mime, "Content-Length": "\(data.count)"])!
        task.didReceive(resp)
        task.didReceive(data)
        task.didFinish()
    }
    func webView(_ webView: WKWebView, stop task: WKURLSchemeTask) {}

    // MARK: - رسائل الجسر
    func userContentController(_ uc: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let type = body["type"] as? String else { return }
        switch type {
        case "location":
            wantsLocation = true
            if location.authorizationStatus == .notDetermined { location.requestWhenInUseAuthorization() }
            else { location.requestLocation() }
        case "heading":
            if (body["on"] as? Bool) == true {
                if CLLocationManager.headingAvailable() { location.startUpdatingHeading() }
            } else { location.stopUpdatingHeading() }
        case "requestNotify":
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
        case "schedule":
            schedule(body["items"] as? [[String: Any]] ?? [])
        case "haptic":
            if (body["style"] as? String) == "success" { UINotificationFeedbackGenerator().notificationOccurred(.success) }
            else { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
        case "keepAwake":
            UIApplication.shared.isIdleTimerDisabled = (body["on"] as? Bool) == true
        case "share":
            share(body["text"] as? String ?? "")
        default: break
        }
    }

    private func schedule(_ items: [[String: Any]]) {
        let center = UNUserNotificationCenter.current()
        center.removeAllPendingNotificationRequests()
        for it in items.prefix(60) {
            guard let id = it["id"] as? String, let at = it["at"] as? Double else { continue }
            let content = UNMutableNotificationContent()
            content.title = it["title"] as? String ?? ""
            content.body = it["body"] as? String ?? ""
            content.sound = .default
            let date = Date(timeIntervalSince1970: at / 1000)
            let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: date)
            let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
            center.add(UNNotificationRequest(identifier: id, content: content, trigger: trigger))
        }
    }

    private func share(_ text: String) {
        DispatchQueue.main.async {
            guard let root = UIApplication.shared.connectedScenes.compactMap({ ($0 as? UIWindowScene)?.keyWindow }).first?.rootViewController else { return }
            let vc = UIActivityViewController(activityItems: [text], applicationActivities: nil)
            vc.popoverPresentationController?.sourceView = root.view
            root.present(vc, animated: true)
        }
    }

    private func js(_ s: String) { DispatchQueue.main.async { self.web?.evaluateJavaScript(s, completionHandler: nil) } }

    // MARK: - الموقع والبوصلة
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if wantsLocation, manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways {
            manager.requestLocation()
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let loc = locations.last else { return }
        wantsLocation = false
        let tz = Double(TimeZone.current.secondsFromGMT()) / 3600.0
        CLGeocoder().reverseGeocodeLocation(loc) { places, _ in
            let city = (places?.first?.locality ?? "موقعي").replacingOccurrences(of: "'", with: "")
            self.js("window.onLocation(\(loc.coordinate.latitude), \(loc.coordinate.longitude), \(tz), '\(city)')")
        }
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {}
    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        let h = newHeading.trueHeading >= 0 ? newHeading.trueHeading : newHeading.magneticHeading
        js("window.onHeading && window.onHeading(\(h))")
    }
}
