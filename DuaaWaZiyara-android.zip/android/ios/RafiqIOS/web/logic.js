// منطق التطبيق منقولاً حرفياً من نسخة أندرويد (HijriCalendar.kt و PrayerTimes.kt) ليتطابق الناتج.
const Hijri = {
  months: ["مُحَرَّم","صَفَر","ربيع الأول","ربيع الثاني","جُمادى الأولى","جُمادى الآخرة","رَجَب","شَعبان","رَمَضان","شَوّال","ذو القَعدة","ذو الحِجّة"],
  weekDays: ["الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"],
  gToJd(y, m, d) {
    const a = Math.floor((14 - m) / 12), yy = y + 4800 - a, mm = m + 12 * a - 3;
    return d + Math.floor((153 * mm + 2) / 5) + 365 * yy + Math.floor(yy / 4) - Math.floor(yy / 100) + Math.floor(yy / 400) - 32045;
  },
  jdToHijri(jdIn, adj = 0) {
    const jd = jdIn + adj, l0 = jd - 1948440 + 10632, n = Math.floor((l0 - 1) / 10631);
    let l = l0 - 10631 * n + 354;
    const j = Math.floor((10985 - l) / 5316) * Math.floor((50 * l) / 17719) + Math.floor(l / 5670) * Math.floor((43 * l) / 15238);
    l = l - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) - Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;
    const m = Math.floor((24 * l) / 709), d = l - Math.floor((709 * m) / 24), y = 30 * n + j - 30;
    return { y, m, d };
  },
  hijriToJd(y, m, d, adj = 0) { return Math.floor((11 * y + 3) / 30) + 354 * y + 30 * m - Math.floor((m - 1) / 2) + d + 1948440 - 385 - adj; },
  jdToGreg(jdIn) {
    const a = jdIn + 32044, b = Math.floor((4 * a + 3) / 146097), c = a - Math.floor((146097 * b) / 4);
    const dd = Math.floor((4 * c + 3) / 1461), e = c - Math.floor((1461 * dd) / 4), m = Math.floor((5 * e + 2) / 153);
    return { y: 100 * b + dd - 4800 + Math.floor(m / 10), m: m + 3 - 12 * Math.floor(m / 10), d: e - Math.floor((153 * m + 2) / 5) + 1 };
  },
  ofDate(date, adj = 0) { return this.jdToHijri(this.gToJd(date.getFullYear(), date.getMonth() + 1, date.getDate()), adj); },
  monthLength(y, m, adj = 0) {
    const ny = m === 12 ? y + 1 : y, nm = m === 12 ? 1 : m + 1;
    return Math.min(30, Math.max(29, this.hijriToJd(ny, nm, 1, adj) - this.hijriToJd(y, m, 1, adj)));
  },
};

const Prayer = {
  methods: [
    { key: "jafari", name: "الجعفري (ليفا - قم)", fajr: 16, maghrib: 4, isha: 14, ishaMin: false, jafariMidnight: true },
    { key: "hadi", name: "الهادي (البوعلي)", fajr: 18, maghrib: 4, isha: 0, ishaMin: true, jafariMidnight: true },
    { key: "tehran", name: "طهران", fajr: 17.7, maghrib: 4.5, isha: 14, ishaMin: false, jafariMidnight: true },
    { key: "karachi", name: "كراتشي", fajr: 18, maghrib: null, isha: 18, ishaMin: false, jafariMidnight: false },
    { key: "mwl", name: "رابطة العالم الإسلامي", fajr: 18, maghrib: null, isha: 17, ishaMin: false, jafariMidnight: false },
    { key: "makkah", name: "أم القرى (مكة)", fajr: 18.5, maghrib: null, isha: 0, ishaMin: true, jafariMidnight: false },
  ],
  byKey(k) { return this.methods.find(m => m.key === k) || this.methods[0]; },
  rtd: r => r * 180 / Math.PI, dtr: d => d * Math.PI / 180,
  sunPos(jd) {
    const d = jd - 2451545.0, g = (357.529 + 0.98560028 * d) % 360, q = (280.459 + 0.98564736 * d) % 360;
    const l = (q + 1.915 * Math.sin(this.dtr(g)) + 0.020 * Math.sin(this.dtr(2 * g))) % 360, e = 23.439 - 0.00000036 * d;
    const decl = this.rtd(Math.asin(Math.sin(this.dtr(e)) * Math.sin(this.dtr(l))));
    let ra = this.rtd(Math.atan2(Math.cos(this.dtr(e)) * Math.sin(this.dtr(l)), Math.cos(this.dtr(l)))) / 15;
    ra = ((ra % 24) + 24) % 24;
    return { decl, eqt: q / 15 - ra };
  },
  tAngle(angle, lat, decl) {
    const x = (-Math.sin(this.dtr(angle)) - Math.sin(this.dtr(lat)) * Math.sin(this.dtr(decl))) / (Math.cos(this.dtr(lat)) * Math.cos(this.dtr(decl)));
    return (x < -1 || x > 1) ? null : this.rtd(Math.acos(x)) / 15;
  },
  asrAngle(lat, decl) {
    const angle = this.rtd(Math.atan(1 / (1 + Math.tan(Math.abs(this.dtr(lat - decl))))));
    const x = (Math.sin(this.dtr(angle)) - Math.sin(this.dtr(lat)) * Math.sin(this.dtr(decl))) / (Math.cos(this.dtr(lat)) * Math.cos(this.dtr(decl)));
    return (x < -1 || x > 1) ? null : this.rtd(Math.acos(x)) / 15;
  },
  compute(date, lat, lng, tz, methodKey) {
    const m = this.byKey(methodKey);
    const jd = Hijri.gToJd(date.getFullYear(), date.getMonth() + 1, date.getDate()) - lng / (15 * 24);
    const sp = this.sunPos(jd), decl = sp.decl, noon = 12 - sp.eqt - lng / 15 + tz;
    const hr = this.tAngle(0.833, lat, decl), ha = hr ?? 6, sunrise = noon - ha, sunset = noon + ha, night = 24 - 2 * ha;
    const fa = this.tAngle(m.fajr, lat, decl), fajr = fa != null ? noon - fa : sunrise - night / 7;
    let maghrib = sunset;
    if (m.maghrib != null) { const mg = this.tAngle(m.maghrib, lat, decl); maghrib = mg != null ? noon + mg : sunset + night / 12; }
    let isha;
    if (m.ishaMin) isha = maghrib + 1.5; else { const ia = this.tAngle(m.isha, lat, decl); isha = ia != null ? noon + ia : sunset + night / 7; }
    const asr = noon + (this.asrAngle(lat, decl) ?? 0);
    const midnight = m.jafariMidnight ? (maghrib + ((fajr + 24) - maghrib) / 2) % 24 : (sunset + ((sunrise + 24) - sunset) / 2) % 24;
    return { fajr, sunrise, dhuhr: noon, asr, maghrib, isha, midnight };
  },
  norm: t => ((t % 24) + 24) % 24,
  fmt(tIn) {
    if (Number.isNaN(tIn)) return "—";
    const t = this.norm(tIn); let h = Math.floor(t), min = Math.round((t - h) * 60);
    if (min === 60) { min = 0; h++; } if (h >= 24) h -= 24;
    const am = h < 12; let hh = h % 12; if (hh === 0) hh = 12;
    return `${hh}:${min < 10 ? "0" + min : min} ${am ? "ص" : "م"}`;
  },
  slots: [["fajr","الفجر"],["sunrise","الشروق"],["dhuhr","الظهر"],["asr","العصر"],["maghrib","المغرب"],["isha","العشاء"],["midnight","منتصف الليل"]],
  next(t, nowH) {
    let k = "fajr", best = Infinity;
    for (const [key] of this.slots) { if (key === "sunrise" || key === "midnight") continue;
      let dt = this.norm(t[key]) - nowH; if (dt < 0) dt += 24; if (dt < best) { best = dt; k = key; } }
    return [k, best];
  },
};

const ArSearch = {
  strip: s => s.replace(/[\u064B-\u0652\u0670\u0640\u06E1-\u06ED]/g, ""),
  normalize(s) { return this.strip(s).replace(/[أإآٱ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه").replace(/ؤ/g, "و").replace(/ئ/g, "ي").replace(/\s+/g, " ").trim(); },
};

/** عدد الأيّام حتى رأس السنة الخمسية (بالتقويم الهجري الفعلي) — مطابقٌ لـ Khums.daysUntilKhumsDay */
function isKhumsDay(h, m, d, adj) { if (h.m !== m) return false; if (h.d === d) return true; return d === 30 && h.d === 29 && Hijri.monthLength(h.y, h.m, adj) === 29; }

if (typeof module !== "undefined") module.exports = { Hijri, Prayer, ArSearch, isKhumsDay };
