// رفيق المؤمن — نواة الويب لنسخة آيفون. المحتوى من content.js (مُصدَّرٌ من بيانات أندرويد الموثّقة)، والمنطق من logic.js.
"use strict";
const C = window.CONTENT;
const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const ar = n => String(n).replace(/\d/g, d => "٠١٢٣٤٥٦٧٨٩"[d]);

// ===== الجسر إلى التطبيق الأصلي (Swift). في المتصفّح يتجاهل الطلبات بأمان =====
const Native = {
  ok: !!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.native),
  post(msg) { if (this.ok) window.webkit.messageHandlers.native.postMessage(msg); },
  haptic(style = "light") { this.post({ type: "haptic", style }); },
  keepAwake(on) { this.post({ type: "keepAwake", on }); },
};

// ===== التخزين =====
const S = {
  get(k, d) { try { const v = localStorage.getItem("rafiq." + k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem("rafiq." + k, JSON.stringify(v)); } catch {} },
};
const settings = {
  get theme() { return S.get("theme", "light"); }, set theme(v) { S.set("theme", v); applyTheme(); },
  get method() { return S.get("method", "jafari"); }, set method(v) { S.set("method", v); },
  get loc() { return S.get("loc", { lat: 25.2048, lng: 55.2708, tz: 4, city: "دبي" }); }, set loc(v) { S.set("loc", v); },
  get fs() { return S.get("fs", 24); }, set fs(v) { S.set("fs", v); },
  get tashkeel() { return S.get("tashkeel", true); }, set tashkeel(v) { S.set("tashkeel", v); },
  get notify() { return S.get("notify", false); }, set notify(v) { S.set("notify", v); },
  get adj() { return S.get("adj", 0); },
};
function applyTheme() { document.documentElement.dataset.theme = settings.theme; }

const CITIES = [["دبي", 25.2048, 55.2708, 4], ["أبوظبي", 24.4539, 54.3773, 4], ["المنامة", 26.2285, 50.586, 3], ["الكويت", 29.3759, 47.9774, 3],
  ["كربلاء", 32.616, 44.0249, 3], ["النجف", 32.0259, 44.3462, 3], ["بغداد", 33.3152, 44.3661, 3], ["قم", 34.6401, 50.8764, 3.5],
  ["مشهد", 36.2605, 59.6168, 3.5], ["الدمام", 26.4207, 50.0888, 3], ["مسقط", 23.588, 58.3829, 4], ["بيروت", 33.8938, 35.5018, 3]];

// ===== أدوات =====
const item = id => C.items[id];
const catOf = id => C.categories.find(c => c.items.includes(id));
const catById = id => C.categories.find(c => c.id === id);
const GRAD = { mashhura: ["#3E6FA6", "#2C4F7C"], ziyarat: ["#2E7D8C", "#1F5E6E"], sahifa: ["#7B5EA7", "#56407A"], quran: ["#2E8C6B", "#1F6650"],
  ramadan: ["#3E94A6", "#1F5E6E"], jumaa: ["#3E6FA6", "#264D7A"], sabah: ["#D8913E", "#C07432"], taqibat: ["#2E8C8C", "#1F6B6B"] };
const grad = id => { const g = GRAD[id] || ["#3E94A6", "#1F5E6E"]; return `--c1:${g[0]};--c2:${g[1]}`; };
function readSet() { return new Set(S.get("read", [])); }
function markRead(id) { const r = readSet(); r.add(id); S.set("read", [...r]); S.set("last", { id, cat: catOf(id)?.id }); }
function toast(msg) { const t = document.createElement("div"); t.className = "toast"; t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), 1800); }
function times(date = new Date()) { const l = settings.loc; return Prayer.compute(date, l.lat, l.lng, l.tz, settings.method); }
function nowH() { const d = new Date(); return d.getHours() + d.getMinutes() / 60 + d.getSeconds() / 3600; }
function countAr(n, one, two, plural, many) { return n === 1 ? one : n === 2 ? two : (n % 100 >= 3 && n % 100 <= 10) ? `${ar(n)} ${plural}` : `${ar(n)} ${many}`; }

// ===== التوجيه =====
const stack = [];
let tab = "home";
function go(render, push = true) { if (push) stack.push(render); draw(); }
function back() { stack.pop(); Native.keepAwake(false); draw(); }
function setTab(t) { tab = t; stack.length = 0; Native.keepAwake(false); draw(); }
function draw() {
  const v = $("#view"); const top = stack[stack.length - 1];
  v.innerHTML = top ? top() : TABS[tab]();
  v.scrollTop = 0;
  document.querySelectorAll("#nav button").forEach(b => b.classList.toggle("on", b.dataset.t === tab));
  if (top && top.after) top.after();
}
const header = (title, sub, withBack) => `<div class="hdr">${withBack ? `<button class="back" aria-label="رجوع" onclick="back()">›</button>` : ""}<h1>${esc(title)}</h1>${sub ? `<div class="sub">${esc(sub)}</div>` : ""}</div>`;

// ===== الرئيسية =====
function Home() {
  const t = times(), [nk, dt] = Prayer.next(t, nowH()), h = Hijri.ofDate(new Date(), settings.adj);
  const names = Object.fromEntries(Prayer.slots), mins = Math.ceil(dt * 60);
  const left = mins < 1 ? "الآن" : mins < 60 ? `بعد ${ar(mins)} د` : `بعد ${ar(Math.floor(mins / 60))} س ${ar(mins % 60)} د`;
  const wd = new Date().getDay(); const wk = C.weekly[(wd + 1) % 7];
  const last = S.get("last", null);
  const five = ["fajr", "dhuhr", "asr", "maghrib", "isha"];
  return `<div class="page">
    <div class="hero">
      <div class="row"><div class="grow" style="font-weight:800">${ar(h.d)} ${Hijri.months[h.m - 1]} ${ar(h.y)} هـ</div><div style="font-size:13px">📍 ${esc(settings.loc.city)}</div></div>
      <div style="text-align:center;opacity:.9;margin-top:10px;font-weight:700">الصلاة القادمة</div>
      <div class="big">${names[nk]}</div>
      <div style="text-align:center">${Prayer.fmt(t[nk])} · ${left}</div>
      <div class="times">${five.map(k => `<div class="t ${k === nk ? "on" : ""}">${names[k]}<b>${Prayer.fmt(t[k])}</b></div>`).join("")}</div>
    </div>
    ${last && item(last.id) ? `<button class="item" onclick="openReader('${last.id}')"><div class="grow"><div class="muted" style="color:var(--gold);font-weight:800">تابِع القراءة</div><div class="t1">${esc(item(last.id).title)}</div></div><span class="chev">‹</span></button>` : ""}
    <div class="sec">ورد اليوم · ${wk[0]}</div>
    ${listRow(wk[1], "دعاء اليوم")}${listRow(wk[2], "زيارة اليوم")}
    ${wd === 4 ? listRow("m-kumayl", "ليلة الجمعة") : ""}${wd === 5 ? listRow("m-nudba", "صباح الجمعة") + listRow("j-samat", "عصر الجمعة") : ""}
    <div class="sec">أعمال وأدوات</div>
    <div class="tiles">
      <button class="tile" style="${grad("hikam")}" onclick="go(Khira)"><span class="ic">✶</span>خيرة القرآن</button>
      <button class="tile" style="${grad("taqibat")}" onclick="go(Tasbih)"><span class="ic">📿</span>السبحة</button>
      <button class="tile" style="${grad("ziyarat")}" onclick="go(Qibla)"><span class="ic">🧭</span>اتجاه القبلة</button>
      <button class="tile" style="${grad("jumaa")}" onclick="go(Weekly)"><span class="ic">🗓</span>البرنامج الأسبوعي</button>
    </div></div>`;
}
function listRow(id, label) {
  const it = item(id); if (!it) return "";
  const read = readSet().has(id) ? "read" : "";
  return `<button class="item ${read}" onclick="openReader('${id}')"><div class="grow"><div class="muted">${esc(label)}</div><div class="t1">${esc(it.title)}</div></div><span class="chev">‹</span></button>`;
}

// ===== الفهرس =====
let query = "";
function Library() {
  return `<div class="page">${header("رفيق المؤمن", "رفيقك إلى ربّك كلّ يوم")}
    <input class="search" placeholder="ابحث في الأدعية والزيارات…" value="${esc(query)}" oninput="query=this.value;renderResults()" />
    <div id="results">${results()}</div></div>`;
}
function renderResults() { $("#results").innerHTML = results(); }
let INDEX = null;
function buildIndex() { INDEX = Object.values(C.items).map(it => ({ it, t: ArSearch.normalize(it.title), b: ArSearch.normalize((it.src || "") + " " + (it.intro || "") + " " + it.text.replace(/\n/g, " ")) })); }
function results() {
  const q = ArSearch.normalize(query);
  if (!q) return `<div class="sec">تصفّح الأبواب</div>` + C.categories.map(c => `<button class="cat" style="${grad(c.id)}" onclick="openCat('${c.id}')">
      <span class="ic">${c.icon}</span><div class="grow"><div class="n">${esc(c.name)}</div><div class="d">${esc(c.desc)}</div></div><span class="cnt">${ar(c.items.length)}</span></button>`).join("");
  if (!INDEX) buildIndex();
  const terms = q.split(" ").filter(Boolean);
  const hits = INDEX.filter(e => terms.every(w => e.t.includes(w) || e.b.includes(w)))
    .map(e => ({ e, s: (e.t === q ? 1000 : e.t.startsWith(q) ? 600 : e.t.includes(q) ? 400 : 0) + (e.b.includes(q) ? 40 : 0) }))
    .sort((a, b) => b.s - a.s).slice(0, 60);
  if (!hits.length) return `<div class="card muted">لا نتائج لـ «${esc(query)}»</div>`;
  return `<div class="sec">${countAr(hits.length, "نتيجة واحدة", "نتيجتان", "نتائج", "نتيجة")}</div>` + hits.map(h => listRow(h.e.it.id, catOf(h.e.it.id)?.name || "")).join("");
}
function openCat(id) {
  const c = catById(id); let filter = "";
  const page = () => {
    const jump = ["sahifa", "quran", "ramadan"].includes(id);
    return `<div class="page">${header(c.name, countAr(c.items.length, "نصٌّ واحد", "نصّان", "نصوص", "نصّاً"), true)}
      <input class="search" placeholder="${jump ? "تصفية، أو رقم…" : "تصفية في " + esc(c.name) + "…"}" oninput="catFilter(this.value)" />
      <div id="catlist">${catList(c, filter)}</div></div>`;
  };
  window.catFilter = v => { filter = v; $("#catlist").innerHTML = catList(c, filter); };
  go(page);
}
function catList(c, filter) {
  const f = ArSearch.normalize(filter); const asNum = parseInt(filter.replace(/[٠-٩]/g, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d)), 10);
  let ids = c.items;
  if (filter.trim()) {
    if (!isNaN(asNum) && ["sahifa", "quran", "ramadan"].includes(c.id)) {
      const n = id => c.id === "quran" ? parseInt(id.slice(2), 10) : c.id === "ramadan" ? parseInt(id.replace("r-day-", ""), 10)
        : ({ "saj-mohimmat": 7, "mu-makarim": 20 }[id] ?? parseInt(id.slice(4), 10));
      ids = ids.filter(id => n(id) === asNum);
    } else ids = ids.filter(id => ArSearch.normalize(item(id).title).includes(f));
  }
  if (!ids.length) return `<div class="card muted">لا نتائج</div>`;
  return ids.map(id => { const it = item(id); const sub = (it.src || "").startsWith(c.name) ? it.src.slice(c.name.length).replace(/^[\s—،:-]+/, "") : it.src;
    const read = readSet().has(id) ? "read" : "";
    return `<button class="item ${read}" onclick="openReader('${id}')"><div class="grow"><div class="t1">${esc(it.title)}</div><div class="t2">${esc(sub || "")}</div></div><span class="chev">‹</span></button>`; }).join("");
}

// ===== القارئ =====
function openReader(id) {
  const c = catOf(id), list = c ? c.items : [id];
  const page = () => {
    const it = item(id), idx = list.indexOf(id);
    const raw = settings.tashkeel ? it.text : ArSearch.strip(it.text);
    const paras = raw.split("\n\n").map(s => s.trim()).filter(Boolean);
    const words = it.text.split(/\s+/).filter(Boolean).length, m = Math.max(1, Math.ceil(words / 100));
    const rt = m === 1 ? "نحو دقيقة" : m === 2 ? "نحو دقيقتين" : m <= 10 ? `نحو ${ar(m)} دقائق` : `نحو ${ar(m)} دقيقة`;
    return `<div class="page">${header(it.title, c ? `${c.name} · ${ar(idx + 1)} من ${ar(list.length)}` : "", true)}
      <div class="reader-tools">
        <button class="tool ${settings.tashkeel ? "on" : ""}" onclick="settings.tashkeel=!settings.tashkeel;draw()">التشكيل${settings.tashkeel ? " ✓" : ""}</button>
        <button class="tool" onclick="settings.fs=Math.max(16,settings.fs-2);draw()">حجم −</button>
        <button class="tool" onclick="settings.fs=Math.min(40,settings.fs+2);draw()">حجم +</button>
        <button class="tool" onclick="shareText('${id}')">مشاركة</button>
      </div>
      ${it.src ? `<div style="margin-bottom:10px"><span class="chip">${esc(it.src)} · ${rt}</span></div>` : ""}
      ${it.intro ? `<div class="intro">${esc(it.intro)}</div>` : ""}
      <div class="card scripture" style="--fs:${settings.fs}px">${paras.map(p => `<p>${esc(p).replace(/\n/g, "<br>")}</p>`).join("")}</div>
      <div class="navbtns">
        <button class="btn alt" ${idx > 0 ? `onclick="stack.pop();openReader('${list[idx - 1]}')"` : "disabled style='opacity:.4'"}>› النصّ السابق</button>
        <button class="btn" ${idx < list.length - 1 ? `onclick="stack.pop();openReader('${list[idx + 1]}')"` : "disabled style='opacity:.4'"}>النصّ التالي ‹</button>
      </div></div>`;
  };
  page.after = () => {
    Native.keepAwake(true); markRead(id);
    const pos = S.get("pos." + id, 0); if (pos > 400) { $("#view").scrollTop = pos; toast("تابعتَ من موضعك"); }
    $("#view").onscroll = () => S.set("pos." + id, $("#view").scrollTop);
  };
  go(page);
}
function shareText(id) { const it = item(id); const text = `${it.title}\n\n${it.text}\n\n— ${it.src || ""}\nمن تطبيق رفيق المؤمن`;
  if (Native.ok) Native.post({ type: "share", text }); else if (navigator.share) navigator.share({ text }); }

// ===== الأوقات =====
function Times() {
  const t = times(), [nk] = Prayer.next(t, nowH());
  return `<div class="page">${header("رفيق المؤمن", "رفيقك إلى ربّك كلّ يوم")}
    <div class="card">${Prayer.slots.map(([k, n]) => `<div class="row" style="padding:10px 6px;${k === nk ? "background:var(--emerald);color:#fff;border-radius:12px" : ""}">
      <div class="grow" style="font-weight:800">${n}</div><b>${Prayer.fmt(t[k])}</b></div>`).join("")}</div>
    <div class="sec">الموقع: ${esc(settings.loc.city)}</div>
    <div class="row" style="gap:8px;flex-wrap:wrap">${Native.ok ? `<button class="tool on" onclick="Native.post({type:'location'})">📍 موقعي الحالي</button>` : ""}
      ${CITIES.map(c => `<button class="tool ${settings.loc.city === c[0] ? "on" : ""}" onclick="setCity('${c[0]}')">${c[0]}</button>`).join("")}</div>
    <div class="sec">طريقة الحساب</div>
    <div class="row" style="gap:8px;flex-wrap:wrap">${Prayer.methods.map(m => `<button class="tool ${settings.method === m.key ? "on" : ""}" onclick="settings.method='${m.key}';scheduleNotifications();draw()">${m.name}</button>`).join("")}</div>
    <div class="sec">التنبيهات</div>
    <button class="tool ${settings.notify ? "on" : ""}" onclick="toggleNotify()">تنبيهات أوقات الصلاة ${settings.notify ? "✓" : ""}</button>
    <p class="muted" style="margin-top:14px;line-height:1.8">الأوقات محسوبةٌ فلكياً بحسب موقعك وتقريبية، وقد تختلف دقائق عن التقويم المحلّي. يُحتاط في أوّل الوقت وآخره.</p></div>`;
}
function setCity(name) { const c = CITIES.find(x => x[0] === name); settings.loc = { city: c[0], lat: c[1], lng: c[2], tz: c[3] }; scheduleNotifications(); draw(); }
window.onLocation = (lat, lng, tz, city) => { settings.loc = { lat, lng, tz, city: city || "موقعي" }; scheduleNotifications(); draw(); };
function toggleNotify() { settings.notify = !settings.notify; if (settings.notify) Native.post({ type: "requestNotify" }); scheduleNotifications(); draw(); }
function scheduleNotifications() {
  if (!settings.notify) { Native.post({ type: "schedule", items: [] }); return; }
  const items = [], names = Object.fromEntries(Prayer.slots), now = Date.now();
  for (let d = 0; d < 12 && items.length < 60; d++) {
    const day = new Date(); day.setDate(day.getDate() + d); const t = times(day);
    for (const k of ["fajr", "dhuhr", "asr", "maghrib", "isha"]) {
      const v = Prayer.norm(t[k]), at = new Date(day.getFullYear(), day.getMonth(), day.getDate(), Math.floor(v), Math.round((v % 1) * 60));
      // التوقيت محسوبٌ بمنطقة الموقع؛ يُصحَّح إلى منطقة الجهاز
      const fix = (settings.loc.tz + new Date().getTimezoneOffset() / 60) * 3600000, ms = at.getTime() - fix;
      if (ms > now) items.push({ id: `p-${d}-${k}`, title: `حان وقت صلاة ${names[k]}`, body: `${settings.loc.city} · ${Prayer.fmt(t[k])}`, at: ms });
    }
  }
  Native.post({ type: "schedule", items: items.slice(0, 60) });
}

// ===== التقويم =====
let calY, calM, calSel;
function Calendar() {
  const today = Hijri.ofDate(new Date(), settings.adj);
  if (!calY) { calY = today.y; calM = today.m; calSel = today.d; }
  const len = Hijri.monthLength(calY, calM, settings.adj), jd1 = Hijri.hijriToJd(calY, calM, 1, settings.adj);
  const g1 = Hijri.jdToGreg(jd1), first = new Date(g1.y, g1.m - 1, g1.d).getDay();
  const startCol = (first + 1) % 7; // السبت أوّل الأسبوع
  const works = C.works.filter(w => w.m === calM);
  let cells = Array(startCol).fill(`<div></div>`);
  for (let d = 1; d <= len; d++) {
    const isT = calY === today.y && calM === today.m && d === today.d, has = works.some(w => w.d === d);
    cells.push(`<button class="d ${isT ? "today" : ""} ${d === calSel ? "sel" : ""}" onclick="calSel=${d};draw()">${ar(d)}${has ? `<span class="dot"></span>` : ""}</button>`);
  }
  const gS = Hijri.jdToGreg(jd1 + calSel - 1), dayWorks = works.filter(w => w.d === calSel || w.d === 0);
  return `<div class="page">${header("رفيق المؤمن", "رفيقك إلى ربّك كلّ يوم")}
    <div class="row" style="margin-bottom:12px"><button class="tool" aria-label="الشهر السابق" onclick="calM--;if(calM<1){calM=12;calY--};calSel=1;draw()">›</button>
      <div class="grow" style="text-align:center;font-weight:800;font-size:18px">${Hijri.months[calM - 1]} ${ar(calY)} هـ</div>
      <button class="tool" aria-label="الشهر التالي" onclick="calM++;if(calM>12){calM=1;calY++};calSel=1;draw()">‹</button></div>
    <div class="cal">${["السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"].map(w => `<div class="wd">${w}</div>`).join("")}${cells.join("")}</div>
    <div class="card" style="margin-top:14px"><div style="font-weight:800;color:var(--emerald)">${ar(calSel)} ${Hijri.months[calM - 1]} ${ar(calY)} هـ — ${gS.d}/${gS.m}/${gS.y}م</div>
      ${dayWorks.length ? dayWorks.map((w, i) => `<button class="item" style="margin-top:10px" onclick="openWork(${C.works.indexOf(w)})"><div class="grow"><div class="t1">${esc(w.title)}</div></div><span class="chev">‹</span></button>`).join("")
        : `<div class="muted" style="margin-top:8px">لا أعمال خاصّة لهذا اليوم في المفاتيح.</div>`}</div></div>`;
}
function openWork(i) { const w = C.works[i];
  go(() => `<div class="page">${header(w.title, `${ar(w.d)} ${Hijri.months[w.m - 1]}`, true)}<div class="card scripture" style="--fs:${settings.fs - 2}px">${w.body.split("\n\n").map(p => `<p>${esc(p)}</p>`).join("")}</div></div>`); }

// ===== المزيد =====
function More() {
  return `<div class="page">${header("رفيق المؤمن", "رفيقك إلى ربّك كلّ يوم")}
    <div class="tiles">
      <button class="tile" style="${grad("hikam")}" onclick="go(Khira)"><span class="ic">✶</span>خيرة القرآن</button>
      <button class="tile" style="${grad("taqibat")}" onclick="go(Tasbih)"><span class="ic">📿</span>السبحة</button>
      <button class="tile" style="${grad("ziyarat")}" onclick="go(Qibla)"><span class="ic">🧭</span>اتجاه القبلة</button>
      <button class="tile" style="${grad("jumaa")}" onclick="go(Weekly)"><span class="ic">🗓</span>البرنامج الأسبوعي</button>
      <button class="tile" style="${grad("ramadan")}" onclick="openCat('ramadan')"><span class="ic">🌙</span>أعمال رمضان</button>
      <button class="tile" style="${grad("sahifa")}" onclick="openCat('sahifa')"><span class="ic">🌸</span>الصحيفة السجّادية</button>
    </div>
    <div class="sec">الإعدادات</div>
    <button class="item" onclick="settings.theme=settings.theme==='dark'?'light':'dark';draw()"><div class="grow t1">الوضع ${settings.theme === "dark" ? "النهاري" : "الليلي"}</div></button>
    <p class="muted" style="text-align:center;margin-top:18px">رفيق المؤمن لآيفون · ${countAr(Object.keys(C.items).length, "", "", "نصوص", "نصّاً")} موثّقة · يعمل دون اتصال</p></div>`;
}

// ===== البرنامج الأسبوعي =====
function Weekly() {
  const today = (new Date().getDay() + 1) % 7;
  return `<div class="page">${header("البرنامج الأسبوعي", "دعاء كلّ يومٍ وزيارتُه", true)}
    ${C.weekly.map((w, i) => `<div class="card" style="${i === today ? "border:1.5px solid var(--gold);background:rgba(198,160,84,.10)" : ""}">
      <div class="row"><div class="grow" style="font-weight:800;font-size:17px;${i === today ? "color:var(--gold)" : ""}">${w[0]}</div>${i === today ? `<span class="chip">اليوم</span>` : ""}</div>
      ${listRow(w[1], "دعاء اليوم")}${listRow(w[2], "زيارة اليوم")}
      ${i === 5 ? listRow("m-kumayl", "ليلة الجمعة: دعاء كميل") : ""}${i === 6 ? listRow("m-nudba", "صباح الجمعة: دعاء الندبة") + listRow("j-samat", "عصر الجمعة: دعاء السمات") : ""}</div>`).join("")}
    <p class="muted" style="line-height:1.8">دعاء كلّ يومٍ مرويٌّ عن الإمام زين العابدين (ع)، وزيارة كلّ يومٍ على ما ذكره العلماء من تخصيص أيّام الأسبوع بالمعصومين (ع).</p></div>`;
}

// ===== خيرة القرآن =====
let VERSES = null;
function verses() {
  if (VERSES) return VERSES; VERSES = [];
  const q = catById("quran"); const rx = /([^()]+?)\s*\((\d+)\)/gs;
  for (const id of q.items) { const s = parseInt(id.slice(2), 10), it = item(id); let m;
    while ((m = rx.exec(it.text))) { let seg = m[1].trim(); const n = +m[2];
      if (s !== 1 && s !== 9 && n === 1 && seg.includes("\n")) seg = seg.slice(seg.lastIndexOf("\n") + 1).trim();
      VERSES.push({ s, name: it.title.replace("سورة ", ""), n, t: seg }); } }
  return VERSES;
}
const KHIRA_STEPS = [["الطهارة", "يُستحبّ أن تكون على وضوء، وأن تستقبل القبلة."], ["الصلاة على محمد وآله", "صلِّ على محمدٍ وآل محمدٍ ثلاث مرّات."],
  ["سورة الإخلاص", "اقرأ (قل هو الله أحد) ثلاث مرّات."], ["دعاء الاستخارة", "«أستخيرُ الله برحمته خِيرةً في عافية» — ثلاث مرّات."]];
let khiraDone = [false, false, false, false], khiraIdx = null, khiraPage = 0;
function Khira() {
  if (khiraIdx !== null) return khiraResult();
  const all = khiraDone.every(Boolean), n = khiraDone.filter(Boolean).length;
  return `<div class="page">${header("خِيرة القرآن الكريم", "", true)}
    <p style="text-align:center;color:var(--ink2);font-weight:700">أتمم الآداب الأربعة، ثم اضغط مطوّلاً على الخاتم؛ يُفتح المصحف على صفحةٍ يمنى ويُقرأ أوّل سطرٍ منها</p>
    ${KHIRA_STEPS.map((s, i) => `<button class="item" onclick="khiraDone[${i}]=!khiraDone[${i}];Native.haptic();draw()">
      <span style="width:30px;height:30px;border-radius:50%;display:grid;place-items:center;font-weight:800;${khiraDone[i] ? "background:var(--emerald);color:#fff" : "background:var(--surface2)"}">${khiraDone[i] ? "✓" : ar(i + 1)}</span>
      <div class="grow"><div class="t1">${s[0]}</div><div class="t2" style="white-space:normal">${s[1]}</div></div></button>`).join("")}
    <div class="seal" id="seal"><svg viewBox="0 0 190 190"><circle cx="95" cy="95" r="80" fill="none" stroke="var(--line)" stroke-width="12"/>
      <circle id="arc" cx="95" cy="95" r="80" fill="none" stroke="var(--gold)" stroke-width="12" stroke-linecap="round" stroke-dasharray="0 503" transform="rotate(-90 95 95)"/></svg>
      <div style="font-weight:800;color:${all ? "var(--emerald)" : "var(--ink2)"};margin-top:60px">${all ? "اضغط مطوّلاً" : "أتمم الآداب أولاً"}</div></div></div>`;
}
Khira.after = () => {
  const seal = $("#seal"); if (!seal || !khiraDone.every(Boolean)) return;
  let t0 = 0, raf = 0;
  const step = () => { const p = Math.min(1, (performance.now() - t0) / 1600); $("#arc").setAttribute("stroke-dasharray", `${p * 503} 503`);
    if (p >= 1) { khiraPage = Math.floor(Math.random() * 302) * 2 + 1; khiraIdx = C.khira.pages[khiraPage - 1]; Native.haptic("success"); draw(); } else raf = requestAnimationFrame(step); };
  seal.onpointerdown = e => { e.preventDefault(); t0 = performance.now(); raf = requestAnimationFrame(step); };
  seal.onpointerup = seal.onpointerleave = () => { cancelAnimationFrame(raf); const a = $("#arc"); if (a) a.setAttribute("stroke-dasharray", "0 503"); };
};
const KHIRA_DETAIL = {
  g: [["عامّة", "خيرٌ ظاهر، فامضِ في أمرك متوكّلاً على الله."], ["الزواج", "فيه توفيقٌ وألفة إن شاء الله، فأقدِم بعد السؤال والتحقّق."],
      ["العمل والتجارة", "مظنّة ربحٍ وبركة، فأقدِم مع حسن التدبير."], ["السفر", "سفرٌ ميسَّر إن شاء الله، وتصدّق قبل خروجك."]],
  b: [["عامّة", "الأولى ترك الأمر أو تأجيله، والتماس غيره ممّا فيه الخير."], ["الزواج", "الأولى عدم الإقدام الآن."],
      ["العمل والتجارة", "مظنّة تعبٍ أو خسارة، فالأولى تركه."], ["السفر", "الأولى تأجيله أو تركه."]],
  m: [["عامّة", "لا يترجّح فيه فعلٌ ولا ترك، والأمر إلى اختيارك وتدبيرك."], ["الزواج", "لا بأس به، فقدّم المشورة والتحرّي ثم اختر."],
      ["العمل والتجارة", "متوسّط العاقبة، فادرسه واستشر أهل الخبرة."], ["السفر", "لا بأس به، مع حسن التدبير."]] };
function khiraResult() {
  const v = verses()[khiraIdx], k = C.khira, code = k.pageVerdict[khiraPage - 1] || "m";
  const th = [...new Set([k.pageThemeA[khiraPage - 1], k.pageThemeB[khiraPage - 1]].filter(x => x && x !== "-").map(x => k.labels[x]).filter(Boolean))];
  const V = { g: ["خيرةٌ جيّدة", "var(--good)"], b: ["خيرةٌ غير جيّدة", "var(--danger)"], m: ["خيرةٌ وسط", "var(--mid)"] }[code];
  const why = code === "m" ? "الآية قصصٌ أو أحكامٌ أو أخبار، لا بشارة فيها ولا تحذير." : th.length ? "في الآية وما يليها ذكرُ " + th.join(" و") + "." : code === "g" ? "في الآية بشارةٌ أو وعدٌ بالخير." : "في الآية إنذارٌ أو نهيٌ أو ذمّ.";
  return `<div class="page">${header("خِيرة القرآن الكريم", "", true)}
    <div class="verdict-hero" style="background:${V[1]}"><div style="font-size:26px;font-weight:800">${V[0]}</div>
      <div style="font-size:12px;font-weight:700;opacity:.9">الصفحة ${ar(khiraPage)} · سورة ${esc(v.name)} · الآية ${ar(v.n)}</div></div>
    <div class="mushaf"><div class="row" style="color:var(--gold);font-size:12px;font-weight:700"><span class="grow">سورة ${esc(v.name)}</span><span>صفحة ${ar(khiraPage)}</span></div>
      <div class="ayah" style="margin-top:12px;background:color-mix(in srgb, var(--gold) 13%, transparent);border-radius:12px;padding:12px">${esc(v.t)} ﴿${ar(v.n)}﴾</div>
      <div class="muted" style="text-align:center;margin-top:4px">أوّل سطرٍ في الصفحة</div>
      <button class="tool" style="margin-top:10px" onclick="openReader('q-${String(v.s).padStart(3, "0")}')">اقرأ السورة كاملة</button></div>
    <div class="card"><div style="font-weight:800">بيان الخيرة</div>${why ? `<div class="muted" style="font-size:13px;margin-top:6px">${why}</div>` : ""}
      ${KHIRA_DETAIL[code].map(([l, t]) => `<div class="row" style="align-items:flex-start;margin-top:10px;padding-top:10px;border-top:1px solid var(--line)"><b style="color:${V[1]};width:96px;flex:none;font-size:13px">${l}</b><span style="font-size:13px">${t}</span></div>`).join("")}</div>
    <p class="muted" style="text-align:center">الخيرة إرشادٌ عند الحيرة بعد التدبّر والمشورة، والقرار بعدها لك متوكّلاً على الله.</p>
    <div class="navbtns"><button class="btn gold" onclick="khiraIdx=null;khiraDone=[false,false,false,false];draw()">خيرة جديدة</button></div></div>`;
}

// ===== السبحة =====
const TMODES = [{ key: "zahra", name: "تسبيح الزهراء (ع)", stages: [["الله أكبر", 34], ["الحمد لله", 33], ["سبحان الله", 33]] },
  { key: "istighfar", name: "الاستغفار", target: 100, label: "أستغفر الله ربّي وأتوب إليه" },
  { key: "salawat", name: "الصلوات", target: 100, label: "اللهم صلّ على محمدٍ وآل محمد" }, { key: "free", name: "عدّاد حرّ", target: 33, label: "ذكرٌ حرّ" }];
let tMode = S.get("tMode", 0), tCount = S.get("tCount", 0), tStage = S.get("tStage", 0), tConfirm = false;
function Tasbih() {
  const m = TMODES[tMode], staged = !!m.stages, done = staged && tStage >= m.stages.length;
  const target = staged ? (done ? 1 : m.stages[tStage][1]) : m.target, label = staged ? (done ? "تمّ، تقبّل الله" : m.stages[tStage][0]) : m.label;
  const frac = Math.min(1, (done ? 1 : tCount / target));
  return `<div class="page">${header("السبحة", "", true)}
    <div class="modes">${TMODES.map((x, i) => `<button class="tool ${i === tMode ? "on" : ""}" onclick="tMode=${i};tCount=0;tStage=0;saveT();draw()">${x.name}</button>`).join("")}</div>
    <div style="text-align:center;font-family:var(--scripture);font-size:24px;margin-top:8px">${label}</div>
    <button class="ring" aria-label="عُدّ تسبيحة" onclick="tap()"><svg viewBox="0 0 230 230" style="position:absolute;inset:0"><circle cx="115" cy="115" r="100" fill="none" stroke="var(--line)" stroke-width="14"/>
      <circle cx="115" cy="115" r="100" fill="none" stroke="var(--gold)" stroke-width="14" stroke-linecap="round" stroke-dasharray="${frac * 628} 628" transform="rotate(-90 115 115)"/></svg>
      <span class="count">${done ? "✓" : ar(tCount)}</span></button>
    <div style="text-align:center" class="muted">${done ? "" : `من ${ar(target)}`}</div>
    <div class="navbtns"><button class="btn alt" onclick="resetT()">${tConfirm ? "اضغط مرّةً أخرى للتصفير" : "تصفير"}</button></div></div>`;
}
function saveT() { S.set("tMode", tMode); S.set("tCount", tCount); S.set("tStage", tStage); }
function tap() {
  const m = TMODES[tMode], staged = !!m.stages; if (staged && tStage >= m.stages.length) return;
  tCount++; tConfirm = false;
  if (staged && tCount >= m.stages[tStage][1]) { tStage++; tCount = 0; Native.haptic("success"); }
  else if (!staged && m.key !== "free" && tCount === m.target) Native.haptic("success");
  else if (m.key === "free" && tCount % 33 === 0) Native.haptic("success"); else Native.haptic("light");
  saveT(); draw();
}
function resetT() { if (!tCount && !tStage) return; if (!tConfirm) { tConfirm = true; draw(); setTimeout(() => { tConfirm = false; }, 3000); return; } tCount = 0; tStage = 0; tConfirm = false; saveT(); draw(); }
Tasbih.after = () => Native.keepAwake(true);

// ===== القبلة =====
function bearingToKaaba(lat, lng) {
  const k = [21.4225, 39.8262].map(x => x * Math.PI / 180), p = [lat, lng].map(x => x * Math.PI / 180);
  const y = Math.sin(k[1] - p[1]), x = Math.cos(p[0]) * Math.tan(k[0]) - Math.sin(p[0]) * Math.cos(k[1] - p[1]);
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}
let heading = null;
window.onHeading = h => { heading = h; const c = $("#compass"); if (c) c.style.transform = `rotate(${-h}deg)`;
  const st = $("#qstatus"), b = bearingToKaaba(settings.loc.lat, settings.loc.lng), diff = Math.abs(((b - h + 540) % 360) - 180);
  if (st) { st.textContent = diff < 4 ? "أنت باتجاه القبلة" : "أدِر الهاتف حتى يشير السهم إلى الأعلى"; if (diff < 4) Native.haptic("light"); } };
function Qibla() {
  const b = bearingToKaaba(settings.loc.lat, settings.loc.lng);
  return `<div class="page">${header("اتجاه القبلة", `${settings.loc.city} · ${ar(Math.round(b))}° من الشمال`, true)}
    <div class="compass" id="compass"><div style="position:absolute;top:6px;left:50%;transform:translateX(-50%);font-weight:800;color:var(--danger)">ش</div>
      <div style="position:absolute;inset:0;transform:rotate(${b}deg)"><div class="needle"></div><div class="kaaba">🕋</div></div></div>
    <div id="qstatus" style="text-align:center;font-weight:800">${Native.ok ? "جارٍ قراءة البوصلة…" : "البوصلة متاحةٌ على الآيفون"}</div>
    <p class="muted" style="text-align:center;line-height:1.8">ضع الهاتف مسطّحاً بعيداً عن المعادن والمغناطيس. إن اضطربت القراءة فحرّك الهاتف على شكل ٨ للمعايرة.</p></div>`;
}
Qibla.after = () => { Native.post({ type: "heading", on: true }); Native.keepAwake(true); };

// ===== الإقلاع =====
const TABS = { home: Home, lib: Library, prayer: Times, cal: Calendar, more: More };
function boot() {
  applyTheme();
  $("#nav").innerHTML = [["home", "🏠", "الرئيسية"], ["lib", "📖", "الفهرس"], ["prayer", "🕒", "الأوقات"], ["cal", "🌙", "التقويم"], ["more", "✦", "المزيد"]]
    .map(([t, i, n]) => `<button data-t="${t}" onclick="setTab('${t}')"><span class="i">${i}</span>${n}</button>`).join("");
  draw();
  setTimeout(buildIndex, 300);
  if (settings.notify) scheduleNotifications();
  const origBack = back; window.back = () => { Native.post({ type: "heading", on: false }); origBack(); };
}
window.addEventListener("DOMContentLoaded", boot);
