package com.shirazi.duaa.export

import com.shirazi.duaa.data.*
import com.shirazi.duaa.ui.*
import java.io.File

private fun esc(s: String): String {
    val b = StringBuilder("\"")
    for (c in s) when (c) {
        '"' -> b.append("\\\""); '\\' -> b.append("\\\\"); '\n' -> b.append("\\n"); '\r' -> b.append("\\r"); '\t' -> b.append("\\t")
        else -> if (c < ' ') b.append(String.format("\\u%04x", c.code)) else b.append(c)
    }
    return b.append('"').toString()
}

fun j(v: Any?): String = when (v) {
    null -> "null"
    is String -> esc(v)
    is Char -> esc(v.toString())
    is Boolean, is Int, is Long -> v.toString()
    is Double -> if (v.isFinite()) v.toString() else "null"
    is Float -> v.toString()
    is IntArray -> v.joinToString(",", "[", "]")
    is Array<*> -> v.joinToString(",", "[", "]") { j(it) }
    is Iterable<*> -> v.joinToString(",", "[", "]") { j(it) }
    is Map<*, *> -> v.entries.joinToString(",", "{", "}") { esc(it.key.toString()) + ":" + j(it.value) }
    is Pair<*, *> -> "[" + j(v.first) + "," + j(v.second) + "]"
    is Triple<*, *, *> -> "[" + j(v.first) + "," + j(v.second) + "," + j(v.third) + "]"
    else -> {
        val fs = v.javaClass.declaredFields.filter { !java.lang.reflect.Modifier.isStatic(it.modifiers) && !it.isSynthetic }
        fs.joinToString(",", "{", "}") { f -> f.isAccessible = true; esc(f.name) + ":" + j(f.get(v)) }
    }
}

fun main(args: Array<String>) {
    val out = StringBuilder("{")
    fun put(k: String, v: Any?) { if (out.length > 1) out.append(','); out.append(esc(k)).append(':').append(j(v)) }
    put("categories", Data.categories)
    put("khiraSteps", Data.khiraSteps)
    put("occasions", Data.occasions)
    put("cities", Data.cities)
    put("works", Amaal.works)
    put("adhkar", DailyContent.adhkar)
    put("hikam", DailyContent.hikam)
    put("asma", AsmaData.names)
    put("masoomeen", MasoomeenData.all)
    put("traits", traits)
    put("khira", mapOf("verdict" to KhiraVerdicts.VERDICT, "themeA" to KhiraVerdicts.THEME_A, "themeB" to KhiraVerdicts.THEME_B,
        "labels" to KhiraVerdicts.LABELS.mapKeys { it.key.toString() }, "pageStart" to KhiraPages.START,
        "pageVerdict" to KhiraPages.PAGE_VERDICT, "pageThemeA" to KhiraPages.PAGE_THEME_A, "pageThemeB" to KhiraPages.PAGE_THEME_B))
    put("hajj", mapOf("umrah" to UMRAH_STEPS, "hajj" to HAJJ_STEPS, "tawafDuas" to TAWAF_DUAS, "preliminaries" to HAJJ_PRELIMINARIES))
    put("juz", mapOf("sura" to QuranJuz.SURA, "aya" to QuranJuz.AYA))
    out.append('}')
    File(args[0]).writeText(out.toString())
    println("written " + out.length)
}
