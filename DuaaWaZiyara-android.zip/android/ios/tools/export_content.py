#!/usr/bin/env python3
"""Exports the verified Android content (categories, texts, calendar works, khira verdicts) to the iOS web core.
Run from the repo root after any content change:  python3 ios/tools/export_content.py"""
import re, glob, json, os
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
D = os.path.join(ROOT, 'app/src/main/java/com/shirazi/duaa/data/')
def span(t, i):
    d, j = 0, i
    while j < len(t):
        if t.startswith('"""', j): j = t.find('"""', j + 3) + 3; continue
        c = t[j]
        if c == '"':
            k = j + 1
            while t[k] != '"': k += 2 if t[k] == '\\' else 1
            j = k + 1; continue
        if c == '(': d += 1
        elif c == ')':
            d -= 1
            if d == 0: return j + 1
        j += 1
alld = '\n'.join(open(f, encoding='utf-8').read() for f in sorted(glob.glob(D + '*.kt')) if not f.endswith('DataWithdrawn.kt'))
def lits(call):
    out = []
    for a, b in re.findall(r'"""(.*?)"""|(null)', call, re.S): out.append(None if b else a)
    return out
items = {}
for m in re.finditer(r'DuaaItem\("([a-z0-9-]+)"', alld):
    call = alld[m.start(): span(alld, m.start() + 8)]; v = lits(call)
    joiner = '\n' if 'joinToString("\\n")' in call else ''
    text = v[3] if len(v) == 4 else (v[3] + '\n' + ' '.join(x for x in v[4:] if x)) if 'joinToString' in call else ''.join(x for x in v[3:] if x)
    items[m.group(1)] = {'id': m.group(1), 'title': v[0], 'src': v[1], 'intro': v[2], 'text': text}
lists = {}
for m in re.finditer(r'internal val (\w+)\s*:\s*List<DuaaItem>\s*=\s*', alld):
    r = alld[m.end():]; lists[m.group(1)] = r[:span(r, 6)] if r.startswith('listOf(') else r.split('\n')[0]
def ids_of(expr, seen=()):
    if expr.startswith('listOf('): return re.findall(r'DuaaItem\("([a-z0-9-]+)"', expr[:span(expr, 6)])
    return [i for w in re.findall(r'\w+', expr) if w in lists and w not in seen for i in ids_of(lists[w], seen + (w,))]
reg = open(D + 'AppRegistry.kt', encoding='utf-8').read()
order = re.findall(r'cat_([a-z]+)', reg[reg.find('val categories'): span(reg, reg.find('listOf(', reg.find('val categories')) + 6)])
def sahifa_order(i): return {'saj-mohimmat': 7, 'mu-makarim': 20}.get(i, int(i[4:]) if i[4:].isdigit() else 999)
cats = []
for cid in order:
    m = re.search(r'internal val cat_' + cid + r': Category = Category\(', alld)
    call = alld[m.end() - 1: span(alld, m.end() - 1)][1:-1]
    head = re.findall(r'"""(.*?)"""|"([^"]*)"', call[:600], re.S); h = [a or b for a, b in head]
    depth = last = j = 0
    while j < len(call):
        if call.startswith('"""', j): j = call.find('"""', j + 3) + 3; continue
        ch = call[j]
        if ch == '"':
            k = j + 1
            while call[k] != '"': k += 2 if call[k] == '\\' else 1
            j = k + 1; continue
        depth += (ch == '(') - (ch == ')')
        if ch == ',' and depth == 0: last = j + 1
        j += 1
    ids = list(dict.fromkeys(ids_of(call[last:].strip())))
    if cid == 'sahifa': ids.sort(key=sahifa_order)
    if ids: cats.append({'id': cid, 'icon': h[1], 'name': h[2], 'desc': h[3], 'items': ids})
used = {i for c in cats for i in c['items']}
works = []
for f in sorted(glob.glob(D + 'Amaal*.kt')):
    t = open(f, encoding='utf-8').read()
    for m in re.finditer(r'\bWork\((\d+),\s*(\d+),', t):
        call = t[m.start(): span(t, m.start() + 4)]
        s = [a if a else b for a, b in re.findall(r'"""(.*?)"""|"((?:\\.|[^"\\])*)"', call[m.end() - m.start():], re.S)][:2]
        s = [x.encode().decode('unicode_escape').encode('latin-1').decode('utf-8') if '\\' in x else x for x in s]
        works.append({'m': int(m.group(1)), 'd': int(m.group(2)), 'title': s[0], 'body': s[1]})
works.sort(key=lambda w: (w['m'], w['d']))
kv = open(D + 'KhiraVerdicts.kt', encoding='utf-8').read()
g = lambda n: re.search(n + r' = "([^"]*)"', kv).group(1)
KP = open(D + 'KhiraPages.kt', encoding='utf-8').read()
PAGES = [int(x) for x in re.search(r'intArrayOf\(([^)]*)\)', KP).group(1).split(',')]
pg = lambda n: re.search(n + r' = "([^"]*)"', KP).group(1)
labels = dict(re.findall(r"'(\w)' to \"([^\"]+)\"", kv))
out = {'categories': cats, 'items': {i: items[i] for i in used}, 'works': works,
       'khira': {'verdict': g('VERDICT'), 'themeA': g('THEME_A'), 'themeB': g('THEME_B'), 'labels': labels, 'pages': PAGES, 'pageVerdict': pg('PAGE_VERDICT'), 'pageThemeA': pg('PAGE_THEME_A'), 'pageThemeB': pg('PAGE_THEME_B')},
       'weekly': [['السبت', 'd-sat', 'z-nabi'], ['الأحد', 'd-sun', 'z-amin'], ['الإثنين', 'd-mon', 'z-mutlaqa'], ['الثلاثاء', 'd-tue', 'z-baqi'],
                  ['الأربعاء', 'd-wed', 'z-kadhim'], ['الخميس', 'd-thu', 'z-askari'], ['الجمعة', 'd-fri', 'z-yasin']]}
dst = os.path.join(ROOT, 'ios/RafiqIOS/web/content.js')
open(dst, 'w', encoding='utf-8').write('window.CONTENT = ' + json.dumps(out, ensure_ascii=False) + ';\n')
print(f"exported {len(cats)} categories, {len(used)} texts, {len(works)} calendar works, khira {len(out['khira']['verdict'])} verdicts -> {os.path.getsize(dst)//1024} KB")
