#!/usr/bin/env bash
# Regenerates ios/Rafiq/Resources/content.json from the Android data package (single source of truth).
# Needs a JDK and any kotlin-compiler-embeddable jar (e.g. the one bundled with Gradle).
set -e
cd "$(dirname "$0")/../.."
D=app/src/main/java/com/shirazi/duaa
JAR=$(ls /opt/gradle*/lib/kotlin-compiler-embeddable-*.jar ~/.gradle/wrapper/dists/*/*/*/lib/kotlin-compiler-embeddable-*.jar 2>/dev/null | head -1)
L=$(dirname "$JAR"); CP=$JAR
for j in kotlin-stdlib kotlin-script-runtime kotlin-reflect trove4j annotations kotlinx-coroutines-core-jvm kotlin-daemon-embeddable; do CP=$CP:$(ls $L/$j-*.jar | head -1); done
OUT=$(mktemp -d)
java -Xmx6g -cp "$CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -cp "$(ls $L/kotlin-stdlib-*.jar | head -1)" -d "$OUT" \
  $(ls $D/data/*.kt | grep -v Settings.kt) $D/ui/HajjData.kt ios/tools/Export.kt
java -cp "$OUT:$(ls $L/kotlin-stdlib-*.jar | head -1)" com.shirazi.duaa.export.ExportKt ios/Rafiq/Resources/content.json
rm -rf "$OUT"
