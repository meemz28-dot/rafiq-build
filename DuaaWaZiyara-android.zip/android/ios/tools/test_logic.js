// Ground truth taken from real device screenshots of the Android app. Fails the iOS build if the port drifts.
const path = require("path");
const { Hijri, Prayer, ArSearch } = require(path.join(__dirname, "..", "RafiqIOS", "web", "logic.js"));
let fails = 0;
const eq = (label, got, want) => { const ok = got === want; if (!ok) fails++; console.log(`${ok ? "OK  " : "FAIL"} ${label}: ${got}${ok ? "" : "  (expected " + want + ")"}`); };
let h = Hijri.ofDate(new Date(2026, 8, 27)); eq("27 Sep 2026", `${h.d}/${h.m}/${h.y}`, "14/4/1448");
h = Hijri.ofDate(new Date(2026, 6, 23)); eq("23 Jul 2026", `${h.d}/${h.m}/${h.y}`, "7/2/1448");
const m = Prayer.compute(new Date(2026, 8, 27), 26.2285, 50.586, 3, "jafari");
[["fajr", "4:21 ص"], ["dhuhr", "11:29 ص"], ["asr", "2:54 م"], ["maghrib", "5:43 م"], ["isha", "6:28 م"]].forEach(([k, w]) => eq("Manama " + k, Prayer.fmt(m[k]), w));
const d = Prayer.compute(new Date(2026, 6, 19), 25.2048, 55.2708, 4, "jafari");
[["fajr", "4:24 ص"], ["sunrise", "5:40 ص"], ["dhuhr", "12:25 م"], ["asr", "3:50 م"], ["maghrib", "7:26 م"], ["isha", "8:16 م"], ["midnight", "11:55 م"]].forEach(([k, w]) => eq("Dubai " + k, Prayer.fmt(d[k]), w));
eq("search normalisation", ArSearch.normalize("أَلْحَمْدُ لِلّٰهِ"), ArSearch.normalize("الحمد لله"));
for (let y = 1440; y <= 1460; y++) { let days = 0; for (let mo = 1; mo <= 12; mo++) days += Hijri.monthLength(y, mo); if (days < 354 || days > 355) { fails++; console.log("FAIL year length", y, days); } }
console.log(fails ? `LOGIC: ${fails} FAILURES` : "LOGIC: ALL OK"); process.exit(fails ? 1 : 0);
