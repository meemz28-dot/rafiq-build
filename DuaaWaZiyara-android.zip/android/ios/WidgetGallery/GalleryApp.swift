import SwiftUI
import WidgetKit

// Debug-only app used by CI: renders every widget at its real size to PNG files
// (Documents/widgets/*.png) so the widgets can be checked without a device.

@main
struct GalleryApp: App {
    var body: some Scene {
        WindowGroup { GalleryRoot() }
    }
}

struct GalleryRoot: View {
    @State private var status = "rendering…"
    var body: some View {
        Text(status).task { await render() }
    }

    private static let sizes: [WidgetFamily: CGSize] = [
        .systemSmall: CGSize(width: 170, height: 170), .systemMedium: CGSize(width: 364, height: 170),
        .systemLarge: CGSize(width: 364, height: 382), .accessoryRectangular: CGSize(width: 172, height: 76),
    ]

    @MainActor private func render() async {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("widgets")
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let city = WidgetCity.all.first { $0.n.contains("دبي") } ?? WidgetCity.all[0]
        let now = Date()
        let prayer = PrayerProvider().entry(at: now, city: city, method: "jafari")
        let daily = DailyEntry.make(now)
        let tasbih = TasbihEntry(date: now, count: 20, rounds: 0)

        func card<V: View, B: View>(_ name: String, _ fam: WidgetFamily, _ bg: B, _ v: V) {
            let size = Self.sizes[fam]!
            let r: CGFloat = fam == .accessoryRectangular ? 12 : 22
            let view = ZStack {
                Color(red: 0x15 / 255, green: 0x30 / 255, blue: 0x3A / 255)
                v.padding(fam == .accessoryRectangular ? 4 : 16)
                    .frame(width: size.width, height: size.height)
                    .background(bg)
                    .clipShape(RoundedRectangle(cornerRadius: r, style: .continuous))
            }
            .frame(width: size.width + 24, height: size.height + 24)
            .environment(\.layoutDirection, .rightToLeft)
            let ren = ImageRenderer(content: view)
            ren.scale = 3
            if let data = ren.uiImage?.pngData() { try? data.write(to: dir.appendingPathComponent("\(name).png")) }
        }

        card("prayer-small", .systemSmall, WS.prayerBG, PrayerWidgetView(entry: prayer, forced: .systemSmall))
        card("prayer-medium", .systemMedium, WS.prayerBG, PrayerWidgetView(entry: prayer, forced: .systemMedium))
        card("prayer-large", .systemLarge, WS.prayerBG, PrayerWidgetView(entry: prayer, forced: .systemLarge))
        card("prayer-lock", .accessoryRectangular, Color.white.opacity(0.18), PrayerWidgetView(entry: prayer, forced: .accessoryRectangular).foregroundStyle(.white))
        card("daily-small", .systemSmall, WS.greenBG, DailyWidgetView(entry: daily, forced: .systemSmall))
        card("daily-medium", .systemMedium, WS.greenBG, DailyWidgetView(entry: daily, forced: .systemMedium))
        card("daily-large", .systemLarge, WS.greenBG, DailyWidgetView(entry: daily, forced: .systemLarge))
        card("daily-lock", .accessoryRectangular, Color.white.opacity(0.18), DailyWidgetView(entry: daily, forced: .accessoryRectangular).foregroundStyle(.white))
        card("tasbih-small", .systemSmall, WS.paperBG, TasbihWidgetView(entry: tasbih, forced: .systemSmall))
        card("tasbih-medium", .systemMedium, WS.paperBG, TasbihWidgetView(entry: tasbih, forced: .systemMedium))
        for p in 0..<3 {
            let e = HubEntry(date: now, prayer: prayer, daily: daily, page: p, tasbih: 20)
            let bg: AnyView = p == 0 ? AnyView(WS.prayerBG) : (p == 1 ? AnyView(WS.greenBG) : AnyView(WS.paperBG))
            card("hub-medium-\(p)", .systemMedium, bg, HubWidgetView(entry: e, forced: .systemMedium))
        }
        card("hub-large", .systemLarge, WS.prayerBG,
             HubWidgetView(entry: HubEntry(date: now, prayer: prayer, daily: daily, page: 0, tasbih: 20), forced: .systemLarge))
        try? "ok".write(to: dir.appendingPathComponent("done.txt"), atomically: true, encoding: .utf8)
        status = "done"
    }
}
