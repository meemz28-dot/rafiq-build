# Porting the Android screens to native SwiftUI (Liquid Glass)

Project root: `/home/claude/android/android`. Android source: `app/src/main/java/com/shirazi/duaa/` (Kotlin + Compose).
iOS target: `ios/Rafiq/` (SwiftUI, iOS 18 minimum, built with Xcode 26 / iOS 26 SDK, Swift 5 language mode).
There is **no Swift compiler here**. The code is compiled later on GitHub, so write conservative, obviously-correct Swift.

## Read these first (the contract; do not edit them)
- `ios/Rafiq/Core/Models.swift`: `Library.shared` (all content), `DuaaCategory`, `DuaaItem`, `Occasion`, `City`, `Work`, `Dhikr`, `Hikma`, `AsmaName`, `Masoom`, `Trait`, `HajjStep`, `HajjTopic`, `KhiraData`, `JuzData`; `Int.ar` (Arabic digits), `String.arabicDigits`, `String.westernDigits`.
- `ios/Rafiq/Core/Store.swift`: `@Observable Store` (UserDefaults). Generic: `int/double/bool/string/strings(key, def)`, `put(key, value)`, `toggle(key, value)`, `series(key)`, `setSeries(key, day:, value:, keepDays:)`, `seriesValue(key, offset:)`, `today` (day number). Specific: fontSize, lineSpacing, tashkeel, sepia, keepAwake, theme, onboardingDone, hijriAdj, method, location(), selectCity, setCustomLocation, times(for:), hijriToday(), favourites, recordRead/recentReads/isRead, scroll/saveScroll, bookmarks, wirdMask/toggleWird, streak, dhikrGoal/dhikrToday/addDhikr, dayIndex.
- `ios/Rafiq/Core/Hijri.swift`, `PrayerTimes.swift`, `Logic.swift` (Khums, ArabicSearch, Recommend, Fasting, Qibla), `Services.swift` (LocationService, Notifier).
- `ios/Rafiq/Design/Theme.swift`: `Brand` colours, `Font.scripture(_)` (Amiri), `Font.counter(_)`, `.glass()`, `.glassCapsule()`, `.glassCircle()`, `.glassButton(prominent:)`, `.card()`, `.hero()`, `.keepScreenAwake(_)`, `StarPattern`, `StarShape`, `IconChip`, `ToolTile`, `SectionTitle`, `Tag`, `EmptyStateView`, `ScreenScroll`, `Haptic`.
- `ios/Rafiq/App/RafiqApp.swift`: `AppNav` (`nav.open(.category(id))`, `nav.openReader(cat, item)`, `nav.openTool(.khira)`, `nav.present(.tasbih)`), `Tool`, `Route`, `SheetKind`, and the **exact view names** the router expects.

## Rules
1. Access state with `@Environment(Store.self) private var store` and `@Environment(AppNav.self) private var nav`.
2. Pushed screens (tools, category, reader) must NOT wrap themselves in `NavigationStack`; set `.navigationTitle(..)` and `.navigationBarTitleDisplayMode(..)`. Sheet views are already wrapped in a `NavigationStack` by the router; give them a toolbar "تم" button using `@Environment(\.dismiss)`. Exception: `TasbihView` is presented bare (full design control).
3. Design language ("محراب" + JazakAllah reference + Apple Liquid Glass):
   - Native first: `List`/`Form` with `.listStyle(.insetGrouped)`, large titles, toolbars, `.searchable`, `ShareLink`, `Menu`, `Picker`, `Toggle`, `Stepper`, sheets. These get Liquid Glass automatically on iOS 26.
   - Hero sections: dark teal patterned surface via `.hero()`, white text, with **glass** controls floating on it (`.glassCapsule()`, `.glass()`, `.glassButton()`).
   - Content cards on the grouped background: `.card()`. Do not put `.glass` on plain reading content.
   - Gold (`Brand.gold`) only for highlights: the current prayer, today, counters, active state. Emerald (`Brand.emerald`) is the tint.
   - Scripture (Quran, dua, ziyara, hadith text) uses `Font.scripture(size)`; UI uses the system font (SF Arabic).
   - Category accents: `Brand.categoryColors(id)` and `Brand.categorySymbol(id)`. Use SF Symbols only (no images).
4. Persistence: reuse the Android preference keys from `data/Settings.kt` through the generic Store API (e.g. `store.int("qFajr")`, `store.put("qFajr", n)`). Do not add stored properties to Store.
5. Copy all Arabic text verbatim from the Kotlin sources. Keep the same features and behaviour as Android. No em-dashes in any new English comments.
6. Naming: only the public view names listed for you. Every helper type/function must be `private` or `fileprivate`, or prefixed with your screen name, to avoid collisions with other files.
7. Swift safety: no force unwraps of data lookups; use `ForEach(Array(xs.enumerated()), id: \.offset)` when items are not Identifiable; keep view bodies small (split into computed properties / private subviews) so the type checker does not time out; avoid ambiguous closures; no `#Preview`; no third-party packages; iOS 18 APIs are fine, iOS 26-only APIs only through the Theme helpers.
8. Write your files under `ios/Rafiq/Screens/<Group>/`. When done, re-read every file you wrote end-to-end and check braces, parentheses, labels and types against the core API.
9. Report back: files written, view names provided, any Android behaviour you could not port, and any API you wished the core had.
