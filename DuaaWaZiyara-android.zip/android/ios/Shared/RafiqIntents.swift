import Foundation
import AppIntents

/// Places Siri, Shortcuts, the Action Button and Control Center can open.
enum RafiqDestination: String, AppEnum {
    case prayer, tasbih, qibla, shrine, khira, kumayl, tawassul, sabah, ashura

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "وجهة"
    static var caseDisplayRepresentations: [RafiqDestination: DisplayRepresentation] = [
        .prayer: "مواقيت الصلاة",
        .tasbih: "التسبيح",
        .qibla: "القبلة",
        .shrine: "بوصلة الزيارة",
        .khira: "الخيرة",
        .kumayl: "دعاء كميل",
        .tawassul: "دعاء التوسل",
        .sabah: "دعاء الصباح",
        .ashura: "زيارة عاشوراء"
    ]
}

/// Hands an opened destination to the running app. If the app is not ready yet, the request waits
/// in UserDefaults and the app consumes it on appear.
enum RafiqIntentBridge {
    static let pendingKey = "pendingIntentDestination"
    @MainActor static var handler: ((String) -> Void)?

    @MainActor static func deliver(_ raw: String) {
        if let h = handler { h(raw) } else { UserDefaults.standard.set(raw, forKey: pendingKey) }
    }
}

struct OpenRafiqIntent: AppIntent {
    static var title: LocalizedStringResource = "فتح في رفيق المؤمن"
    static var description = IntentDescription("يفتح التطبيق على الصفحة المختارة")
    static var openAppWhenRun: Bool = true

    @Parameter(title: "الوجهة", default: .tasbih) var destination: RafiqDestination

    init() {}
    init(destination: RafiqDestination) { self.destination = destination }

    @MainActor func perform() async throws -> some IntentResult {
        RafiqIntentBridge.deliver(destination.rawValue)
        return .result()
    }
}
