import Foundation
import ActivityKit

/// Live Activity for the next prayer (compiled into both the app and the widget extension).
struct PrayerActivityAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var prayer: String      // e.g. "المغرب"
        var time: String        // formatted local time
        var target: Date        // when it is due
    }
    var city: String
}
