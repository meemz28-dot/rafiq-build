import Foundation
import ActivityKit

/// Live Activity for the next prayer (compiled into both the app and the widget extension).
struct PrayerActivityAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var prayer: String      // e.g. "المغرب"
        var time: String        // formatted local time
        var target: Date        // when it is due
        var since: Date? = nil  // previous prayer (start of the progress bar)
        var after: String? = nil // the prayer after it, e.g. "العشاء ٦:٣٦"
    }
    var city: String
}
