# رفيق المؤمن for iPhone (native SwiftUI, Liquid Glass)

- Native SwiftUI app, iOS 18 minimum, built with Xcode 26 so iOS 26 devices get Liquid Glass (tab bar, toolbars, glass controls).
- Content is the same verified library as Android: `Rafiq/Resources/content.json` is generated from the Android data package by `tools/export_json.sh` (never edit it by hand).
- Structure: `Rafiq/App` (app, tabs, router), `Rafiq/Core` (models, Store, prayer times, Hijri, khums, search, services), `Rafiq/Design` (brand + glass components), `Rafiq/Screens/*` (all screens).
- Build: GitHub Actions `build-ios.yml` on a macOS 26 runner (xcodegen + xcodebuild, unsigned), then sideload the .ipa with Sideloadly.
- Not ported: home-screen widget (needs a paid Apple developer account for app groups when sideloading).
