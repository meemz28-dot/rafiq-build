# رفيق المؤمن: Launch Task List

Status key: DONE / IN PROGRESS / BLOCKED / TODO. Owner: **M** = Munther, **C** = Claude.

## Phase 0: Green build (gate: APK installs and runs on a device)
| # | Task | Owner | Status |
|---|------|-------|--------|
| 0.1 | GitHub Actions pipeline on Gradle 8.11.1 | M+C | DONE |
| 0.2 | Paste `===== ERRORS =====` from the latest Actions run | M | BLOCKED on M |
| 0.3 | Fix whatever the log names | C | Waiting on 0.2 |
| 0.4 | Install APK, send screenshots for device QA | M | TODO |

## Phase 1: Launch on Google Play (gate: 10K installs, D30 retention above 20%)
| # | Task | Owner | Status |
|---|------|-------|--------|
| 1.1 | Store description AR + EN | C | DONE, rewritten for 1.0.0 and verified against code |
| 1.2 | Privacy policy AR + EN | C | DONE, rewritten; hostable page in store-listing/privacy-site/ |
| 1.3 | Feature graphic + promo square | C | DONE (store-listing/assets/) |
| 1.4 | Share-app + rate-app in About | C | DONE (v20.1) |
| 1.5 | Occasion reminders (retention engine) | C | DONE (v20.0) |
| 1.6 | Replace placeholder support email `feedback@rafiqalmumin.app` with a real inbox | M | TODO |
| 1.7 | Host privacy policy (GitHub Pages on rafiq-build works) | M | TODO |
| 1.8 | Google Play developer account (one-time USD 25) | M | TODO |
| 1.9 | Generate keystore, build signed AAB (store-listing/RELEASE-1.md, release workflow ready) | M | TODO, needs 0.x |
| 1.10 | 6 to 8 device screenshots | M | TODO, needs 0.4 |
| 1.11 | Scholar review pack (sources, orthography, weekday-ziyara mapping, Mafatih trimming rule) | C | DONE (Claude Doc); awaiting scholar sign-off |
| 1.12 | Internal testing track, then production | M | TODO |

## Phase 2: Localize (gate: 250K MAU)
| # | Task | Owner | Status |
|---|------|-------|--------|
| 2.1 | Move UI strings to resources (prerequisite for any language) | C | TODO |
| 2.2 | English UI | C | TODO |
| 2.3 | Farsi and Urdu UI (native reviewers needed) | M+C | TODO |
| 2.4 | Marja manasik (Shirazi, Modarresi) once books are uploaded | M+C | BLOCKED on uploads |

## Phase 3: Transact (gate: first licensed payment flow live)
| # | Task | Owner | Status |
|---|------|-------|--------|
| 3.1 | Partnership with one marja office for khums and sadaqa | M | TODO |
| 3.2 | Link-out from the khums calculator to the partner's official payment page | C | TODO, needs 3.1 |
| 3.3 | Legal and payments review | M | TODO |

## Phase 4: Travel (gate: transaction revenue above subscription revenue)
| # | Task | Owner | Status |
|---|------|-------|--------|
| 4.1 | Arbaeen and ziyara booking partner | M | TODO |
| 4.2 | In-app trip planner tied to the calendar | C | TODO |
