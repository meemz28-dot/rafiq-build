import Foundation
import CoreLocation
import UserNotifications
import Observation

// MARK: - Location and compass heading

@Observable
final class LocationService: NSObject, CLLocationManagerDelegate {
    @ObservationIgnored private let manager = CLLocationManager()
    var heading: Double?            // true heading in degrees, nil until available
    var location: CLLocation?
    var authorized: Bool = false
    var errorText: String?

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyKilometer
        manager.headingFilter = 1
    }

    func requestLocation() {
        errorText = nil
        if manager.authorizationStatus == .notDetermined { manager.requestWhenInUseAuthorization() }
        manager.requestLocation()
    }
    func startHeading() {
        if manager.authorizationStatus == .notDetermined { manager.requestWhenInUseAuthorization() }
        if CLLocationManager.headingAvailable() { manager.startUpdatingHeading() }
        manager.requestLocation()
    }
    func stopHeading() { manager.stopUpdatingHeading() }

    func locationManagerDidChangeAuthorization(_ m: CLLocationManager) {
        authorized = m.authorizationStatus == .authorizedWhenInUse || m.authorizationStatus == .authorizedAlways
    }
    func locationManager(_ m: CLLocationManager, didUpdateLocations locations: [CLLocation]) { location = locations.last }
    func locationManager(_ m: CLLocationManager, didFailWithError error: Error) { errorText = "تعذّر تحديد الموقع" }
    func locationManager(_ m: CLLocationManager, didUpdateHeading h: CLHeading) {
        heading = h.trueHeading >= 0 ? h.trueHeading : h.magneticHeading
    }

    /// Reverse-geocodes to a city name (best effort).
    func cityName(for loc: CLLocation) async -> String {
        let marks = try? await CLGeocoder().reverseGeocodeLocation(loc, preferredLocale: Locale(identifier: "ar"))
        return marks?.first?.locality ?? marks?.first?.administrativeArea ?? "موقعي"
    }
}

// MARK: - Local notifications (prayer times, daily dhikr)

enum Notifier {
    static func requestPermission() async -> Bool {
        (try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])) ?? false
    }

    /// Schedules the five prayers for the next 12 days (iOS allows 64 pending requests).
    static func schedulePrayers(store: Store) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: (0..<12).flatMap { d in PrayerTimes.prayerKeys.map { "p-\(d)-\($0)" } })
        guard store.bool("notify", false) else { return }
        let city = store.location()
        for d in 0..<12 {
            guard let day = Calendar.current.date(byAdding: .day, value: d, to: Date()) else { continue }
            let t = PrayerTimes.compute(date: day, lat: city.lat, lng: city.lng, tz: city.tz, methodKey: store.method)
            for key in PrayerTimes.prayerKeys {
                let when = PrayerTimes.date(PrayerTimes.value(t, key), on: day)
                if when < Date() { continue }
                let c = UNMutableNotificationContent()
                c.title = "حان وقت صلاة \(PrayerTimes.name(key))"
                c.body = "\(city.n) · \(PrayerTimes.fmt(PrayerTimes.value(t, key)))"
                c.sound = .default
                let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: when)
                center.add(UNNotificationRequest(identifier: "p-\(d)-\(key)", content: c,
                                                 trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
            }
        }
    }

    /// One repeating reminder at hour:minute with the given id.
    static func scheduleDaily(id: String, hour: Int, minute: Int, title: String, body: String) {
        let c = UNMutableNotificationContent(); c.title = title; c.body = body; c.sound = .default
        var dc = DateComponents(); dc.hour = hour; dc.minute = minute
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: id, content: c,
                                                                      trigger: UNCalendarNotificationTrigger(dateMatching: dc, repeats: true)))
    }
    static func cancel(_ ids: [String]) { UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ids) }
}
