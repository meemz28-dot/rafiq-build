import Foundation
import Observation

/// All user state, persisted in UserDefaults (on device only).
/// Generic accessors read `rev` so SwiftUI views refresh after any write.
@Observable
final class Store {
    @ObservationIgnored private let ud = UserDefaults.standard
    /// Bumped on every write; read by every getter so views observe changes.
    var rev = 0

    // MARK: Generic typed storage (use the same keys as the Android app where one exists)
    func int(_ k: String, _ def: Int = 0) -> Int { _ = rev; return ud.object(forKey: k) == nil ? def : ud.integer(forKey: k) }
    func double(_ k: String, _ def: Double = 0) -> Double { _ = rev; return ud.object(forKey: k) == nil ? def : ud.double(forKey: k) }
    func bool(_ k: String, _ def: Bool = false) -> Bool { _ = rev; return ud.object(forKey: k) == nil ? def : ud.bool(forKey: k) }
    func string(_ k: String, _ def: String = "") -> String { _ = rev; return ud.string(forKey: k) ?? def }
    func strings(_ k: String) -> [String] { _ = rev; return ud.stringArray(forKey: k) ?? [] }
    func has(_ k: String) -> Bool { _ = rev; return ud.object(forKey: k) != nil }
    func put(_ k: String, _ v: Any?) { if let v { ud.set(v, forKey: k) } else { ud.removeObject(forKey: k) }; rev += 1 }

    /// Toggles membership of `value` in a string-array set stored at `k`.
    func toggle(_ k: String, _ value: String) {
        var a = strings(k)
        if let i = a.firstIndex(of: value) { a.remove(at: i) } else { a.append(value) }
        put(k, a)
    }

    // MARK: Day numbers and daily series (value per day, kept N days)
    static func dayNumber(_ date: Date = Date()) -> Int {
        let tz = Double(TimeZone.current.secondsFromGMT(for: date))
        return Int(floor((date.timeIntervalSince1970 + tz) / 86400))
    }
    var today: Int { Store.dayNumber() }

    func series(_ k: String) -> [Int: Int] {
        _ = rev
        var out: [Int: Int] = [:]
        for part in (ud.string(forKey: k) ?? "").split(separator: ",") {
            let p = part.split(separator: ":")
            if p.count == 2, let d = Int(p[0]), let v = Int(p[1]) { out[d] = v }
        }
        return out
    }
    func setSeries(_ k: String, day: Int, value: Int, keepDays: Int = 90) {
        var m = series(k); m[day] = value
        let enc = m.filter { $0.key >= day - keepDays }.sorted { $0.key < $1.key }.map { "\($0.key):\($0.value)" }.joined(separator: ",")
        put(k, enc)
    }
    func seriesValue(_ k: String, offset: Int) -> Int { series(k)[today - offset] ?? 0 }

    // MARK: Appearance and reader
    var fontSize: Double { get { double("fontSize", 22) } set { put("fontSize", newValue) } }
    var lineSpacing: Double { get { double("rLine", 2.0) } set { put("rLine", newValue) } }
    var tashkeel: Bool { get { bool("rTashkeel", true) } set { put("rTashkeel", newValue) } }
    var sepia: Bool { get { bool("rSepia", false) } set { put("rSepia", newValue) } }
    var keepAwake: Bool { get { bool("keepAwake", true) } set { put("keepAwake", newValue) } }
    /// "system", "light" or "dark"
    var theme: String { get { string("theme", "system") } set { put("theme", newValue) } }
    var onboardingDone: Bool { get { bool("onboarded", false) } set { put("onboarded", newValue) } }

    // MARK: Location, method, Hijri adjustment
    var hijriAdj: Int { get { int("hijriAdj", 0) } set { put("hijriAdj", max(-2, min(2, newValue))) } }
    var method: String { get { string("method", "jafari") } set { put("method", newValue) } }
    var cityIdx: Int { get { int("cityIdx", 0) } set { put("cityIdx", newValue) } }
    func location() -> City {
        if has("lat"), has("lng") {
            return City(n: string("cityName", "موقعي"), lat: double("lat"), lng: double("lng"), tz: double("tz", Double(TimeZone.current.secondsFromGMT()) / 3600))
        }
        let cs = Library.shared.cities
        return cs[max(0, min(cs.count - 1, cityIdx))]
    }
    func setCustomLocation(name: String, lat: Double, lng: Double, tz: Double) {
        ud.set(name, forKey: "cityName"); ud.set(lat, forKey: "lat"); ud.set(lng, forKey: "lng"); ud.set(tz, forKey: "tz"); rev += 1
    }
    func selectCity(_ idx: Int) {
        for k in ["cityName", "lat", "lng", "tz"] { ud.removeObject(forKey: k) }
        put("cityIdx", idx)
    }
    func times(for date: Date = Date()) -> PrayerTimes.Times {
        let c = location()
        return PrayerTimes.compute(date: date, lat: c.lat, lng: c.lng, tz: c.tz, methodKey: method)
    }
    func hijriToday() -> Hijri.HDate { _ = rev; return Hijri.today(adj: hijriAdj) }

    // MARK: Favourites, reading history, bookmarks
    func isFav(_ c: String, _ i: String) -> Bool { strings("favs").contains("\(c)|\(i)") }
    func toggleFav(_ c: String, _ i: String) { toggle("favs", "\(c)|\(i)") }
    var favorites: [(String, String)] { strings("favs").compactMap { s in let p = s.split(separator: "|"); return p.count == 2 ? (String(p[0]), String(p[1])) : nil } }

    func recordRead(_ c: String, _ i: String) {
        var r = strings("recent").filter { $0 != "\(c)|\(i)" }
        r.insert("\(c)|\(i)", at: 0)
        put("recent", Array(r.prefix(30)))
        var counts = strings("readKeys"); if !counts.contains("\(c)|\(i)") { counts.append("\(c)|\(i)"); put("readKeys", counts) }
        setSeries("readHist", day: today, value: seriesValue("readHist", offset: 0) + 1)
    }
    var recentReads: [(String, String)] { strings("recent").compactMap { s in let p = s.split(separator: "|"); return p.count == 2 ? (String(p[0]), String(p[1])) : nil } }
    func isRead(_ c: String, _ i: String) -> Bool { strings("readKeys").contains("\(c)|\(i)") }
    func scroll(_ c: String, _ i: String) -> Double { double("scroll_\(c)|\(i)", 0) }
    func saveScroll(_ c: String, _ i: String, _ v: Double) { ud.set(v, forKey: "scroll_\(c)|\(i)") }  // silent: no view refresh

    struct Bookmark: Hashable { let catId: String; let itemId: String; let para: Int; let title: String }
    var bookmarks: [Bookmark] {
        strings("bookmarks").compactMap { s in
            let p = s.components(separatedBy: "§"); guard p.count == 4, let n = Int(p[2]) else { return nil }
            return Bookmark(catId: p[0], itemId: p[1], para: n, title: p[3])
        }
    }
    func addBookmark(_ b: Bookmark) { var a = strings("bookmarks"); a.insert("\(b.catId)§\(b.itemId)§\(b.para)§\(b.title)", at: 0); put("bookmarks", a) }
    func removeBookmark(_ b: Bookmark) { put("bookmarks", strings("bookmarks").filter { $0 != "\(b.catId)§\(b.itemId)§\(b.para)§\(b.title)" }) }

    // MARK: Daily wird (bit mask per day) and streak
    var wirdMask: Int { series("wird")[today] ?? 0 }
    func toggleWird(_ bit: Int) { setSeries("wird", day: today, value: wirdMask ^ (1 << bit)); touchStreak() }
    func touchStreak() {
        let last = int("streakDay", -1)
        if last == today { return }
        let s = last == today - 1 ? int("streak", 0) + 1 : 1
        put("streak", s); put("streakDay", today); if s > int("bestStreak", 0) { put("bestStreak", s) }
    }
    var streak: Int { int("streakDay", -1) >= today - 1 ? int("streak", 0) : 0 }

    // MARK: Tasbih
    var dhikrGoal: Int { get { int("dhikrGoal", 100) } set { put("dhikrGoal", newValue) } }
    var dhikrToday: Int { series("dhikrHist")[today] ?? 0 }
    func addDhikr(_ n: Int) { setSeries("dhikrHist", day: today, value: dhikrToday + n) }

    /// Day-of-year index used to rotate daily content (same as Android).
    var dayIndex: Int { today % 366 }
}
