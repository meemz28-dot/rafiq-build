import SwiftUI
import StoreKit

// MARK: - الإعدادات (ported from Android ui/Sheets.kt SettingsSheet)

struct SettingsView: View {
    @Environment(Store.self) private var store
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        Form {
            appearanceSection
            fontSection
            readerSection
            SettingsNotificationsSections()
            placeSections
            hijriSection
            aboutSection
        }
        .formStyle(.grouped)
        .navigationTitle("الإعدادات")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("تم") { dismiss() }
            }
        }
    }

    // MARK: Appearance

    private var themeBinding: Binding<String> {
        Binding(get: { store.theme }, set: { store.theme = $0 })
    }

    private var appearanceSection: some View {
        Section("المظهر") {
            Picker("المظهر", selection: themeBinding) {
                Text("تلقائي").tag("system")
                Text("فاتح").tag("light")
                Text("داكن").tag("dark")
            }
            .pickerStyle(.segmented)
        }
    }

    // MARK: Font size with live preview

    private var fontBinding: Binding<Double> {
        Binding(get: { store.fontSize }, set: { store.fontSize = max(15, min(40, $0)) })
    }

    private var fontSection: some View {
        let sample = "بِسْمِ اللهِ الرَّحْمنِ الرَّحِيمِ"
        let size = store.fontSize
        return Section {
            Stepper(value: fontBinding, in: 15...40, step: 1) {
                Text("حجم خط الأدعية: \(Int(size).ar)")
            }
            Text(store.tashkeel ? sample : ArabicSearch.stripTashkeel(sample))
                .font(.scripture(CGFloat(size)))
                .lineSpacing(CGFloat(size) * 0.5)
                .frame(maxWidth: .infinity)
                .multilineTextAlignment(.center)
                .padding(.vertical, 6)
        }
    }

    // MARK: Reader preferences

    private var tashkeelBinding: Binding<Bool> { Binding(get: { store.tashkeel }, set: { store.tashkeel = $0 }) }
    private var sepiaBinding: Binding<Bool> { Binding(get: { store.sepia }, set: { store.sepia = $0 }) }
    private var awakeBinding: Binding<Bool> { Binding(get: { store.keepAwake }, set: { store.keepAwake = $0 }) }

    /// Android cycles 1.7 → 2.5; three buckets labelled ١/٢/٣.
    private var spacingBinding: Binding<Double> {
        Binding(get: {
            let v = store.lineSpacing
            if v >= 2.35 { return 2.4 }
            if v >= 2.05 { return 2.1 }
            return 1.7
        }, set: { store.lineSpacing = $0 })
    }

    private var readerSection: some View {
        Section {
            Toggle(isOn: tashkeelBinding) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("التشكيل في النصوص")
                    Text(store.tashkeel ? "ظاهر" : "مخفيّ").font(.caption).foregroundStyle(.secondary)
                }
            }
            Toggle("الشاشة مضاءة", isOn: awakeBinding)
            Toggle("ورقي", isOn: sepiaBinding)
            Picker("تباعد", selection: spacingBinding) {
                Text("١").tag(1.7)
                Text("٢").tag(2.1)
                Text("٣").tag(2.4)
            }
            .pickerStyle(.segmented)
        }
        .tint(Brand.emerald)
    }

    // MARK: Method and location

    private var placeSections: some View {
        Group {
            Section("طريقة حساب المواقيت") {
                NavigationLink {
                    MethodView()
                } label: {
                    Label(PrayerTimes.method(store.method).name, systemImage: "slider.horizontal.3")
                }
            }
            Section("الموقع") {
                NavigationLink {
                    LocationView()
                } label: {
                    Label(store.location().n, systemImage: "mappin.and.ellipse")
                }
            }
        }
    }

    // MARK: Hijri adjustment

    private var adjBinding: Binding<Int> {
        Binding(get: { store.hijriAdj }, set: { v in
            store.hijriAdj = v
            PrayerRoutines.refreshRoutines(store: store)
        })
    }

    private var hijriSection: some View {
        let adj = store.hijriAdj
        let sign = adj > 0 ? "+" : ""
        return Section {
            Stepper(value: adjBinding, in: -2...2) {
                HStack {
                    Text("اليوم")
                    Spacer()
                    Text(Hijri.format(store.hijriToday())).foregroundStyle(.secondary)
                }
            }
        } header: {
            Text("تعديل التقويم الهجري (\(sign)\(adj.ar) يوم)")
        } footer: {
            Text("عدّل التقويم ±يوم أو يومين عند اختلاف رؤية الهلال محلياً.")
        }
    }

    // MARK: About

    private var aboutSection: some View {
        Section("عن التطبيق") {
            NavigationLink {
                AboutView()
            } label: {
                Label("حول التطبيق", systemImage: "info.circle")
            }
            Button {
                store.onboardingDone = false
                dismiss()
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: "sparkles").foregroundStyle(Brand.emerald)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("إعادة مشاهدة الترحيب").foregroundStyle(.primary)
                        Text("اعرض شاشات البداية من جديد").font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
        }
    }
}

// MARK: - Notification toggles

private struct SettingsNotificationsSections: View {
    @Environment(Store.self) private var store

    private func flag(_ key: String, _ def: Bool, _ apply: @escaping (Store) -> Void) -> Binding<Bool> {
        Binding(get: { store.bool(key, def) }, set: { on in
            store.put(key, on)
            if on {
                Task {
                    _ = await Notifier.requestPermission()
                    apply(store)
                }
            } else {
                apply(store)
            }
        })
    }

    private func number(_ key: String, _ def: Int, _ range: ClosedRange<Int>, _ apply: @escaping (Store) -> Void) -> Binding<Int> {
        Binding(get: { store.int(key, def) }, set: { v in
            store.put(key, max(range.lowerBound, min(range.upperBound, v)))
            apply(store)
        })
    }

    private func state(_ on: Bool, feminine: Bool) -> String {
        feminine ? (on ? "مفعّلة" : "متوقّفة") : (on ? "مفعّل" : "متوقّف")
    }

    var body: some View {
        prayerSection
        dhikrSection
        occasionSection
        taqibSection
        laylSection
        sadaqaSection
    }

    private var prayerSection: some View {
        let on = store.bool("notify", false)
        return Section("تنبيهات أوقات الصلاة") {
            Toggle(state(on, feminine: true), isOn: flag("notify", false) { Notifier.schedulePrayers(store: $0) })
        }
        .tint(Brand.emerald)
    }

    private var dhikrSection: some View {
        let on = store.bool("dhikrOn", false)
        let count = store.int("dhikrCount", 5)
        return Section {
            Toggle(state(on, feminine: true), isOn: flag("dhikrOn", false) { PrayerRoutines.refreshDhikr(store: $0) })
            if on {
                Stepper(value: number("dhikrCount", 5, 1...12) { PrayerRoutines.refreshDhikr(store: $0) }, in: 1...12) {
                    Text("عدد التذكيرات يومياً: \(count.ar)")
                }
            }
        } header: {
            Text("تذكير بالأذكار (صلوات / استغفار)")
        } footer: {
            if on {
                Text("تُوزَّع بأوقات عشوائية بين الـ\(PrayerRoutines.startHour.ar) صباحاً والـ\((PrayerRoutines.endHour - 12).ar) مساءً، بذِكرٍ مختلف في كلّ مرّة.")
            }
        }
        .tint(Brand.emerald)
    }

    private var occasionSection: some View {
        let on = store.bool("occasionOn", true)
        return Section("تنبيهات المناسبات (ليالي القدر، الأعياد، المواليد…)") {
            Toggle(isOn: flag("occasionOn", true) { PrayerRoutines.refreshRoutines(store: $0) }) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(state(on, feminine: false))
                    Text("عند المغرب إن كانت الليلة ذات أعمال، وصباح الأيّام الكبرى").font(.caption).foregroundStyle(.secondary)
                }
            }
        }
        .tint(Brand.emerald)
    }

    private var taqibSection: some View {
        let on = store.bool("taqibOn", false)
        return Section {
            Toggle(state(on, feminine: false), isOn: flag("taqibOn", false) { PrayerRoutines.refreshRoutines(store: $0) })
        } header: {
            Text("تذكير التعقيبات بعد كل صلاة")
        } footer: {
            if on {
                Text("تذكير لطيف بعد كل فريضة بدقائق، بتسبيح الزهراء (ع) والتعقيب — مرتبط بمواقيت صلاتك الفعلية.")
            }
        }
        .tint(Brand.emerald)
    }

    private var laylSection: some View {
        let on = store.bool("laylOn", false)
        let before = store.int("laylBefore", 60)
        return Section {
            Toggle(state(on, feminine: false), isOn: flag("laylOn", false) { PrayerRoutines.refreshRoutines(store: $0) })
            if on {
                Stepper(value: number("laylBefore", 60, 15...120) { PrayerRoutines.refreshRoutines(store: $0) }, in: 15...120, step: 15) {
                    Text("قبل الفجر بـ \(before.ar) دقيقة")
                }
            }
        } header: {
            Text("تذكير صلاة الليل قبل الفجر")
        } footer: {
            if on {
                Text("ينبّهك قبيل الفجر لإحياء ليلك بصلاة الليل ولو ركعة الوتر — مرتبط بوقت الفجر الفعلي لموقعك.")
            }
        }
        .tint(Brand.emerald)
    }

    private var sadaqaSection: some View {
        let on = store.bool("sadaqaOn", false)
        let hour = store.int("sadaqaHour", 9)
        return Section {
            Toggle(state(on, feminine: false), isOn: flag("sadaqaOn", false) { PrayerRoutines.refreshSadaqa(store: $0) })
            if on {
                Stepper(value: number("sadaqaHour", 9, 5...22) { PrayerRoutines.refreshSadaqa(store: $0) }, in: 5...22) {
                    Text("الساعة \(hour.ar):٠٠")
                }
            }
        } header: {
            Text("تذكير الصدقة اليومي")
        } footer: {
            if on {
                Text("يذكّرك يومياً بالصدقة ولو يسيرة، مع بيان فضلها. «الصدقة تدفع البلاء وتزيد في الرزق».")
            }
        }
        .tint(Brand.emerald)
    }
}

// MARK: - حول التطبيق (ported from Android ui/Sheets.kt AboutSheet)

struct AboutView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.requestReview) private var requestReview

    private let shareText = "رفيق المؤمن: أدعية وزيارات موثّقة، ومواقيت، وتقويمٌ يذكّرك بأعمال كلّ يوم وليلة. بلا إعلانات ودون اتصال."

    private var versionLine: String {
        let v = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0.0"
        let b = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "?"
        return "نسخة \(v) (بناء \(b)) — يعمل دون اتصال — بياناتك محفوظة على جهازك فقط."
    }

    var body: some View {
        ScreenScroll {
            header
            actions
            VStack(alignment: .leading, spacing: 10) {
                Text("رفيق المؤمن — رفيق المسلم الشيعي اليومي").font(.headline.weight(.heavy))
                Text("تطبيق جامع للصلاة والدعاء والزيارة وفق مذهب أهل البيت (ع): مواقيت الصلاة المحسوبة فلكياً مع تنبيهاتها، التعقيبات المشتركة والمختصة بكل صلاة، أدعية الأيام والمناسبات، الأدعية المشهورة والزيارات، خِيرة القرآن، حاسبة الخُمس، دليل صلاة الليل التفاعلي، اتجاه القبلة، متتبّع حركات الصلاة، التقويم الهجري بمناسباته، التسبيح متعدّد الأذكار، أدعية الحاجات، النصائح التربوية، محاسبة النفس، الأعمال والمستحبّات بحسب التقويم، تتبّع القضاء، أوقات الفضيلة، والوِرد اليومي.")
                    .lineSpacing(5)
                Text("النصوص منتقاة من كتب الأدعية والزيارات المعتبرة المتداولة، وفي مقدّمتها مفاتيح الجنان.")
                    .lineSpacing(5)
            }
            .card()
            Text("مصادر مفتوحة مع الشكر: أحاديث الكافي وتصحيحاتها من بيانات مشروع ثقلين (thaqalayn.net، رخصة CC0)، وصفحات المصحف وأجزاؤه من مشروع تنزيل (tanzil.net، رخصة CC BY 3.0)، ومراجعة مناسبات التقويم بمساعدة تطبيق Shia Companion (رخصة MIT).")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .lineSpacing(4)
                .card()
            Label {
                Text("تنبيه: النصوص بنُسخها المتداولة المعروفة وقد تختلف يسيراً عن الطبعات الورقية؛ يُرجى مراجعة المطبوع عند الحاجة للدقّة. المواقيت وبدايات الأشهر تقريبية فيُحتاط في العبادات.")
                    .font(.footnote)
                    .lineSpacing(4)
            } icon: {
                Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(Brand.gold)
            }
            .foregroundStyle(.secondary)
            .card()
            Text(versionLine)
                .font(.caption)
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity)
                .multilineTextAlignment(.center)
        }
        .navigationTitle("حول التطبيق")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("تم") { dismiss() }
            }
        }
    }

    private var header: some View {
        VStack(spacing: 10) {
            StarShape()
                .stroke(Brand.gold, lineWidth: 2.5)
                .frame(width: 64, height: 64)
                .padding(18)
                .glassCircle()
            Text("رفيق المؤمن").font(.title.weight(.heavy))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 24)
        .hero()
    }

    private var actions: some View {
        HStack(spacing: 10) {
            ShareLink(item: shareText) {
                Label("شارك التطبيق", systemImage: "square.and.arrow.up")
                    .font(.subheadline.weight(.bold))
                    .frame(maxWidth: .infinity)
            }
            .glassButton(prominent: true)
            Button {
                requestReview()
            } label: {
                Label("قيّم التطبيق", systemImage: "star")
                    .font(.subheadline.weight(.bold))
                    .frame(maxWidth: .infinity)
            }
            .glassButton()
        }
        .controlSize(.large)
    }
}
