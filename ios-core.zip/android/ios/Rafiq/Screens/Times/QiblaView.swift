import SwiftUI
import CoreLocation

// MARK: - اتجاه القبلة (ported from Android ui/QiblaScreen.kt)

struct QiblaView: View {
    @Environment(Store.self) private var store
    @State private var service = LocationService()
    @State private var hasCompass = CLLocationManager.headingAvailable()

    private var city: City { store.location() }
    private var bearing: Double { Qibla.bearing(lat: city.lat, lng: city.lng) }
    private var heading: Double { service.heading ?? 0 }
    /// Angle of the Qibla relative to the top of the device, 0..360.
    private var needle: Double {
        let v = (bearing - heading).truncatingRemainder(dividingBy: 360)
        return v < 0 ? v + 360 : v
    }
    private var aligned: Bool { service.heading != nil && (needle < 3 || needle > 357) }

    private var distanceKm: Int {
        let r = Double.pi / 180
        let dLat = (Qibla.kaabaLat - city.lat) * r
        let dLng = (Qibla.kaabaLng - city.lng) * r
        let a = sin(dLat / 2) * sin(dLat / 2) + cos(city.lat * r) * cos(Qibla.kaabaLat * r) * sin(dLng / 2) * sin(dLng / 2)
        return Int((6371.0 * 2 * atan2(sqrt(a), sqrt(1 - a))).rounded())
    }

    var body: some View {
        ZStack {
            QiblaBackground()
            if hasCompass {
                compassContent
            } else {
                noSensor
            }
        }
        .navigationTitle(Tool.qibla.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .keepScreenAwake(true)
        .onAppear { if hasCompass { service.startHeading() } }
        .onDisappear { service.stopHeading() }
        .onChange(of: aligned) { _, isAligned in
            if isAligned { Haptic.confirm() }
        }
    }

    private var noSensor: some View {
        Text("جهازك لا يحتوي مُستشعِر البوصلة اللازم لتحديد القبلة.")
            .font(.body.weight(.semibold))
            .multilineTextAlignment(.center)
            .foregroundStyle(.white)
            .padding(22)
            .glass(22)
            .padding(24)
    }

    private var compassContent: some View {
        ScrollView {
            VStack(spacing: 14) {
                Text("اتجاه القبلة من \(city.n): \(Int(bearing.rounded()).ar)°")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white.opacity(0.85))
                guidance
                QiblaCompass(heading: heading, needle: needle, aligned: aligned)
                    .frame(width: 300, height: 300)
                    .padding(.vertical, 12)
                Text("الكعبة المشرّفة تبعد نحو \(Khums.money(Double(distanceKm))) كم")
                    .font(.footnote.weight(.bold))
                    .foregroundStyle(Brand.gold)
                VStack(spacing: 2) {
                    Text("\(Int(heading.rounded()).ar)°")
                        .font(.counter(40))
                        .foregroundStyle(.white)
                        .contentTransition(.numericText())
                    Text("اتجاه جهازك عن الشمال").font(.caption).foregroundStyle(.white.opacity(0.7))
                }
                .padding(.top, 6)
                Text("أمسك الجهاز مسطّحاً أو قائماً وابتعد عن المعادن والشواحن لدقّةٍ أعلى. إن بدا الاتجاه خاطئاً فعاير البوصلة بتحريك الجهاز على شكل ٨.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.85))
                    .multilineTextAlignment(.center)
                    .padding(14)
                    .frame(maxWidth: .infinity)
                    .glass(18)
                    .padding(.top, 10)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 20)
        }
    }

    @ViewBuilder private var guidance: some View {
        if aligned {
            Label("أنت موجَّه نحو القبلة الآن", systemImage: "checkmark.circle.fill")
                .font(.subheadline.weight(.heavy))
                .foregroundStyle(.white)
                .padding(.horizontal, 16).padding(.vertical, 8)
                .glassCapsule(tint: Brand.good)
        } else if service.heading == nil {
            Text(service.errorText ?? "أدِر جهازك حتى تستقيم الكعبة لأعلى")
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.75))
        } else {
            Text("أدِر جهازك حتى تستقيم الكعبة لأعلى")
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.75))
        }
    }
}

private struct QiblaBackground: View {
    var body: some View {
        ZStack {
            Brand.heroGradient
            StarPattern().foregroundStyle(.white.opacity(0.06))
        }
        .ignoresSafeArea()
    }
}

/// Glass dial that turns against the device heading, with the Kaaba marker and a gold needle.
private struct QiblaCompass: View {
    let heading: Double
    let needle: Double
    let aligned: Bool

    var body: some View {
        GeometryReader { geo in
            let size = min(geo.size.width, geo.size.height)
            let radius = size / 2
            ZStack {
                Circle()
                    .fill(Color.white.opacity(0.001))
                    .glassCircle(tint: aligned ? Brand.good : nil)
                QiblaDial()
                    .foregroundStyle(.white)
                    .rotationEffect(.degrees(-heading))
                QiblaNeedle(color: aligned ? Brand.good : Brand.gold)
                    .rotationEffect(.degrees(needle))
                QiblaKaaba(highlight: aligned ? Brand.good : Brand.gold)
                    .frame(width: 44, height: 44)
                    .offset(x: CGFloat(sin(needle * .pi / 180)) * radius * 0.70,
                            y: -CGFloat(cos(needle * .pi / 180)) * radius * 0.70)
                Circle().fill(Brand.emerald).frame(width: 18, height: 18)
                Circle().fill(Color.white).frame(width: 7, height: 7)
            }
            .frame(width: size, height: size)
            .position(x: geo.size.width / 2, y: geo.size.height / 2)
        }
        // Geometry is absolute (north up); keep it unaffected by the RTL layout.
        .environment(\.layoutDirection, .leftToRight)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(aligned ? "أنت موجَّه نحو القبلة الآن" : "أدِر جهازك حتى تستقيم الكعبة لأعلى")
    }
}

private struct QiblaDial: View {
    var body: some View {
        GeometryReader { geo in
            let s = min(geo.size.width, geo.size.height)
            ZStack {
                Canvas { ctx, size in
                    let r = min(size.width, size.height) / 2 - 2
                    let c = CGPoint(x: size.width / 2, y: size.height / 2)
                    var outer = Path()
                    outer.addEllipse(in: CGRect(x: c.x - r, y: c.y - r, width: 2 * r, height: 2 * r))
                    ctx.stroke(outer, with: .color(Color.white.opacity(0.35)), lineWidth: 1.5)
                    var inner = Path()
                    let ri = r * 0.72
                    inner.addEllipse(in: CGRect(x: c.x - ri, y: c.y - ri, width: 2 * ri, height: 2 * ri))
                    ctx.stroke(inner, with: .color(Color.white.opacity(0.18)), lineWidth: 1)
                    for i in 0..<72 {
                        let a = Double(i) * 5 * .pi / 180
                        let long = i % 6 == 0
                        let rIn = r - (long ? 16 : 8)
                        var p = Path()
                        p.move(to: CGPoint(x: c.x + CGFloat(sin(a)) * rIn, y: c.y - CGFloat(cos(a)) * rIn))
                        p.addLine(to: CGPoint(x: c.x + CGFloat(sin(a)) * r, y: c.y - CGFloat(cos(a)) * r))
                        ctx.stroke(p, with: .color(long ? Brand.gold : Color.white.opacity(0.4)), lineWidth: long ? 2.5 : 1)
                    }
                }
                Text("ش")
                    .font(.caption.weight(.heavy))
                    .foregroundStyle(Brand.gold)
                    .position(x: s / 2, y: 28)
            }
        }
    }
}

private struct QiblaNeedle: View {
    let color: Color

    var body: some View {
        GeometryReader { geo in
            let s = min(geo.size.width, geo.size.height)
            Capsule()
                .fill(LinearGradient(colors: [color, color.opacity(0.35)], startPoint: .top, endPoint: .bottom))
                .frame(width: 6, height: s * 0.24)
                .position(x: geo.size.width / 2, y: geo.size.height / 2 - s * 0.15)
        }
    }
}

/// Kaaba glyph: black cube with a gold kiswa band and door, framed in the highlight colour.
private struct QiblaKaaba: View {
    let highlight: Color

    var body: some View {
        GeometryReader { geo in
            let s = min(geo.size.width, geo.size.height)
            let gold = Color(red: 0xC9 / 255, green: 0xA8 / 255, blue: 0x6A / 255)
            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: s * 0.08)
                    .fill(Color(red: 0.08, green: 0.08, blue: 0.08))
                Rectangle().fill(gold)
                    .frame(width: s, height: s * 0.10)
                    .offset(y: s * 0.26)
                Rectangle().fill(gold)
                    .frame(width: s * 0.16, height: s * 0.36)
                    .offset(x: s * 0.42, y: s * 0.58)
                RoundedRectangle(cornerRadius: s * 0.08)
                    .stroke(highlight, lineWidth: s * 0.06)
            }
            .frame(width: s, height: s)
            .clipShape(RoundedRectangle(cornerRadius: s * 0.08))
            .shadow(color: .black.opacity(0.35), radius: 4, y: 2)
        }
    }
}
