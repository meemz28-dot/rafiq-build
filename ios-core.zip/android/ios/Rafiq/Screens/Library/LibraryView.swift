import SwiftUI

/// الفهرس: the category list with full-library search (port of Android LibraryScreen).
struct LibraryView: View {
    @Environment(Store.self) private var store
    @Environment(AppNav.self) private var nav
    @State private var query = ""
    @State private var hits: [ArabicSearch.Hit] = []

    var body: some View {
        LibraryContent(query: query, hits: hits)
            .navigationTitle("الفهرس")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $query, prompt: "ابحث في الأدعية والزيارات…")
            .task(id: query) {
                let q = query
                if q.trimmingCharacters(in: .whitespaces).isEmpty { hits = []; return }
                try? await Task.sleep(nanoseconds: 180_000_000)
                if Task.isCancelled { return }
                hits = ArabicSearch.search(q)
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { menu }
            }
    }

    private var menu: some View {
        Menu {
            Button { nav.present(.favorites) } label: { Label("المفضلة", systemImage: "star") }
            Button { nav.present(.bookmarks) } label: { Label("العلامات المرجعية", systemImage: "bookmark") }
            Button { nav.present(.settings) } label: { Label("الإعدادات", systemImage: "gearshape") }
        } label: {
            Image(systemName: "ellipsis.circle")
        }
        .accessibilityLabel("المزيد")
    }
}

/// Body of the library; a child of `.searchable` so it can read `isSearching`.
private struct LibraryContent: View {
    let query: String
    let hits: [ArabicSearch.Hit]
    @Environment(\.isSearching) private var isSearching

    private var trimmed: String { query.trimmingCharacters(in: .whitespaces) }

    var body: some View {
        List {
            if trimmed.isEmpty {
                if isSearching { quickSection }
                categoriesSection
            } else {
                resultsSection
            }
        }
        .listStyle(.insetGrouped)
    }

    // "Most requested" picks, shown only while the search field is focused (as on Android).
    private static let quick: [(String, String, String)] = [
        ("كميل", "mashhura", "m-kumayl"),
        ("زيارة عاشوراء", "ziyarat", "z-ashura"),
        ("الندبة", "mashhura", "m-nudba"),
        ("التوسّل", "mashhura", "m-tawassul"),
        ("الجوشن الكبير", "ramadan", "r-jawshan"),
        ("أبو حمزة", "ramadan", "r-abuhamza"),
        ("تسبيح الزهراء", "nawafil", "nf-tasbih-fatima"),
        ("الزيارة الجامعة", "ziyarat", "z-jamia")
    ]

    private var quickSection: some View {
        Section("الأكثر طلباً") {
            ForEach(Array(Self.quick.enumerated()), id: \.offset) { _, q in
                if Library.item(q.1, q.2) != nil {
                    NavigationLink(value: Route.reader(q.1, q.2)) {
                        Label {
                            Text(q.0).font(.body.weight(.semibold))
                        } icon: {
                            Image(systemName: Brand.categorySymbol(q.1)).foregroundStyle(Brand.emerald)
                        }
                    }
                }
            }
        }
    }

    private var categoriesSection: some View {
        Section("تصفّح الأبواب") {
            ForEach(Library.categories) { c in
                NavigationLink(value: Route.category(c.id)) {
                    LibraryCategoryRow(cat: c)
                }
            }
        }
    }

    @ViewBuilder private var resultsSection: some View {
        if hits.isEmpty {
            Section {
                EmptyStateView(symbol: "magnifyingglass", title: "لا توجد نتائج لـ «\(trimmed)»", message: "")
                    .listRowBackground(Color.clear)
            }
        } else {
            Section {
                ForEach(hits) { h in
                    NavigationLink(value: Route.reader(h.cat.id, h.item.id)) {
                        LibrarySearchRow(hit: h)
                    }
                }
            } header: {
                Text("\(hits.count.ar) نتيجة")
            }
        }
    }
}

/// Category row: icon chip, name, description and item count.
private struct LibraryCategoryRow: View {
    let cat: DuaaCategory
    var body: some View {
        HStack(spacing: 12) {
            IconChip(symbol: Brand.categorySymbol(cat.id), colors: Brand.categoryColors(cat.id), size: 46)
            VStack(alignment: .leading, spacing: 2) {
                Text(cat.name).font(.headline).foregroundStyle(.primary).lineLimit(1)
                Text(cat.desc).font(.footnote).foregroundStyle(.secondary).lineLimit(2)
            }
            Spacer(minLength: 6)
            Text(cat.items.count.ar)
                .font(.footnote.weight(.heavy))
                .foregroundStyle(Brand.emerald)
                .padding(.horizontal, 10).padding(.vertical, 4)
                .background(Brand.emerald.opacity(0.10), in: Capsule())
        }
        .padding(.vertical, 4)
    }
}

/// Search result row: title, category and snippet.
private struct LibrarySearchRow: View {
    let hit: ArabicSearch.Hit
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            IconChip(symbol: Brand.categorySymbol(hit.cat.id), colors: Brand.categoryColors(hit.cat.id), size: 36)
            VStack(alignment: .leading, spacing: 3) {
                Text(hit.item.title).font(.body.weight(.semibold)).foregroundStyle(.primary).lineLimit(2)
                Text(hit.cat.name).font(.caption.weight(.bold)).foregroundStyle(Brand.emerald)
                if !hit.snippet.isEmpty {
                    Text(hit.snippet).font(.footnote).foregroundStyle(.secondary).lineLimit(2)
                }
            }
        }
        .padding(.vertical, 2)
    }
}
