import SwiftUI

struct HomeView: View { var body: some View { Text("HomeView") } }
struct OnboardingView: View { var body: some View { Text("OnboardingView") } }
struct LibraryView: View { var body: some View { Text("LibraryView") } }
struct FavoritesView: View { var body: some View { Text("FavoritesView") } }
struct BookmarksView: View { var body: some View { Text("BookmarksView") } }
struct PrayerView: View { var body: some View { Text("PrayerView") } }
struct CalendarView: View { var body: some View { Text("CalendarView") } }
struct ConverterView: View { var body: some View { Text("ConverterView") } }
struct PrayerTableView: View { var body: some View { Text("PrayerTableView") } }
struct QiblaView: View { var body: some View { Text("QiblaView") } }
struct SettingsView: View { var body: some View { Text("SettingsView") } }
struct AboutView: View { var body: some View { Text("AboutView") } }
struct LocationView: View { var body: some View { Text("LocationView") } }
struct MethodView: View { var body: some View { Text("MethodView") } }
struct MoreView: View { var body: some View { Text("MoreView") } }
struct KhiraView: View { var body: some View { Text("KhiraView") } }
struct WeeklyView: View { var body: some View { Text("WeeklyView") } }
struct KhumsView: View { var body: some View { Text("KhumsView") } }
struct TasbihView: View { var body: some View { Text("TasbihView") } }
struct AsmaView: View { var body: some View { Text("AsmaView") } }
struct MasoomeenView: View { var body: some View { Text("MasoomeenView") } }
struct HajjView: View { var body: some View { Text("HajjView") } }
struct AshuraView: View { var body: some View { Text("AshuraView") } }
struct LaylView: View { var body: some View { Text("LaylView") } }
struct AmaalView: View { var body: some View { Text("AmaalView") } }
struct MuhasabaView: View { var body: some View { Text("MuhasabaView") } }
struct JourneyView: View { var body: some View { Text("JourneyView") } }
struct TraitView: View { var body: some View { Text("TraitView") } }
struct QadaView: View { var body: some View { Text("QadaView") } }
struct KhatmaView: View { var body: some View { Text("KhatmaView") } }
struct QuranPointsView: View { var body: some View { Text("QuranPointsView") } }
struct TrackerView: View { var body: some View { Text("TrackerView") } }
struct CategoryView: View { let catId: String; var body: some View { Text(catId) } }
struct ReaderView: View { let catId: String; let itemId: String; var body: some View { Text(itemId) } }
